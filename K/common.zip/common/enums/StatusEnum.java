package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * StatusEnum 状态
 * @date 2024/4/21 14:58
 */
@Getter
public enum StatusEnum {

    ACTIVE(1, "有效"),
    DISABLED(2, "禁用"),
    ;

    StatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
