package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * UpgradeTaskStatusEnum 升级任务状态
 * @date 2024/4/21 14:56
 */
@Getter
public enum UpgradeTaskStatusEnum {

    IN_PROGRESS(0, "进行中"),
    COMPLETED(1, "已完成"),
    TERMINATED(2, "已终止"),
    ;

    UpgradeTaskStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
