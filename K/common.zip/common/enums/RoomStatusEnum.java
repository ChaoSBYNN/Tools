package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: RoomStatusEnum 房间状态
 * @date 2024/4/21 15:05
 */
@Getter
public enum RoomStatusEnum {

    NO_DEVICE(0, "无设备"),
    FOR_RENT(1, "招租中"),
    OCCUPIED(2, "已入住"),
    PAUSED(3, "暂停"),
    ;

    RoomStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
