package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * AlarmTypeEnum 告警类型
 * @date 2024/4/21 13:01
 */
@Getter
public enum AlarmTypeEnum {

    BATTERY(1, "电池"),
    DOOR_LOCK(2, "门锁"),
    ;

    AlarmTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
