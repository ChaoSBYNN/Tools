package com.kaadas.common.enums;

/**
 * @author Spike_Zhang
 * @description:
 * DelPwdTypeEnum TODO
 * @date 2024/4/21 13:28
 */

import lombok.Getter;

@Getter
public enum DelPwdTypeEnum {

    USER(1, "普通用户"),
    ADMIN(2, "管理员"),
    USERS_ADMIN(3, "普通用户和管理员"),
    ;

    DelPwdTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
