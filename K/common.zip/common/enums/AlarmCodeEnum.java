package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * AlarmCodeEnum 告警类型枚举 门锁警报
 * @date 2024/4/21 12:55
 */
@Getter
public enum AlarmCodeEnum {

    LOW_BATTERY(1, "低电量报警"),
    TAMPER(2, "防撬报警"),
    LOCK(3, "锁定报警"),
    JAMMED(4, "堵转告警"),
    ;

    AlarmCodeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
