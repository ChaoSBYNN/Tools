package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WorkTypeEnum 工单类型
 * @date 2024/4/21 14:37
 */
@Getter
public enum WorkTypeEnum {

    INSTALL(1, "安装工单"),
    REPAIR(2, "维修工单"),
    TEAR_DOWN(3, "拆卸工单"),
    REINSTALL(4, "重装工单"),
    ;

    WorkTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
