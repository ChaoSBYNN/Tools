package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * LockConditionEnum 门锁状态
 * @date 2024/4/21 14:29
 */
@Getter
public enum LockConditionEnum {

    UNKNOWN(0, "未知"),
    LOCK(1, "上锁"),
    UNLOCK(2, "开锁"),
    ;

    LockConditionEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
