package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * SourceEnum 来源
 * @date 2024/4/21 14:59
 */
@Getter
public enum SourceEnum {

    PLATFORM(1, "平台"),
    INTERFACE(2, "接口"),
    ;

    SourceEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
