package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: RoomTypeEnum 房间类型
 * @date 2024/4/21 15:04
 */
@Getter
public enum RoomTypeEnum {

    ROOM(1, "房间"),
    PUBLIC_AREA(2, "公区"),
    ;

    RoomTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
