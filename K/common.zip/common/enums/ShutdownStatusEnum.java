package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * ShutdownStatusEnum 设备拉合闸状态
 * @date 2024/4/21 15:00
 */
@Getter
public enum ShutdownStatusEnum {

    OPEN_CIRCUIT(0, "断电"),
    CLOSED_CIRCUIT(1, "通电"),
    ;

    ShutdownStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
