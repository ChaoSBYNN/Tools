package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * SoundVolumeEnum 音量枚举
 * @date 2024/4/21 12:50
 */
@Getter
public enum SoundVolumeEnum {

    MUTE(0, "静音"),
    LOW_VOLUME(1, "低音量"),
    High_Volume(2, "高音量"),
    ;

    SoundVolumeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
