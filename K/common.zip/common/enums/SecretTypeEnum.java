package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: SecretTypeEnum 密钥类型
 * @date 2024/4/21 15:02
 */
@Getter
public enum SecretTypeEnum {

    LIMITED_TIME(1, "限时"),
    PERIODIC(2, "周期性"),
    LIMITED_COUNT(3, "限次"),
    ;

    SecretTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
