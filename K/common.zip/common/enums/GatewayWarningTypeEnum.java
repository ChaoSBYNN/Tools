package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * GatewayWarningTypeEnum 网关预警类型
 * @date 2024/4/21 14:27
 */
@Getter
public enum GatewayWarningTypeEnum {

    PlatformNoDevice(1, "设备平台没有"),
    GatewayNoDevice(2, "设备网关没有"),
    ;

    GatewayWarningTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
