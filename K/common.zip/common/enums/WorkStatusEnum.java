package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WorkStatusEnum 工单状态枚举
 * @date 2024/4/21 14:39
 */
@Getter
public enum WorkStatusEnum {

    PENDING_DISPATCH(1, "待派单"),
    PENDING_ASSIGNMENT(2, "待指派"),
    PENDING_APPOINTMENT(3, "待预约"),
    PENDING_INSTALLATION(4, "待安装"),
    PENDING_VERIFICATION(5, "待核销"),
    COMPLETED(6, "已完结"),
    PENDING_REVIEW(9, "待审核"),
    CLOSED(10, "已关闭"),
    ;

    WorkStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
