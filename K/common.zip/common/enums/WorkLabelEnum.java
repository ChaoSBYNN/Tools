package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WorkLabelEnum TODO
 * @date 2024/4/21 14:50
 */
@Getter
public enum WorkLabelEnum {

    SECOND_VISIT(1, "二次上门"),
    EXCEPTION_FEEDBACK(2, "异常反馈"),
    ;

    WorkLabelEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
