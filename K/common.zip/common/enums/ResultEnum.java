package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: ResultEnum 结果
 * @date 2024/4/21 15:06
 */
@Getter
public enum ResultEnum {

    SUCCESS(0, "成功"),
    FAIL(10, "失败"),
    REPEAT(20, "重复操作"),
    ;

    ResultEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
