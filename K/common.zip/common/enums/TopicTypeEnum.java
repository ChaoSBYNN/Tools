package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * TopicTypeEnum MQTT Topic 类型
 * @date 2024/4/21 14:57
 */
@Getter
public enum TopicTypeEnum {

    SERVICE(1, "服务"),
    EVENT(2, "事件"),
    PROPERTY(3, "属性"),
    ;

    TopicTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
