package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * BelongTypeEnum 所属类型
 * @date 2024/4/21 13:01
 */
@Getter
public enum BelongTypeEnum {

    TEAM(1, "团队"),
    WORKER(2, "师傅"),
    ;

    BelongTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
