package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: OperatingModesEnum 操作模式
 * @date 2024/4/21 15:09
 */
@Getter
public enum OperatingModesEnum {

    NORMAL(1, "正常模式"),
    HOLIDAY(2, "假期模式"),
    LOCKOUT(3, "反锁模式"),
    CONSTANTLY_OPEN(4, "常开模式"),
    ;

    OperatingModesEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
