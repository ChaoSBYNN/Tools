package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WorkUserTypeEnum 工单系统用户类型
 * @date 2024/4/21 14:38
 */
@Getter
public enum WorkUserTypeEnum {

    AFTER_SALE(1, "售后"),
    WORKER(2, "师傅"),
    OPERATOR(3, "运营方"),
    ;

    WorkUserTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
