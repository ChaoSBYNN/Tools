package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * ProtocolEnum 协议类型
 * @date 2024/4/21 13:51
 */
@Getter
public enum ProtocolEnum {

    MQTT(1, "MQTT协议"),
    HTTPS(2, "HTTPS协议"),
    ;

    ProtocolEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
