package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * AlarmStatusEnum 告警状态枚举
 * @date 2024/4/21 12:59
 */
@Getter
public enum AlarmStatusEnum {

    RESOLVED(0, "解除"),
    TRIGGERED(1, "触发"),
    ;

    AlarmStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
