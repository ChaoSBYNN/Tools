package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: SecretStatusEnum 平台密码枚举
 * @date 2024/4/21 15:03
 */
@Getter
public enum SecretStatusEnum {

    NOT_ACTIVATED(0, "未生效"),
    DELETED(1, "已删除"),
    ACTIVE(2, "已生效"),
    FROZEN(3, "已冻结"),
    EXPIRED(4, "已过期"),
    ;

    SecretStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
