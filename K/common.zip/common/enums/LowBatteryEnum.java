package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * LowBatteryEnum 低电量
 * @date 2024/4/21 14:30
 */
@Getter
public enum LowBatteryEnum {

    LOW_TEN(10, "低于10%"),
    LOW_TWENTY(20, "低于20%"),
    ;

    LowBatteryEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
