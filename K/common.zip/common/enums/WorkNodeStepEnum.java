package com.kaadas.common.enums;

import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;

/**
 * @author Spike_Zhang
 * @description:
 * WorkNodeStepEnum 工单步骤节点枚举
 * @date 2024/4/21 14:41
 */
@Getter
public enum WorkNodeStepEnum {

    CREATE_WORK_ORDER(1, "新建工单", Lists.newArrayList(NodeTypeEnum.CREATE_WORK_ORDER)),
    DISPATCH_AFTER_SALES(2, "售后派单", Lists.newArrayList(NodeTypeEnum.DISPATCH_AFTER_SALES)),
    ASSIGN_TECHNICIAN(3, "指派师傅", Lists.newArrayList(NodeTypeEnum.ASSIGN_TECHNICIAN)),
    SCHEDULE_APPOINTMENT(4, "预约上门", Lists.newArrayList(NodeTypeEnum.SCHEDULE_APPOINTMENT)),
    PUNCH_IN(5, "上门打卡", Lists.newArrayList(NodeTypeEnum.PUNCH_IN)),
    INSTALLATION_COMPLETION(6, "安装完工", Lists.newArrayList(NodeTypeEnum.INSTALLATION_COMPLETION)),
    AUDIT_COMPLETED(7, "审核完成", Lists.newArrayList(NodeTypeEnum.APPROVE, NodeTypeEnum.REJECT)),
    ;

    WorkNodeStepEnum(Integer value, String desc, List<NodeTypeEnum> nodeTypeEnums) {
        this.value = value;
        this.desc = desc;
        this.nodeTypeEnums = nodeTypeEnums;
    }

    private final Integer value;

    private final String desc;

    private final List<NodeTypeEnum> nodeTypeEnums;
}
