package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: PwdTypeEnum 密码类型
 * @date 2024/4/21 15:07
 */
@Getter
public enum PwdTypeEnum {

    PASSWORD(1, "密码"),
    CARD(2, "卡片"),
    FINGERPRINT(3, "指纹"),
    ;

    PwdTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
