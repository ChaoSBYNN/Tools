package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * InstructionStatusEnum 指令状态枚举
 * @date 2024/4/21 14:28
 */
@Getter
public enum InstructionStatusEnum {

    ISSUING(1, "下发中"),
    RECEIVED(2, "已接收"),
    EXECUTED_SUCCESSFULLY(3, "执行成功"),
    EXECUTION_FAILED(4, "执行失败"),
    EXECUTED_TIMEOUT(5, "执行超时"),
    ;

    InstructionStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
