package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DevNumEnum TODO
 * @date 2024/4/21 14:13
 */
@Getter
public enum DevNumEnum {

    WIFI_MODULE(1, "WIFI模组"),
    WIFI_LOCK(2, "WIFI锁"),
    FACE(3, "人脸模组"),
    VIDEO(4, "视频模组"),
    MCU(5, "讯美模组MCU"),
    FRONT_PANEL(6, "前板"),
    BACK_PANEL(7, "后板"),
    VOICE_FLASH(8, "语音Flash"),
    DISPLAY_DECODE_BOARD(9, "显示屏解码板"),
    INDUCTIVE_HANDLE(10, "感应把手"),
    DOOR_MAGNET(11, "门磁"),
    REMOTE_CONTROLLER(12, "遥控器"),
    KEYBOARD(13, "键盘"),
    GATEWAY(14, "网关"),
    UVC_CAMERA(15, "UVC摄像头"),
    VEIN(16, "指静脉模组"),
    ULTRASONIC(17, "超声波模组"),
    RADAR(18, "雷达模组"),
    FINGERPRINT(19, "指纹模组"),
    PALM_VEIN(20, "掌静脉模组"),
    FRONT_PANEL_LCD_BLOCK(21, "前板LCD块"),
    TOUCH_CHIP(22, "TOUCH芯片"),
    SERIAL_PORT_EXTENSION(23, "串口扩展模组"),
    MODULE_CODE(24, "模组代号"),
    WE_METER(999, "水电采集器"),
    ;

    DevNumEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
