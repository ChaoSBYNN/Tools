package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * HomeTypeEnum 房源类型
 * @date 2024/4/21 14:27
 */
@Getter
public enum HomeTypeEnum {

    DISPERSED(1, "分散型"),
    CENTRALIZED(2, "集中型"),
    ;

    HomeTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
