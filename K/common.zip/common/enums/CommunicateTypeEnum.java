package com.kaadas.common.enums;

import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;

/**
 * @author Spike_Zhang
 * @description:
 * CommunicateTypeEnum 通讯类型
 * @date 2024/4/21 13:15
 */
@Getter
public enum CommunicateTypeEnum {

    LoRA(1, "LoRA网关", Lists.newArrayList(DeviceTypeEnum.LOCK, DeviceTypeEnum.ENERGY_METER, DeviceTypeEnum.COLD_WATER_METER, DeviceTypeEnum.HOT_WATER_METER)),
    NB(2, "NB_LOT", Lists.newArrayList(DeviceTypeEnum.LOCK, DeviceTypeEnum.ENERGY_METER, DeviceTypeEnum.COLD_WATER_METER, DeviceTypeEnum.HOT_WATER_METER)),
    BLUETOOTH(3, "蓝牙", Lists.newArrayList(DeviceTypeEnum.LOCK)),
    RS485(4, "RS485", Lists.newArrayList(DeviceTypeEnum.ENERGY_METER, DeviceTypeEnum.COLD_WATER_METER, DeviceTypeEnum.HOT_WATER_METER)),
    M_BUS(5, "M-BUS", Lists.newArrayList(DeviceTypeEnum.ENERGY_METER, DeviceTypeEnum.COLD_WATER_METER, DeviceTypeEnum.HOT_WATER_METER)),
    ;

    CommunicateTypeEnum(Integer value, String desc, List<DeviceTypeEnum> deviceTypes) {
        this.value = value;
        this.desc = desc;
        this.deviceTypes = deviceTypes;
    }

    private final Integer value;

    private final String desc;

    private final List<DeviceTypeEnum> deviceTypes;
}
