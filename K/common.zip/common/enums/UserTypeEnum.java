package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * UserTypeEnum 用户类型
 * @date 2024/4/21 14:55
 */
@Getter
public enum UserTypeEnum {

    OPENAPI(1, "OpenAPI"),
    EMPLOYEE(2, "员工"),
    PLATFORM(3, "平台"),
    WORKER(4, "师傅"),
    TENANT(5, "租户"),
    ;

    UserTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
