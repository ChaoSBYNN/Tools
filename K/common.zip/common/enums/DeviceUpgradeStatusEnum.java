package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DeviceUpgradeStatusEnum 设备升级状态
 * @date 2024/4/21 13:44
 */
@Getter
public enum DeviceUpgradeStatusEnum {

    INSTRUCTION_ISSUED(0, "指令下发"),
    INSTRUCTION_FAILED(1, "指令下发失败"),
    FIRMWARE_DOWNLOAD(2, "固件下载"),
    FIRMWARE_DOWNLOAD_FAILED(3, "固件下载失败"),
    UPGRADING(4, "升级中"),
    UPGRADE_COMPLETED(5, "升级完成"),
    ;

    DeviceUpgradeStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
