package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description: SexEnum 性别枚举
 * @date 2024/4/21 15:02
 */
@Getter
public enum SexEnum {

    MALE(1, "男"),
    FEMALE(2, "女"),
    ;

    SexEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
