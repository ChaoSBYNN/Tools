package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WorkerIdentityEnum 師傅身份枚举
 * @date 2024/4/21 14:51
 */
@Getter
public enum WorkerIdentityEnum {

    TEAM_LEADER(1, "团队负责人"),
    ORDINARY_WORKER(2, "普通师傅"),
    ;

    WorkerIdentityEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
