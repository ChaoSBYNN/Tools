package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * FeeTypeEnum 费用类型
 * @date 2024/4/21 14:26
 */
@Getter
public enum FeeTypeEnum {

    STANDARD(10, "标准安装服务"),
    ADDITIONAL(20, "附加费用"),
    DEDUCTION(30, "扣除费用"),
    ;

    FeeTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
