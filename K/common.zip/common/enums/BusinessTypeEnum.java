package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * BusinessTypeEnum 业务类型
 * @date 2024/4/21 13:01
 */
@Getter
public enum BusinessTypeEnum {

    SENSITIVE(0, "敏感信息"),
    ACCOUNT_HANDLING(1, "账号处理"),
    OPERATOR(2, "运营方管理"),
    OPERA_HOUSE(3, "运营方房源管理"),
    TEAM(4, "安维团队管理"),
    ;

    BusinessTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
