package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @description: DeviceStateEnum 联网设备状态
 * @author Spike_Zhang
 * @date 2024/4/21 13:40
 */
@Getter
public enum DeviceStateEnum {

    ONLINE(1, "在线"),
    OFFLINE(2, "离线"),
    ABNORMAL(3, "异常"),
    ;

    DeviceStateEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
