package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * WMAlarmTypeEnum 水表表告警类型
 * @date 2024/4/21 14:20
 */
@Getter
public enum WMAlarmTypeEnum {

    DEVICE_OFFLINE(0, "设备离线"),
    TRANSMISSION_EXCEPTION(1, "传输异常"),
    ABNORMAL_READING_REPORT_ALERT(2, "读数上报异常预警"),
    METER_TAMPERING_ALERT(3, "跳表预警"),
    LOW_BATTERY_WARNING(4, "低电预警"),
    ;

    WMAlarmTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
