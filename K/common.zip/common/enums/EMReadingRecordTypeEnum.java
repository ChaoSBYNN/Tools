package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * EMReadingRecordTypeEnum 电表抄表记录类型
 * @date 2024/4/21 14:22
 */
@Getter
public enum EMReadingRecordTypeEnum {

    AUTO_RECORD(0, "定时上报"),
    SUDDEN_METER_READING(1, "临时抄表"),
    MANUAL_METER_READING(2, "手工抄表"),
    HIS_METER_READING_RECORD(3, "历史读数上报"),
    ;

    EMReadingRecordTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
