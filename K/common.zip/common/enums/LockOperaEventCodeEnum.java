package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * LockOperaEventCodeEnum 锁操作事件Code
 * @date 2024/4/21 14:31
 */
@Getter
public enum LockOperaEventCodeEnum {

    UNKNOWN(0, "未知的"),
    LOCK(1, "上锁"),
    UNLOCK(2, "开锁"),
    ERROR_KEY_OR_ID_LOCK(3, "错误密钥或ID上锁"),
    ERROR_KEY_OR_ID_UNLOCK(4, "错误密钥或ID开锁"),
    INVALID_KEY_OR_ID_UNLOCK(5, "无效的密钥或ID开锁"),
    INVALID_PLAN_UNLOCK(6, "无效的计划开锁"),
    ONE_KEY_LOCK(7, "一键上锁"),
    KEY_LOCK(8, "钥匙上锁"),
    KEY_UNLOCK(9, "钥匙开锁"),
    AUTO_LOCK(10, "自动上锁"),
    PLAN_LOCK(11, "计划上锁"),
    PLAN_UNLOCK(12, "计划开锁"),
    MANUAL_LOCK(13, "手动上锁"),
    MANUAL_UNLOCK(14, "手动开锁"),
    ;

    LockOperaEventCodeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
