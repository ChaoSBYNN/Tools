package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * NetworkModeEnum 联网方式
 * @date 2024/4/21 13:50
 */
@Getter
public enum NetworkModeEnum {

    MODE_4G(1, "4G"),
    MODE_ETHERNET(2, "以太网"),
    ;

    NetworkModeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
