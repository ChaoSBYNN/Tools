package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * AuthRoleTypeEnum 授权角色类型
 * @date 2024/4/21 13:03
 */
@Getter
public enum AuthRoleTypeEnum {

    TENANT(1, "租客"),
    WORKER(2, "安装师傅"),
    EMPLOYEE(3, "员工"),
    ;

    AuthRoleTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
