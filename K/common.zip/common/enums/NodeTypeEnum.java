package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * NodeTypeEnum 工单节点类型
 * @date 2024/4/21 14:42
 */
@Getter
public enum NodeTypeEnum {

    CREATE_WORK_ORDER(10, "新建工单"),
    EDIT_WORK_ORDER(20, "编辑工单"),
    REMARK_WORK_ORDER(30, "备注工单"),
    DISPATCH_AFTER_SALES(40, "售后派单"),
    ASSIGN_TECHNICIAN(50, "指派师傅"),
    SCHEDULE_APPOINTMENT(60, "预约上门"),
    CHANGE_APPOINTMENT(70, "改约"),
    PUNCH_IN(80, "上门打卡"),
    ABNORMAL_FEEDBACK(90, "异常反馈"),
    BIND_DEVICE(100, "绑定设备"),
    UNBIND_DEVICE(110, "解绑设备"),
    INSTALLATION_COMPLETION(120, "安装完工"),
    CANCEL_INSTALLATION(130, "取消安装"),
    APPROVE(140, "审核通过"),
    REJECT(150, "审核不通过"),
    SET_CHANNEL(160, "设置信道"),
    DEVICE_NETWORKING(170, "设备配网"),
    GATEWAY_REBINDING(180, "网关换绑"),
    ;

    NodeTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
