package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DeviceTypeEnum 设备类型
 * @date 2024/4/21 13:11
 */
@Getter
public enum DeviceTypeEnum {

    LOCK_GATEWAY(1, "门锁网关"),
    LOCK(2, "门锁"),
    WE_METER(3, "水电采集器"),
    ENERGY_METER(4, "电表"),
    HOT_WATER_METER(5, "热水表"),
    COLD_WATER_METER(6, "冷水表"),
    ;

    DeviceTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
