package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * EventSourceEnum TODO
 * @date 2024/4/21 14:24
 */
@Getter
public enum EventSourceEnum {

    PASSWORD(1, "密码"),
    WIRELESS(2, "无线"),
    MANUAL(3, "手动"),
    CARD(4, "卡片"),
    FINGERPRINT(5, "指纹"),
    UNDEFINED(255, "无定义"),
    ;

    EventSourceEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
