package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DeviceOperaTypeEnum 设备操作类型
 * @date 2024/4/21 13:29
 */
@Getter
public enum DeviceOperaTypeEnum {

    BIND(1, "绑定设备"),
    UNBIND(2, "解绑设备"),
    REBOOT(3, "重启设备"),
    REMOTE_OPEN_DOOR(4, "远程开门"),
    SET_CHANNEL(5, "设置信道"),
    DEVICE_NETWORKING(6, "设备配网"),
    GATEWAY_REBINDING(7, "网关换绑"),
    REFRESH_LOCK_IS_ALIVE(8, "刷新门锁状态"),
    SUDDEN_METER_READING(9, "临时抄表"),
    ENERGY_SWITCH_OUT(10, "电表拉闸"),
    ENERGY_SWITCH_ON(11, "电表合闸"),
    METER_STATUS(12, "获取设备状态"),
    ;

    DeviceOperaTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
