package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DeviceOperaStatusEnum 设备操作状态
 * @date 2024/4/21 13:37
 */
@Getter
public enum DeviceOperaStatusEnum {

    NORMAL(1, "常态"),
    BINDING(2, "绑定中(换绑操作绑定)"),
    UNBINDING(3, "解绑中(换绑操作解绑)"),
    ;

    DeviceOperaStatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
