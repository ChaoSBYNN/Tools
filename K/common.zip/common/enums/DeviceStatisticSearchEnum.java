package com.kaadas.common.enums;

import lombok.Getter;

/**
 * @author Spike_Zhang
 * @description:
 * DeviceStatisticSearchEnum 门锁警报 查询统计范围
 * @date 2024/4/21 13:42
 */
@Getter
public enum DeviceStatisticSearchEnum {

    THIS_MONTH(1, "本月"),
    NEAR_THREE_MONTH(2, "近三个月"),
    NEAR_HALF_MONTH(3, "近半月"),
    NEAR_ONE_YEAR(4, "近一年"),
    ;

    DeviceStatisticSearchEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private final Integer value;

    private final String desc;
}
