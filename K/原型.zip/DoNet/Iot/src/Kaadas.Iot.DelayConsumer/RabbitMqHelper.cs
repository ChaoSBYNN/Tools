﻿using Flurl.Http;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.OpenApi.DelayConsumer
{
    public class RabbitMqHelper
    {
        private static string VirtualHost;
        private static string HostName;
        private static int Port;
        private static int WebApiPort;
        private static string Username;
        private static string Password;
        public RabbitMqHelper(string hostName, int port, int webApiPort, string username, string password, string virtualHost)
        {
            HostName = hostName;
            Port = port;
            WebApiPort = webApiPort;
            Username = username;
            Password = password;
            VirtualHost = virtualHost;
        }

        /// <summary>
        /// 获取延迟队列列表
        /// </summary>
        /// <returns></returns>
        public async Task<List<(string, string)>> GetDelayQueues(string exchangeName)
        {
            var result = new List<(string, string)>() {};
            var mqUrl = string.Format("http://{0}:{1}", HostName, WebApiPort);
            var url = $"{mqUrl}/api/exchanges/{System.Web.HttpUtility.UrlEncode(VirtualHost)}/{exchangeName}/bindings/source";
            // 获取交换机绑定信息
            var bindingsResponse = await url.WithBasicAuth(Username, Password).GetStringAsync();
            var arr = Newtonsoft.Json.Linq.JArray.Parse(bindingsResponse);
            if (arr.Count() > 0)
            {
                foreach (var item in arr)
                {
                    if (!string.IsNullOrWhiteSpace(item["destination"].ToString()) && !string.IsNullOrWhiteSpace(item["routing_key"].ToString()))
                    {
                        result.Add((item["destination"].ToString(), item["routing_key"].ToString()));
                    }
                }
            }
            return result.Distinct().ToList();
        }
    }
}
