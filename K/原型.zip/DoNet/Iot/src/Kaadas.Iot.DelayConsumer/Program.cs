﻿using CSRedis;
using Flurl.Http;
using Kaadas.Iot.Common;
using Kaadas.Iot.CommonDto.Consts;
using Kaadas.Iot.OpenApi.DelayConsumer;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace Kaadas.Iot.DelayConsumer
{
    public class Program
    {
        private static string virtualHost;
        private static string hostName;
        private static int port;
        private static int webApiPort;
        private static string username;
        private static string password;
        private static List<(string, string)> queues = new List<(string, string)>();
        private static string redisConnection;
        private static string redisDatabase;
        static async Task Main()
        {
            Console.WriteLine($"---------------------------------开始运行！---------------------------------");
            Console.WriteLine("----------------------------------------------------------------------------");
            hostName = ConfigurationManager.AppSettings["Host"];
            port = int.Parse(ConfigurationManager.AppSettings["Port"]);
            webApiPort = int.Parse(ConfigurationManager.AppSettings["WebApiPort"]);
            username = ConfigurationManager.AppSettings["Username"];
            password = ConfigurationManager.AppSettings["Password"];
            virtualHost = ConfigurationManager.AppSettings["VirtualHost"];
            redisConnection = ConfigurationManager.AppSettings["RedisConn"];
            redisDatabase = ConfigurationManager.AppSettings["RedisDatabase"];
            var redisDB = new CSRedisClient(redisConnection + ",defaultDatabase=" + redisDatabase);
            RedisHelper.Initialization(redisDB);
            Console.WriteLine($"-------------------------------Redis连接成功！------------------------------");
            Console.WriteLine("----------------------------------------------------------------------------");
            var factory = new ConnectionFactory() { HostName = hostName, Port = port, UserName = username, Password = password, VirtualHost = virtualHost };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                await Excute(connection, channel);
                Console.ReadLine();
            }

        }


        /// <summary>
        /// 处理队列
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="channel"></param>
        /// <returns></returns>
        public static async Task Excute(IConnection conn, IModel channel)
        {
            Console.WriteLine($"-----------------------------RabbitMq连接成功！-----------------------------");
            Console.WriteLine("----------------------------------------------------------------------------");
            Console.WriteLine($"-----------------------------等待延迟队列进入！-----------------------------");
            Console.WriteLine("----------------------------------------------------------------------------");
            try
            {
                RabbitMqHelper mq = new RabbitMqHelper(hostName, port, webApiPort, username, password, virtualHost);
                //queues = await mq.GetDelayQueues();
                //foreach (var queue in queues)
                //{
                //    ConsumeQueue(conn, channel, queue.Item1, queue.Item2);
                //}
                var timer = new System.Threading.Timer(async state =>
                {
                    var cacheKey = RedisKeyConst.RABBITMQ_DELAY_QUEUES;
                    var redisQueues = RedisHelper.Get<List<string>>(cacheKey) ?? new List<string>();
                    if (redisQueues.Count() != queues.Count() || redisQueues.Count() <= 0)
                    {
                        var currentQueues = await mq.GetDelayQueues(DelayMQConst.OPENAPI_DELAY_EXCHANGE);
                        var newQueues = currentQueues.Except(queues).ToList();

                        if (newQueues.Any())
                        {
                            // 订阅新队列
                            foreach (var newQueue in newQueues)
                            {
                                ConsumeQueue(conn, channel, newQueue.Item1, newQueue.Item2);
                            }

                            // 更新初始队列列表
                            queues.AddRange(newQueues);
                            redisQueues.AddRange(newQueues.Select(x => x.Item1).ToList());
                            RedisHelper.Set(cacheKey, redisQueues);
                        }
                    }
                }, null, TimeSpan.Zero, TimeSpan.FromSeconds(10)); // 定期检查，例如每隔 10 秒
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                LogHelper.WriteWithTime(ex);
            }
        }

        /// <summary>
        /// 队列消费
        /// </summary>
        /// <param name="queueName"></param>
        public static void ConsumeQueue(IConnection conn, IModel channel, string queueName, string routingKey)
        {
            // 定义延迟队列和交换机
            channel.ExchangeDeclare(DelayMQConst.OPENAPI_DELAY_EXCHANGE, "x-delayed-message", arguments: new Dictionary<string, object> { { "x-delayed-type", "direct" } });
            channel.QueueDeclare(queueName, durable: true, exclusive: false, autoDelete: false, arguments: null);
            channel.QueueBind(queueName, DelayMQConst.OPENAPI_DELAY_EXCHANGE, routingKey);
            //消费端每次只拿一条消息，不占用全局信道
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            var consumer = new EventingBasicConsumer(channel);
            // 使用消费者标识符
            var consumerTag = Guid.NewGuid().ToString();
            channel.BasicConsume(queue: queueName, autoAck: false, consumer: consumer, consumerTag: consumerTag);

            Console.WriteLine($"-------------------{queueName}监听中-------------------");
            Console.WriteLine($"------------------------------等待消息进入队列------------------------------");

            // 设置消息的 TTL
            var properties = channel.CreateBasicProperties();
            properties.Expiration = "30000"; // 30秒
            consumer.Received += async (model, ea) =>
            {
                var body = ea.Body.ToArray(); // 修正这一行
                var message = System.Text.Encoding.UTF8.GetString(body);
                try
                {
                    switch (routingKey)
                    {
                        case DelayMQConst.OPENAPI_DELAY_ROUTINGKEY:
                            await ConsumeMsg(message);
                            channel.BasicAck(ea.DeliveryTag, false);
                            break;
                        default:
                            // 其他情况的处理逻辑
                            //channel.BasicNack(ulong.Parse(consumerTag), false, true);
                            break;
                    }

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    LogHelper.WriteWithTime(ex);
                }
            };
        }

        /// <summary>
        /// 消费消息(iot延迟队列)
        /// </summary>
        /// <param name="msg"></param>
        private static async Task ConsumeMsg(string msg)
        {
            Console.WriteLine($"接收到消息：{msg}");
            var dto = JToken.Parse(msg);
            var url = dto["Url"]?.ToString();
            var data = dto["Data"]?.ToString();

            if (!string.IsNullOrWhiteSpace(url))
            {
                try
                {
                    //请求接口，10秒超时
                    var res = await url.WithHeader("Content-Type", "application/json").WithTimeout(TimeSpan.FromSeconds(10)).PostStringAsync(data);
                    Console.WriteLine($"响应时间：{DateTime.Now}");
                    Console.WriteLine(res.GetStringAsync().Result);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    LogHelper.WriteWithTime(ex);
                }
            }
        }
    }
}
