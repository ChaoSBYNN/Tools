﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.WEM
{
    public class ReadingRecordResult
    {
        public string Method { get; set; }
        public ReadingRecordData Data { get; set; }
        public List<ReadingRecordData> Args { get; set; }
    }

    public class ReadingRecordData
    { 
        public string ResponseId { get; set; }
        /// <summary>
        /// 读数
        /// </summary>
        public decimal MeterRead { get; set; }
        /// <summary>
        /// 读数记录时间
        /// </summary>
        public string ReadTime { get; set; }
    }
}
