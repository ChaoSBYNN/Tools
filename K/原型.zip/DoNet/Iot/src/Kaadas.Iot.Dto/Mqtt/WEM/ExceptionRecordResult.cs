﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.WEM
{
    public class ExceptionRecordResult
    {
        public string Method { get; set; }
        public ExceptionRecordData Data { get; set; }
        public List<ExceptionRecordData> Args { get; set; }
    }

    public class ExceptionRecordData
    { 
        public string ResponseId { get; set; }
        /// <summary>
        /// 异常类型
        /// </summary>
        public int AlarmType { get; set; }
        /// <summary>
        /// 异常记录时间
        /// </summary>
        public string RecordTime { get; set; }
    }
}
