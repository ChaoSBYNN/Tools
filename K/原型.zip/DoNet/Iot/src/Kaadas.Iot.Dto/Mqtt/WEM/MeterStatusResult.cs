﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.WEM
{
    public class MeterStatusResult
    {
        public string Method { get; set; }
        public MeterStatusData Data { get; set; }
        public MeterStatusData Args { get; set; }
    }

    public class MeterStatusData
    { 
        public string ResponseId { get; set; }
        /// <summary>
        /// 在线状态
        /// </summary>
        public int OnlineStatus { get; set; }
        /// <summary>
        /// 拉合闸状态
        /// </summary>
        public int EnableStatus { get; set; }
        /// <summary>
        /// 电量
        /// </summary>
        public int? Battery { get; set; }
    }
}
