﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// ACK 响应数据
    /// </summary>
    public class MqttAckReply : MqttBase
    {
        /// <summary>
        /// 返回状态码
        /// </summary>
        public ReqResultEnum Code { get; set; }
    }
}
