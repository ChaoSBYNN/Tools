﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Reply
{
    /// <summary>
    /// 设备绑定响应
    /// </summary>
    public class DeviceBindReply : MqttReplyBase<DeviceBindDto>
    {
    }

    /// <summary>
    /// 设备绑定数据
    /// </summary>
    public class DeviceBindDto : BindResultReply
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 算法密钥 
        /// </summary>
        public string AlgorithmKey { get; set; }
    }
}
