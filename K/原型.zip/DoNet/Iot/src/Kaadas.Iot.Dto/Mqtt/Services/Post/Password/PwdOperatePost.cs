﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post.Password
{
    public class PwdOperatePost
    {
        /// <summary>
        /// 密钥Id（单个门锁内唯一）
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密钥状态
        /// </summary>
        public SecretStatusEnum Status { get; set; }

    }
}
