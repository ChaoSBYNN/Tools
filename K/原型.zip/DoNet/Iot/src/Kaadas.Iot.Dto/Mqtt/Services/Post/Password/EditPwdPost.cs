﻿using Kaadas.Iot.CommonDto.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post.Password
{
    /// <summary>
    /// 密码管理（添加|修改）
    /// </summary>
    public class EditPwdPost
    {
        /// <summary>
        /// 1：添加;2：修改
        /// </summary>
        public int OptCode { get; set; }
        /// <summary>
        /// 密钥Id（单个门锁内唯一）
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密码类型1：普通用户（默认）;2：管理员用户
        /// </summary>
        public int UserType { get; set; } = 1;

        /// <summary>
        /// 密码值的类型的对象，要配PwdType组合判断
        /// </summary>
        public PwdValueParamDto PwdValueParam { get; set; }

        /// <summary>
        /// 有效时间段
        /// </summary>
        public EffectiveParamsDto EffectiveParams { get; set; }

        /// <summary>
        /// 策略规则 仅策略密钥才填充此字段 
        /// </summary>
        public ScheduleArgsDto ScheduleArgs { get; set; }
    }

    /// <summary>
    /// 1.所有密码都可以包含有效时间范围和次数限制；
    /// 2.有效时间范围和有效次数同时设置时两者都有效；
    /// 3.当两个参数都不设置时表示无时间和次数设置；
    /// </summary>
    public class EffectiveParamsDto
    {
        /// <summary>
        /// 有效起始时间，本地时间=UTC+时区
        /// </summary>
        public int? StartTime { get; set; }

        /// <summary>
        /// 有效结束时间，本地时间=UTC+时区
        /// </summary>
        public int? EndTime { get; set; }

        /// <summary>
        /// 有效次数
        /// </summary>
        public int? ValidNum { get; set; }

    }

    /// <summary>
    /// 策略规则 仅策略密钥才填充此字段 
    /// </summary>
    public class ScheduleArgsDto
    {
        /// <summary>
        /// 策略类型1：年月日计划；2：周计划
        /// </summary>
        public int? ScheduleType { get; set; }

        /// <summary>
        /// 日掩码，0~6对应周日 ~周六，周计划包含
        /// </summary>
        public int[] DaysMask { get; set; }

        /// <summary>
        /// 起始小时，周计划策略包含0~23
        /// </summary>
        public int? StartHour { get; set; } = 0;

        /// <summary>
        /// 起始分钟，周计划策略包含0~59
        /// </summary>
        public int? StartMinute { get; set; } = 0;

        /// <summary>
        /// 结束小时，周计划策略包含0~23
        /// </summary>
        public int? EndHour { get; set; } = 23;

        /// <summary>
        /// 结束分钟，周计划策略包含0~59
        /// </summary>
        public int? EndMinute { get; set; } = 59;

        /// <summary>
        /// 起始时间，单位秒，本地时间，年月日计划策略包含
        /// </summary>
        public int? StartTime { get; set; }

        /// <summary>
        /// 结束时间，单位秒，本地时间，年月日计划策略包含
        /// </summary>
        public int? EndTime { get; set; }
    }

    /// <summary>
    /// 密码值的类型的对象，要配PwdType组合判断
    /// </summary>
    public class PwdValueParamDto {
        /// <summary>
        /// 数字密码，取值为：0~9
        /// </summary>
        public string PinCode { get; set; }

        /// <summary>
        /// 指纹模板完整URL地址
        /// </summary>
        public string FingerUrl { get; set; }

        /// <summary>
        /// 卡片ID，十六进制Hex串
        /// </summary>
        public string CardId { get; set; }

        /// <summary>
        /// 指纹本地录入的激活码，取值为：0~9
        /// 平台业务场景：远程授权指纹下发
        /// </summary>
        public string FingerActiveCode { get; set; }
    }
}
