﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    public class WakeUpDevicePost
    {
        /// <summary>
        /// ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 唤醒操作
        /// </summary>
        public int Ping { get; set; }
    }
}
