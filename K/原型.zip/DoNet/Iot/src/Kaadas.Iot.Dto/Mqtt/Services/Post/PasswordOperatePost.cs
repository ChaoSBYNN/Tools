﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 
    /// </summary>
    public class PasswordOperatePost
    {
        /// <summary>
        /// 密码Id
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码操作
        /// </summary>
        public PasswordOperateEnum Status { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

    }
}
