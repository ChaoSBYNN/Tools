﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 水电表绑定推送
    /// </summary>
    public class WEBindPost
    {
        /// <summary>
        /// 水表/电表ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 水表/电表密码
        /// </summary>
        public string Pwd { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }
    } 
}
