﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 门锁绑定
    /// </summary>
    public class LockBindPost
    {
        /// <summary>
        /// 门锁ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 门锁设备密码
        /// </summary>
        public string Pwd { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }
    }
}
