﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 远程开锁
    /// </summary>
    public class RemoteDoorOpenPost
    {
        /// <summary>
        /// 是否反锁状态强制开门
        /// </summary>
        public int ForceUnlock { get; set; }
    }
}
