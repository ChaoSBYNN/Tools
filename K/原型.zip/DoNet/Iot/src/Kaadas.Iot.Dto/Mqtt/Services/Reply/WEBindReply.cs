﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Services.Reply
{
    /// <summary>
    /// 水表/电表绑定结果响应
    /// </summary>
    public class WEBindReply : MqttReplyBase<WEMBindDto>
    {

    }

    /// <summary>
    /// 水表/电表绑定结果数据
    /// </summary>
    public class WEMBindDto : ReplyDtoBase
    {
        /// <summary>
        /// 水表/电表 绑定结果集合
        /// </summary>

        public List<WEMBindResult> BindResults { get; set; }
    }

    /// <summary>
    /// 水表/电表绑定结果
    /// </summary>
    public class WEMBindResult : BindResultReply
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }
    }

}
