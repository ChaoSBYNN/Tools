﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Reply
{
    public class OTAUpgradesReply : MqttReplyBase<BindResultReply>
    {
    }
}
