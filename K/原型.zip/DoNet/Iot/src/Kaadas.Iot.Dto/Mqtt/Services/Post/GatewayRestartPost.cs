﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 网关重启POST
    /// </summary>
    public class GatewayRestartPost
    {
        /// <summary>
        /// 网关ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 操作类型
        /// </summary>
        public int Op { get; set; } = 1;

        /// <summary>
        /// 重启时间 - 时间戳
        /// </summary>
        public int ExecuteTime { get; set; } = 0;
    }
}
