﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Services.Reply
{
    /// <summary>
    /// 绑定返回数据
    /// </summary>
    public class BindResultReply : ReplyDtoBase
    {
        /// <summary>
        /// 结果
        /// </summary>
        public ResultEnum Result { get; set; }
    }
}
