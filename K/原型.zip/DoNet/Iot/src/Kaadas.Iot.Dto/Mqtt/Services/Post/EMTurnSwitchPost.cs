﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    public class EMTurnSwitchPost
    {
        /// <summary>
        /// 0=拉闸；1=合闸
        /// </summary>
        public int ElecSwitchType { get; set; }
    }
}
