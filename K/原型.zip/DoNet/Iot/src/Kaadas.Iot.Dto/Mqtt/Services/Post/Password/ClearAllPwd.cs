﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post.Password
{
    public class ClearAllPwd
    {
        /// <summary>
        /// 删除密码类型 1：普通用户（默认）2：管理员用户3：普通用户+管理员用户
        /// </summary>
        public DelPwdTypeEnum DelPwdType { get; set; }
    }
}
