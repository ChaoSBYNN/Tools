﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 网关 拓扑 关系上报请求
    /// </summary>
    public class GatewayTopoPost : MqttPostBase<UnbindDto>
    {

    }

    /// <summary>
    /// 网关拓扑关系
    /// </summary>
    public class UnbindDto
    {
        /// <summary>
        /// 设备类型 
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }
    }  
}
