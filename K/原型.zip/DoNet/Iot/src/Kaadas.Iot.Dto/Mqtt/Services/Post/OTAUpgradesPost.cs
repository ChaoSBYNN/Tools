﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// OTA请求
    /// </summary>
    public class OTAUpgradesPost
    {
        /// <summary>
        /// 文件路径
        /// </summary>
        public string FileUrl { get; set; }
        /// <summary>
        /// 文件MD5值
        /// </summary>
        public string FileMD5 { get; set; }
        /// <summary>
        /// 固件版本号
        /// </summary>
        public string SoftwareVer { get; set; }
        /// <summary>
        /// 文件大小
        /// </summary>
        public int FileLength { get; set; }
        /// <summary>
        /// ESN
        /// </summary>
        public string ESN { get; set; }
        /// <summary>
        /// 设备的子模块的编码
        /// </summary>
        public int DevNum { get; set; }
        /// <summary>
        /// 硬件版本
        /// </summary>
        public string HardwareVer { get; set; }
    }

    public class ReplyOTAUpgrades
    {
        public OTAUpgradesPost Args { get; set; }
    }
}
