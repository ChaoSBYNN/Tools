﻿namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 网关绑定
    /// </summary>
    public class GatewayBindPost
    {
        /// <summary>
        /// 信道
        /// </summary>
        public int Channel { get; set; }
    }
}
