﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    public class LocalAddPassworkPost
    {
        /// <summary>
        /// 密钥Id（单个门锁内唯一）
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 授权指令
        /// </summary>
        public string AuthSecretKey { get; set; }

        /// <summary>
        /// 密钥类型
        /// </summary>
        public SecretTypeEnum SecretAuthType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public string LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public string LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }

        /// <summary>
        /// 密钥状态
        /// </summary>
        public SecretStatusEnum Status { get; set; }
    }
}
