﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
   public class LockIsAlivePost
    {
        public int Ping { get; set; } = 1;
    }
}
