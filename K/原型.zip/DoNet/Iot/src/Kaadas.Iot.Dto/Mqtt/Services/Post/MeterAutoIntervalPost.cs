﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    public class MeterAutoIntervalPost
    {
        /// <summary>
        /// 起始时间
        /// </summary>
        public int StartTime { get; set; }

        /// <summary>
        /// 时间间隔
        /// </summary>
        public int Interval { get; set; }

        /// <summary>
        /// 时间间隔类型
        /// </summary>
        public int TimeType { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public int DeviceType { get; set; }
    }
}
