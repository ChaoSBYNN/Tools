﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
   public class GetMeterStatusPost
    {
        public string ESN { get; set; }
    }
}
