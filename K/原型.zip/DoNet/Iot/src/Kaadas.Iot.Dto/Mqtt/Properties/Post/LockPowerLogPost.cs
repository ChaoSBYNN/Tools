﻿using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Properties.Post
{
    public class LockPowerLogPost : MqttPostBase<List<LockPowerLogDto>>
    {
    }

    public class LockPowerLogDto
    {
        /// <summary>
        /// 电池1电量，取值0~100对应0~100%
        /// </summary>
        public int BatteryLevel { get; set; }

        /// <summary>
        /// 电池1电压，单位mV
        /// </summary>
        public int? BatteryVoltage { get; set; }

        /// <summary>
        /// 获取时间(秒)
        /// </summary>
        public string RecordTime { get; set; }
    }
}
