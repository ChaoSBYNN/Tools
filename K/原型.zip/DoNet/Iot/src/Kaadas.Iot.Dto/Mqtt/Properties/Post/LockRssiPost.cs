﻿namespace Kaadas.Iot.Dto.Mqtt.Properties.Post
{
    public class LockRssiPost : MqttPostBase<LockRssiDto>
    {
    }
    public class LockRssiDto
    {
        /// <summary>
        /// 信号强度
        /// </summary>
        public int Rssi { get; set; }

        /// <summary>
        /// 刷新信号强度时间
        /// </summary>
        public int RefreshTime { get; set; }
    }
}
