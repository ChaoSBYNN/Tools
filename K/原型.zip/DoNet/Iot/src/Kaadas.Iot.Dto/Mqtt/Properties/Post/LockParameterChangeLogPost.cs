﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Properties.Post
{
   public class LockParameterchangeLogPost : MqttPostBase<List<LockParameterchangeLogDto>>
    {
    }

    public class LockParameterchangeLogDto
    {
        /// <summary>
        /// 门锁型号，使用研发型号
        /// </summary>
        public string LockModel { get; set; }

        /// <summary>
        ///语言ISO639-1（中文：zh；英文：en）
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// 门锁音量0：静音；1：低音量；2：高音量
        /// </summary>
        public SoundVolumeEnum? SoundVolume { get; set; }

        /// <summary>
        /// 1：正常模式（默认）；2：假期模式（预留）；3：隐私/反锁模式；4：通道/常开模式（预留）
        /// </summary>
        public OperatingModesEnum? OperatingModes { get; set; }

        /// <summary>
        /// 0：未知；1：上锁：2：开锁
        /// </summary>
        public LockConditionEnum? LockState { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary>
        public string RecordTime { get; set; }

        /// <summary>
        /// 固件版本
        /// </summary>
        public List<Versions> Versions { get; set; }
    }
}
