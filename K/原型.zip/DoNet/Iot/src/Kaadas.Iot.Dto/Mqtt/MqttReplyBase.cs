﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// MQTT响应
    /// </summary>
    public class MqttReplyBase<T> : MqttTranBase
    {
        /// <summary>
        /// 返回状态码
        /// </summary>
        public ReqResultEnum Code { get; set; }

        /// <summary>
        /// 响应数据
        /// </summary>
        public virtual T Data { get; set; }
    }
}
