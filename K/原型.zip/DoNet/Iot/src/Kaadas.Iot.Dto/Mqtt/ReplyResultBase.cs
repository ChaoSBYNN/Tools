﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// 响应结果基类
    /// </summary>
    public class ReplyResultBase : ReplyDtoBase
    {
        /// <summary>
        /// 结果
        /// </summary>
        public ResultEnum Result { get; set; }
    }
}
