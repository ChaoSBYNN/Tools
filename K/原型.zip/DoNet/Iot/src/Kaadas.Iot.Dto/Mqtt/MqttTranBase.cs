﻿namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// MQTT消息传递基类
    /// </summary>
    public class MqttTranBase : MqttBase
    {
        /// <summary>
        /// 协议版本号
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// 请求方法，定义好的数据字典
        /// </summary>
        public string Method { get; set; }
    }
}
