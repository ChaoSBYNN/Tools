﻿namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// Reply 基类
    /// </summary>
    public class MqttBase
    {
        /// <summary>
        /// 消息id  毫秒级时间戳 + 6位顺序号
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 通讯请求时间戳(秒)
        /// </summary>
        public string Timestamp { get; set; }

        /// <summary>
        /// 信息
        /// </summary>
        public string Msg { get; set; }
    }
}
