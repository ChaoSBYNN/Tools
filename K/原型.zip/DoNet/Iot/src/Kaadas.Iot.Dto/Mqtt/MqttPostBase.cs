﻿namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// MQTT 消息基类
    /// </summary>
    public class MqttPostBase<T> : MqttTranBase
    {
        /// <summary>
        /// 业务具体参数对象，详细内容查看设备功能接口说明
        /// </summary>
        public virtual T Args { get; set; }
    }
}