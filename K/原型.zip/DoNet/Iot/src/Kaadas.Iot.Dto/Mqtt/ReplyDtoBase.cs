﻿namespace Kaadas.Iot.Dto.Mqtt
{
    /// <summary>
    /// 指令响应业务基类
    /// </summary>
    public class ReplyDtoBase
    {
        /// <summary>
        /// 响应指令MsgId
        /// </summary>
        public string ResponseId { get; set; }
    }
}
