﻿using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    public class LockWirelessLogPost : MqttPostBase<List<LockWirelessLogDto>>
    {

    }

    public class LockWirelessLogDto
    {
        /// <summary>
        /// 接收信号强度，单位dBm
        /// </summary>
        public int RxRSSI { get; set; }

        /// <summary>
        /// 发送信号强度
        /// </summary>
        public int? TxRSSI { get; set; }

        /// <summary>
        /// 刷新信号强度时间(秒)
        /// </summary>
        public string RecordTime { get; set; }
    }
}
