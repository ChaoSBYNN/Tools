﻿
using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    /// <summary>
    /// 网关预警通知
    /// </summary>
    public class GatewayWarningPost
    {
        /// <summary>
        /// 预警类型
        /// </summary>
        public GwWarningTypeEnum Type { get; set; }

        /// <summary>
        /// 预警设备ESN
        /// </summary>
        public string ESN { get; set; }
    }
}
