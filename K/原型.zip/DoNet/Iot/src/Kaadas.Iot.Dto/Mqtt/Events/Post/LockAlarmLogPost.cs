﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    public class LockAlarmLogPost : MqttPostBase<List<LockAlarmLogDto>>
    {
    }

    public class LockAlarmLogDto
    {
        /// <summary>
        /// 告警类型(1=电池,2=门锁)
        /// </summary>
        public AlarmTypeEnum AlarmType { get; set; }

        /// <summary>
        /// 告警编码
        /// </summary>
        public AlarmCodeEnum AlarmCode { get; set; }

        /// <summary>
        /// 产生告警的时间(精确到秒)
        /// </summary>
        public string RecordTime { get; set; }

        /// <summary>
        /// 告警状态(0:解除(暂不支持),1=触发)
        /// </summary>
        public AlarmStatusEnum AlarmStatus { get; set; }
    }
}
