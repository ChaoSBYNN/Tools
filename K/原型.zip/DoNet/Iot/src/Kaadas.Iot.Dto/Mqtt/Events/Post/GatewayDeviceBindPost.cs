﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    /// <summary>
    /// 网关设备绑定 post
    /// </summary>
    public class GatewayDeviceBindPost : MqttPostBase<List<DevinceBindResult>>
    {
    }

    /// <summary>
    /// 设备绑定结果
    /// </summary>
    public class DevinceBindResult
    {
        /// <summary>
        /// 设备esn
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 结果
        /// </summary>
        public ResultEnum Result { get; set; }

        /// <summary>
        /// 信息
        /// </summary>
        public string Msg { get; set; }
    }
}
