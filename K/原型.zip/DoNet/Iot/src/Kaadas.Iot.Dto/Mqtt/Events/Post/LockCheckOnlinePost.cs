﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    /// <summary>
    /// 设备在线状态上报数据
    /// </summary>
    public class LockCheckOnlinePost : MqttPostBase<LockCheckOnlineDto>
    {
    }

    /// <summary>
    /// 
    /// </summary>
    public class LockCheckOnlineDto
    {
        /// <summary>
        /// 是否在线 0=离线；1=在线
        /// </summary>
        public int OnlineStatus { get; set; }
    }
}
