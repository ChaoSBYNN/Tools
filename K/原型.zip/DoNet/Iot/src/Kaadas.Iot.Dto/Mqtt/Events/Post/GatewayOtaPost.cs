﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Mqtt.Events.Post
{
    public class GatewayOtaPost : MqttPostBase<GatewayOtaPostDto>
    {
    }

    public class GatewayOtaPostDto
    {
        /// <summary>
        /// ESN
        /// </summary>
        public string ESN { get; set; }
        /// <summary>
        /// 模块编码
        /// </summary>
        public int DevNum { get; set; }
        /// <summary>
        /// 固件版本
        /// </summary>
        public string SoftwareVer { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int Status { get; set; }
    }
}
