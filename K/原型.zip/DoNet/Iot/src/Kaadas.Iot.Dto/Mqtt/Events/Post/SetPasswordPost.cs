﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Mqtt;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Dto.LockEvent
{
    /// <summary>
    /// 电子密钥上报
    /// </summary>
    public class SetPasswordPost : MqttPostBase<List<SetPasswordDto>>
    {

    }

    public class SetPasswordDto
    {
        /// <summary>
        /// 密码id
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型(1=纯密码；2=卡片；3=指纹)
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary>
        public string RecordTime { get; set; }

        /// <summary>
        /// 操作类型(1=新增；2=修改；3=删除；4=冻结；5=解冻;6=失效)
        /// </summary>
        public PwdOperTypeEnum OperType { get; set; }
    }
}
