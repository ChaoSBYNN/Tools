﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Mqtt.Services.Post
{
    /// <summary>
    /// 门锁开门记录上报
    /// </summary>
    public class SwtichLockLogPost : MqttPostBase<List<OpenLockLogDto>>
    {
    }

    public class OpenLockLogDto
    {
        /// <summary>
        /// 事件源(1=密码；2=无线；3=手动；4=卡片；5=指纹；255=无定义)
        /// </summary>
        public EventSourceEnum EventSource { get; set; }

        /// <summary>
        /// 门锁操作事件代码
        /// </summary>
        public LockOperEventCodeEnum EventCode { get; set; }

        /// <summary>
        /// 事件发生时间
        /// </summary>
        public string RecordTime { get; set; }

        /// <summary>
        /// 密码id
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 事件补充说明
        /// </summary>
        public string EventMsg { get; set; }
    }
}
