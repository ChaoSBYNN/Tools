﻿namespace Kaadas.Iot.Dto.Dto.Worker
{
    /// <summary>
    /// 团队和师傅服务区域
    /// </summary>
    public class ServiceAreaDto
    {
        /// <summary>
        /// 省编号
        /// </summary>
        public string ProviceNo { get; set; }

        /// <summary>
        /// 省名称
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// 城市编号
        /// </summary>
        public string CityNo { get; set; }

        /// <summary>
        /// 城市名称
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 区域编号
        /// </summary>
        public string RegionNo { get; set; }

        /// <summary>
        /// 区域名称
        /// </summary>
        public string RegionName { get; set; }
    }
}
