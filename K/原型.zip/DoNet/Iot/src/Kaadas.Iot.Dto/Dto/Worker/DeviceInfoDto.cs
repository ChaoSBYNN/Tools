﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Dto.Worker
{
    /// <summary>
    /// 设备信息 
    /// </summary>
    public class DeviceInfoDto
    {
        /// <summary>
        /// 联网编号 - 获取网关绑定设备需要使用此字段
        /// </summary>
        public string NetNo { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备型号
        /// </summary>
        public string DeviceName { get; set; }  

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 房间名称
        /// </summary>
        public string RoomName { get; set; }

        /// <summary>
        /// 安装备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 信道 
        /// </summary>
        public int? Channel { get; set; } 

        /// <summary>
        /// 状态
        /// </summary>
        public DeviceStateEnum? State { get; set; }

        /// <summary>
        /// 信号强度
        /// </summary>
        public int? TxRSSI { get; set; }

        /// <summary>
        /// 信号强度
        /// </summary>
        public int? RxRSSI { get; set; }
    }
}
