﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Dto.Worker
{
    /// <summary>
    /// 师傅信息
    /// </summary>
    public class WorkerInfoDto
    {
        /// <summary>
        /// 师傅名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 师傅手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 身份证号
        /// </summary>
        public string IDCardNo { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public SexEnum Sex { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 师傅技能
        /// </summary>
        public List<string> WorkerTechs { get; set; }
    }
}
