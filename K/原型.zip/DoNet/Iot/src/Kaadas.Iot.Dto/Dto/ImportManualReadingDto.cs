﻿using Kaadas.Iot.CommonDto.Enums;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class ImportManualReadingReq
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        public IFormFile File { get; set; }
    }

    public class ImportManualReadingRes
    {
        /// <summary>
        /// 导入总条数
        /// </summary>
        public int ImportTotal { get; set; }
        /// <summary>
        /// 成功条数
        /// </summary>
        public int SuccessCount { get; set; }
        /// <summary>
        /// 失败条数
        /// </summary>
        public int FailCount { get; set; }

        public List<ImportManualReadingData> Data { get; set; }
    }
    public class ImportManualReadingData
    {
        public string SN { get; set; }
        /// <summary>
        /// 房间号
        /// </summary>
        public string RoomName { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }
        /// <summary>
        /// 设备类型（描述）
        /// </summary>
        public string DeviceTypeName { get; set; }
        /// <summary>
        /// 抄表时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 抄表数值
        /// </summary>
        public decimal? Reading { get; set; }

        /// <summary>
        /// 导入时间
        /// </summary>
        public DateTime? ImportTime { get; set; }
    }
}
