﻿using Kaadas.Iot.CommonDto.Enums;
using MediatR;
using System;

namespace Kaadas.Iot.Dto.Listener
{
    /// <summary>
    /// 工单节点监听
    /// </summary>
    public class WorkNodeListener : INotification
    {
        /// <summary>
        /// 节点操作类型
        /// </summary>
        public NodeTypeEnum NodeType { get; set; }

        /// <summary>
        /// 操作人编号
        /// </summary>
        public string OpNo { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary>
        public DateTime OpTime { get; set; }

        /// <summary>
        /// 工单信息
        /// </summary>
        public string WorkNo { get; set; }
    }
}

