﻿using MediatR;

namespace Kaadas.Iot.Dto.Dto.Listener
{
    /// <summary>
    /// 消息推送监听
    /// </summary>
    public class MqttPublishListener : IRequest
    {
        /// <summary>
        /// 主题
        /// </summary>
        public string Topic { get; set; }

        /// <summary>
        /// 推送内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 推送级别
        /// </summary>
        public int Level { get; set; }
    }
}
