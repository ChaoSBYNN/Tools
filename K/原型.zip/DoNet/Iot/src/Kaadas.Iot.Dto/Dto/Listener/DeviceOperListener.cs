﻿using Kaadas.Iot.CommonDto.Enums;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.Listener
{
    /// <summary>
    /// 设备操作监听
    /// </summary>
    public class DeviceOperListener : IRequest
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 操作类型
        /// </summary>
        public DeviceOperTypeEnum Type { get; set; }

        /// <summary>
        /// Args
        /// </summary>
        public object Args { get; set; }

        /// <summary>
        /// 备注 
        /// </summary>
        public string Remark { get; set; }
    }
}
