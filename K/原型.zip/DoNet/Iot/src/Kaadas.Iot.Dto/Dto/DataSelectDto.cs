﻿namespace Kaadas.Iot.Dto.Dto
{
    /// <summary>
    /// 下拉数据-带对象
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DataSelectDto<T> : SelectItemDto
    {
        /// <summary>
        /// 数据
        /// </summary>
        public T Data { get; set; }
    }
}
