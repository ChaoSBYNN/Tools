﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class GetManualReadingDetailPageReq : PageReq
    {
        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }
        public string SN { get; set; }
        public string RecordNo { get; set; }
    }

    public class GetManualReadingDetailPageRes
    {
        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }
        public string SN { get; set; }
        /// <summary>
        /// 房间号
        /// </summary>
        public string RoomName { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }
        /// <summary>
        /// 设备类型（描述）
        /// </summary>
        public string DeviceTypeName { get; set; }
        /// <summary>
        /// 抄表时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 抄表数值
        /// </summary>
        public decimal? Reading { get; set; }

        /// <summary>
        /// 导入时间
        /// </summary>
        public DateTime ImportTime { get; set; }
    }
}
