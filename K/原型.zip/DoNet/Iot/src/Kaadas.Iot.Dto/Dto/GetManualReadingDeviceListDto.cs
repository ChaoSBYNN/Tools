﻿using Kaadas.Iot.CommonDto.Enums;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class GetManualReadingDeviceListReq
    {
        /// <summary>
        /// 运营方
        /// </summary>
        public string OperatorNo { get; set; }
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }
        /// <summary>
        /// 设备类型
        /// </summary>
        public List<int> DeviceTypes { get; set; }
    }
    public class GetManualReadingDeviceListRes
    {
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }
        /// <summary>
        /// 房间号
        /// </summary>
        public string RoomName { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }
        /// <summary>
        /// SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 设备类型
        /// </summary>
        public string DeviceTypeName { get; set; }

        public DeviceTypeEnum DeviceType { get; set; }
        /// <summary>
        /// 运营方
        /// </summary>
        public string OperatorNo { get; set; }
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }
    }
}
