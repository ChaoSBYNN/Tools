﻿using Kaadas.Iot.CommonDto.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OperHouse
{
    public class OperHouseSearchReq
    {
        public int? PageSize { get; set; } = 10;
        public int? PageIndex { get; set; } = 1;
    }
    public class OperHouseSearchRes
    {
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }

        /// <summary>
        /// 房源类型
        /// </summary>
        public int? HouseType { get; set; }

        /// <summary>
        /// 省份
        /// </summary>
        public string Province { get; set; }

        /// <summary>
        /// 城市
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// 区域
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 房间信息
        /// </summary>

        public List<RoomInfo> RoomList { get; set; } = new List<RoomInfo>();
        /// <summary>
        /// 设备信息
        /// </summary>
        public List<DeviceInfo> DeviceList { get; set; } = new List<DeviceInfo>();
    }

    public class RoomInfo
    {
        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 房间名称
        /// </summary>
        public string RoomName { get; set; }

        /// <summary>
        /// 房间类型
        /// </summary>
        public RoomTypeEnum? RoomType { get; set; }

        /// <summary>
        /// 楼层号
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? FloorNum { get; set; }

        /// <summary>
        /// 房间状态
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public RoomStatusEnum? RoomStatus { get; set; }
    }

    public class DeviceInfo
    {
        /// <summary>
        /// SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string RoomNo { get; set; }
    }
}
