﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OperHouse
{
    public class OpenApiEditHouseReq
    {
        /// <summary>
        /// 房源编号
        /// </summary>
        [Required(ErrorMessage = "房源编号不能为空！")]
        public string HouseNo { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        [Required(ErrorMessage = "房源名称不能为空！")]
        [MaxLength(50,ErrorMessage ="房源名称超长，最大长度为50！")]
        public string HouseName { get; set; }
        /// <summary>
        /// 省
        /// </summary>
        [Required(ErrorMessage = "省不能为空！")]
        public string Province { get; set; }
        /// <summary>
        /// 市
        /// </summary>
        [Required(ErrorMessage = "市不能为空！")]
        public string City { get; set; }
        /// <summary>
        /// 区
        /// </summary>
        [Required(ErrorMessage = "区不能为空！")]
        public string Region { get; set; }
        /// <summary>
        /// 房源地址
        /// </summary>
        [Required(ErrorMessage = "房源地址不能为空！")]
        [MaxLength(200,ErrorMessage ="房源地址超长，最大长度为200！")]
        public string Address { get; set; }
    }
}
