﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OperHouse
{
    public class OperHouseGetDeviceRes
    {
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }
        /// <summary>
        /// 设备信息
        /// </summary>
        public List<DeviceInfo> DeviceList { get; set; } = new List<DeviceInfo>();
    }
}
