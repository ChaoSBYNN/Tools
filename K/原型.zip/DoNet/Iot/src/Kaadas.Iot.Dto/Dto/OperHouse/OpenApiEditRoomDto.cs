﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OperHouse
{
    public class OpenApiEditRoomReq
    {
        /// <summary>
        /// 房间编号
        /// </summary>
        [Required(ErrorMessage = "房间编号不能为空！")]
        public string RoomNo { get; set; }
        /// <summary>
        /// 房间名称
        /// </summary>
        [Required(ErrorMessage = "房间名称不能为空！")]
        [MaxLength(50,ErrorMessage ="房间名称超长，最大长度为50！")]
        public string RoomName { get; set; }
        /// <summary>
        /// 房间状态
        /// </summary>
        [Required(ErrorMessage = "房间状态不能为空！")]
        [EnumValidation]
        public RoomStatusEnum? RoomStatus { get; set; }
    }
}
