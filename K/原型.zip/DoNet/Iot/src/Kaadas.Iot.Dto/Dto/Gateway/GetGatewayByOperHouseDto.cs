﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.Gateway
{
    public class GetGatewayByOperHouseRes
    {
        /// <summary>
        /// SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 绑定时间
        /// </summary>
        public long BindTime { get; set; }
        /// <summary>
        /// 在线状态
        /// </summary>
        public int OnlineStatus { get; set; }
        /// <summary>
        /// 固件版本
        /// </summary>
        public string SoftwareVer { get; set; }
        /// <summary>
        /// 硬件版本
        /// </summary>
        public string HardwareVer { get; set; }

    }
}
