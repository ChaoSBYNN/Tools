﻿namespace Kaadas.Iot.Dto.Dto
{
    /// <summary>
    /// 下拉数据
    /// </summary>
    public class SelectItemDto
    {
        /// <summary>
        /// 文字显示
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 值
        /// </summary>
        public string Value { get; set; }
    }
}
