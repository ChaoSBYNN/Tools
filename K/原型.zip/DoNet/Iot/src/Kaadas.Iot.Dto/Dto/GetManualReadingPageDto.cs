﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class GetManualReadingPageReq : PageReq
    {
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// 运营方
        /// </summary>
        public string OperatorNo { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }
    }

    public class GetManualReadingPageRes : CreateBase
    {
        /// <summary>
        /// 记录编号
        /// </summary>
        public string No { get; set; }
        /// <summary>
        /// 运营方名称
        /// </summary>
        public string OpratorName { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }

        /// <summary>
        /// 说明
        /// </summary>
        public string Remark { get; set; }

        public string DeviceType { get; set; }

    }
}
