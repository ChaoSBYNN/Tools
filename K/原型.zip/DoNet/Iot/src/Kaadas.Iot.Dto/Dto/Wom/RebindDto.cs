﻿using Kaadas.Iot.CommonDto.Enums;
using NPOI.HSSF.Record.PivotTable;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Dto.Wom
{
    /// <summary>
    /// 网关换绑DTO
    /// </summary>
    public class RebindDto
    {
        /// <summary>
        /// 工单编号 - 师傅小程序必须传，管理系统不用传
        /// </summary> 
        public string WorkNo { get; set; }

        /// <summary>
        /// 原网关SN
        /// </summary> 
        public string SourceSN { get; set; }

        /// <summary>
        /// 新网关SN
        /// </summary> 
        public string NewSN { get; set; }

        /// <summary>
        /// 新网关设备编号
        /// </summary> 
        public string NewDeviceNo { get; set; }

        /// <summary>
        /// 操作用户类型
        /// </summary>
        public UserTypeEnum? UserType { get; set; } 

        /// <summary>
        /// 操作用户编号
        /// </summary>
        public string UserNo { get; set; }

        /// <summary>
        /// 操作用户名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 位置备注
        /// </summary>
        public string Remark { get; set; }
    }
}
