﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Dto.Wom
{
    /// <summary>
    /// 工单节点信息
    /// </summary>
    public class WorkNodeDto
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 节点描述
        /// </summary>
        public string NodeDescription { get; set; }

        /// <summary>
        /// 操作用户类型
        /// </summary>
        public OperUserTypeEnum OpUserType { get; set; }

        /// <summary>
        /// 操作用户编号
        /// </summary>
        public string OpUserNo { get; set; }

        /// <summary>
        /// 操作用户名
        /// </summary>
        public string OpUserName { get; set; }

        /// <summary>
        /// 节点备注
        /// </summary>
        public string Remark { get; set; }
    }
}
