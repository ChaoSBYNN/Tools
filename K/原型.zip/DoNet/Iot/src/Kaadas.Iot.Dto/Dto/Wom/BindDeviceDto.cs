﻿using Kaadas.Iot.CommonDto.Enums;
using NPOI.OpenXmlFormats.Dml;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Dto.Wom
{
    /// <summary>
    /// 设备绑定DTO
    /// </summary>
    public class BindDeviceDto
    {
        /// <summary>
        /// 工单编号
        /// </summary> 
        public string WorkNo { get; set; }

        ///// <summary>
        ///// 设备编号
        ///// </summary> 
        //public string DeviceNo { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary> 
        public string SN { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary> 
        public string RoomNo { get; set; }

        /// <summary>
        /// 信道 设备绑定传0
        /// </summary>
        public int Channel { get; set; } = 0;

        /// <summary>
        /// 绑定网关SN/水电采集器SN  绑定设备类型为网关/水电采集器时，为null
        /// </summary>
        public string BindGatewaySN { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 替换设备 SN
        /// </summary>
        public string SourceSN { get; set; }

        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum  UserType{ get; set; }

        /// <summary>
        /// 操作人编号
        /// </summary>
        public string UserNo { get; set; }

        /// <summary>
        /// 操作人名称
        /// </summary>
        public string UserName { get; set; }
    }
}
