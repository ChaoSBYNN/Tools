﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class GetManualReadingTemplateReq
    {
        //List<string> sns, string operatorNo, string houseNo, int[] deviceTypes
        public List<string> sns { get; set; }
        public string operatorNo { get; set; }
        public string houseNo { get; set; }
        public List<int> deviceTypes { get; set; }
    }

    public class GetManualReadingTemplateRes
    {

    }
}
