﻿namespace Kaadas.Iot.Dto.Dto
{
    /// <summary>
    /// 操作人信息
    /// </summary>
    public class OperInfoDto
    {
        /// <summary>
        /// 操作人编号
        /// </summary>
        public string OperNo { get; set; }

        /// <summary>
        /// 操作人姓名
        /// </summary>
        public string OperName { get; set; }
    }
}
