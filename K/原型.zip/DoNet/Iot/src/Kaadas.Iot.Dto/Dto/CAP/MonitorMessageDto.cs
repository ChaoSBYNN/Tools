﻿using Kaadas.Iot.CommonDto.Enums;
using System;

namespace Kaadas.Iot.Dto.Dto.CAP
{
    /// <summary>
    /// Host.Monitor 接收消息
    /// </summary>
    public class MonitorMessageDto
    {
        /// <summary>
        /// 消息ID
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 客户端Id
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// 接收消息主题
        /// </summary>
        public string Topic { get; set; }

        /// <summary>
        /// 消息内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 消息级别
        /// </summary>
        public int Qos { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public DateTime SendTime { get; set; }

        /// <summary>
        /// 接收时间
        /// </summary>
        public DateTime ReceiveTime { get; set; } = DateTime.Now;

        /// <summary>
        /// 是否ACK响应
        /// </summary>
        public bool IsAck { get; set; } 
    }
}
