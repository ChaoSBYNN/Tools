﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class RetryDataDto
    {
        /// <summary>
        /// 重试次数
        /// </summary>
        public int RetryNum { get; set; }
    }
}
