﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class OperInfoDto
    {
        /// <summary>
        /// 
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// token
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperNo { get; set; }

        /// <summary>
        /// 接口每秒可访问频率
        /// </summary>
        public int Frequency { get; set; }
    }
}
