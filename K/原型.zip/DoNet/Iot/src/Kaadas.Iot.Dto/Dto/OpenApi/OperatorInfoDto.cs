﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    /// <summary>
    /// 运营方信息
    /// </summary>
    public class OperatorInfoDto
    {
        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// AppSecret
        /// </summary>
        public string AppSecret { get; set; }

        /// <summary>
        /// 运营方推送地址
        /// </summary>
        public string OperatorUrl { get; set; }

        /// <summary>
        /// OpenApi地址
        /// </summary>
        public string OpenApiUrl { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum  DeviceType{ get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string DeviceESN { get; set; }
    }
}
