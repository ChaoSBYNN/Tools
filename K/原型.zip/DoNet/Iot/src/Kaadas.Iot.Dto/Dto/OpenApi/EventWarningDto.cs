﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class EventWarningDto
    {
        /// <summary>
        /// 预警次数
        /// </summary>
        public int WarningNum { get; set; }

        /// <summary>
        /// 异常次数
        /// </summary>
        public int ErrorNum { get; set; }

        /// <summary>
        /// 过期时间
        /// </summary>
        public int ExpiredTime { get; set; }
    }
}
