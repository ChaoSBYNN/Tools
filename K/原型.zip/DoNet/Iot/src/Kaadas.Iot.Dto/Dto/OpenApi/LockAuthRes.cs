﻿using Kaadas.Iot.Common;
using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class LockAuthRes : CreateBase
    {
        /// <summary>
        /// 主键Id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 人员名称
        /// </summary>
        public string PersonnelName { get; set; }

        /// <summary>
        /// 人员手机
        /// </summary>
        public string PersonnelPhone { get; set; }

        /// <summary>
        /// 密钥状态
        /// </summary>
        public SecretStatusEnum Status { get; set; }

        /// <summary>
        /// 状态名称
        /// </summary>
        public string StatusName { get { return Status.GetDescription(); } }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }
    }
}
