﻿using Kaadas.Iot.CommonDto.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class DeviceEventPushDto
    {
        /// <summary>
        /// 事件类型标识
        /// </summary>
        public string EventType { get; set; }

        /// <summary>
        /// 推送时间
        /// </summary>
        public long Timestamp { get; set; }

        /// <summary>
        /// 联网设备唯一标识
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 房源标识
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间No
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 事件对象数据明细
        /// </summary>
        public string EventData { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 数据签名
        /// </summary>
        public string Sign { get; set; }

    }
}
