﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.OpenApi
{
    public class AddAuthDto
    {
        /// <summary>
        /// 房间NO
        /// </summary>
        [Required(ErrorMessage = "房间编号不能为空！")]
        public string RoomNo { get; set; }

        /// <summary>
        /// 人员名称
        /// </summary>
        [Required(ErrorMessage = "人员名称不能为空！")]
        public string PersonnelName { get; set; }

        /// <summary>
        /// 人员手机
        /// </summary>
        [Required(ErrorMessage = "人员手机不能为空！")]
        public string PersonnelPhone { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; } = PwdTypeEnum.Password;

        /// <summary>
        /// 门锁SN
        /// </summary>
        [Required(ErrorMessage = "门锁SN不能为空！")]
        public string SN { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [Required(ErrorMessage = "开始时间不能为空！")]
        public DateTime? LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Required(ErrorMessage = "结束时间不能为空！")]
        public DateTime? LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }

        /// <summary>
        /// 密码值
        /// </summary>
        public string PwdValue { get; set; }
    }
}
