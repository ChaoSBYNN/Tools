﻿using System;

namespace Kaadas.Iot.Dto.Dto.Mqtt
{
    /// <summary>
    /// MQTT连接对象
    /// </summary>
    public class MqttConnectedDto
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 连接时间
        /// </summary>
        public DateTime ConnectTime { get; set; }
    }
}
