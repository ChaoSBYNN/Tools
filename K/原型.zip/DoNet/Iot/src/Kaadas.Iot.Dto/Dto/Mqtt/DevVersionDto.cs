﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Dto.Mqtt
{
    /// <summary>
    /// 模组版本信息
    /// </summary>
    public class DevVersionDto
    {
        /// <summary>
        /// 模组编号
        /// </summary>
        public DevNumEnum DevNum { get; set; }

        /// <summary>
        /// 模组固件版本
        /// </summary>
        public string SoftVer { get; set; }

        /// <summary>
        /// 模组硬件版本
        /// </summary>
        public string HWVer { get; set; }
    }
}
