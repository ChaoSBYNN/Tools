﻿namespace Kaadas.Iot.Dto.Dto.Mqtt
{
    /// <summary>
    /// 指令配置
    /// </summary>
    public class MqttInstructionDto
    {
        /// <summary>
        /// 是否ACK响应结果即是成功
        /// </summary>
        public bool IsAckResult { get; set; }

        /// <summary>
        /// 数据表名
        /// </summary>
        public string TableName { get; set; }

        /// <summary>
        ///  超时时间 单位：秒 
        /// </summary>
        public int ExpireSeconds { get; set; }

        /// <summary>
        /// 是否Mqtt统一处理 忽略修改
        /// </summary>
        public bool IsMqttIgnore { get; set; } = false;
    }
}
