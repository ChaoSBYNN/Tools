﻿namespace Kaadas.Iot.Dto.Dto.Mqtt
{
    public class InstructionConfigDto
    {
        /// <summary>
        /// 是否ACK响应结果是成功
        /// </summary>
        public bool IsAckResult { get; set; }

        /// <summary>
        /// 表格名称
        /// </summary>
        public string TableName { get; set; }
    }
}
