﻿namespace Kaadas.Iot.Dto.Dto.Device
{
    public class GetESNAndSNDto
    {
        public string ESN { get; set; }

        public string SN { get; set; }
    }
}
