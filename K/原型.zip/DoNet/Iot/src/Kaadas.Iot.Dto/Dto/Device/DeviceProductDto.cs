﻿namespace Kaadas.Iot.Dto.Dto.Device
{
    /// <summary>
    /// 设备下的产品
    /// </summary>
    public class DeviceProductDto
    {
        /// <summary>
        /// 产品颜色
        /// </summary>
        /// <returns></returns>
        public string Color { get; set; }
        /// <summary>
        /// 产品料号
        /// </summary>
        /// <returns></returns>
        public string ProoductNo { get; set; }
    }
}
