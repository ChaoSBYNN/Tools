﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Dto.Device
{
    /// <summary>
    /// 设备其它参数
    /// </summary>
    public class DeviceParameterDto
    {
        /// <summary>
        /// 参数名称
        /// </summary>
        /// <returns></returns>
        [MaxLength(50, ErrorMessage = "超过限制字数50")]
        public string ParamName { get; set; }
        /// <summary>
        /// 参数值
        /// </summary>
        /// <returns></returns>
        [MaxLength(100, ErrorMessage = "超过限制字数100")]
        public string ParamValue { get; set; }
    }
}
