﻿namespace Kaadas.Iot.Dto.Dto.Login
{
    /// <summary>
    /// 登录用户信息
    /// </summary>
    public class LoginUserInfoDto
    {
        /// <summary>
        /// 编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 账号 
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 随机字符串 - 防止一个账号多次登录
        /// </summary>
        public string NonceStr { get; set; }

        /// <summary>
        /// 访问令牌
        /// </summary>
        public string Token { get; set; }
    }
}
