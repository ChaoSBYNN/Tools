﻿using System;

namespace Kaadas.Iot.Dto.Dto.Login
{
    /// <summary>
    /// 登录失败DTO
    /// </summary>
    public class LoginErrorDto
    {
        /// <summary>
        /// 首次登录错误时间
        /// </summary>
        public DateTime FirstErrorTime { get; set; }

        /// <summary>
        /// 登录错误次数
        /// </summary>
        public int LoginErrorCount { get; set; }
    }
}
