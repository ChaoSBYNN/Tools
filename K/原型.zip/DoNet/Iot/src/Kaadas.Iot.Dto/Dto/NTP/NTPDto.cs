﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Dto.NTP
{
    public class NTPDto
    {
        /// <summary>
        /// 时间戳格式精确到秒(时间服务器的时间(UTC))
        /// </summary>
        public long ServerTime { get; set; }

        /// <summary>
        /// 时区(默认东八区)
        /// </summary>
        public TimeZoneEnum TimeZone { get; set; } = TimeZoneEnum.UTC8;
    }
}
