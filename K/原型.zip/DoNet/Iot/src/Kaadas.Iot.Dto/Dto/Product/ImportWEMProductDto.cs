﻿using Kaadas.Iot.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.Product
{
   public class ImportWEMProductDto: BaseImport
    {
        /// <summary>
        /// 序列号
        /// </summary>
        [Import(1)]
        public string SN { get; set; }

        /// <summary>
        /// PID
        /// </summary>
        [Import(2)]
        public string PID { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        [Import(3)]
        public string ProductType { get; set; }

    }
}
