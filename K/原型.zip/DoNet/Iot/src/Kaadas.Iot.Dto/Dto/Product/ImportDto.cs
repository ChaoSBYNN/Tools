﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto.Product
{
   public class ImportDto
    {
        public IFormFile File { get; set; }
    }
}
