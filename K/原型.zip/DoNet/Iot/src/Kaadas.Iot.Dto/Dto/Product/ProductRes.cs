﻿namespace Kaadas.Iot.Dto.Dto.Product
{
    public class ProductRes
    {
        public string code { get; set; }

        public string msg { get; set; }

        public long nowTime { get; set; }

        public object data { get; set; }
    }
}
