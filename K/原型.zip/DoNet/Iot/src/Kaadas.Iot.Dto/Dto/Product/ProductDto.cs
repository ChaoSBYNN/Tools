﻿using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Dto.Product
{
    public class ProductDto
    {
        /// <summary>
        /// 当前时间戳(单位秒)
        /// </summary>
        public int timestamp { get; set; }
        /// <summary>
        /// 签名(MD5(timestamp+secret) 。其中secret为21f2a17d548b34450d986fd144b1af31。
        /// </summary>
        public string sign { get; set; }
        /// <summary>
        /// 设备类型。1为蓝牙/ZigBee设备，2为网关，3为WIFI设备。
        /// </summary>
        public int type { get; set; }
        /// <summary>
        /// 客户。1为凯迪仕。18为飞利浦
        /// </summary>
        public int customer { get; set; }
        /// <summary>
        /// 产测数据
        /// </summary>
        public List<ProductDetailDto> data { get; set; }
    }

    public class ProductDetailDto
    {
        /// <summary>
        /// ESN序列号
        /// </summary>
        public string sn { get; set; }
        /// <summary>
        /// 密码1。当设备为网关不传。
        /// </summary>
        public string password1 { get; set; }
        /// <summary>
        /// MAC地址
        /// </summary>
        public string mac { get; set; }
        /// <summary>
        /// 门锁序列号
        /// </summary>
        public string lockSn { get; set; }
        /// <summary>
        /// 产品型号
        /// </summary>
        public string model { get; set; }
        /// <summary>
        /// 模块初始化版本，格式：”{研发型号}_{模组编号}_{版本}”
        /// </summary>
        public List<string> verList { get; set; }
    }
}
