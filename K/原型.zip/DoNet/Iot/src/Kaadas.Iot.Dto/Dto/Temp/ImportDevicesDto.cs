﻿namespace Kaadas.Iot.Dto.Dto.Temp
{
    /// <summary>
    /// 导入设备
    /// </summary>
    public class ImportDevicesDto
    {
        /// <summary>
        /// 网关ESN -- 网关必须为已操作绑定的网关
        /// </summary>
        public string Gateway { get; set; }

        /// <summary>
        /// 设备ESN 数组
        /// </summary>
        public string[] Devices{ get; set; }
    }
}
