﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Dto
{
    public class PublishMsgDto
    {
        /// <summary>
        /// 消费端需请求的地址
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 消费推送数据
        /// </summary>
        public object Data { get; set; }
    }
}
