﻿using Kaadas.Iot.CommonDto.Attributes;
using System;

namespace Kaadas.Iot.Dto
{
    /// <summary>
    /// 创建人信息基类
    /// </summary>
    public class CreateBase
    {
        /// <summary>
        /// 创建人编号
        /// </summary>
        public string CreatorUserId { get; set; }

        /// <summary>
        /// 创建人名称
        /// </summary>
        public string Creator { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [DefaultSort]
        public DateTime CreatorTime { get; set; }
    }
}
