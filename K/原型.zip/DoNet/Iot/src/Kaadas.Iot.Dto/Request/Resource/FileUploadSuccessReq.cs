﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Resource
{
    /// <summary>
    /// 上传成功响应
    /// </summary>
    public class FileUploadSuccessReq
    {
        /// <summary>
        /// 文件Md5值
        /// </summary>
        public string Md5 { get; set; }

        /// <summary>
        /// 文件类型
        /// </summary>
        public ResourceTypeEnum? ResourceType { get; set; }

    }
}
