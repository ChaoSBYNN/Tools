﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Resource
{
    /// <summary>
    /// 资源上传请求
    /// </summary>
    public class FileUploadReq
    {
        /// <summary>
        /// 文件Md5值
        /// </summary>
        public string Md5 { get; set; }

        /// <summary> 
        /// 文件类型 
        /// </summary>
        public ResourceTypeEnum ResourceType { get; set; }

        /// <summary>
        /// 文件名 - 包括文件扩展名
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// 文件大小
        /// </summary>
        public int FileSize { get; set; }
    }
}
