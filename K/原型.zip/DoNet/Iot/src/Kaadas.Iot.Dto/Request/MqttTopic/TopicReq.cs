﻿namespace Kaadas.Iot.Dto.Request.MqttTopic
{
    /// <summary>
    /// 
    /// </summary>
    public class TopicReq : PageReq
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }
    }
}
