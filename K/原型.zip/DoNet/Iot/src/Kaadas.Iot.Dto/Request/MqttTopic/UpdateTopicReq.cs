﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.MqttTopic
{
    /// <summary>
    /// 更新序列编号
    /// </summary>
    public class UpdateTopicReq
    {
        public string Id { get; set; }
        /// <summary>
        /// 主题正则
        /// </summary>
        public string TopicReg { get; set; }

        /// <summary>
        /// MQTT payload 定义的 Method - 可在 MqttMethodConst 查看
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 执行CAP
        /// </summary>
        public string ExecuteCap { get; set; }
    }
}
