﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Team
{
    public class EditTeamStatusReq
    {
        public string Id { get; set; }

        public StatusEnum Status { get; set; }
    }
}
