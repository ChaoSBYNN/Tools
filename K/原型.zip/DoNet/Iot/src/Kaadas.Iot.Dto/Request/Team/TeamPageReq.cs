﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Team
{
    /// <summary>
    /// 安维团队列表入参
    /// </summary>
    public class TeamPageReq : PageReq
    {
        /// <summary>
        /// 团队名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 团队编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 团队状态
        /// </summary>
        public StatusEnum? Status { get; set; }

        /// <summary>
        /// 师傅名称
        /// </summary>
        public string WorkerName { get; set; }

        /// <summary>
        /// 师傅手机号
        /// </summary>
        public string Phone { get; set; }
    }
}
