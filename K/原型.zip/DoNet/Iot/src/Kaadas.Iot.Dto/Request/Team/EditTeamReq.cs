﻿using Kaadas.Iot.Dto.Dto.Worker;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Team
{
    /// <summary>
    /// 编辑师傅团队信息
    /// </summary>
    public class EditTeamReq
    {
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 团队名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 服务区域
        /// </summary>
        public List<ServiceAreaDto> ServiceAreas { get; set; }
    }
}
