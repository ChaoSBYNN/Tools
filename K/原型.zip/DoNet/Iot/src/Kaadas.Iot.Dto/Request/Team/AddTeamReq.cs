﻿using Kaadas.Iot.Dto.Dto.Worker;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Team
{
    /// <summary>
    /// 新增团队信息
    /// </summary>
    public class AddTeamReq
    {
        /// <summary>
        /// 团队名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 师傅信息
        /// </summary>
        public WorkerInfoDto WorkerInfo { get; set; }
        /// <summary>
        /// 服务区域
        /// </summary>
        public List<ServiceAreaDto> ServiceAreas { get; set; }
    }
}
