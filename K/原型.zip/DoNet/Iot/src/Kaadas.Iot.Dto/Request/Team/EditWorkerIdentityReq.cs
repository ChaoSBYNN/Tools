﻿namespace Kaadas.Iot.Dto.Request.Team
{
    /// <summary>
    /// 转交负责人入参
    /// </summary>
    public class EditWorkerIdentityReq
    {

        /// <summary>
        /// 团队Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 负责人编号
        /// </summary>
        public string WorkerNo { get; set; }
    }
}
