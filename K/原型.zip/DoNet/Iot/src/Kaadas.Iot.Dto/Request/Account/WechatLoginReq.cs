﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Account
{
    /// <summary>
    /// 小程序账密登录
    /// </summary>
    public class WechatLoginReq : LoginReq
    {
        /// <summary>
        /// 微信授权Code
        /// </summary>
        [Required(ErrorMessage = "微信授权Code不能为空")]
        public string WxCode { get; set; }
    }
}
