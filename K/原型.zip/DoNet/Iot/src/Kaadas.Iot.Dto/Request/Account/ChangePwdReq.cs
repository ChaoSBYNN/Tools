﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Account
{
    /// <summary>
    /// 修改密码请求
    /// </summary>
    public class ChangePwdReq
    {
        /// <summary>
        /// 原密码 -- 不加密
        /// </summary>
        [Required(ErrorMessage = "原密码不能为空")]
        public string OriginalPwd { get; set; }

        /// <summary>
        /// 新密码 -- 不加密
        /// </summary>
        [Required(ErrorMessage = "新密码不能为空")]
        public string NewPwd { get; set; }
    }
}
