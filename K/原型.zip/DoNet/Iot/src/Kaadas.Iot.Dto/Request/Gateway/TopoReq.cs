﻿namespace Kaadas.Iot.Dto.Request.Gateway
{
    /// <summary>
    /// 网关topo关系获取
    /// </summary>
    public class TopoReq : MonitorApiBaseReq
    {
    }
}
