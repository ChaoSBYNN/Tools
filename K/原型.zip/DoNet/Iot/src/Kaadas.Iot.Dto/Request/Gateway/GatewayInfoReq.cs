﻿namespace Kaadas.Iot.Dto.Request.Gateway
{
    /// <summary>
    /// 网关保存信息
    /// </summary>
    public class GatewayInfoReq
    {
        /// <summary>
        /// 信息
        /// </summary>
        public string Info { get; set; }
    }
}
