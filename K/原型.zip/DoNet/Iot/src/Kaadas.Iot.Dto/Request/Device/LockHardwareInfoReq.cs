﻿namespace Kaadas.Iot.Dto.Request.Device
{
    public class LockHardwareInfoReq
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }
    }
}
