﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.Device
{
    public class LockVersInfoDto : PageReq
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string SN { get; set; }
    }
}
