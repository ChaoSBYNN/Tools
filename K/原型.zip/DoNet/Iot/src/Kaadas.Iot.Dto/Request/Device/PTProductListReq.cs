﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Device
{
    public class PTProductListReq : PageReq
    {
        /// <summary>
        /// esn
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// sn
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        /// <returns></returns>
        public DeviceTypeEnum? DeviceType { get; set; }

    }
}
