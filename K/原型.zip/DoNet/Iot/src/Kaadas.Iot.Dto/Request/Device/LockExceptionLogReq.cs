﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Device
{
    public class LockExceptionLogReq : PageReq
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 异常类型
        /// </summary>
        public List<AlarmCodeEnum> LockAlarmTypes { get; set; }
    }
}
