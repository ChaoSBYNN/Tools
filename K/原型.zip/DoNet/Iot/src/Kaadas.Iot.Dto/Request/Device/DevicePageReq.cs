﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Device
{
    /// <summary>
    /// 设备列表入参
    /// </summary>
    public class DevicePageReq : PageReq
    {
        /// <summary>
        /// 设备编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        /// <returns></returns>
        public DeviceTypeEnum? DeviceType { get; set; }

        /// <summary>
        /// 来源产商
        /// </summary>
        /// <returns></returns>
        public string FromFactory { get; set; }
    }
}
