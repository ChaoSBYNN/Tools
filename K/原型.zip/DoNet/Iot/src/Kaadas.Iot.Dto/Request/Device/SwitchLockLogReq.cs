﻿using Kaadas.Iot.CommonDto.Enums;
using System.Diagnostics.Tracing;

namespace Kaadas.Iot.Dto.Request.Device
{
    public class SwitchLockLogReq : PageReq
    {
        /// <summary>
        /// 门锁ESN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 开关锁类型(指纹 = 1,密码 = 2,ID卡 = 3)
        /// </summary>
        public EventSourceEnum? OpenLockType { get; set; }


    }
}
