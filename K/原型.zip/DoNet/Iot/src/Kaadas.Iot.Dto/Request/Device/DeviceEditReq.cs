﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Dto.Device;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Device
{
    /// <summary>
    /// 编辑设备型号入参
    /// </summary>
    public class DeviceEditReq
    {
        public string Id { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 设备型号
        /// </summary>
        /// <returns></returns>
        public string ModelNum { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        /// <returns></returns>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 来源产商
        /// </summary>
        /// <returns></returns>
        public string FromFactory { get; set; }

        /// <summary>
        /// 通讯类型 多选，隔开
        /// 锁单选、 水电表 多选
        /// </summary>
        /// <returns></returns>
        public string CommunicateType { get; set; }

        /// <summary>
        /// 开锁方式（锁属性）,多种,隔开  
        /// OpenWayEnum 枚举
        /// </summary>
        /// <returns></returns>
        public string OpenWays { get; set; }

        /// <summary>
        /// 通讯协议（网关属性）
        /// </summary>
        /// <returns></returns>
        public ProtocolEnum? Protocol { get; set; }

        /// <summary>
        /// 联网方式（网关属性）多种,隔开
        /// NetworkModeEnum 枚举
        /// </summary>
        /// <returns></returns>
        public string NetworkMode { get; set; }

        /// <summary>
        /// 设备下的产品
        /// </summary>
        public List<DeviceProductDto> DeviceProducts { get; set; }

        /// <summary>
        /// 设备其它参数
        /// </summary>
        public List<DeviceParameterDto> DeviceParameters { get; set; }

        /// <summary>
        /// 设备对应PID
        /// </summary>
        public string[] PIDs { get; set; }  

        /// <summary>
        /// 电表 - 最大电流
        /// </summary>
        public string MaxElectric { get; set; }
    }
}
