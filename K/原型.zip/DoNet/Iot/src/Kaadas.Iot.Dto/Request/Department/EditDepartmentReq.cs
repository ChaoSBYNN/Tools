﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Department
{
    /// <summary>
    /// 编辑部门
    /// </summary>
    public class EditDepartmentReq
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 上级部门编号
        /// </summary>
        [Required(ErrorMessage = "上级部门编号不能为空")]
        public string ParentNo { get; set; }

        /// <summary>
        /// 部门名称
        /// </summary>
        [Required(ErrorMessage = "部门名称不能为空")]
        public string Name { get; set; }

        /// <summary>
        /// 部门简写
        /// </summary>
        [Required(ErrorMessage = "部门简写不能为空")]
        public string Abbreviation { get; set; }
    }
}
