﻿namespace Kaadas.Iot.Dto.Request.OperHouse
{
    /// <summary>
    /// 房源数据查询入参
    /// </summary>
    public class OperHousePageReq : PageReq
    {
        /// <summary>
        /// 房源名称或编号
        /// </summary>
        public string OperHouseName { get; set; }

        /// <summary>
        /// 商户编号（多个以小写逗号隔开）
        /// </summary>
        public string OperatorNo { get; set; }
    }
}
