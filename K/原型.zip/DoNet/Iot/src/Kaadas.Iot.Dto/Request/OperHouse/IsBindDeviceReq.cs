﻿using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.OperHouse
{
    /// <summary>
    /// 判断是否有无绑定设备入参
    /// </summary>
    public class IsBindDeviceReq
    {
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }
        /// <summary>
        /// 房间信息
        /// </summary>
        public List<RoomItem> Rooms { get; set; }
    }
}
