﻿namespace Kaadas.Iot.Dto.Request.OperHouse
{
    /// <summary>
    /// 房源房间信息
    /// </summary>
    public class RoomItem
    {
        /// <summary>
        /// 楼层号
        /// </summary>
        public int FloorLevel { get; set; }
        /// <summary>
        /// 房间名
        /// </summary>
        public string RoomName { get; set; }
    }
}
