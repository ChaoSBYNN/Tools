﻿using Kaadas.Iot.CommonDto.Enums;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.OperHouse
{
    /// <summary>
    /// 房源数据新增或者修改入参
    /// </summary>
    public class EditOperHouseReq : CreateBase
    {
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 房源编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 公区编号
        /// </summary>
        public string PublicAreasNo { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        [MaxLength(25, ErrorMessage = "房源名称输入超长，请修改！")]
        public string Name { get; set; }
        /// <summary>
        /// 房源详细地址
        /// </summary>
        [MaxLength(200, ErrorMessage = "房源地址输入超长，请修改！")]
        public string Address { get; set; }
        /// <summary>
        /// 省编号
        /// </summary>
        public string Province { get; set; }
        public string ProvinceName { get; set; }
        /// <summary>
        /// 市编号
        /// </summary>
        public string City { get; set; }
        public string CityName { get; set; }
        /// <summary>
        /// 区编号
        /// </summary>
        public string Region { get; set; }
        public string RegionName { get; set; }
        /// <summary>
        /// 房源类型
        /// </summary>
        public HomeTypeEnum HomeType { get; set; }
        /// <summary>
        /// 所属商户
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// 所属商户名称
        /// </summary>
        public string OperatorName { get; set; }

        /// <summary>
        /// 房源管理员
        /// </summary>
        public string AdminName { get; set; }
        /// <summary>
        /// 房源管理员手机号
        /// </summary>
        public string AdminPhone { get; set; }

        /// <summary>
        /// 房间数
        /// </summary>
        public int RoomNum { get; set; }

        /// <summary>
        /// 楼层数
        /// </summary>
        public int FloorNum { get; set; }

        /// <summary>
        /// 楼层房间信息列表
        /// </summary>
        public List<RoomItem> RoomList { get; set; }

        /// <summary>
        /// 是否强制开锁
        /// </summary>
        public int IsForceUnlock { get; set; }

    }
}
