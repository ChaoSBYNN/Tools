﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Mqtt;

namespace Kaadas.Iot.Dto.Request
{
    /// <summary>
    /// Open Api MQTT 事件基类
    /// </summary> 
    public class OpenApiPostBase : MqttPostBase<object>
    {
        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// 运营方密钥
        /// </summary>
        public string AppSecret { get; set; }

        /// <summary>
        /// Open Api 请求地址
        /// </summary>

        public string OpenApiUrl { get; set; }

        /// <summary>
        /// 推送地址
        /// </summary>
        public string OperatorUrl { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 事件类型
        /// </summary>
        public string EventType { get; set; }

        /// <summary>
        /// 主题
        /// </summary>
        public string Topic { get; set; }
    }
}
