﻿namespace Kaadas.Iot.Dto.Request.Config
{
    /// <summary>
    /// 增加/修改配置请求
    /// </summary>
    public class ConfigReq
    {
        /// <summary>
        /// 唯一Id - 增加操作为空
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 配置key
        /// </summary>
        public string ConfigKey { get; set; }

        /// <summary>
        /// 配置值
        /// </summary>
        public string ConfigValue { get; set; }

        /// <summary>
        /// 分类字典 key
        /// </summary>
        public string CategoryKey { get; set; }
    }
}
