﻿using Kaadas.Iot.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.UsedDevice
{
    public class ImportUpgradeDeviceReq : BaseImport
    {
        [Import(1)]
        public string ESN { get; set; }
    }
}
