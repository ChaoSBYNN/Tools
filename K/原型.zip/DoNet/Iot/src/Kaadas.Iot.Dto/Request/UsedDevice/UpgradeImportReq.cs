﻿using Kaadas.Iot.CommonDto.Enums;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.UsedDevice
{
    public class UpgradeImportReq
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        public IFormFile File { get; set; }
        /// <summary>
        /// 模组编号
        /// </summary>
        public DevNumEnum? DevNum { get; set; }
        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }
    }
}
