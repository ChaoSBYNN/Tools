﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.UsedDevice
{
    public class UsedDevicePageReq : PageReq
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        public string Name { get; set; }

        /// <summary>
        /// 设备联网状态
        /// </summary>
        public DeviceStateEnum? DeviceState { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }

        /// <summary>
        /// 绑定网关
        /// </summary>
        public string BindGatewaySN { get; set; }

        /// <summary>
        /// 低电量
        /// </summary>
        public LowBatteryEnum? LowBattery { get; set; }
    }
}
