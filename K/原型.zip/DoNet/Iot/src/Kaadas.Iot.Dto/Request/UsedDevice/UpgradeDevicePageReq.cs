﻿using Kaadas.Iot.CommonDto.Enums;
using Org.BouncyCastle.Bcpg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.UsedDevice
{
    public class UpgradeDevicePageReq : PageReq
    {
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }
        /// <summary>
        /// 运营方
        /// </summary>
        public string OperatorNo { get; set; }
        /// <summary>
        /// ESN
        /// </summary>
        public string ESN { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }
        /// <summary>
        /// 软件版本号
        /// </summary>
        public string SoftwareVer { get; set; }
        /// <summary>
        /// 硬件版本号
        /// </summary>
        public string HardwareVer { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }

        /// <summary>
        /// 模组编号
        /// </summary>
        public DevNumEnum? DevNum { get; set; }
    }
}
