﻿namespace Kaadas.Iot.Dto.Request.Tenant
{
    /// <summary>
    /// 租客列表入参
    /// </summary>
    public class TenantPageReq : PageReq
    {
        /// <summary>
        /// 租客编号
        /// </summary>
        public string No { get; set; }
        /// <summary>
        /// 租客名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 租客手机号
        /// </summary>
        public string Phone { get; set; }
    }
}
