﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Room
{
    public class AddRoomDto
    {
        public string HouseNo { get; set; }

        [MaxLength(25, ErrorMessage = "房间名称输入超长，请修改！")]
        public string RoomName { get; set; }

        public int FloorNum { get; set; }
    }
}
