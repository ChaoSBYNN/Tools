﻿
using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.DMS
{
    /// <summary>
    /// 联网设备请求
    /// </summary>
    public class NetDeviceReq : PageReq
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }
    }
}
