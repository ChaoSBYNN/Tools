﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.DMS
{
    /// <summary>
    /// 使用设备请求
    /// </summary>
    public class UsedDeviceReq : PageReq
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DeviceStateEnum? State { get; set; }
    }
}
