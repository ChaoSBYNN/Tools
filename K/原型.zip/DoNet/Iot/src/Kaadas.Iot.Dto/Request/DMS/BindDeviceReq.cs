﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.DMS
{
    /// <summary>
    /// 绑定设备请求
    /// </summary>
    public class BindDeviceReq
    {
        ///// <summary>
        ///// 设备编号
        ///// </summary>
        //[Required(ErrorMessage = "设备编号不能为空")]
        //public string DeviceNo { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        [Required(ErrorMessage = "设备SN不能为空")]
        public string SN { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        [Required(ErrorMessage = "房间编号不能为空")]
        public string RoomNo { get; set; }

        /// <summary>
        /// 信道 设备绑定传0
        /// </summary>
        public int Channel { get; set; } = 0;

        /// <summary>
        /// 绑定网关SN 绑定设备类型为网关时，为null
        /// </summary>
        public string BindGatewaySN { get; set; }

        /// <summary>
        /// 备注
        /// </summary> 
        public string Remark { get; set; }
    }
}
