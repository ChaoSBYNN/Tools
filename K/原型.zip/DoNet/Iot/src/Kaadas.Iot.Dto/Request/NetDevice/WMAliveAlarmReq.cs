﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    public class WMAliveAlarmReq : PageReq
    {
        /// <summary>
        /// 房源名称
        /// </summary>
        public string HouseName { get; set; }

        /// <summary>
        /// 警报类型
        /// </summary>
        public WMAlarmTypeEnum? LockAlarmType { get; set; }

        public DeviceTypeEnum DeviceType { get; set; }
    }
}
