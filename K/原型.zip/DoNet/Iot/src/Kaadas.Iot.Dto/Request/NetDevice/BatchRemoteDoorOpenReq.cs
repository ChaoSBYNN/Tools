﻿namespace Kaadas.Iot.Dto.Request.NetDevice
{
    /// <summary>
    /// 
    /// </summary>
    public class BatchRemoteDoorOpenReq
    {
        /// <summary>
        /// 房源编号
        /// </summary>
        public string OperHouseNo { get; set; }

        /// <summary>
        /// 是否全部房间
        /// </summary>
        public int IsAllRoom { get; set; }

        /// <summary>
        /// 自定义授权房间No
        /// </summary>
        public string[] RoomNos { get; set; }
    }
}
