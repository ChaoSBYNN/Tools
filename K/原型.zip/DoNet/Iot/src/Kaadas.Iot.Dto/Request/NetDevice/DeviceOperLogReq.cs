﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    /// <summary>
    /// 设备操作记录请求
    /// </summary>
    public class DeviceOperLogReq : PageReq
    {
        /// <summary>
        /// 联网编号 房源设备 传此字段
        /// </summary>
        public string NetNo { get; set; }

        /// <summary>
        /// 设备SN - 设备列表 传此字段
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 操作类型
        /// </summary>
        public DeviceOperTypeEnum? Type { get; set; }
    }
}
