﻿using System;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    /// <summary>
    /// 网关重启请求
    /// </summary>
    public class GatewayRestartReq
    {
        /// <summary>
        /// 重启网关SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 网关重启执行时间 
        /// </summary>
        public DateTime? ExecuteTime { get; set; }
    }
}
