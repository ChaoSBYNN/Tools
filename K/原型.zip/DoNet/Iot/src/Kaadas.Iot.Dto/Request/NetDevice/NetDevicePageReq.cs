﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    public class NetDevicePageReq : PageReq
    {
        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum? DeviceType { get; set; }
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// 房间名
        /// </summary>
        public string RoomName { get; set; }

        /// <summary>
        /// 楼层
        /// </summary>
        public int? Floor { get; set; }

        /// <summary>
        /// 设备联网状态
        /// </summary>
        public DeviceStateEnum? DeviceState { get; set; }
    }
}
