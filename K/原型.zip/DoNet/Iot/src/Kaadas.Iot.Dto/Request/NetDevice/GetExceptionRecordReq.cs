﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    public class GetExceptionRecordReq : PageReq
    {
        /// <summary>
        /// 设备sn
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 异常类型
        /// </summary>
        public int? ExceptionType { get; set; }
    }
}
