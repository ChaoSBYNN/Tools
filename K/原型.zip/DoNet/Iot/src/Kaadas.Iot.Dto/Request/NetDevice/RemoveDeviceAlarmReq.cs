﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.NetDevice
{
    public class RemoveDeviceAlarmReq
    {
        /// <summary>
        /// 异常id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 解除备注
        /// </summary>
        [Required(ErrorMessage = "请填写备注")]
        public string Remark { get; set; }

    }
}
