﻿namespace Kaadas.Iot.Dto.Request.Menu
{
    /// <summary>
    /// 获取元素列表
    /// </summary>
    public class EleMentPageReq : PageReq
    {
        /// <summary>
        /// 菜单编号
        /// </summary>
        public string MenuNo { get; set; }
    }
}
