﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Menu
{
    /// <summary>
    /// 添加菜单
    /// </summary>
    public class EditMenuReq
    {
        /// <summary>
        /// 菜单Id，空为新增
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 上级菜单代号
        /// </summary>
        /// <returns></returns>
        [Required(ErrorMessage = "上级菜单代号不能为空")]
        public string ParentNo { get; set; }
        ///// <summary>
        ///// 层级Id；预留
        ///// </summary>
        ///// <returns></returns>
        //public int? LayerId { get; set; }
        /// <summary>
        /// 所有子元素层级ID集合，用逗号隔开；预留
        /// </summary>
        /// <returns></returns>
        public string MenuIdList { get; set; }
        /// <summary>
        /// 菜单名称
        /// </summary>
        /// <returns></returns>
        [Required(ErrorMessage = "菜单名称不能为空")]
        public string MenuName { get; set; }

        /// <summary>
        /// 前端组件名称
        /// </summary>
        public string ModuleName { get; set; }

        /// <summary>
        /// 是否显示
        /// </summary>
        /// <returns></returns>
        public int IsShow { get; set; }
        /// <summary>
        /// 菜单图标样式，通常用fa-icon
        /// </summary>
        /// <returns></returns>
        public string IconCls { get; set; }
        ///// <summary>
        ///// 0：没有子节点，1：有子节点
        ///// </summary>
        ///// <returns></returns>
        //public int? IsSubNode { get; set; }
        /// <summary>
        /// 菜单地址
        /// </summary>
        /// <returns></returns>
        public string Router { get; set; }
        ///// <summary>
        ///// 项目类型
        ///// </summary>
        ///// <returns></returns>
        //public ProjectTypeEnum ProjectType { get; set; }

        /// <summary>
        /// 接口地址
        /// </summary>
        public string MenuInUrl { get; set; }

        public string Component { get; set; }

        public string Redirect { get; set; }

        public string ActiveMenu { get; set; }

        public int NoShowingChildren { get; set; }

        public int SortCode { get; set; }
    }
}
