﻿namespace Kaadas.Iot.Dto.Request.Menu
{
    public class TreeSelectModel
    {
        public string Id { get; set; }
        public string Text { get; set; }
        public string Code { get; set; }
        public string ParentId { get; set; }
        public object Data { get; set; }
    }
}
