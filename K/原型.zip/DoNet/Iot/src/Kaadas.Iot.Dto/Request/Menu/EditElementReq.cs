﻿namespace Kaadas.Iot.Dto.Request.Menu
{
    /// <summary>
    /// 编辑菜单元素
    /// </summary>
    public class EditElementReq
    {

        public string Id { get; set; }
        /// <summary>
        /// 菜单代号
        /// </summary>
        /// <returns></returns>
        public string MenuNo { get; set; }
        /// <summary>
        /// 元素名称
        /// </summary>
        /// <returns></returns>
        public string ElementName { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        /// <returns></returns>
        public string Remarks { get; set; }
        /// <summary>
        /// 元素允许访问的接口地址
        /// </summary>
        /// <returns></returns>
        public string ActionUrl { get; set; }

        /// <summary>
        /// 前端唯一标识
        /// </summary>
        public string FrontEndNo { get; set; }
    }
}
