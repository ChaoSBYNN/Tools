﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.KDF
{
    public class PublishInfoPageReq : PageReq
    {
        public string Key { get; set; }
    }
}
