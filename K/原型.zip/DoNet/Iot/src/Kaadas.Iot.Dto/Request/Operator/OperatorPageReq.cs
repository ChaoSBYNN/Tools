﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 运营方列表入参
    /// </summary>
    public class OperatorPageReq : PageReq
    {
        /// <summary>
        /// 编号
        /// </summary>
        public string No { get; set; }

        ///// <summary>
        ///// 运营方类型
        ///// </summary>
        ///// <returns></returns>
        //public OperatorTypeEnum? OperatorType { get; set; }


        /// <summary>
        /// 运营方类型
        /// </summary>
        /// <returns></returns>
        public string OperatorTypes { get; set; }

        /// <summary>
        /// 商户名称/联系人/联系方式
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        /// <returns></returns>
        public StatusEnum? Status { get; set; }
    }
}
