﻿namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 编辑运营方负责人
    /// </summary>
    public class EditOperHeadReq
    {
        /// <summary>
        /// 
        /// </summary>
        public string No { get; set; }
        /// <summary>
        /// 联系人
        /// </summary>
        public string ContactsName { get; set; }

        /// <summary>
        /// 联系人电话
        /// </summary>
        public string ContactsPhone { get; set; }
    }
}
