﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.Operator
{
    public class EditOpenApiInfoReq
    {
        public string Id { get; set; }

        /// <summary>
        /// 是否开放第三方对接
        /// </summary>
        public bool IsOpenApi { get; set; } = false;

        /// <summary>
        /// 运营方回调地址地址
        /// </summary>
        public string CallbackUrl { get; set; }

        /// <summary>
        /// 访问限制频率
        /// </summary>
        public int Frequency { get; set; } = 0;

        /// <summary>
        /// 事件推送地址
        /// </summary>
        public string EvevtPushUrl { get; set; }
    }
}
