﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.Operator
{
    public class ChangeWMControlParamsReq
    {
        public string Id { get; set; }
        /// <summary>
        /// 水表未上报天数
        /// </summary>
        public int? WMUnReportDays { get; set; }

        /// <summary>
        /// 冷水表跳表
        /// </summary>
        public int? CWMSkipReading { get; set; }

        /// <summary>
        /// 热水表跳表
        /// </summary>
        public int? HWMSkipReading { get; set; }

        /// <summary>
        /// 水表定时抄表
        /// </summary>
        public int? WMAutoRecord { get; set; }
    }
}
