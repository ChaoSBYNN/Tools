﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 编辑运营方
    /// </summary>
    public class EditOperatorReq
    {
        public string Id { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        /// <returns></returns>
        public string Name { get; set; }
        /// <summary>
        /// 全称
        /// </summary>
        /// <returns></returns>
        public string FullName { get; set; }
        /// <summary>
        /// 运营方类型
        /// </summary>
        /// <returns></returns>
        public OperatorTypeEnum OperatorType { get; set; }

        /// <summary>
        /// 合同编号
        /// </summary>
        /// <returns></returns>
        public string ContractNo { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        public string ContactsName { get; set; }

        /// <summary>
        /// 联系人电话
        /// </summary>
        public string ContactsPhone { get; set; }

        /// <summary>
        /// 包安装设备（多个用,隔开）
        /// </summary>
        public string Devices { get; set; }

        
    }
}
