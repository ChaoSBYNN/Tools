﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.Operator
{
    public class ChangeEMControlParamsReq
    {
        public string Id { get; set; }
        /// <summary>
        /// 电表未上报天数
        /// </summary>
        public int? EMUnReportDays { get; set; }

        /// <summary>
        /// 电表跳表
        /// </summary>
        public int? EMSkipReading { get; set; }

        /// <summary>
        /// 电表定时抄表
        /// </summary>
        public int? EMAutoRecord { get; set; }
    }
}
