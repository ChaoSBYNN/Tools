﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 编辑运营方子用户
    /// </summary>
    public class EditOperUserReq
    {
        public string Id { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 用户手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string PassWord { get; set; }

        /// <summary>
        /// 用户角色
        /// </summary>
        public OperUserTypeEnum OperUserType { get; set; }

        /// <summary>
        /// 管理房源
        /// </summary>
        public string HouseNos { get; set; }
    }
}
