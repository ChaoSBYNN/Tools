﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 编辑状态
    /// </summary>
    public class EditOperStateReq
    {
        public string Id { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public StatusEnum Status { get; set; }
    }
}
