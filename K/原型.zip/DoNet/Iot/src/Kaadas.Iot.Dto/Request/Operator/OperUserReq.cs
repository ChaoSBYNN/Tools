﻿namespace Kaadas.Iot.Dto.Request.Operator
{
    /// <summary>
    /// 子用户列表入参
    /// </summary>
    public class OperUserReq : PageReq
    {
        /// <summary>
        /// 运营方No
        /// </summary>
        public string OperNo { get; set; }
    }
}
