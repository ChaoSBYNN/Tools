﻿namespace Kaadas.Iot.Dto.Request
{
    /// <summary>
    /// Monitor 项目Api接口请求基类
    /// </summary>
    public class MonitorApiBaseReq
    {
        /// <summary>
        /// 网关ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 请求访问Token
        /// </summary>
        public string Token { get; set; }
    }
}
