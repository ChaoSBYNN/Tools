﻿namespace Kaadas.Iot.Dto.Request.Seq
{
    /// <summary>
    /// 新增序列号
    /// </summary> 
    public class AddSeqReq
    {
        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 字首
        /// </summary>
        public string Prefix { get; set; }

        /// <summary>
        /// 时间格式
        /// </summary>

        public string DateFormart { get; set; }

        /// <summary>
        /// 序列长度
        /// </summary>
        public int SerialLength { get; set; }
        /// <summary>
        /// 当前号码
        /// </summary>
        public int CurrentNumber { get; set; }
    }
}
