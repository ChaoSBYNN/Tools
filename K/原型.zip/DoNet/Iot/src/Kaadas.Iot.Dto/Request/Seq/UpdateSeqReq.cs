﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Seq
{
    /// <summary>
    /// 更新序列编号
    /// </summary>
    public class UpdateSeqReq
    {
        /// <summary>
        /// id
        /// </summary>
        [Required(ErrorMessage = "Id不能为空")]
        public string Id { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        [Required(ErrorMessage = "名称不能为空")]
        public string Name { get; set; }

        /// <summary>
        /// 时间格式
        /// </summary>
        [Required(ErrorMessage = "时间格式不能为空")]

        public string DateFormart { get; set; }

        /// <summary>
        /// 序列长度
        /// </summary>
        [Required(ErrorMessage = "序列长度不能为空")]
        public int SerialLength { get; set; }
        /// <summary>
        /// 当前号码
        /// </summary>
        [Required(ErrorMessage = "当前号码不能为空")]
        public int CurrentNumber { get; set; }
    }
}
