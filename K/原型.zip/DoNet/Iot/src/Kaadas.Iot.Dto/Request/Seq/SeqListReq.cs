﻿namespace Kaadas.Iot.Dto.Request.Seq
{
    /// <summary>
    /// 
    /// </summary>
    public class SeqReq : PageReq
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }
    }
}
