﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Log
{
    /// <summary>
    /// 异常日志查询
    /// </summary>
    public class ExceptionLogSearchReq : PageReq
    {
        /// <summary>
        /// 所属项目
        /// </summary>
        public ProjectTypeEnum? ProjectType { get; set; }

        /// <summary>
        /// 请求地址
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 请求信息
        /// </summary>
        public string RequestInfo { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public string ExceptionMessage { get; set; }
    }
}
