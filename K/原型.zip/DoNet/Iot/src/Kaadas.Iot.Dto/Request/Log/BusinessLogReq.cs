﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Log
{
    /// <summary>
    /// 业务日志请求参数
    /// </summary>
    public class BusinessLogReq : PageReq
    {
        /// <summary>
        /// 关键字
        /// </summary>
        public string KeyWord { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string OperUser { get; set; }

        /// <summary>
        /// 业务类型
        /// </summary>
        /// <returns></returns>
        public BusinessTypeEnum BusinessType { get; set; }

        /// <summary>
        /// 业务No
        /// </summary>
        public string BusinessNo { get; set; }

        /// <summary>
        /// 项目编号
        /// </summary>
        public ProjectTypeEnum ProjectNo { get; set; }

        /// <summary>
        /// 创建时间-开始时间
        /// </summary>
        public string BeginCreateTime { get; set; }

        /// <summary>
        /// 创建时间-截止时间
        /// </summary>
        public string EndCreateTime { get; set; }
    }
}
