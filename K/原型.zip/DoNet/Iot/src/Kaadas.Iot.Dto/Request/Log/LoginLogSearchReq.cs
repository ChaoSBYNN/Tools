﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Log
{
    /// <summary>
    /// 登录日志查询
    /// </summary>
    public class LoginLogSearchReq : PageReq
    {
        /// <summary>
        /// 登录账号
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 项目
        /// </summary>
        public ProjectTypeEnum? ProjectType { get; set; }

        /// <summary>
        /// 结果
        /// </summary>
        public ResultEnum? Result { get; set; }

        /// <summary>
        /// 登录开始时间
        /// </summary>
        public string LoginTimeBegin { get; set; }

        /// <summary>
        /// 登录结束时间
        /// </summary>
        public string LoginTimeEnd { get; set; }
    }
}
