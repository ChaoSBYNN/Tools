﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.Dto.Request.Authorize;
using System;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.LockAuthorize
{
    public class TotalCardAuthReq
    {
        /// <summary>
        /// 角色类型
        /// </summary>
        public AuthRoleTypeEnum RoleType { get; set; }

        /// <summary>
        /// 人员No
        /// </summary>
        public string PersonnelNo { get; set; }

        /// <summary>
        /// 人员名称
        /// </summary>
        public string PersonnelName { get; set; }

        /// <summary>
        /// 人员手机
        /// </summary>
        public string PersonnelPhone { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 卡片值，指纹为特征点地址
        /// </summary>
        public List<FingerPrint> FingerPrints { get; set; }

        /// <summary>
        /// 密钥类型
        /// </summary>
        public SecretTypeEnum SecretAuthType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? LimitedTimeEnd { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string OperHouseNo { get; set; }

        /// <summary>
        /// 是否全部房间
        /// </summary>
        public int IsAllRoom { get; set; }

        /// <summary>
        /// 自定义授权房间No
        /// </summary>
        public string[] RoomNos { get; set; }

        /// <summary>
        /// 是否强制开锁
        /// </summary>
        public int IsForceUnlock { get; set; }
    }
}
