﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Authorize
{
    public class UpdateAuthorizeReq
    {
        [Required(ErrorMessage = "Id不能为空！")]
        public string Id { get; set; }

        /// <summary>
        /// 密钥类型
        /// </summary>
        public SecretTypeEnum SecretAuthType { get; set; } = SecretTypeEnum.LimitedTime;

        /// <summary>
        /// 开始时间
        /// </summary>
        [Required(ErrorMessage = "开始时间不能为空！")]
        public DateTime? LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [Required(ErrorMessage = "结束时间不能为空！")]
        public DateTime? LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }
    }
}
