﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Authorize
{
    /// <summary>
    /// 新增授权
    /// </summary>
    public class AddAuthorizeReq
    {
        /// <summary>
        /// 房间NO
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 角色类型
        /// </summary>
        public AuthRoleTypeEnum RoleType { get; set; }

        /// <summary>
        /// 人员No
        /// </summary>
        public string PersonnelNo { get; set; }

        /// <summary>
        /// 人员名称
        /// </summary>
        public string PersonnelName { get; set; }

        /// <summary>
        /// 人员手机
        /// </summary>
        public string PersonnelPhone { get; set; }

       
        /// <summary>
        /// 门锁SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密钥值（密码）
        /// </summary>
        public string PwdValues { get; set; }

        /// <summary>
        /// 卡片值，指纹为特征点地址
        /// </summary>
        public List<FingerPrint> FingerPrints { get; set; }

        /// <summary>
        /// 密钥类型
        /// </summary>
        public SecretTypeEnum SecretAuthType { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }

        /// <summary>
        /// 是否本地在线录入指纹
        /// </summary>
        public int? IsLocalAuth { get; set; }

        /// <summary>
        /// 是否离线密码
        /// </summary>
        public bool IsOffline { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class FingerPrint
    {
        /// <summary>
        /// 密码名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 密码值
        /// </summary>
        public string Str { get; set; }
    }
}
