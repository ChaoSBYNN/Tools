﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Authorize
{
    public class AuthorizePageReq : PageReq
    {
        /// <summary>
        /// 房间No
        /// </summary>
        ///[Required(ErrorMessage = "房间编号不能为空！")]
        public string RoomNo { get; set; }

        /// <summary>
        /// 门锁SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum? PwdType { get; set; }
    }
}
