﻿namespace Kaadas.Iot.Dto.Request
{
    /// <summary>
    /// 分页请求
    /// </summary>
    public class PageReq
    {
        /// <summary>
        /// 页码
        /// </summary>
        public int Page { get; set; } = 1;

        /// <summary>
        /// 页条数
        /// </summary>
        public int Rows { get; set; } = 10;

        /// <summary>
        /// 排序字段
        /// </summary>
        public string SortBy { get; set; }

        /// <summary>
        /// 是否降序  1 - 是 0 - 否
        /// </summary>
        public int IsDesc { get; set; } = 1;
    }
}
