﻿namespace Kaadas.Iot.Dto.Request.Manager
{
    /// <summary>
    /// 批量添加用户对应角色
    /// </summary>
    public class EditUserInRoleReq
    {
        /// <summary>
        /// 
        /// </summary>
        public string RoleNos { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string UserNos { get; set; }
    }
}
