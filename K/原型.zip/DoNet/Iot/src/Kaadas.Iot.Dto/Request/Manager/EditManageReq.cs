﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Manager
{
    /// <summary>
    /// 编辑管理员信息
    /// </summary>
    public class EditManageReq
    {
        /// <summary>
        /// 
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 账号
        /// </summary>
        [Required(ErrorMessage = "账号不能为空")]
        public string Account { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        [Required(ErrorMessage = "用户名称不能为空")]
        public string UserName { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public SexEnum Sex { get; set; }

        /// <summary>
        /// 角色No 多个用,隔开
        /// </summary>
        public string Roles { get; set; }

        /// <summary>
        /// 部门No
        /// </summary>
        public string DepartmentNo { get; set; }

        /// <summary>
        /// 策略
        /// </summary>
        public string[] Strategys { get; set; }
    }
}
