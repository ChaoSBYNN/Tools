﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Manager
{
    public class EditManageStateReq
    {
        public string Id { get; set; }

        public StatusEnum UserStatus { get; set; }
    }
}
