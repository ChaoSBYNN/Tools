﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Manager
{
    /// <summary>
    /// 管理员信息列表入参
    /// </summary>
    public class ManagerPageReq : PageReq
    {
        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 角色No
        /// </summary>
        public string RoleNos { get; set; }

        /// <summary>
        /// 用户状态
        /// </summary>
        public StatusEnum? UserStatus { get; set; }
    }
}
