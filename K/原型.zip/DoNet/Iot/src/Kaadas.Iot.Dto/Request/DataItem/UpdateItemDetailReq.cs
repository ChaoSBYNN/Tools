﻿namespace Kaadas.Iot.Dto.Request.DataItem
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateItemDetailReq
    {
        /// <summary>
        /// 编辑id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// 排序编号
        /// </summary>
        public int SortCode { get; set; }

    }
}
