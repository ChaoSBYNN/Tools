﻿namespace Kaadas.Iot.Dto.Request.DataItem
{
    /// <summary>
    /// 
    /// </summary>
    public class DataItemListReq
    {
        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }
    }
}
