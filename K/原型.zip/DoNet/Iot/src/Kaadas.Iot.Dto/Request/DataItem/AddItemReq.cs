﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.DataItem
{
    /// <summary>
    /// 
    /// </summary>
    public class AddItemReq
    {
        /// <summary>
        /// 名称
        /// </summary>
        [Required(ErrorMessage = "名称不能为空")]
        public string Label { get; set; }

        /// <summary>
        /// 编号
        /// </summary>
        [Required(ErrorMessage = "编号不能为空")]
        public string Code { get; set; }

        /// <summary>
        /// 排序编号
        /// </summary>
        [Required(ErrorMessage = "排序编号不能为空")]
        public int SortCode { get; set; }

        /// <summary>
        /// 上级id
        /// </summary>
        [Required(ErrorMessage = "上级id不能为空")]
        public string ParentId { get; set; }
    }
}
