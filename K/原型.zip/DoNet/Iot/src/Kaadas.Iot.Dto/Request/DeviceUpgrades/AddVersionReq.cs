﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.DeviceUpgrades
{
    public class AddVersionReq : CreateBase
    {
        /// <summary>
        /// 设备类型
        /// </summary>
        public int? DeviceType { get; set; }
        /// <summary>
        /// 模块编号
        /// </summary>
        public int? DevNum { get; set; }
        /// <summary>
        /// 版本号
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 版本文件地址
        /// </summary>
        public string FileUrl { get; set; }
        /// <summary>
        /// 版本文件MD5
        /// </summary>
        public string FileMD5 { get; set; }
        /// <summary>
        /// 版本更新内容
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 上个版本文件编号
        /// </summary>
        public string LastVersionNo { get; set; }
        /// <summary>
        /// 上个版本版本号
        /// </summary>
        public string LastVersionName { get; set; }
        /// <summary>
        /// 依赖版本文件编号
        /// </summary>
        public string DependVersionNo { get; set; }
        /// <summary>
        /// 依赖版本版本号
        /// </summary>
        public string DependVersionName { get; set; }
    }
}
