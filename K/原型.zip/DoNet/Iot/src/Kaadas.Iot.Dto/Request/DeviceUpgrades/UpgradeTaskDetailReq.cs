﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.DeviceUpgrades
{
    public class UpgradeTaskDetailReq
    {
        /// <summary>
        /// 任务编号
        /// </summary>
        public string TaskNo { get; set; }

        /// <summary>
        /// 任务状态
        /// </summary>
        public int? Status { get; set; }

    }
}
