﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.DeviceUpgrades
{
    public class VersionPageReq : PageReq
    {
        public string VersionName { get; set; }
    }
}
