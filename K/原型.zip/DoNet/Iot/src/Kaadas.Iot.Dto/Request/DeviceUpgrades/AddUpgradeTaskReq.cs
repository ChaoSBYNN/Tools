﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.DeviceUpgrades
{
    public class AddUpgradeTaskReq
    {

        /// <summary>
        /// 版本信息编号
        /// </summary>
        public string VersionNo { get; set; }

        /// <summary>
        /// 版本号
        /// </summary>
        public string VersionName { get; set; }
        /// <summary>
        /// 设备信息
        /// </summary>
        public List<UpgradeTaskDetail> Details { get; set; }

    }

    public class UpgradeTaskDetail 
    { 
        /// <summary>
        /// ESN
        /// </summary>
        public string ESN { get; set; }
        /// <summary>
        /// SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }
        /// <summary>
        /// 固件版本
        /// </summary>
        public string SoftwareVer { get; set; }
        /// <summary>
        /// 硬件版本
        /// </summary>
        public string HardwareVer { get; set; }
    }
}
