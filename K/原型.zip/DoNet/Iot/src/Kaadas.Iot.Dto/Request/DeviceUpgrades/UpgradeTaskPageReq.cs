﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Dto.Request.DeviceUpgrades
{
    public class UpgradeTaskPageReq : PageReq
    {
        /// <summary>
        /// 版本号
        /// </summary>
        public string VersionName { get; set; }
        /// <summary>
        /// 任务状态
        /// </summary>
        public int? Status { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? EndTime { get; set; }
    }
}
