﻿namespace Kaadas.Iot.Dto.Request.Worker.Manage
{
    /// <summary>
    /// 师傅列表入参
    /// </summary>
    public class WorkerPageReq : PageReq
    {
        /// <summary>
        /// 师傅姓名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 师傅电话
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 省编号
        /// </summary>
        public string ProviceNo { get; set; }

        /// <summary>
        /// 城市编号
        /// </summary>
        public string CityNo { get; set; }

        /// <summary>
        /// 区域编号
        /// </summary>
        public string RegionNo { get; set; }

        /// <summary>
        /// 团队编号
        /// </summary>
        public string TeamNo { get; set; }
    }
}
