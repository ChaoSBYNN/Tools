﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.Dto.Request.Worker.Worker
{
    public class EditWorkerStatusReq
    {
        public string Id { get; set; }

        public StatusEnum Status { get; set; }
    }
}
