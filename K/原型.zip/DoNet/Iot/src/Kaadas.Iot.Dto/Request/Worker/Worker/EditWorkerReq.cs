﻿using Kaadas.Iot.Dto.Dto.Worker;
using System.Collections.Generic;

namespace Kaadas.Iot.Dto.Request.Worker.Worker
{
    /// <summary>
    /// 编辑师傅信息
    /// </summary>
    public class EditWorkerReq
    {
        public string Id { get; set; }
        /// <summary>
        /// 师傅信息
        /// </summary>
        public WorkerInfoDto WorkerInfo { get; set; }
        /// <summary>
        /// 服务区域
        /// </summary>
        public List<ServiceAreaDto> ServiceAreas { get; set; }
    }
}
