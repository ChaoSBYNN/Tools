﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Worker.Worker
{
    public class ForgotCodeReq
    {
        /// <summary>
        /// 手机号
        /// </summary>
        [Required(ErrorMessage = "手机号不能为空")]
        public string Phone { get; set; }

        /// <summary>
        /// 验证码KEY
        /// </summary>
        [Required(ErrorMessage = "无效的请求！")]
        public string CaptchaKey { get; set; }

        /// <summary>
        /// 图形验证码
        /// </summary>
        [Required(ErrorMessage = "图形验证码不能空")]
        public string CaptchaCode { get; set; }
    }
}
