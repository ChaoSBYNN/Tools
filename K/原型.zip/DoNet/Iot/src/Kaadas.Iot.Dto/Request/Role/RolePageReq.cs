﻿namespace Kaadas.Iot.Dto.Request.Role
{
    /// <summary>
    /// 角色分页请求
    /// </summary>
    public class RolePageReq : PageReq
    {
        /// <summary>
        /// 角色名称
        /// </summary>
        public string Name { get; set; }
    }
}
