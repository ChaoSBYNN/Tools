﻿using System.ComponentModel.DataAnnotations;

namespace Kaadas.Iot.Dto.Request.Role
{
    /// <summary>
    /// 编辑角色入参
    /// </summary>
    public class EditRoleReq
    {
        public string Id { get; set; }
        public string No { get; set; }
        /// <summary>
        /// 角色名称
        /// </summary>
        /// <returns></returns>
        [Required(ErrorMessage = "角色名称不能为空")]
        public string Name { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        /// <returns></returns>
        public string Remarks { get; set; }

        /// <summary>
        /// 已有权限菜单编号
        /// </summary>
        public string[] MenuNos { get; set; }

        /// <summary>
        /// 角色等级
        /// </summary>
        public string[] Strategys { get; set; }
    }
}
