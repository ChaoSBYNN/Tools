﻿using Kaadas.Iot.CommonDto.Interfaces;
using Kaadas.Iot.DB.Entitys.SqlServer;
using Kaadas.Iot.DB.IRepositorys.SqlServer;
using System;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys
{
    public interface IUnitOfWork : IDisposable, IDenpendency
    {
        IBaseRepository<TEntity> Repository<TEntity>() where TEntity : BaseEntity, new();

        void BeginTransaction();

        int SaveChanges();

        Task<int> SaveChangesAsync();

        int Commit();

        Task<int> CommitAsync();

        Task RollbackAsync();
    }
}
