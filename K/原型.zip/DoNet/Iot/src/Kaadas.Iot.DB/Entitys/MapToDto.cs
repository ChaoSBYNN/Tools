﻿using AutoMapper;
using Kaadas.Iot.DB.Entitys.SqlServer.DMS;
using Kaadas.Iot.Dto.Mqtt.Events.Post;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys
{
   public class MapToDto : Profile
    {
            public MapToDto()
            {
                CreateMap<LockWirelessLogDto, NetDeviceEntity>()
                .ForAllMembers(opt => opt.Condition((src,dest,sreMernber)=> sreMernber!=null));
        }

        
    }
}
