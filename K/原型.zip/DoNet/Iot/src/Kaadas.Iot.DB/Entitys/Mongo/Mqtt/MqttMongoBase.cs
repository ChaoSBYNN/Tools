﻿namespace Kaadas.Iot.DB.Entitys.Mongo.Mqtt
{
    public class MqttMongoBase : BaseMongo
    {
        /// <summary>
        /// 消息ID
        /// </summary>
        public string MsgId { get; set; } 

        /// <summary>
        /// 接收消息主题
        /// </summary>
        public string Topic { get; set; }

        /// <summary>
        /// 消息内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 消息级别
        /// </summary>
        public int Qos { get; set; }
    }
}
