﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Kaadas.Iot.DB.Entitys.Mongo.Mqtt
{
    /// <summary>
    /// MQTT接收消息实体
    /// </summary>
    public class MqttReceiveMsgEntity : MqttMongoBase
    {
        /// <summary>
        /// 消息来源 ClientId 
        /// </summary>
        public string From { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime SendTime{ get; set; }

        /// <summary>
        /// 接收时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime RecieveTime { get; set; } = DateTime.Now;
    }
}
