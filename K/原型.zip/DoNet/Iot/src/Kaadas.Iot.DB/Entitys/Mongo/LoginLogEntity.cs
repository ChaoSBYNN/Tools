﻿using Kaadas.Iot.CommonDto.Enums;
using MongoDB.Bson.Serialization.Attributes;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    [BsonIgnoreExtraElements]
    public class LoginLogEntity : BaseMongo
    {
        /// <summary>
        /// 账号
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 项目类型
        /// </summary>
        public ProjectTypeEnum ProjectType { get; set; }

        /// <summary>
        /// 项目名
        /// </summary>
        public string ProjectName { get; set; }

        /// <summary>
        /// 登录平台
        /// </summary>
        public RequestPlatformEnum LoginPlatform { get; set; }

        /// <summary>
        /// IP地址
        /// </summary>
        public string IPAddress { get; set; }

        /// <summary>
        /// 结果
        /// </summary>
        public ResultEnum Result { get; set; } = ResultEnum.Fail;

        /// <summary>
        /// 备注
        /// </summary>
        /// <returns></returns>
        public string Remark { get; set; }
    }
}
