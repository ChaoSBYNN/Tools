﻿using Kaadas.Iot.CommonDto.Enums;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// 设备操作记录
    /// </summary>
    public class DeviceOperLogEntity : BaseMongo
    {
        /// <summary>
        /// 所属项目
        /// </summary>
        public ProjectTypeEnum ProjectType { get; set; }

        /// <summary>
        /// 联网编号
        /// </summary>
        public string NetNo { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 操作类型
        /// </summary>
        public DeviceOperTypeEnum Type { get; set; }

        /// <summary>
        /// 用户类型
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        /// <summary>
        /// 用户编号
        /// </summary>
        public string UserNo { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary> 
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime OpTime { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
