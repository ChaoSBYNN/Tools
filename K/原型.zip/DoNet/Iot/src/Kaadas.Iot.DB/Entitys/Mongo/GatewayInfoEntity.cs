﻿using MongoDB.Bson.Serialization.Attributes;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// 网关信息
    /// </summary>
    [BsonIgnoreExtraElements]
    public class GatewayInfoEntity : BaseMongo
    {
        /// <summary>
        /// 网关ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 保存信息
        /// </summary>
        public string Info { get; set; }
    }
}
