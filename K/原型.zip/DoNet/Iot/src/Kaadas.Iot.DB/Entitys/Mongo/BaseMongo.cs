﻿using Kaadas.Iot.CommonDto.Attributes;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    public class BaseMongo
    {
        public ObjectId _id { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public long _updatetime { get; set; }

        /// <summary>
        /// 创建时间 = TTL INDEX 可使用此字段
        /// </summary> 
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        [DefaultSort]
        public DateTime _kdscreatetime { get; set; }
    }
}
