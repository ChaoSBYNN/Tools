﻿using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Kaadas.Iot.DB.Entitys.Mongo.Mqtt
{
    /// <summary>
    /// MQTT 推送消息
    /// </summary>
    public class MqttPublishMsgEntity : MqttMongoBase
    {
        /// <summary>
        /// 发送客户端Id 
        /// </summary>
        public string PublishClientId { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime PublishTime { get; set; } = DateTime.Now;
    }
}
