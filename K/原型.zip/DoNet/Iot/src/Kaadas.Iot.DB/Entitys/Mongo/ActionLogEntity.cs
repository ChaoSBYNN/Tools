﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// Action请求log
    /// </summary>
    public class ActionLogEntity : BaseMongo
    {
        /// <summary>
        /// 消息ID
        /// </summary>
        public string MsgId { get; set; } 

        /// <summary>
        /// 路径
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// QueryString
        /// </summary>
        public string QueryString { get; set; }

        /// <summary>
        /// 方法
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 请求体
        /// </summary>
        public object Body { get; set; }

        /// <summary>
        /// 是否异常
        /// </summary>
        public bool IsException { get; set; }

        /// <summary>
        /// 操作人编号
        /// </summary>
        public string OperNo { get; set; }

        /// <summary>
        /// 操作人名
        /// </summary>
        public string OperName { get; set; }
    }
}
