﻿using Kaadas.Iot.CommonDto.Enums;
using MongoDB.Bson.Serialization.Attributes;

namespace Kaadas.Iot.DB.Entitys.Mongo.Mqtt
{
    /// <summary>
    /// 网关预警
    /// </summary>
    [BsonIgnoreExtraElements] 
    public class GatewayWarningEntity : BaseMongo
    {
        /// <summary>
        /// 预警topic
        /// </summary>
        public string Topic { get; set; }

        /// <summary>
        /// 网关ESN
        /// </summary>
        public string GatewayESN { get; set; }

        /// <summary>
        /// 预警类型
        /// </summary>
        public GwWarningTypeEnum Type { get; set; } 

        /// <summary>
        /// 预警设备ESN
        /// </summary>
        public string ESN { get; set; }
    }
}
