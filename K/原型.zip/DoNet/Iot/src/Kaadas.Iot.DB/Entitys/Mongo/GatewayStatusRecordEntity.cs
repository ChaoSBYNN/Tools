﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// 网关状态记录表
    /// </summary>
    public class GatewayStatusRecordEntity : BaseMongo
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备状态
        /// </summary>
        public DeviceStateEnum State{ get; set; }
    }
}
