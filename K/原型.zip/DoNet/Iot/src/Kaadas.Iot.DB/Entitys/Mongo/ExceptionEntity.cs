﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// 异常记录
    /// </summary>
    public class ExceptionEntity : BaseMongo
    {
        /// <summary>
        /// 消息ID
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 项目枚举
        /// </summary>
        public ProjectTypeEnum ProjectType { get; set; }

        /// <summary>
        /// 项目名称
        /// </summary>
        public string ProjectTypeName { get; set; }

        /// <summary>
        /// 路径
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// QueryString
        /// </summary>
        public string QueryString { get; set; }

        /// <summary>
        /// 方法
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 请求体
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 异常明细
        /// </summary>
        public string Exception { get; set; }
    }
}
