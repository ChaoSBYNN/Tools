﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// Action 结果日志
    /// </summary>
    public class ActionResultEntity : BaseMongo
    { 
        /// <summary>
        /// 消息ID 
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 状态码
        /// </summary>
        public ReqResultEnum Code { get; set; }

        /// <summary>
        /// 返回消息
        /// </summary>
        public string Msg { get; set; }

        /// <summary>
        /// 返回消息
        /// </summary>
        public string Data { get; set; }
    }
}
