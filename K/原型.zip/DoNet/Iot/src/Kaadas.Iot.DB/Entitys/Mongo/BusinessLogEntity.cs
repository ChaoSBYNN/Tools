﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Enums;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    /// <summary>
    /// 业务操作日志
    /// </summary>
    public class BusinessLogEntity : BaseMongo
    {

        /// <summary>
        /// 业务No
        /// </summary>
        public string BusinessNo { get; set; }
        /// <summary>
        /// 操作人名称
        /// </summary>
        /// <returns></returns>
        public string OperationUser { get; set; }
        /// <summary>
        /// 操作类型
        /// </summary>
        /// <returns></returns>
        public OperationTypeEnum OperationType { get; set; }
        /// <summary>
        /// 操作类容
        /// </summary>
        /// <returns></returns>
        public string OperationContent { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        /// <returns></returns>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        [DefaultSort]
        public DateTime OperationDate { get; set; } = DateTime.Now;
        /// <summary>
        /// 操作人编号
        /// </summary>
        /// <returns></returns>
        public string OperationUserNo { get; set; }
        /// <summary>
        /// 业务类型
        /// </summary>
        /// <returns></returns>
        public BusinessTypeEnum BusinessType { get; set; }
        /// <summary>
        /// 操作人IP地址
        /// </summary>
        /// <returns></returns>
        public string OperationIP { get; set; }
        /// <summary>
        /// 项目名称
        /// </summary>
        /// <returns></returns>
        public ProjectTypeEnum ProjectType { get; set; }
    }
}
