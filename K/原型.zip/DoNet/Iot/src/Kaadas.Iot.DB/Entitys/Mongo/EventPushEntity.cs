﻿using Kaadas.Iot.CommonDto.Models;
using Kaadas.Iot.Dto.Dto.OpenApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.Mongo
{
    public class EventPushEntity : BaseMongo
    {
        /// <summary>
        /// 请求数据
        /// </summary>
        public DeviceEventPushDto RequestMsg { get; set; }

        /// <summary>
        /// 返回数据
        /// </summary>
        public KaadasResult ResponseMsg { get; set; }

        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string DeviceESN { get; set; }
    }
}
