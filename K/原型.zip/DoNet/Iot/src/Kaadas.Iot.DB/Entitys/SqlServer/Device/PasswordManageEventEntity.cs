﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 电子密钥管理上报
    /// </summary>
    [Table("DMS_PasswordManageEvent")]
    public class PasswordManageEventEntity : BaseEntity
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 密码id
        /// </summary>
        public int PasswordId { get; set; }

        /// <summary>
        /// 消息上报时间
        /// </summary>
        public DateTime MsgTime { get; set; }

        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 密码操作时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密码操作类型
        /// </summary>
        public PwdOperTypeEnum PwdOperType { get; set; }
    }
}
