﻿using System;
using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer;
using System.ComponentModel.DataAnnotations.Schema;


namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 创 建：超级管理员
    /// 日 期：2024/2/20 17:47:21
    /// 描 述：
    /// </summary>

    [Table("DMS_WMReadingRecord")]
    public class WMReadingRecordEntity : BaseEntity
    {
        /// <summary>
        /// 
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 读数
        /// </summary>
        public decimal Reading { get; set; }

        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 上报时间
        /// </summary>
        public DateTime ReportTime { get; set; }

        /// <summary>
        /// 读数上报类型
        /// </summary>
        public WMReadingRecordTypeEnum ReadingRecordType { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

    }

}
