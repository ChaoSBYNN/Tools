﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单房间信息
    /// </summary>
    [Table("WOM_WorkRoom")]
    public class WorkRoomEntity : BaseModifyEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 绑定设备数
        /// </summary>
        public int BindDeviceCount { get; set; } = 0;
    }
}
