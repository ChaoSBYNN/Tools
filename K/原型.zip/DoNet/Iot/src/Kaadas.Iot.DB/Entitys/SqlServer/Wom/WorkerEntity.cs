﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 师傅
    /// </summary>
    [Table("WOM_Worker")]
    public class WorkerEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 师傅编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 师傅名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 师傅手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 身份证号
        /// </summary>
        public string IDCardNo { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public SexEnum Sex { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public StatusEnum Status { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 团队编号
        /// </summary>
        public string TeamNo { get; set; }

        /// <summary>
        /// 身份
        /// </summary>
        public WorkerIdentityEnum Identity { get; set; }

        /// <summary>
        /// 是否修改密码
        /// </summary>
        public int InitPassword { get; set; }

        /// <summary>
        /// 微信OpenId
        /// </summary>
        public string OpenId { get; set; }

        /// <summary>
        /// 微信UnionId
        /// </summary>
        public string UnionId { get; set; }
    }
}
