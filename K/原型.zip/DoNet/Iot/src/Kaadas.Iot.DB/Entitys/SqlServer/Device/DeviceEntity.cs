﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 设备
    /// </summary>
    [Table("DMS_Device")]
    public class DeviceEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        /// <returns></returns>
        public string No { get; set; }

        /// <summary>
        /// 设备型号
        /// </summary>
        /// <returns></returns>
        public string ModelNum { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        /// <returns></returns>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 来源产商
        /// </summary>
        /// <returns></returns>
        public string FromFactory { get; set; }

        /// <summary>
        /// 通讯类型（锁属性）
        /// </summary>
        /// <returns></returns>
        public string CommunicateType { get; set; }

        /// <summary>
        /// 开锁方式（锁属性）,多种,隔开  
        /// PwdTypeEnum 枚举
        /// </summary>
        /// <returns></returns>
        public string OpenWays { get; set; }

        /// <summary>
        /// 通讯协议（网关属性）
        /// </summary>
        /// <returns></returns>
        public ProtocolEnum? Protocol { get; set; }

        /// <summary>
        /// 联网方式（网关属性）多种,隔开
        /// NetworkModeEnum 枚举
        /// </summary>
        /// <returns></returns>
        public string NetworkMode { get; set; }

        /// <summary>
        /// 电表 - 最大电流
        /// </summary>
        public string MaxElectric { get; set; }
    }
}
