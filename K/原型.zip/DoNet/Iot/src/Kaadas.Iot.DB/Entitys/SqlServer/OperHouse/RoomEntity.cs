﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.OperHouse
{
    [Table("RMS_Room")]
    public class RoomEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        public string No { get; set; }
        /// <summary>
        /// 房间类型（1：房间；2：公区）
        /// </summary>
        public RoomTypeEnum RoomType { get; set; }
        /// <summary>
        /// 房间状态（招租；已入住；暂停；）
        /// </summary>
        public RoomStatusEnum RoomStatus { get; set; }
        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }
        /// <summary>
        /// 楼层
        /// </summary>
        public int Floor { get; set; }
        /// <summary>
        /// 房间名称（房间号）
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 设备数量
        /// </summary>
        public int DeviceQuantity { get; set; }

    }
}
