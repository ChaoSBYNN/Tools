﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 设备产品
    /// </summary>
    [Table("DMS_DeviceProduct")]
    public class DeviceProductEntity : BaseEntity
    {
        /// <summary>
        /// 设备编号
        /// </summary>
        /// <returns></returns>
        public string DeviceNo { get; set; }
        /// <summary>
        /// 产品颜色
        /// </summary>
        /// <returns></returns>
        public string Color { get; set; }
        /// <summary>
        /// 产品料号
        /// </summary>
        /// <returns></returns>
        public string ProoductNo { get; set; }
    }
}
