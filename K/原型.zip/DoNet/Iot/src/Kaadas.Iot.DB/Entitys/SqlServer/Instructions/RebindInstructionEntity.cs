﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Consts;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Instructions
{
    /// <summary>
    /// 网关重绑指令
    /// </summary> 
    [Table("DMS_RebindInstruction")]
    [Instruction(MqttMethodConst.GATEWAY_REBIND, ExpireSeconds = TimeConst.TWO_HUNDRED_SECONDS, IsMqttIgnore = true)]
    public class RebindInstructionEntity : BaseInstructionEntity
    {
        /// <summary>
        /// 工单编号 - 师傅小程序下发指令不为空
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 原网关SN
        /// </summary>
        public string SourceSN { get; set; }

        /// <summary>
        /// 新网关SN
        /// </summary>
        public string NewSN { get; set; }

        /// <summary>
        /// 新网关设备编号
        /// </summary>
        public string NewDeviceNo { get; set; }
    }
}
