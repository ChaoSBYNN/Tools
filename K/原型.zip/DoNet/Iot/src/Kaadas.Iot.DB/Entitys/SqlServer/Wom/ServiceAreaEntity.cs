﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 团队/师傅 服务区域
    /// </summary>
    [Table("WOM_ServiceArea")]
    public class ServiceAreaEntity : BaseModifyEntity
    {
        /// <summary>
        /// 团队/师傅编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 所属类型
        /// </summary>
        public BelongTypeEnum BelongType { get; set; }

        /// <summary>
        /// 省编号
        /// </summary>
        public string ProviceNo { get; set; }

        /// <summary>
        /// 省名称
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// 城市编号
        /// </summary>
        public string CityNo { get; set; }

        /// <summary>
        /// 城市名称
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 区域编号
        /// </summary>
        public string RegionNo { get; set; }

        /// <summary>
        /// 区域名称
        /// </summary>
        public string RegionName { get; set; }
    }
}
