﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 创 建：超级管理员
    /// 日 期：2024/2/20 17:45:44
    /// 描 述：
    /// </summary>

    [Table("DMS_EMReadingRecord")]
    public class EMReadingRecordEntity : BaseEntity
    {
        /// <summary>
        /// 
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 读数
        /// </summary>
        public decimal Reading { get; set; }

        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 上报时间
        /// </summary>
        public DateTime ReportTime { get; set; }

        /// <summary>
        /// 读数上报类型
        /// </summary>
        public EMReadingRecordTypeEnum ReadingRecordType { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        
    }

}
