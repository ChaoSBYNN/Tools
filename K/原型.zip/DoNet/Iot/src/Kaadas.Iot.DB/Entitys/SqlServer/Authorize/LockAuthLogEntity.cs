﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Consts;
using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer.Instructions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Authorize
{
    /// <summary>
    /// 密码管理指令
    /// </summary>
    [Table("RMS_LockAuthLog")]
    [Instruction(MqttMethodConst.LOCK_PASSWORD_EDIT, MqttMethodConst.LOCK_PASSWORD_SET)]
    public class LockAuthLogEntity : BaseInstructionEntity
    {

        public PwdOptCodeEnum PwdOptCode { get; set; }

        public string SecretFId { get; set; }

        /// <summary>
        /// 门锁SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 密钥Id（单个门锁内唯一）
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密码类型1：普通用户（默认）;2：管理员用户
        /// </summary>
        public int UserType { get; set; } = 1;

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime LimitedTimeEnd { get; set; }

        /// <summary>
        /// 有效次数
        /// </summary>
        public int? Number { get; set; }

        /// <summary>
        /// 日掩码，0~6对应周日 ~周六，周计划包含
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 密钥状态
        /// </summary>
        public SecretStatusEnum LockStatus { get; set; }

        /// <summary>
        /// 授权No
        /// </summary>
        public string AuthNo { get; set; }

    }
}
