﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单数据
    /// </summary>
    [Table("WOM_WorkInfo")]
    public class WorkInfoEntity : BaseModifyEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 工单类型
        /// </summary>
        public WorkTypeEnum WorkType { get; set; }

        /// <summary>
        /// 工单状态
        /// </summary>
        public WorkStatusEnum WorkStatus { get; set; }

        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 下单人
        /// </summary>
        public string CreatorName { get; set; }

        /// <summary>
        /// 下单人手机
        /// </summary>
        public string CreatorPhone { get; set; }

        /// <summary>
        /// 现场联系人
        /// </summary>
        public string ContactName { get; set; }

        /// <summary>
        /// 现场联系人电话
        /// </summary>
        public string ContactPhone { get; set; }

        /// <summary>
        /// 期望时间
        /// </summary>
        public DateTime ExpectTime { get; set; }

        /// <summary>
        /// 安维团队编号
        /// </summary>
        public string TeamNo { get; set; }

        /// <summary>
        /// 工单备注
        /// </summary>
        public string WorkRemark { get; set; }

        /// <summary>
        /// 指派团队时间
        /// </summary>
        public DateTime? AssignTeamTime { get; set; }

        /// <summary>
        /// 指派师傅时间
        /// </summary>
        public DateTime? AssignWorkerTime { get; set; }

        /// <summary>
        /// 预约时间
        /// </summary>
        public DateTime? AppointTime { get; set; }

        /// <summary>
        /// 预约时间段
        /// </summary>
        public string AppointTimeSlot { get; set; }

        /// <summary>
        /// 签到时间
        /// </summary>
        public DateTime? SignTime { get; set; }

        /// <summary>
        /// 签到地址
        /// </summary>
        public string SignAddress { get; set; }

        /// <summary>
        /// 完工时间
        /// </summary>
        public DateTime? DoneTime { get; set; }

        /// <summary>
        /// 安装备注
        /// </summary>
        public string InstallRemark { get; set; }

        /// <summary>
        /// 取消安装时间
        /// </summary>
        public DateTime? CancelTime { get; set; }

        /// <summary>
        /// 取消安装原因  -- 字典数据
        /// </summary>
        public string CancelReasonCode { get; set; }

        /// <summary>
        /// 取消安装备注 - 字典描述，其他 为输入，
        /// </summary>
        public string CancelRemark { get; set; }

        /// <summary>
        /// 结束时间 - 即 核销审核/取消审核时间
        /// </summary>
        public DateTime? FinishTime { get; set; }
    }
}
