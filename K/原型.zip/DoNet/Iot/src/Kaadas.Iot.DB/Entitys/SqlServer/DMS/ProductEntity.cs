﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 产品表
    /// </summary>
    [Table("DMS_Product")]
    public class ProductEntity : BaseModifyEntity
    {
        /// <summary>
        /// boss同步时间
        /// </summary>
        public DateTime BossAsyncTime { get; set; }

        /// <summary>
        /// 产品类型(1=门锁；2=网关；3=水表；4=电表）
        /// </summary>
        public int ProductType { get; set; }

        /// <summary>
        /// 产品ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 产品SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 产品PID
        /// </summary>
        public string PID { get; set; }

        /// <summary>
        /// 产品mac
        /// </summary>
        public string Mac { get; set; }

        /// <summary>
        /// 产品研发型号
        /// </summary>
        public string Model { get; set; }


        /// <summary>
        /// 产品密钥
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 客户(1=凯迪仕；18=飞利浦)
        /// </summary>
        public int Customer { get; set; }

        /// <summary>
        /// 模块初始化版本，格式：”{研发型号}_{模组编号}_{版本}”
        /// </summary>
        public string VerList { get; set; }

    }
}
