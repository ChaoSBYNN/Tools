﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    /// <summary>
    /// 管理员
    /// </summary>
    [Table("K_Manager")]
    public class ManagerEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 用户编号
        /// </summary> 
        public string No { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 账号
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string PassWord { get; set; }

        /// <summary>
        /// 用户性别
        /// </summary>
        public SexEnum Sex { get; set; }

        /// <summary>
        /// 用户状态
        /// </summary>
        public StatusEnum UserStatus { get; set; }

        /// <summary>
        /// 是否管理员
        /// </summary>
        public int IsAdmin { get; set; }

        /// <summary>
        /// 1=已修改过密码，0=没有修改过密码
        /// </summary>
        public int InitPassword { get; set; }

        /// <summary>
        /// 部门No
        /// </summary>
        public string DepartmentNo { get; set; }
    }
}
