﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Authorize
{

    /// <summary>
    /// 密钥信息
    /// </summary>
    [Table("RMS_SecretKeyInfo")]
    public class SecretKeyInfoEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 密码No
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 门锁ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 门锁SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 密钥Id（单个门锁内唯一）
        /// </summary>
        public int PwdId { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }

        /// <summary>
        /// 密钥值（密码，卡片值，指纹为特征点地址）
        /// </summary>
        public string PwdValue { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime LimitedTimeBegin { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime LimitedTimeEnd { get; set; }

        /// <summary>
        /// 周期，周期性密码特有
        /// </summary>
        public string PeriodTime { get; set; }

        /// <summary>
        /// 次数，限次密码特有
        /// </summary>
        public int? Number { get; set; }

        /// <summary>
        /// 密钥状态
        /// </summary>
        public SecretStatusEnum Status { get; set; }

        /// <summary>
        /// 授权No
        /// </summary>
        public string AuthNo { get; set; }

        /// <summary>
        /// 密码名称
        /// </summary>
        public string SecretName { get; set; }

        /// <summary>
        /// 是否管理员密码
        /// </summary>
        public int IsAdmin { get; set; }

        /// <summary>
        /// 当前指令状态
        /// </summary>
        public string Instruct { get; set; }
    }
}
