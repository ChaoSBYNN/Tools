﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单房间设备信息
    /// </summary>
    [Table("WOM_WorkRoomDevice")]
    public class WorkRoomDeviceEntity : BaseModifyEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string DeviceNo { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 设备名
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// 师傅编号
        /// </summary>
        public string WorkerNo { get; set; }

        /// <summary>
        /// 绑定时间
        /// </summary>
        public DateTime? BindTime { get; set; }

        /// <summary>
        /// 绑定网关ESN
        /// </summary>
        public string BindGatewayESN { get; set; }

        /// <summary>
        /// 绑定网关SN
        /// </summary>
        public string BindGatewaySN { get; set; }

        /// <summary>
        /// 故障描述 维修/拆卸工单数据
        /// </summary>
        public string FaultDesc { get; set; }

        /// <summary>
        /// 安维图片列表 多张，隔开
        /// </summary>
        public string ImgUrls { get; set; }

        /// <summary>
        /// 更换设备SN
        /// </summary>
        public string ReplaceSN { get; set; }

        /// <summary>
        /// 更换设备名称
        /// </summary>
        public string ReplaceDeviceName { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
