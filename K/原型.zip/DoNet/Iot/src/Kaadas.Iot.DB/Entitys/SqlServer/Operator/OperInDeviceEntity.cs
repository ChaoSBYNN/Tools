﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Operator
{
    [Table("RMS_OperInDevice")]
    public class OperInDeviceEntity : BaseEntity
    {
        public string OperNo { get; set; }

        public DeviceTypeEnum DeviceType { get; set; }
    }
}
