﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单标签
    /// </summary>
    [Table("WOM_WorkLabel")]
    public class WorkLabelEntity : BaseEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 标签
        /// </summary>
        public WorkLabelEnum Label { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
