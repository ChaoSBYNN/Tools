﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer;
using System;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// 创 建：超级管理员
/// 日 期：2023/11/8 10:40:02
/// 描 述：Upgrade Task Detail
/// </summary>
[Table("OTA_UpgradeTaskDetail")]
public class UpgradeTaskDetailEntity : BaseDeleteEntity
{

    /// <summary>
    /// 升级任务明细编号
    /// </summary>
    public string No { get; set; }

    /// <summary>
    /// 升级任务编号
    /// </summary>
    public string TaskNo { get; set; }

    /// <summary>
    /// 版本信息编号
    /// </summary>
    public string VersionNo { get; set; }

    /// <summary>
    /// 设备SN
    /// </summary>
    public string SN { get; set; }

    /// <summary>
    /// 设备ESN
    /// </summary>
    public string ESN { get; set; }

    public DevNumEnum DevNum { get; set; }

    /// <summary>
    /// 设备名称
    /// </summary>
    public string DeviceName { get; set; }

    /// <summary>
    /// 升级状态
    /// </summary>
    public DeviceUpgradeStatusEnum? UpgradeStatus { get; set; } = DeviceUpgradeStatusEnum.InstructionIssued;

    /// <summary>
    /// 状态更新时间
    /// </summary>
    public DateTime? UpdateStatusTime { get; set; }

    /// <summary>
    /// 软件版本号
    /// </summary>
    public string SoftwareVer { get; set; }

    /// <summary>
    /// 硬件版本号
    /// </summary>
    public string HardwareVer { get; set; }

    /// <summary>
    /// 上一次升级时间
    /// </summary>
    public DateTime? LastUpgradeTime { get; set; }

    /// <summary>
    /// 绑定网关的SN
    /// </summary>
    public string BindGatewaySN { get; set; }

    /// <summary>
    /// 绑定网关的ESN
    /// </summary>
    public string BindGatewayESN { get; set; }
}