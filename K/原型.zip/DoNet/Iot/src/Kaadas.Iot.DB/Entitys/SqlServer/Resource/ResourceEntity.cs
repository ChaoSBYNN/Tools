﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Resource
{
    /// <summary>
    /// 资源管理类
    /// </summary>
    [Table("K_Resource")]
    public class ResourceEntity : BaseDeleteEntity
    {

        /// <summary>
        /// 资源MD5值
        /// </summary>
        public string MD5 { get; set; }

        /// <summary>
        /// OSS 存储空间名称
        /// </summary>
        public string BucketName { get; set; }

        /// <summary>
        /// 文件 对象名
        /// </summary>
        public string ObjectName { get; set; }

        /// <summary>
        /// 资源状态 
        /// </summary>
        public ResourceStatusEnum ResourceStatus { get; set; } = ResourceStatusEnum.NotUploaded;

        /// <summary>
        /// 图片地址MD5 唯一索引 修改通过地址加密MD5 通过此字段修改
        /// </summary>
        public string PathMD5 { get; set; }

        /// <summary>
        /// 地址访问地址 - 冗余使用 可根据BucketName 以及 ObjectName 生成新的访问地址
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// 地址访问超时时间
        /// </summary>
        public DateTime? ExpireTime { get; set; }

        /// <summary>
        /// 来源 项目
        /// </summary>
        public ProjectTypeEnum FromProjectType { get; set; }

        /// <summary>
        /// 资源类型
        /// </summary>
        public ResourceTypeEnum ResourceType { get; set; }

        /// <summary>
        /// 文件大小 单位Byte
        /// </summary>
        public int FileSize { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
