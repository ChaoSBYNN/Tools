﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Authorize
{
    /// <summary>
    /// 门锁授权信息
    /// </summary>
    [Table("RMS_LockAuthorizeInfo")]
    public class LockAuthorizeInfoEntity : BaseDeleteEntity
    {

        /// <summary>
        /// 授权No
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 房间NO
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 角色类型
        /// </summary>
        public AuthRoleTypeEnum RoleType { get; set; }

        /// <summary>
        /// 人员No
        /// </summary>
        public string PersonnelNo { get; set; }

        /// <summary>
        /// 人员名称
        /// </summary>
        public string PersonnelName { get; set; }

        /// <summary>
        /// 人员手机
        /// </summary>
        public string PersonnelPhone { get; set; }

        /// <summary>
        /// 来源
        /// </summary>
        public SourceEnum Source { get; set; }

        /// <summary>
        /// 第三方消息Id
        /// </summary>
        public string MessageId { get; set; }

        /// <summary>
        /// 门锁ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 密码类型
        /// </summary>
        public PwdTypeEnum PwdType { get; set; }


        /// <summary>
        /// 门锁SN
        /// </summary>
        public string SN { get; set; }
    }
}
