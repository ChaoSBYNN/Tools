﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Sys
{
    /// <summary>
    /// 配置
    /// </summary>
    [Table("V_SysArea")]
    public class SysAreaEntity : BaseEntity
    {
        /// <summary>
        ///省-No
        /// </summary>
        public string ProvinceNo { get; set; }
        /// <summary>
        /// 省-名称
        /// </summary>

        public string ProvinceName { get; set; }
        /// <summary>
        /// 城市-No
        /// </summary>
        public string CityNo { get; set; }

        /// <summary>
        /// 城市-名称
        /// </summary>
        public string CityName { get; set; }

        /// <summary>
        /// 地区-No
        /// </summary>
        public string RegionNo { get; set; }

        /// <summary>
        /// 地区-名称
        /// </summary>
        public string RegionName { get; set; }
    }
}
