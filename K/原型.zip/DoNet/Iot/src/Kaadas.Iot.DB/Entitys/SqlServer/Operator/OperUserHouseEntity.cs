﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Operator
{
    [Table("RMS_OperUserHouse")]
    public class OperUserHouseEntity : BaseEntity
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        /// <returns></returns>
        public string UserNo { get; set; }
        /// <summary>
        /// 房源编号
        /// </summary>
        /// <returns></returns>
        public string HouseNo { get; set; }

    }
}
