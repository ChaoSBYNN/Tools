﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// 创 建：超级管理员
/// 日 期：2023/11/8 10:38:30
/// 描 述：Upgrade Task Info
/// </summary>
[Table("OTA_UpgradeTask")]
public class UpgradeTaskEntity : BaseEntity
{

    /// <summary>
    /// 升级任务编号
    /// </summary>
    public string No { get; set; }

    /// <summary>
    /// 关联版本编号
    /// </summary>
    public string VersionNo { get; set; }

    /// <summary>
    /// 关联版本号
    /// </summary>
    public string VersionName { get; set; }

    /// <summary>
    /// 状态
    /// </summary>
    public UpgradeTaskStatusEnum? Status { get; set; } = UpgradeTaskStatusEnum.InProgress;

    /// <summary>
    /// 升级设备数量
    /// </summary>
    public int? DeviceCount { get; set; } = 0;

    /// <summary>
    /// 备注
    /// </summary>
    public string Remark { get; set; }


}