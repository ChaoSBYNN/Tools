﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Sys
{
    /// <summary>
    /// MQTT 主题
    /// </summary>
    [Table("K_MqttTopic")]
    public class MqttTopicEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 主题正则
        /// </summary>
        public string TopicReg { get; set; }

        /// <summary>
        /// MQTT payload 定义的 Method - 可在 MqttMethodConst 查看
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 执行CAP
        /// </summary>
        public string ExecuteCap { get; set; }

        /// <summary>
        /// 是否主动响应
        /// </summary>
        public int IsAutoRes { get; set; }
    }
}
