﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    [Table("DMS_LockPowerLog")]
    public class LockPowerLogEntity : BaseEntity
    {
        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }
        /// <summary>
        /// 消息上报时间
        /// </summary>
        public DateTime MsgTime { get; set; }

        /// <summary>
        /// 门锁sn
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 门锁esn
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 电池1电量，取值0~100对应0~100%
        /// </summary>
        public int BatteryLevel { get; set; }

        /// <summary>
        /// 电池1电压，单位mV
        /// </summary>
        public int? BatteryVoltage { get; set; }

        /// <summary>
        /// 获取时间(秒)
        /// </summary>
        public DateTime RecordTime { get; set; }
    }
}
