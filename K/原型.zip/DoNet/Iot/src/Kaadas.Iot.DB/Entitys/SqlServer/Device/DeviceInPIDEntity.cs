﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 设备对应PID
    /// </summary>
    [Table("DMS_DeviceInPID")]
    public class DeviceInPIDEntity : BaseEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        /// <returns></returns>
        public string DeviceNo { get; set; }

        /// <summary>
        /// PID
        /// </summary>
        public string PID { get; set; }
    }
}
