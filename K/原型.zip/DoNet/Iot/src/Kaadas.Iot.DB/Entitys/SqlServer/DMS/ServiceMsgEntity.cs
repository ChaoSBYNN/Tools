﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 设备服务消息
    /// </summary>
    [Table("DMS_ServiceMsg")]
    public class ServiceMsgEntity : BaseModifyEntity
    {
        /// <summary>
        /// 消息Id
        /// </summary>
        public string MessageId { get; set; }

        /// <summary>
        /// 消息时间
        /// </summary>
        public DateTime MessageTime { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 消息内容
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public PostDeviceResultEnum Status { get; set; }
    }
}
