﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Consts;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Instructions
{
    /// <summary>
    /// OTA升级指令
    /// </summary>
    [Table("DMS_UpgradeInstruction")]
    [Instruction(MqttMethodConst.GATEWAY_OTA, ExpireSeconds = TimeConst.THREE_MINUTES)]
    public class UpgradeInstructionEntity : BaseInstructionEntity
    {

    }
}
