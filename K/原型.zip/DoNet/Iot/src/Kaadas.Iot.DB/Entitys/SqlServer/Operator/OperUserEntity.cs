﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Operator
{
    [Table("RMS_OperUser")]
    public class OperUserEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        /// <returns></returns>
        public string No { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        /// <returns></returns>
        public string Name { get; set; }
        /// <summary>
        /// 账号（手机号）
        /// </summary>
        /// <returns></returns>
        public string Account { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        /// <returns></returns>
        public string PassWord { get; set; }

        /// <summary>
        /// 是否管理员
        /// </summary>
        /// <returns></returns>
        public int IsAdmin { get; set; }

        /// <summary>
        /// 是否主负责人
        /// </summary>
        /// <returns></returns>
        public int IsHead { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        /// <returns></returns>
        public StatusEnum Status { get; set; }

        /// <summary>
        /// 角色
        /// </summary>
        public OperUserTypeEnum UserType { get; set; }

        /// <summary>
        /// 运营商编号
        /// </summary>
        public string OperNo { get; set; }

    }
}
