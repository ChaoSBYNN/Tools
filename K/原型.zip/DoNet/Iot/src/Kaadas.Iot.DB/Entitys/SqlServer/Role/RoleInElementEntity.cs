﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Role
{
    [Table("K_RoleInElement")]
    public class RoleInElementEntity : BaseEntity
    {

        /// <summary>
        /// 元素代号
        /// </summary>
        /// <returns></returns>
        public string ElementNo { get; set; }
        /// <summary>
        /// 角色代号
        /// </summary>
        /// <returns></returns>
        public string RoleNo { get; set; }

    }
}
