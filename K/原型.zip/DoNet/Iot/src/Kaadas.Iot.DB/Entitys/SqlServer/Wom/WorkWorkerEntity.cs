﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单安装师傅
    /// </summary>
    [Table("WOM_WorkWorker")]
    public class WorkWorkerEntity : BaseEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 团队编号
        /// </summary>
        public string TeamNo { get; set; }

        /// <summary>
        /// 师傅编号
        /// </summary>
        public string WorkerNo { get; set; }
    }
}
