﻿using Kaadas.Iot.CommonDto.Enums;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 联网设备
    /// </summary>
    [Table("DMS_NetDevice")]
    public class NetDeviceEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 联网编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public DeviceStateEnum State { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string DeviceNo { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 房源编号
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 房间编号
        /// </summary>
        public string RoomNo { get; set; }

        /// <summary>
        /// 绑定网关SN
        /// </summary>
        public string BindGatewaySN { get; set; }

        /// <summary>
        /// 绑定网关ESN
        /// </summary>
        public string BindGatewayESN { get; set; }

        /// <summary>
        /// 绑定时间
        /// </summary>
        public DateTime BindTime { get; set; }

        /// <summary>
        /// 电量 -  锁设备专有
        /// </summary>
        public int? BatteryLevel { get; set; }

        /// <summary>
        /// 信道 
        /// </summary>
        public int Channel { get; set; } = 0;

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 接收信号强度，单位dBm
        /// </summary>
        public int? RxRSSI { get; set; }

        /// <summary>
        /// 发送信号强度
        /// </summary>
        public int? TxRSSI { get; set; }

        /// <summary>
        /// 设备算法密钥 
        /// </summary>
        public string AlgorithmKey { get; set; }

        /// <summary>
        /// 操作状态
        /// </summary>
        public DeviceOpStatusEnum OpStatus { get; set; } = DeviceOpStatusEnum.Normal;

        /// <summary>
        /// 设备拉合闸状态（水电表用）
        /// </summary>
        public ShutdownStatusEnum? ShutdownStatus { get; set; } = ShutdownStatusEnum.ClosedCircuit;

        /// <summary>
        /// 读数（水电表用）
        /// </summary>
        public decimal? MeterReading { get; set; }
    }
}
