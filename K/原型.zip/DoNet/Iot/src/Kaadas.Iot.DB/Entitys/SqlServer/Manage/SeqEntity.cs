﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    /// <summary>
    /// 序列号生成
    /// </summary>
    [Table("K_Seq")]
    public class SeqEntity : BaseModifyEntity
    {
        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 字首
        /// </summary>
        public string Prefix { get; set; }

        /// <summary>
        /// 时间格式
        /// </summary>

        public string DateFormart { get; set; }

        /// <summary>
        /// 序列长度
        /// </summary>
        public int SerialLength { get; set; }
        /// <summary>
        /// 当前号码
        /// </summary>
        public int CurrentNumber { get; set; }
    }
}
