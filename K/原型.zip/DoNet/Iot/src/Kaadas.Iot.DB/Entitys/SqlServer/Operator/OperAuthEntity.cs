﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Operator
{

    [Table("KOP_OperAuth")]
    public class OperAuthEntity: BaseDeleteEntity
    {
        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperNo { get; set; }

        /// <summary>
        /// appId
        /// </summary>
        public string AppId { get; set; }

        /// <summary>
        /// AppSecret
        /// </summary>
        public string AppSecret { get; set; }

        /// <summary>
        /// 运营方回调地址
        /// </summary>
        public string CallbackUrl { get; set; }

        /// <summary>
        /// 访问限制频率
        /// </summary>
        public int Frequency { get; set; } = 0;

        /// <summary>
        /// 事件推送地址
        /// </summary>
        public string EvevtPushUrl { get; set; }
    }
}
