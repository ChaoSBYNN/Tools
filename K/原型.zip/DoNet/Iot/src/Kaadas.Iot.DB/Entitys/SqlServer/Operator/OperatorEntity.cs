﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Operator
{
    [Table("RMS_Operator")]
    public class OperatorEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        /// <returns></returns>
        public string No { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        /// <returns></returns>
        public string Name { get; set; }
        /// <summary>
        /// 全称
        /// </summary>
        /// <returns></returns>
        public string FullName { get; set; }
        /// <summary>
        /// 运营方类型
        /// </summary>
        /// <returns></returns>
        public OperatorTypeEnum OperatorType { get; set; }

        /// <summary>
        /// 联系人电话
        /// </summary>
        public string ContactsPhone { get; set; }

        /// <summary>
        /// 联系人名称
        /// </summary>
        public string ContactsName { get; set; }

        /// <summary>
        /// 合同编号
        /// </summary>
        /// <returns></returns>
        public string ContractNo { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        /// <returns></returns>
        public StatusEnum Status { get; set; }

        /// <summary>
        /// 是否强制开锁
        /// </summary>
        public int IsForceUnlock { get; set; }

        /// <summary>
        /// 电表未上报天数
        /// </summary>
        public int? EMUnReportDays { get; set; }

        /// <summary>
        /// 电表跳表
        /// </summary>
        public int? EMSkipReading { get; set; }

        /// <summary>
        /// 电表定时抄表
        /// </summary>
        public int? EMAutoRecord { get; set; }

        /// <summary>
        /// 水表未上报天数
        /// </summary>
        public int? WMUnReportDays { get; set; }

        /// <summary>
        /// 冷水表跳表
        /// </summary>
        public int? CWMSkipReading { get; set; }

        /// <summary>
        /// 热水表跳表
        /// </summary>
        public int? HWMSkipReading { get; set; }

        /// <summary>
        /// 水表定时抄表
        /// </summary>
        public int? WMAutoRecord { get; set; }


    }
}
