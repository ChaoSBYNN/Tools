﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单异常反馈
    /// </summary>
    [Table("WOM_WorkException")]
    public class WorkExceptionEntity : BaseEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 异常类型 - 配置字典
        /// </summary>
        public string ExceptionType { get; set; }

        /// <summary>
        /// 异常类型备注 -  类型为其他  需传值 
        /// </summary>
        public string ExceptionRemark { get; set; }

        /// <summary>
        /// 图片地址
        /// </summary>
        public string ImgUrl { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
