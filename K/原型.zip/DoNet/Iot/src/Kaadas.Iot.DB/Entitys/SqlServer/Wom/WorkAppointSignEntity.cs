﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单预约签到
    /// </summary>
    [Table("WOM_WorkAppointSign")]
    public class WorkAppointSignEntity : BaseModifyEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 预约时间
        /// </summary>
        public DateTime AppointTime { get; set; }

        /// <summary>
        /// 预约时间段
        /// </summary>
        public string AppointTimeSlot { get; set; }

        /// <summary>
        /// 预约图片
        /// </summary>
        public string AppointImgUrl { get; set; }

        /// <summary>
        /// 预约备注
        /// </summary>
        public string AppointRemark { get; set; }

        /// <summary>
        /// 签到时间
        /// </summary>
        public DateTime? SignTime { get; set; }

        /// <summary>
        /// 签到地址
        /// </summary>
        public string SignAddress { get; set; }

        /// <summary>
        /// 签到图片
        /// </summary>
        public string SignImgUrl { get; set; }

        /// <summary>
        /// 签到维度
        /// </summary>
        public string SignLatitude { get; set; }

        /// <summary>
        /// 签到经度
        /// </summary>
        public string SignLongitude { get; set; }

        /// <summary>
        /// 国家
        /// </summary>
        public string Nation { get; set; }

        /// <summary>
        /// 省份
        /// </summary>

        public string Province { get; set; }

        /// <summary>
        /// 城市
        /// </summary>

        public string City { get; set; }

        /// <summary>
        /// 区县
        /// </summary>

        public string District { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        public string AdCode { get; set; }
    }
}
