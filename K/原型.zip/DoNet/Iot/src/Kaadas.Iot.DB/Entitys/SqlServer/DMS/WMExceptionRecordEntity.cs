﻿using System;
using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer;
using System.ComponentModel.DataAnnotations.Schema;


namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 创 建：超级管理员
    /// 日 期：2024/2/20 17:47:51
    /// 描 述：
    /// </summary>

    [Table("DMS_WMExceptionRecord")]
    public class WMExceptionRecordEntity : BaseEntity
    {
        /// <summary>
        /// 
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 异常类型
        /// </summary>
        public WMAlarmTypeEnum ExceptionType { get; set; }

        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 上报时间
        /// </summary>
        public DateTime ReportTime { get; set; }
        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }
        /// <summary>
        /// 是否解除警报
        /// </summary>
        public int IsAlarmDisarmed { get; set; }
        /// <summary>
        /// 警报解除时间
        /// </summary>
        public DateTime? AlarmDisarmedTime { get; set; }
        /// <summary>
        /// 警报解除人
        /// </summary>
        public string AlarmDisarmedor { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }

}
