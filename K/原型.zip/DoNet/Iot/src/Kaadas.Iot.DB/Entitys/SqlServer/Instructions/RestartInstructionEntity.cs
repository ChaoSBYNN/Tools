﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Consts;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Instructions
{
    /// <summary>
    /// 重启指令
    /// </summary>
    [Table("DMS_RestartInstruction")]
    [Instruction(MqttMethodConst.GATEWAY_RESTART)]
    public class RestartInstructionEntity : BaseInstructionEntity
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }
    }
}
