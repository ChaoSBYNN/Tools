﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    [Table("DMS_SwitchLockEvent")]
    public class SwitchLockEventEntity : BaseEntity
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 授权编号
        /// </summary>
        public string AuthNo { get; set; }

        /// <summary>
        /// 门锁操作方式
        /// </summary>
        public EventSourceEnum EventSource { get; set; }

        /// <summary>
        /// 门锁操作事件代码
        /// </summary>
        public LockOperEventCodeEnum EventCode { get; set; }

        /// <summary>
        /// 事件发生时间
        /// </summary>
        [DefaultSort]
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 开锁人编号
        /// </summary>
        public string OpenLockPeopleNo { get; set; }

        /// <summary>
        /// 开锁人
        /// </summary>
        public string OpenLockPeopleName { get; set; }

        /// <summary>
        /// 开锁人角色
        /// </summary>
        public AuthRoleTypeEnum? OpenLockPeopleRole { get; set; }

        /// <summary>
        /// 密码id
        /// </summary>
        public int? PwdId { get; set; }

        /// <summary>
        /// 消息上报时间
        /// </summary>
        public DateTime MsgTime { get; set; }

        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 事件补充说明
        /// </summary>
        public string EventMsg { get; set; }
    }
}
