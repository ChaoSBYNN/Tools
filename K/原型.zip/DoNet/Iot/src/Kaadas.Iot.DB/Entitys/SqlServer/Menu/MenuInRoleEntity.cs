﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Menu
{

    [Table("K_MenuInRole")]
    public class MenuInRoleEntity : BaseEntity
    {
        /// <summary>
        /// 角色代号
        /// </summary>
        public string RoleNo { get; set; }

        /// <summary>
        /// 菜单代号
        /// </summary>
        /// <returns></returns>
        public string MenuNo { get; set; }
    }
}
