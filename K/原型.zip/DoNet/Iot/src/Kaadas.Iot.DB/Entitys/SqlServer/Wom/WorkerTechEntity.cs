﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 师傅技能
    /// </summary>
    [Table("WOM_WorkerTech")]
    public class WorkerTechEntity : BaseEntity
    {
        /// <summary>
        /// 师傅编号
        /// </summary>
        public string WorkerNo { get; set; }

        /// <summary>
        /// 技能编码 -  字典
        /// </summary>
        public string TechCode { get; set; }
    }
}
