﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    [Table("DMS_LockWirelessLog")]
    public class LockWirelessLogEntity : BaseEntity
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }
        /// <summary>
        /// 接收信号强度，单位dBm
        /// </summary>
        public int RxRSSI { get; set; }

        /// <summary>
        /// 发送信号强度
        /// </summary>
        public int? TxRSSI { get; set; }

        /// <summary>
        /// 刷新信号强度时间(秒)
        /// </summary>
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 消息上报时间
        /// </summary>
        public DateTime MsgTime { get; set; }
    }
}
