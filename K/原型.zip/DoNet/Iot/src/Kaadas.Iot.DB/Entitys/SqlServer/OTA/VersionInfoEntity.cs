﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// 创 建：超级管理员
/// 日 期：2023/11/8 10:33:21
/// 描 述：Device Version Info
/// </summary>
[Table("OTA_VersionInfo")]
public class VersionInfoEntity : BaseDeleteEntity
{
    /// <summary>
    /// 版本编码
    /// </summary>
    public string No { get; set; }

    /// <summary>
    /// 版本号
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// 模块编号
    /// </summary>
    public DevNumEnum DevNum { get; set; }

    /// <summary>
    /// 设备类型
    /// </summary>
    public DeviceTypeEnum? DeviceType { get; set; }

    /// <summary>
    /// 当前版本文件
    /// </summary>
    public string FileUrl { get; set; }

    /// <summary>
    /// 版本文件MD5值
    /// </summary>
    public string FileMD5 { get; set; }

    /// <summary>
    /// 上一个版本编号
    /// </summary>
    public string LastVersionNo { get; set; }

    /// <summary>
    /// 上一个版本号
    /// </summary>
    public string LastVersionName { get; set; }

    /// <summary>
    /// 依赖版本编号
    /// </summary>
    public string DependVersionNo { get; set; }

    /// <summary>
    /// 依赖版本文件
    /// </summary>
    public string DependVersionName { get; set; }

    /// <summary>
    /// 版本更新内容
    /// </summary>
    public string Remark { get; set; }


}