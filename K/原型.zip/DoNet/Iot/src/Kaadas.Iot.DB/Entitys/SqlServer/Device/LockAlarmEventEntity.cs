﻿using Kaadas.Iot.CommonDto.Attributes;
using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 门锁警报事件记录
    /// </summary>
    [Table("DMS_LockAlarmEvent")]
    public class LockAlarmEventEntity : BaseEntity
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 警报编码
        /// </summary>
        public AlarmCodeEnum AlarmCode { get; set; }

        /// <summary>
        /// 告警类型(1=电池,2=门锁)
        /// </summary>
        public AlarmTypeEnum AlarmType { get; set; }

        /// <summary>
        /// 告警状态(0:解除(暂不支持),1=触发)
        /// </summary>
        public AlarmStatusEnum AlarmStatus { get; set; }

        /// <summary>
        /// 警报时间
        /// </summary>
        [DefaultSort]
        public DateTime RecordTime { get; set; }

        /// <summary>
        /// 消息上报时间
        /// </summary>
        public DateTime MsgTime { get; set; }

        /// <summary>
        /// 消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 是否处理(0=未处理；1=已处理)
        /// </summary>
        public int IsSolve { get; set; }

        /// <summary>
        /// 处理备注
        /// </summary>
        public string SolveRemark { get; set; }

        /// <summary>
        /// 处理人
        /// </summary>
        public string SolvePepole { get; set; }

        /// <summary>
        /// 处理人编号
        /// </summary>
        public string SolvePepoleNo { get; set; }

        /// <summary>
        /// 处理时间
        /// </summary>
        public DateTime? SolveTime { get; set; }
    }
}
