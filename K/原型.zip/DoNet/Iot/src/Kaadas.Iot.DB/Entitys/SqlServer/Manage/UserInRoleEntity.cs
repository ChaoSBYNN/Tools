﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    [Table("K_UserInRole")]
    public class UserInRoleEntity : BaseEntity
    {
        public string UserNo { get; set; }

        public string RoleNo { get; set; }
    }
}
