﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    [Table("DMS_LockInfoVersions")]
    [Obsolete]
    public class LockInfoVersionsEntity : BaseEntity
    {
        /// <summary>
        /// 门锁型号(研发型号)
        /// </summary>
        public string LockModel { get; set; }
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 模组编号
        /// </summary>
        public int DevNum { get; set; }

        /// <summary>
        /// 模组固件版本
        /// </summary>
        public string SoftVer { get; set; }

        /// <summary>
        /// 模组硬件版本
        /// </summary>
        public string HWVer { get; set; }

        /// <summary>
        /// 属性上报时间
        /// </summary>
        public DateTime RecordTime { get; set; }
    }
}
