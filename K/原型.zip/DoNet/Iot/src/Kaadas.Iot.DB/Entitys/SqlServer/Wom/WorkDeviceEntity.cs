﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单设备
    /// </summary>
    [Table("WOM_WorkDevice")]
    public class WorkDeviceEntity : BaseModifyEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string DeviceNo { get; set; }

        /// <summary>
        /// 设备名称
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// 安装数量
        /// </summary>
        public int InstallCount { get; set; }

        /// <summary>
        /// 完成数量
        /// </summary>
        public int FinishCount { get; set; }
    }
}
