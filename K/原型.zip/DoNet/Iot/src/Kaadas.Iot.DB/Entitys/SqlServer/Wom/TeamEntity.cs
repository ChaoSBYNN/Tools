﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    ///  团队信息
    /// </summary>
    [Table("WOM_Team")]
    public class TeamEntity : BaseModifyEntity
    {
        /// <summary>
        /// 团队编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 团队名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 负责人 编号
        /// </summary>
        public string PrincipalWorkerNo { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public StatusEnum Status { get; set; }
    }
}
