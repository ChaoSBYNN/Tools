﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Role
{
    [Table("K_RoleInStrategy")]
    public class RoleInStrategyEntity : BaseEntity
    {
        /// <summary>
        /// 策略代号
        /// </summary>
        /// <returns></returns>
        public string StrategyNo { get; set; }
        /// <summary>
        /// 角色代号
        /// </summary>
        /// <returns></returns>
        public string RoleNo { get; set; }
    }
}
