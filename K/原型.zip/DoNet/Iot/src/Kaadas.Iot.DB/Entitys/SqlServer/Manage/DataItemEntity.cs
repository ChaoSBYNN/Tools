﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    [Table("K_DataItem")]
    public class DataItemEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 父级id
        /// </summary>
        public string ParentId { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 层级
        /// </summary>
        public int layers { get; set; }

        /// <summary>
        /// 排序编码
        /// </summary>
        public int SortCode { get; set; }
    }
}
