﻿using Kaadas.Iot.DB.Entitys.SqlServer.Authorize;
using Kaadas.Iot.DB.Entitys.SqlServer.Device;
using Kaadas.Iot.DB.Entitys.SqlServer.DMS;
using Kaadas.Iot.DB.Entitys.SqlServer.Instructions;
using Kaadas.Iot.DB.Entitys.SqlServer.Manage;
using Kaadas.Iot.DB.Entitys.SqlServer.Menu;
using Kaadas.Iot.DB.Entitys.SqlServer.Operator;
using Kaadas.Iot.DB.Entitys.SqlServer.OperHouse;
using Kaadas.Iot.DB.Entitys.SqlServer.Resource;
using Kaadas.Iot.DB.Entitys.SqlServer.Role;
using Kaadas.Iot.DB.Entitys.SqlServer.Sys;
using Kaadas.Iot.DB.Entitys.SqlServer.Wom;
using Microsoft.EntityFrameworkCore;

namespace Kaadas.Iot.DB.Entitys.SqlServer
{
    public class IotDbContext : DbContext
    {
        public IotDbContext(DbContextOptions<IotDbContext> options)
          : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        { 
            //optionsBuilder.LogTo(message => System.Console.WriteLine(message));
            base.OnConfiguring(optionsBuilder);
        }
        public DbSet<ManagerEntity> Managers { get; set; }
        public DbSet<KdsConfigEntity> KdsConfigs { get; set; }
        public DbSet<SeqEntity> Seqs { get; set; }
        public DbSet<MenuEntity> Menus { get; set; }
        public DbSet<MenuInElementEntity> MenuInElements { get; set; }
        public DbSet<MenuInRoleEntity> MenuInRoles { get; set; }
        public DbSet<MenuInUrlEntity> MenuInUrls { get; set; }
        public DbSet<RoleEntity> Roles { get; set; }
        public DbSet<RoleInElementEntity> RoleInElements { get; set; }
        public DbSet<RoleInStrategyEntity> RoleInStrategys { get; set; }
        public DbSet<DataItemEntity> DataItems { get; set; }
        public DbSet<UserInRoleEntity> UserInRoles { get; set; }
        public DbSet<DepartmentEntity> Departments { get; set; }
        public DbSet<OperatorEntity> Operators { get; set; }
        public DbSet<OperUserEntity> OperUsers { get; set; }
        public DbSet<OperHouseEntity> OperHouses { get; set; }
        public DbSet<RoomEntity> Rooms { get; set; }
        public DbSet<AreaEntity> Areas { get; set; }
        public DbSet<OperInDeviceEntity> OperInDevices { get; set; }
        public DbSet<TeamEntity> Teams { get; set; }
        public DbSet<ServiceAreaEntity> ServiceAreas { get; set; }
        public DbSet<WorkAppointSignEntity> WorkAppointSigns { get; set; }
        public DbSet<WorkDeviceEntity> WorkDevices { get; set; }
        public DbSet<WorkerEntity> Workers { get; set; }
        public DbSet<WorkerTechEntity> WorkerTeches { get; set; }
        public DbSet<WorkExceptionEntity> WorkExceptions { get; set; }
        public DbSet<WorkInfoEntity> WorkInfos { get; set; }
        public DbSet<WorkLabelEntity> WorkLabels { get; set; }
        public DbSet<WorkNodeEntity> WorkNodes { get; set; }
        public DbSet<WorkWorkerEntity> WorkWorkers { get; set; }
        public DbSet<DeviceEntity> Devices { get; set; }
        public DbSet<DeviceParameterEntity> DeviceParameters { get; set; }
        public DbSet<DeviceProductEntity> DeviceProducts { get; set; } 
        public DbSet<WorkRoomEntity> WorkRooms { get; set; }
        public DbSet<WorkRoomDeviceEntity> WorkRoomDevices { get; set; }
        public DbSet<ResourceEntity> Resources { get; set; }
        public DbSet<MqttTopicEntity> MqttTopics { get; set; }
        public DbSet<NetDeviceEntity> NetDevices { get; set; }
        public DbSet<UsedDeviceEntity> UsedDevices { get; set; }
        public DbSet<ProductEntity> Products { get; set; }
        public DbSet<LockAlarmEventEntity> LockAlarmLogs { get; set; }
        public DbSet<LockPowerLogEntity> LockPowerLogs { get; set; }
        public DbSet<PasswordManageEventEntity> PasswordManageLogs { get; set; }
        public DbSet<SwitchLockEventEntity> SwitchLockLogs { get; set; }
        public DbSet<LockAuthorizeInfoEntity> AuthorizeInfos { get; set; }
        public DbSet<SecretKeyInfoEntity> SecretKeyInfos { get; set; }
        public DbSet<TenantEntity> Tenants { get; set; }
        public DbSet<RestartInstructionEntity> bindInstructions { get; set; }
        public DbSet<LockWirelessLogEntity> LockRssiLogs { get; set; }
        public DbSet<VersionInfoEntity> VersionInfos { get; set; }
        public DbSet<UpgradeTaskEntity> UpgradeTasks { get; set; }
        public DbSet<UpgradeTaskDetailEntity> UpgradeTaskDetails { get; set; }
        public DbSet<DevicePropertyEntity> DeviceProperties { get; set; } 
        public DbSet<DeviceModuleEntity> DeviceModules { get; set; } 
        //public DbSet<LockInfoVersionsEntity> LockInfoVersionss { get; set; }
        public DbSet<LockAuthLogEntity> LockAuthLog { get; set; } 
        public DbSet<RebindInstructionEntity> RebindInstructions { get; set; }
        public DbSet<OperAuthEntity > OperInterface { get; set; }
        public DbSet<DeviceInPIDEntity> DeviceInPIDs { get; set; }
        public DbSet<UpgradeInstructionEntity> UpgradeInstructions { get; set; }
        public DbSet<SysAreaEntity> SysAreas { get; set; }
        public DbSet<PublishInfoEntity> PublishInfos { get; set; }
        public DbSet<StrategyEntity> StrategyEntities { get; set; }
        public DbSet<WMExceptionRecordEntity> WMExceptionRecordEntities { get; set; }
        public DbSet<WMReadingRecordEntity> WMReadingRecordEntitities { get; set; }
        public DbSet<EMExceptionRecordEntity> EMExceptionRecordEntities { get; set; }
        public DbSet<EMReadingRecordEntity> EMReadingRecordEntities { get; set; }
        public DbSet<ManualReadingDetailEntity> ManualReadingDetailEntities { get; set; }
        public DbSet<ManualReadingEntity> ManualReadingEntities { get; set; }
    }
}
