﻿using Kaadas.Iot.CommonDto.Attributes;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer
{
    public class BaseEntity
    {
        [Key]
        [MaxLength(50)]
        [Column("F_Id")]
        public virtual string Id { get; set; }

        [MaxLength(50)]
        [Required]
        [Column("F_CreatorUserId")]
        public virtual string CreatorUserId { get; set; }

        [Required]
        [Column("F_CreatorTime")]
        [DefaultSort]
        public DateTime CreatorTime { get; set; } = DateTime.Now;

    }

    public class BaseModifyEntity : BaseEntity
    {
        [MaxLength(50)]
        [Column("F_LastModifyUserId")]
        [Required]
        public string LastModifyUserId { get; set; }

        [Column("F_LastModifyTime")]
        public DateTime LastModifyTime { get; set; }
    }

    public class BaseDeleteEntity : BaseModifyEntity
    {
        [MaxLength(50)]
        [Column("F_DeleteUserId")]
        public string DeleteUserId { get; set; }

        [Column("F_DeleteTime")]
        public DateTime? DeleteTime { get; set; }

        [Column("F_DeleteMark")]
        public bool IsDelete { get; set; } = false;
    }
}
