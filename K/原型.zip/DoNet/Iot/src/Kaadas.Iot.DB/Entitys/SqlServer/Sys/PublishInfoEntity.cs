﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Sys
{
    [Table("K_PublishInfo")]
    public class PublishInfoEntity : BaseEntity
    {
        /// <summary>
        ///站点唯一编码： IIS 的站点名称
        /// </summary>
        public string SiteCode { get; set; }

        /// <summary>
        /// 站点名称-描述
        /// </summary>
        public string SiteName { get; set; }

        /// <summary>
        /// 正式站点路径
        /// </summary>
        public string SitePath { get; set; }

        /// <summary>
        /// UAT 站点的路径
        /// </summary>
        public string UatPath { get; set; }

        /// <summary>
        /// 最后一次备份的路径
        /// </summary>
        public string BakPath { get; set; }

        /// <summary>
        /// 排除的文件或文件夹，比如：日志文件夹，appseetings.json文件
        /// </summary>
        public string Excludes { get; set; }

        /// <summary>
        /// 最后发布人执行人
        /// </summary>
        public string PublishName { get; set; }

        /// <summary>
        /// 最后一次发布的时间
        /// </summary>
        public DateTime? PublishTime { get; set; }

        /// <summary>
        /// 发布返回的消息
        /// </summary>
        public string Message { get; set; }

        public string NginxPath { get; set; }

        /// <summary>
        /// 是否停止Nginx（0：否；1：是）
        /// </summary>
        public int IsStopNginx { get; set; }

        /// <summary>
        /// 是否停止IIS（0：否；1：是）
        /// </summary>
        public int IsStopIIS { get; set; }
    }
}
