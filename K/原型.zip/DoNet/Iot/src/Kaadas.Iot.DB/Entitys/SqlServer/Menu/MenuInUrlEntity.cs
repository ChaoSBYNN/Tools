﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    [Table("K_MenuInUrl")]
    public class MenuInUrlEntity : BaseEntity
    {
        /// <summary>
        /// 菜单允许访问的接口地址
        /// </summary>
        /// <returns></returns>
        public string ActionUrl { get; set; }
        /// <summary>
        /// 菜单代号
        /// </summary>
        /// <returns></returns>
        public string MenuNo { get; set; }
    }
}
