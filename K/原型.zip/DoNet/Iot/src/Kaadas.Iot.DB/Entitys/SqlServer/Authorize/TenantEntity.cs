﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Authorize
{
    /// <summary>
    /// 租客信息
    /// </summary>
    [Table("RMS_Tenant")]
    public class TenantEntity : BaseDeleteEntity
    {
        public string No { get; set; }

        public string Phone { get; set; }

        public string Name { get; set; }

        /// <summary>
        /// 用户性别
        /// </summary>
        public SexEnum Sex { get; set; }
    }
}
