﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.OperHouse
{
    [Table("RMS_OperHouse")]
    public class OperHouseEntity : BaseDeleteEntity
    {

        /// <summary>
        /// 编号
        /// </summary>
        public string No { get; set; }
        /// <summary>
        /// 房源名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 房源详细地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 运营方编号
        /// </summary>
        public string OperatorNo { get; set; }
        /// <summary>
        /// 房源类型
        /// </summary>
        public HomeTypeEnum HomeType { get; set; }
        /// <summary>
        /// 省编号
        /// </summary>
        public string Province { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ProvinceName { get; set; }
        /// <summary>
        /// 市编号
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CityName { get; set; }
        /// <summary>
        /// 区编号
        /// </summary>
        public string Region { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string RegionName { get; set; }
        /// <summary>
        /// 房源Id（API传入）
        /// </summary>
        public string ThirdPartyHomeId { get; set; }


    }
}
