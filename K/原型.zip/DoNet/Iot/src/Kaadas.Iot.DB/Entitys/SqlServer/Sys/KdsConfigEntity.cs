﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Sys
{
    /// <summary>
    /// 配置
    /// </summary>
    [Table("K_Config")]
    public class KdsConfigEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 描述
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 配置key
        /// </summary>
        public string ConfigKey { get; set; }

        /// <summary>
        /// 配置值
        /// </summary>
        public string ConfigValue { get; set; }

        /// <summary>
        /// 分类字典 key
        /// </summary>
        public string CategoryKey { get; set; }
    }
}
