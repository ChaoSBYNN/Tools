﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Role
{
    [Table("K_Strategy")]
    public class StrategyEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 策略编号 需与AuthStrategyConst 常量内一致
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 策略名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remarks { get; set; }

    }
}
