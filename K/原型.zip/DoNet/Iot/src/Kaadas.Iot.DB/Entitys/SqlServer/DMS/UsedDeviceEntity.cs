﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 使用设备
    /// </summary>
    [Table("DMS_UsedDevice")]
    public class UsedDeviceEntity : BaseModifyEntity
    {
        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备类型
        /// </summary>
        public DeviceTypeEnum DeviceType { get; set; }

        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备编号
        /// </summary>
        public string DeviceNo { get; set; }

        /// <summary>
        /// 安装工单编号
        /// </summary>
        public string SetUpWorkNo { get; set; }

        /// <summary>
        /// 安装师傅编号
        /// </summary>
        public string SetupWorkerNo { get; set; }

        /// <summary>
        /// 安装师傅姓名
        /// </summary>
        public string SetupWorkerName { get; set; }

        /// <summary>
        /// 安装师傅手机
        /// </summary>
        public string SetupWorkerPhone { get; set; }

        /// <summary>
        /// 绑定时间
        /// </summary>
        public DateTime BindTime { get; set; }

        /// <summary>
        /// 交付时间/师傅核销时间
        /// </summary>
        public DateTime? SetupWriteOffTime { get; set; }

        /// <summary>
        /// 首次添加联网编号
        /// </summary>
        public string CreateNetNo { get; set; }

        /// <summary>
        /// 最后联网编号
        /// </summary>
        public string LastBindNetNo { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}
