﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Device
{
    /// <summary>
    /// 设备其它参数
    /// </summary>
    [Table("DMS_DeviceParameter")]
    public class DeviceParameterEntity : BaseEntity
    {
        /// <summary>
        /// 设备编号
        /// </summary>
        /// <returns></returns>
        public string DeviceNo { get; set; }
        /// <summary>
        /// 参数名称
        /// </summary>
        /// <returns></returns>
        public string ParamName { get; set; }
        /// <summary>
        /// 参数值
        /// </summary>
        /// <returns></returns>
        public string ParamValue { get; set; }
    }
}
