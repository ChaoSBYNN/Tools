﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 创 建：超级管理员
    /// 日 期：2024/2/28 14:50:17
    /// 描 述：
    /// </summary>

    [Table("DMS_ManualReading")]
    public class ManualReadingEntity : BaseEntity
    {
        /// <summary>
        /// 
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string OpratorNo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string OpratorName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string HouseNo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string HouseName { get; set; }

        /// <summary>
        /// 设备类型（英文逗号隔开）
        /// </summary>
        public string DeviceType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Remark { get; set; }

    }
}
