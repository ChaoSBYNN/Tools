﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Role
{
    [Table("K_Role")]
    public class RoleEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 角色编号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 角色所属项目
        /// </summary>
        /// <returns></returns>
        public ProjectTypeEnum ProjectType { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        /// <returns></returns>
        public string Remarks { get; set; }
    }
}
