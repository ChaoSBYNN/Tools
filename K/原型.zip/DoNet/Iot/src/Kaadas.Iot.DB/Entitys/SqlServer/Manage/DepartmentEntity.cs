﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Manage
{
    [Table("K_Department")]
    public class DepartmentEntity : BaseDeleteEntity
    {
        /// <summary>
        /// 部门编号
        /// </summary> 
        public string No { get; set; }

        /// <summary>
        /// 部门名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 部门简写
        /// </summary>
        public string Abbreviation { get; set; }

        /// <summary>
        /// 上级部门编号
        /// </summary>
        public string ParentNo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Level { get; set; } = 0;
    }
}
