﻿using Kaadas.Iot.CommonDto.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Wom
{
    /// <summary>
    /// 工单节点
    /// </summary>
    [Table("WOM_WorkNode")]
    public class WorkNodeEntity : BaseEntity
    {
        /// <summary>
        /// 工单编号
        /// </summary>
        public string WorkNo { get; set; }

        /// <summary>
        /// 节点类型
        /// </summary>
        public NodeTypeEnum NodeType { get; set; }

        /// <summary>
        /// 节点描述  - 枚举Description
        /// </summary>
        public string NodeDescription { get; set; }

        /// <summary>
        /// 操作用户类型
        /// </summary>
        public WorkUserTypeEnum OpUserType { get; set; }

        /// <summary>
        /// 操作用户编号
        /// </summary>
        public string OpUserNo { get; set; }

        /// <summary>
        /// 操作用户名
        /// </summary>
        public string OpUserName { get; set; }

        /// <summary>
        /// 节点备注
        /// </summary>
        public string Remark { get; set; }
    }
}
