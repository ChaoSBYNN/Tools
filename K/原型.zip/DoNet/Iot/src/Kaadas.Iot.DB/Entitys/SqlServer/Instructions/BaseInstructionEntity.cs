﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.DB.Entitys.SqlServer.Instructions
{
    public class BaseInstructionEntity : BaseModifyEntity
    {
        public InstructionStatusEnum Status { get; set; } = InstructionStatusEnum.Issuing;

        /// <summary>
        /// 指令消息id
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 指令响应消息id
        /// </summary>
        public string ReplyMsgId { get; set; } = "";
    }
}
