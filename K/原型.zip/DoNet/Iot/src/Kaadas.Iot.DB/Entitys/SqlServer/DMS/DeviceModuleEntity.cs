﻿using Kaadas.Iot.CommonDto.Enums;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Kaadas.Iot.DB.Entitys.SqlServer.DMS
{
    /// <summary>
    /// 设备模组
    /// </summary>
    [Table("DMS_DeviceModule")]
    public class DeviceModuleEntity : BaseModifyEntity
    {
        /// <summary>
        /// 设备SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 设备ESN
        /// </summary>
        public string ESN { get; set; }

        /// <summary>
        /// 设备模组
        /// </summary>
        public DevNumEnum DevNum { get; set; }

        /// <summary>
        /// 模组固件版本
        /// </summary>
        public string SoftVer { get; set; }

        /// <summary>
        /// 模组硬件版本
        /// </summary>
        public string HWVer { get; set; }

        /// <summary>
        /// 设备记录时间
        /// </summary>

        public DateTime? RecordTime { get; set; }
    }
}
