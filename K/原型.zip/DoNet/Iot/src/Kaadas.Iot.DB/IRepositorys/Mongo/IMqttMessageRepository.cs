﻿using Kaadas.Iot.DB.Entitys.Mongo.Mqtt;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface IMqttMessageRepository : IBaseMongoRepository<MqttReceiveMsgEntity>
    {
    }
}
