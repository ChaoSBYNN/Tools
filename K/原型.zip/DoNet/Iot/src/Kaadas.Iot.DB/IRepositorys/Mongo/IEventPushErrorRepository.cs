﻿using Kaadas.Iot.CommonDto.Models;
using Kaadas.Iot.DB.Entitys.Mongo;
using Kaadas.Iot.Dto.Dto.OpenApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface IEventPushErrorRepository : IBaseMongoRepository<EventPushEntity>
    {
        void SaveLogToMongo(DeviceEventPushDto dto, KaadasResult result, string operatorNo, string deviceEsn);

        void SaveErrorLogToMongo(DeviceEventPushDto dto, string operatorNo, string deviceEsn, string errorMsg);
    }
}
