﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.Mongo;
using System;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface IDeviceOperLogRepository : IBaseMongoRepository<DeviceOperLogEntity>
    {
        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="netNo">联网编号</param>
        /// <param name="esn">设备ESN</param>
        /// <param name="sn">设备SN</param>
        /// <param name="type">操作类型</param>
        /// <param name="userType">用户类型</param>
        /// <param name="userNo">用户编号</param>
        /// <param name="userName">用户名称</param>
        /// <param name="remark">备注</param>
        /// <param name="opTime">操作时间</param>
        /// <returns></returns>
        Task AddLog(string netNo, string esn, string sn, DeviceOperTypeEnum type, UserTypeEnum userType,
            string userNo, string userName, string remark = null, DateTime? opTime = null);

        /// <summary>
        /// 添加记录并推送运营方
        /// </summary>
        /// <param name="netNo">联网编号</param>
        /// <param name="esn">设备ESN</param>
        /// <param name="sn">设备SN</param>
        /// <param name="type">操作类型</param>
        /// <param name="userType">用户类型</param>
        /// <param name="userNo">用户编号</param>
        /// <param name="userName">用户名称</param>
        /// <param name="remark">备注</param>
        /// <param name="opTime">操作时间</param>
        /// <param name="param">透传参数</param>
        /// <returns></returns>
        Task AddLogAndPush(string netNo, string esn, string sn, DeviceOperTypeEnum type, UserTypeEnum userType,
            string userNo, string userName, string remark = null, DateTime? opTime = null, object param = null);
    }
}
