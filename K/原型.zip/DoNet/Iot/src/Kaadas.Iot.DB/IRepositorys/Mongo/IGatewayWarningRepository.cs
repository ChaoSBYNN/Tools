﻿using Kaadas.Iot.DB.Entitys.Mongo;
using Kaadas.Iot.DB.Entitys.Mongo.Mqtt;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    /// <summary>
    /// 网关预警上报
    /// </summary>
    public interface IGatewayWarningRepository : IBaseMongoRepository<GatewayWarningEntity>
    {
    }
}
