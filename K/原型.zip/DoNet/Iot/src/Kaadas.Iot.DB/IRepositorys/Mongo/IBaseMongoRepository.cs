﻿using Kaadas.Iot.CommonDto.Interfaces;
using Kaadas.Iot.DB.Entitys.Mongo;
using MongoDB.Driver;
using System;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface IBaseMongoRepository<TDocument> : IDenpendency where TDocument : BaseMongo, new()
    {
        /// <summary>
        /// 当前集合
        /// </summary>
        public IMongoCollection<TDocument> CurCollection { get; }

        /// <summary>
        /// 获取集合
        /// </summary>
        /// <param name="dbName"></param>
        /// <param name="collectionName"></param>
        /// <returns></returns>
        IMongoCollection<T> GetCollection<T>(string dbName, string collectionName) where T : BaseMongo, new();

        /// <summary>
        /// 处理单个数据
        /// 根据条件判断 无则插入，有则更新整个对象（除_id,_kdscreatetime）
        /// </summary>
        /// <param name="collection"></param>
        /// <param name="data"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        Task DealDataAsync(TDocument data, Expression<Func<TDocument, bool>> predicate);

        /// <summary>
        /// 获取单个数据
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        Task<TDocument> GetEntity(Expression<Func<TDocument, bool>> predicate);

        /// <summary>
        /// 插入单个数据
        /// </summary>
        /// <typeparam name="TDocument"></typeparam>
        /// <param name="collection"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        Task InsertDataAsync(TDocument data);

        /// <summary>
        /// 查询单条数据
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        Task<TDocument> FirstOrDefaultAsync(Expression<Func<TDocument, bool>> predicate);
    }
}
