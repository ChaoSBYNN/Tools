﻿
using Kaadas.Iot.DB.Entitys.Mongo;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface ILoginLogMongoRepository : IBaseMongoRepository<LoginLogEntity>
    {
    }
}
