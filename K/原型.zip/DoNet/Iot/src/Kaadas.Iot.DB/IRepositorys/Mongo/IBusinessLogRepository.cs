﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.Mongo;

namespace Kaadas.Iot.DB.IRepositorys.Mongo
{
    public interface IBusinessLogRepository : IBaseMongoRepository<BusinessLogEntity>
    {
        void SaveRecordLog(BusinessTypeEnum businessType, string ip, string operationContent, OperationTypeEnum operationType, string businessNo = "", string userName = "", string userNo = "");
    }
}
