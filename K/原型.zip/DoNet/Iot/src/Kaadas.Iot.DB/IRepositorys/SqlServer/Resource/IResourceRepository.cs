﻿using Kaadas.Iot.DB.Entitys.SqlServer.Resource;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Resource
{
    /// <summary>
    /// 资源处理
    /// </summary>
    public interface IResourceRepository : IBaseRepository<ResourceEntity>
    {
    }
}
