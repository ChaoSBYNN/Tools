﻿using Kaadas.Iot.DB.Entitys.SqlServer.Manage;
using Kaadas.Iot.Dto.Dto;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IDataItemRepository : IBaseRepository<DataItemEntity>
    {
        /// <summary>
        /// 根据字典编码获取字典数据
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        List<DataItemEntity> GetItemsByCode(string code); 

        /// <summary>
        /// 根据字典编码获取字典下拉数据
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        List<SelectItemDto> GetItemSelectByCode(string code);

        /// <summary>
        /// 根据字典获取字典数据Query
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        IQueryable<DataItemEntity> ItemsQuery(string code);
    }
}
