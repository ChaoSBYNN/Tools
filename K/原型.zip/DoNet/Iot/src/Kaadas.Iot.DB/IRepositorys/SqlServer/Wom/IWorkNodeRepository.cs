﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.DB.Entitys.SqlServer.Wom;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Wom
{
    public interface IWorkNodeRepository : IBaseRepository<WorkNodeEntity>
    {
        /// <summary>
        /// 获取工单节点
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        Task<List<WorkNodeEntity>> GetWorkNodes(Expression<Func<WorkNodeEntity, bool>> expression);


        /// <summary>
        /// 添加节点
        /// </summary>
        /// <param name="work">工单</param>
        /// <param name="nodeType">节点类型</param>
        /// <param name="userType">操作用户类型</param>
        /// <param name="operNo">操作用户编号</param>
        /// <param name="operName">操作用户名</param>
        /// <param name="remark">节点备注</param>
        /// <returns></returns>
        Task AddNode(string workNo, NodeTypeEnum nodeType, WorkUserTypeEnum userType, string operNo, string operName, string remark = null);
    }
}
