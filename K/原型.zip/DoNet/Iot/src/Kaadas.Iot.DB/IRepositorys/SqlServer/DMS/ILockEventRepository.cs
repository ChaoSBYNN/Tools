﻿using Kaadas.Iot.DB.Entitys.SqlServer.Device;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.DMS
{
    public interface ILockEventRepository : IBaseRepository<PasswordManageEventEntity>
    {

    }
}
