﻿using Kaadas.Iot.CommonDto.Interfaces;
using Kaadas.Iot.DB.Entitys.SqlServer;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer
{
    public interface IBaseRepository<T> : IDenpendency where T : BaseEntity, new()
    {
        int ExecuteSqlRaw(string sql, params object[] param);
        IQueryable<T> Query();

        IQueryable<T> Query(Expression<Func<T, bool>> whereLambda);

        IQueryable<T> QueryWithNoLock();

        IQueryable<T> QueryWithNoLock(Expression<Func<T, bool>> whereLambda);

        IQueryable<T> Where(Expression<Func<T, bool>> whereLambda);

        ValueTask<EntityEntry<T>> InsertAsync(T entity);

        Task BatchInsertAsync(List<T> entitys);

        void BatchInsert(List<T> entitys);

        void Update(T entity);

        void UpdatePartial(T entity, T dto);

        Task<int> UpdateAsync(Expression<Func<T, bool>> whereLambda, Expression<Func<T, T>> entity);

        Task<int> BatchDeleteAsync(Expression<Func<T, bool>> whereLambda);

        int Count(Expression<Func<T, bool>> whereLambda);

        Task<int> CountAsync(Expression<Func<T, bool>> whereLambda);

        bool Any(Expression<Func<T, bool>> whereLambda);
        Task<bool> AnyAsync(Expression<Func<T, bool>> whereLambda);

        Task<T> GetEntity(Expression<Func<T, bool>> whereLambda);

        Task<List<T>> GetListAsync();

        Task<List<T>> GetListAsync(Expression<Func<T, bool>> whereLambda);

        Task<Tuple<List<T>, int>> GetPageData<S>(int pageIndex, int pageSize, Expression<Func<T, bool>> whereLambda, Expression<Func<T, S>> orderByLambda, bool isAsc);
    }
}
