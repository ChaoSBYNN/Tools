﻿using Kaadas.Iot.DB.Entitys.SqlServer.Authorize;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface ITenantRepository : IBaseRepository<TenantEntity>
    {
    }
}
