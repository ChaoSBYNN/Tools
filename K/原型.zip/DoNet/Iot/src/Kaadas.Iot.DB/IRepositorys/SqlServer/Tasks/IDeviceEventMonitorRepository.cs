﻿using Kaadas.Iot.DB.Entitys.SqlServer.Device;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Tasks
{
    public interface IDeviceEventMonitorRepository : IBaseRepository<LockAlarmEventEntity>
    {
    }
}
