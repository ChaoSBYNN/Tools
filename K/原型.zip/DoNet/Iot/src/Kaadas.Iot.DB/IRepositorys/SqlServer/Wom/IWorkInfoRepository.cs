﻿using Kaadas.Iot.DB.Entitys.SqlServer.Wom;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Wom
{
    /// <summary>
    /// 工单数据Repository
    /// </summary>
    public interface IWorkInfoRepository : IBaseRepository<WorkInfoEntity>
    {
    }
}
