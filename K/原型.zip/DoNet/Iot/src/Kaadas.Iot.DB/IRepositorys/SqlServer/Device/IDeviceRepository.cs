﻿using Kaadas.Iot.DB.Entitys.SqlServer.Device;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Device
{
    public interface IDeviceRepository : IBaseRepository<DeviceEntity>
    {
    }
}
