﻿using Kaadas.Iot.DB.Entitys.SqlServer.OperHouse;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Operator
{
    public interface IRoomRepository : IBaseRepository<RoomEntity>
    {
    }
}
