﻿using Kaadas.Iot.DB.Entitys.SqlServer.Sys;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IMqttTopicRepository : IBaseRepository<MqttTopicEntity>
    {
    }
}
