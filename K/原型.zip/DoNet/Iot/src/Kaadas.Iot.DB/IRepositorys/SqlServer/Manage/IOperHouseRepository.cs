﻿using Kaadas.Iot.DB.Entitys.SqlServer.OperHouse;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IOperHouseRepository : IBaseRepository<OperHouseEntity>
    {
    }
}
