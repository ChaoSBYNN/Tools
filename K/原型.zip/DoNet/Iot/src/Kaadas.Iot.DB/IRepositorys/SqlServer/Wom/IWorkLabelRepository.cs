﻿using Kaadas.Iot.DB.Entitys.SqlServer.Wom;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Wom
{
    /// <summary>
    /// 工单标签
    /// </summary>
    public interface IWorkLabelRepository : IBaseRepository<WorkLabelEntity>
    {
    }
}
