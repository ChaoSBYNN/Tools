﻿namespace Kaadas.Iot.DB.IRepositorys.SqlServer.OTA
{
    public interface IUpgradeTaskDetailRepository : IBaseRepository<UpgradeTaskDetailEntity>
    {
    }
}
