﻿using Kaadas.Iot.DB.Entitys.SqlServer.Manage;
using Kaadas.Iot.DB.Entitys.SqlServer.Role;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IUserInRoleRepository : IBaseRepository<UserInRoleEntity>
    {
    }
}
