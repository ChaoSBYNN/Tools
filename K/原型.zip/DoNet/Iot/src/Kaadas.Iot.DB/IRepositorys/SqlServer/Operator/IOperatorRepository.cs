﻿using Kaadas.Iot.DB.Entitys.SqlServer.Operator;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Operator
{
    public interface IOperatorRepository : IBaseRepository<OperatorEntity>
    {
    }
}
