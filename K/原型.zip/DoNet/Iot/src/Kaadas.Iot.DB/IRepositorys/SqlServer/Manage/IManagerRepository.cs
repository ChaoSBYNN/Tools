﻿using Kaadas.Iot.DB.Entitys.SqlServer.Manage;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IManagerRepository : IBaseRepository<ManagerEntity>
    {
    }
}
