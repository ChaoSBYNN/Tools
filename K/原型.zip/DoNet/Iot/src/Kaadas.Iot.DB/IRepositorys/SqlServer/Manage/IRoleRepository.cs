﻿using Kaadas.Iot.DB.Entitys.SqlServer.Role;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IRoleRepository : IBaseRepository<RoleEntity>
    {
    }
}
