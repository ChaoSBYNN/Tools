﻿using Kaadas.Iot.DB.Entitys.SqlServer.Wom;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Wom
{
    public interface ITeamRepository : IBaseRepository<TeamEntity>
    {
    }
}
