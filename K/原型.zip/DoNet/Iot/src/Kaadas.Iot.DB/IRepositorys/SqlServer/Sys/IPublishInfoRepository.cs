﻿using Kaadas.Iot.DB.Entitys.SqlServer.Sys;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Sys
{
    public interface IPublishInfoRepository : IBaseRepository<PublishInfoEntity>
    {
    }
}
