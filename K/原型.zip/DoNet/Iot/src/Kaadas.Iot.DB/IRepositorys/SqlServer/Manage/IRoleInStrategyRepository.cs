﻿using Kaadas.Iot.DB.Entitys.SqlServer.Role;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.Manage
{
    public interface IRoleInStrategyRepository : IBaseRepository<RoleInStrategyEntity>
    {
    }
}
