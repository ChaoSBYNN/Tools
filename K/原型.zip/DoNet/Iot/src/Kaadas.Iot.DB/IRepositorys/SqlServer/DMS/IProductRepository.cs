﻿using Kaadas.Iot.DB.Entitys.SqlServer.DMS;

namespace Kaadas.Iot.DB.IRepositorys.SqlServer.DMS
{
    public interface IProductRepository : IBaseRepository<ProductEntity>
    {
    }
}
