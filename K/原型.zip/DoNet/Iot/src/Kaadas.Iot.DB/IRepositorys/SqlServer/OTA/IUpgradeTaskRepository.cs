﻿namespace Kaadas.Iot.DB.IRepositorys.SqlServer.OTA
{
    public interface IUpgradeTaskRepository : IBaseRepository<UpgradeTaskEntity>
    {
    }
}
