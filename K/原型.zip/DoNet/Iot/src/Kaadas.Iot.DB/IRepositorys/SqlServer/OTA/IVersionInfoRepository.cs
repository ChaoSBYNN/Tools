﻿namespace Kaadas.Iot.DB.IRepositorys.SqlServer.OTA
{
    public interface IVersionInfoRepository : IBaseRepository<VersionInfoEntity>
    {
    }
}
