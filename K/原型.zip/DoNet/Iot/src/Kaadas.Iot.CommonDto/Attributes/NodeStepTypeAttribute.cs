﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.CommonDto.Models;
using System;

namespace Kaadas.Iot.CommonDto.Attributes
{
    /// <summary>
    /// 节点步骤对应节点类型
    /// </summary>
    public class NodeStepTypeAttribute : Attribute
    {
        public readonly NodeTypeEnum[] _nodeTypes;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="nodeTypes"></param>
        public NodeStepTypeAttribute(params NodeTypeEnum[] nodeTypes)
        {
            if (nodeTypes.Length <= 0)
                throw new KaadasException("未配置步骤节点类型");
            _nodeTypes = nodeTypes;
        }
    }
}
