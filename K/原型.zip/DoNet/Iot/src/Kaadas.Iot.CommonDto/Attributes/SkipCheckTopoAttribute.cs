﻿using System;

namespace Kaadas.Iot.CommonDto.Attributes
{
    /// <summary>
    /// 跳过检查Topo 
    /// </summary>
    public class SkipCheckTopoAttribute : Attribute
    {
    }
}
