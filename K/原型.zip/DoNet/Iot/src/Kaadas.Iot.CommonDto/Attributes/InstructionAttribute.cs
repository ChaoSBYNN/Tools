﻿using Kaadas.Iot.CommonDto.Consts;
using Kaadas.Iot.CommonDto.Models;
using System;

namespace Kaadas.Iot.CommonDto.Attributes
{
    /// <summary>
    /// 指令 特性
    /// </summary>
    public class InstructionAttribute : Attribute
    {
        /// <summary>
        /// 是否ACK响应结果即是成功
        /// </summary>
        public bool IsAckResult { get; set; }

        /// <summary>
        /// 执行指令方法
        /// </summary>
        public string[] Methods { get; set; }

        /// <summary>
        /// 超时时间 单位：秒  - 默认5分钟
        /// </summary>
        public int ExpireSeconds { get; set; } = TimeConst.FIVE_MINUTES;

        /// <summary>
        /// Mqtt忽略修改状态
        /// </summary>
        public bool IsMqttIgnore { get; set; } = false;

        /// <summary>
        /// 指令 特性
        /// </summary>
        /// <param name="methods">执行指令方法</param>
        public InstructionAttribute(params string[] methods)
        {
            if (methods == null || methods.Length <= 0)
                throw new KaadasException("未配置指令方法");
            Methods = methods;
        }

        /// <summary>
        /// 指令 特性
        /// </summary>
        /// <param name="isAckResult">是否ACK响应结果是成功</param>
        /// <param name="methods">执行指令方法</param>
        public InstructionAttribute(bool isAckResult, params string[] methods)
        {
            if (methods == null || methods.Length <= 0)
                throw new KaadasException("未配置指令方法");
            IsAckResult = isAckResult;
            Methods = methods;
        }
    }
}
