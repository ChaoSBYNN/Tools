﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Attributes
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
    public class EnumValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return false; // 或者根据需求返回 true 或者其他逻辑
            }

            if (value is Enum)
            {
                return Enum.IsDefined(value.GetType(), value);
            }

            return false; // 如果不是枚举类型，返回 false，或者根据需要定制逻辑
        }

        public override string FormatErrorMessage(string name)
        {
            return $"参数{name}输入的枚举值未定义";
        }
    }
}
