﻿using System;

namespace Kaadas.Iot.CommonDto.Attributes
{
    /// <summary>
    /// 默认排序特性 标识 分页数据时 排序字段
    /// </summary>
    public class DefaultSortAttribute : Attribute
    {
    }
}
