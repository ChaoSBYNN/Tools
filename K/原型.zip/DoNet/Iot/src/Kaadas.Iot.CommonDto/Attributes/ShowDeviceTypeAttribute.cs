﻿using Kaadas.Iot.CommonDto.Enums;
using Kaadas.Iot.CommonDto.Models;
using System;

namespace Kaadas.Iot.CommonDto.Attributes
{
    /// <summary>
    /// 通讯类型展示
    /// </summary>
    public class ShowDeviceTypeAttribute : Attribute
    {
        /// <summary>
        /// 展示的设备类型
        /// </summary>
        public DeviceTypeEnum[] DeviceTypes { get; set; }

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="deviceTypes">展示的设备类型</param>
        /// <exception cref="KaadasException"></exception>
        public ShowDeviceTypeAttribute(params DeviceTypeEnum[] deviceTypes)
        {
            if (deviceTypes == null || deviceTypes.Length == 0)
                throw new KaadasException("未配置展示的设备类型");
            DeviceTypes = deviceTypes;
        }
    }
}
