﻿using System.Collections.Generic;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 路由常量
    /// </summary>
    public class CapRouterConst
    {
        /// <summary>
        /// Action日志路由
        /// </summary>
        public const string ACTION_LOG_ROUTER = "LogAction.Cap";

        /// <summary>
        ///  MQTT接收消息记录路由
        /// </summary>
        public const string MQTT_MONITOR_LOG = "Mqtt.Monitor.Log";

        /// <summary>
        /// MQTT Push MQTT推送消息记录路由
        /// </summary>
        public const string MQTT_PUSH_LOG = "Mqtt.Push.Log";

        /// <summary>
        ///  网关属性上报处理
        /// </summary>
        public const string MQTT_GATEWAY_PROPERTY = "Mqtt.Gateway.Property";

        /// <summary>
        ///  电子密钥管理上报
        /// </summary>
        public const string MQTT_LOCK_EVENT_PASSWORD = "Mqtt.Lock.Event.Password";

        /// <summary>
        ///  网关上报设备绑定
        /// </summary>
        public const string MQTT_GATEWAY_EVENT_DEVINCE_BIND = "Mqtt.Gateway.Event.Device.Bind";

        /// <summary>
        ///  下发网关绑定网关响应
        /// </summary>
        public const string MQTT_GATEWAY_BIND_REPLY = "Mqtt.Gateway.Bind.Reply";

        /// <summary>
        ///  下发网关换绑响应
        /// </summary>
        public const string MQTT_GATEWAY_REBIND_REPLY = "Mqtt.Gateway.Rebind.Reply";

        /// <summary>
        ///  下发网关绑定设备响应
        /// </summary>
        public const string MQTT_LOCK_BIND_REPLY = "Mqtt.Lock.Bind.Reply";

        /// <summary>
        ///  下发水电采集器绑定水表/电表响应
        /// </summary>
        public const string MQTT_WE_BIND_REPLY = "Mqtt.WE.Bind.Reply";

        /// <summary>
        ///  门锁开关门事件上报
        /// </summary>
        public const string MQTT_LOCK_EVENT_SWITCHLOCK = "Mqtt.Lock.Event.OpenLock";

        /// <summary>
        ///  门锁警报事件上报
        /// </summary>
        public const string MQTT_LOCK_EVENT_ALARMLOCK = "Mqtt.Lock.Event.AlarmLock";

        /// <summary>
        ///  门锁电量上报
        /// </summary>
        public const string MQTT_LOCK_PROPERTY_POWER = "Mqtt.Lock.Property.Power";

        /// <summary>
        ///  门锁参数变更上报
        /// </summary>
        public const string MQTT_LOCK_PROPERTY_PARAMETERCHANGE = "Mqtt.Lock.Property.ParameterChange";

        /// <summary>
        ///  门锁属性上报
        /// </summary>
        public const string MQTT_LOCK_PROPERTY_HARDWARE = "Mqtt.Lock.Property.Hardware";

        /// <summary>
        ///  门锁信号强度上报
        /// </summary>
        public const string MQTT_LOCK_PROPERTY_RSSI = "Mqtt.Lock.Property.Rssi";

        /// <summary>
        /// 设备OTA
        /// </summary>
        public const string OTA_UPGRADES_DEVICE = "OTA.UpgradesDevice";

        /// <summary>
        /// 设备OTA上报
        /// </summary>
        public const string MQTT_OTA_UPGRADESDEVICE_REPLY = "Mqtt.OTA.UpgradesDevice.Reply";

        /// <summary>
        /// 网关重启响应
        /// </summary>
        public const string MQTT_GATEWAY_RESTART_REPLY = "Mqtt.Gateway.Restart.Reply";

        /// <summary>
        /// 网关设置响应
        /// </summary>
        public const string MQTT_GATEWAY_SET_REPLY = "Mqtt.Gateway.Set.Reply";

        /// <summary>
        /// 网关预警
        /// </summary>
        public const string MQTT_GATEWAY_EVENT_WARNING = "Mqtt.Gateway.Event.Warning";

        /// <summary>
        /// 设备在线状态上报
        /// </summary>
        public const string MQTT_LOCK_EVENT_ONLINE = "Mqtt.Lock.Event.Online";

        /// <summary>
        /// 网关OTA 事件上报
        /// </summary>
        public const string MQTT_GATEWAY_EVENT_OTA = "Mqtt.Gateway.Event.OTA";

        /// <summary>
        /// 电子密钥管理响应
        /// </summary>
        public const string MQTT_LOCK_SERVICES_PWDMGMT_REPLY = "Mqtt.Lock.Services.PwdMgmt.Reply";

        /// <summary>
        /// 获取读数响应/读数上报
        /// </summary>
        public const string MQTT_METER_SERVICES_READINGRECORD = "Mqtt.Meter.Services.ReadingRecord";

        /// <summary>
        /// 获取状态响应/状态上报
        /// </summary>
        public const string MQTT_METER_SERVICES_STATUS = "Mqtt.Meter.Services.Status";

        /// <summary>
        /// 异常上报
        /// </summary>
        public const string MQTT_METER_EVENT_ABNORMAL = "Mqtt.Meter.Event.Abnormal";

        /// <summary>
        /// 电表拉合闸响应
        /// </summary>
        public const string MQTT_EM_SERVICES_ELECSWITCH = "Mqtt.EM.Services.Elecswitch";

        /// <summary>
        /// 水电表信息上报
        /// </summary>
        public const string MQTT_WEM_PROPERTY_INFO = "Mqtt.WEM.Property.Info";

        /// <summary>
        /// 水电采集器信息上报
        /// </summary>
        public const string MQTT_WEC_PROPERTY_INFO = "Mqtt.WEC.Property.Info";


        /// <summary>
        /// 获取路由列表
        /// </summary>
        /// <returns></returns>
        public static List<string> GetRouters()
        {
            List<string> list = new List<string>();
            var type = typeof(CapRouterConst);
            var fields = type.GetFields();
            foreach (var field in fields)
            {
                var value = type.InvokeMember(field.Name, System.Reflection.BindingFlags.GetField, null, null, null);
                if (value != null)
                    list.Add(value.ToString());
            }
            return list;
        }
    }
}
