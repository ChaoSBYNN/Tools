﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 设备属性
    /// </summary>
    public class DevicePropertyConst
    {
        /// <summary>
        /// 固件版本
        /// </summary>
        public const string SOFTWAREVER = "SoftwareVer";
        /// <summary>
        /// 硬件版本
        /// </summary>
        public const string HARDWAREVER = "HardwareVer";

        /// <summary>
        /// 门锁语言
        /// </summary>
        public const string LANGUAGE = "语言";

        /// <summary>
        /// 门锁语言
        /// </summary>
        public const string OPERATING_MODES = "门锁工作模式";

        /// <summary>
        /// 门锁状态
        /// </summary>
        public const string LOCK_STATE = "门锁状态";

        /// <summary>
        /// 门锁音量
        /// </summary>
        public const string SOUND_VOLUME = "门锁音量";
    }
}
