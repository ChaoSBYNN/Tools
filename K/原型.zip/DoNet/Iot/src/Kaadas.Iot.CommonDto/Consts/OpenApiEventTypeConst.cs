﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// OpenApi 事件类型常量
    /// </summary>
    public class OpenApiEventTypeConst
    {
        /// <summary>
        /// 设备绑定
        /// </summary>
        public const string DEVICE_BINDING = "dms.openapi.common.deviceBinding";

        /// <summary>
        /// 设备解绑
        /// </summary>
        public const string DEVICE_UNBINDING = "dms.openapi.common.deviceUnbinding";
         
        /// <summary>
        /// 设备换绑
        /// </summary>
        public const string DEVICE_REBINDING = "dms.openapi.common.deviceRebinding";
    }
}
