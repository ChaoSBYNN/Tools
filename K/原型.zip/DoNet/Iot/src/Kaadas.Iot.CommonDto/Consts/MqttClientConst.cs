﻿using System;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// MQTT Client相关常量
    /// </summary>
    public class MqttClientConst
    {
        /// <summary>
        /// Monitor Host MQTT连接 ClientID
        /// </summary>
        public const string MONITOR_HOST_CLIENT = "Monitor.Host";

        /// <summary>
        /// Push Host MQTT连接 ClientID
        /// </summary>
        public const string PUSH_HOST_CLIENT = "Push.Host"; 
    }
}
