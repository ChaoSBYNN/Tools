﻿namespace Kaadas.Iot.CommonDto.Consts
{
    public class PasswordEncryptionKeyConst
    {
        /// <summary>
        /// 设备密码加密key
        /// </summary>
        public const string DEVICE_PASSWORD_AES = "F646CB5A15807305";
    }
}
