﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Consts
{
    public class DelayMQConst
    {
        /// <summary>
        /// OpenApi延迟交换机
        /// </summary>
        public const string OPENAPI_DELAY_EXCHANGE = "Kaadas.Iot.OpenApi.Delayed.Exchange";

        /// <summary>
        /// OpenApi延迟队列
        /// </summary>
        public const string OPENAPI_DELAY_QUEUE = "Kaadas.Iot.OpenApi.Delayed.Queue";

        /// <summary>
        /// OpenApi RoutingKey
        /// </summary>
        public const string OPENAPI_DELAY_ROUTINGKEY = "Iot.OpenApi";
    }
}
