﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 
    /// </summary>
    public class OpenApiConst
    {
        #region 事件类型
        /// <summary>
        /// 操作密码事件上报
        /// </summary>
        public const string LOCK_PASSWORD = "dms.openapi.lock.password";

        /// <summary>
        /// 门锁警报事件上报
        /// </summary>
        public const string LOCK_ALARM = "dms.openapi.lock.alarm";

        /// <summary>
        /// 门锁开关门事件上报
        /// </summary>
        public const string OPERATE_LOCK = "dms.openapi.lock.operate";

        /// <summary>
        /// 门锁信息上报
        /// </summary>
        public const string LOCK_INFO = "dms.property.lock.info";

        /// <summary>
        /// 门锁电量上报
        /// </summary>
        public const string LOCK_POWER = "dms.property.lock.power";

        /// <summary>
        /// 门锁电量上报
        /// </summary>
        public const string LOCK_RSSI = "dms.property.lock.rssi";
        #endregion
    }
}
