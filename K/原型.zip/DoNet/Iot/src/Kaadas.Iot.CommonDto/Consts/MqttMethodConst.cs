﻿using Kaadas.Iot.CommonDto.Attributes;
using System;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// MQTT Payload 中的Method 常量
    /// </summary>
    public class MqttMethodConst
    {
        #region 网关 Method
        /// <summary>
        /// 通知网关绑定
        /// </summary>
        [SkipCheckTopo]
        public const string GATEWAY_BIND = "dms.gw.service.binding";

        /// <summary>
        /// 通知网关绑定锁
        /// </summary>
        public const string LOCK_BIND = "dms.gw.service.device.binding";

        /// <summary>
        /// 通知设备解绑
        /// </summary>
        [SkipCheckTopo]
        public const string LOCK_UNBIND = "dms.gw.service.unbinding";

        /// <summary>
        /// 通知水电采集器绑定水电表
        /// </summary>
        [SkipCheckTopo]
        public const string WE_BIND = "dms.wem.service.device.binding";

        /// <summary>
        /// 通知设备解绑
        /// </summary>
        [SkipCheckTopo]
        public const string WE_UNBIND = "  dms.wem.service.unbinding ";

        /// <summary>
        /// 设置网关
        /// </summary>
        public const string GATEWAY_SET = "dms.gw.service.setting";  

        /// <summary>
        /// 网关属性上报
        /// </summary>
        [SkipCheckTopo]
        public const string GATEWAY_PROPERTY_POST = "dms.gw.property.posting";

        /// <summary>
        /// 子设备上线上报
        /// </summary>
        public const string GATEWAY_DEVICE_LOGIN_POST = "dms.gw.event.device.online";  

        /// <summary>
        /// 网关重启
        /// </summary>
        public const string GATEWAY_RESTART = "dms.gw.service.restart";

        /// <summary>
        /// 信道设置
        /// </summary>
        public const string GATEWAY_CHANNEL_SET = "dms.gw.service.setting";

        /// <summary>
        /// 网关预警事件
        /// </summary>
        public const string GATEWAY_WARNING = "dms.gw.event.warning";

        /// <summary>
        /// 网关换绑
        /// </summary> 
        public const string GATEWAY_REBIND = "dms.gw.service.rebinding";
        #endregion

        #region 锁 Method 
        /// <summary>
        /// 锁属性上报
        /// </summary>
        [SkipCheckTopo]
        public const string LOCK_PROPERTY_POST = "dms.lock.property.lockInfo.post";

        /// <summary>
        /// 电子密钥管理上报
        /// </summary>
        public const string LOCK_PASSWORD_POST = "dms.lock.event.program.post";

        /// <summary>
        /// 门锁操作事件上报
        /// </summary>
        public const string LOCK_OPERATE_POST = "dms.lock.event.operate.post";

        /// <summary>
        /// 门锁警告事件上报
        /// </summary>
        public const string LOCK_ALARM_POST = "dms.lock.event.alarm.post";


        /// <summary>
        /// 设备在线状态上报
        /// </summary>
        public const string LOCK_CHECKONLINE_POST = "dms.lock.event.checkOnline.post";

        /// <summary>
        /// 门锁无线信息上报
        /// </summary>
        public const string LOCK_WIRELESS_POST = "dms.lock.property.wireless.post";

        /// <summary>
        /// 门锁参数变更上报
        /// </summary>
        public const string LOCK_PARAMETERCHANGE_POST = "dms.lock.property.parameterChange.post";

        /// <summary>
        /// 门锁电量上报
        /// </summary>
        public const string LOCK_POWER_POST = "dms.lock.property.power.post";

        /// <summary>
        /// 远程电子密钥编辑
        /// </summary>
        public const string LOCK_PASSWORD_EDIT = "dms.lock.services.passwordMgmt";

        /// <summary>
        /// 本地指纹添加授权
        /// </summary>
        public const string LOCK_PASSWORD_ADDAUTH = "dms.lock.services.fingerprintauth";

        /// <summary>
        /// 远程电子密钥操作
        /// </summary>
        public const string LOCK_PASSWORD_SET = "dms.lock.services.pwdOperate";

        /// <summary>
        /// 远程开锁
        /// </summary>
        public const string LOCK_OPENLOCK_SET = "dms.lock.services.unlock";

        /// <summary>
        /// 刷新门锁状态
        /// </summary>
        public const string LOCK_ISALIVE_CHECK = "dms.lock.services.isAlive";

        /// <summary>
        /// 批量清除锁端密钥
        /// </summary>
        public const string LOCK_PASSWORD_CLEARALL = "dms.lock.services.clearAll";

        /// <summary>
        /// 设备在线状态
        /// </summary>
        public const string GATEWAY_CHECKONLINE = "dms.lock.services.checkOnline";
        #endregion

        #region 水电采集器 Method
        /// <summary>
        /// 水电表绑定
        /// </summary>
        [SkipCheckTopo]
        public const string WEM_BIND = "dms.wem.service.device.binding";

        /// <summary>
        /// 水电采集器重启
        /// </summary>
        public const string WEM_RESTART = "dms.wem.service.restart";

        /// <summary>
        /// 定时上报设置
        /// </summary>
        public const string WEM_AUTOINTERVAL = "dms.wem.services.autointerval";
        #endregion

        #region 水表 Method
        /// <summary>
        /// 水表抄表
        /// </summary>
        public const string DMS_WM_SERVICES_READRECORD = "dms.wm.services.readrecord";

        /// <summary>
        /// 获取水表状态
        /// </summary>
        public const string DMS_WM_SERVICES_STATUS = "dms.wm.services.status";

        /// <summary>
        /// 水表异常上报
        /// </summary>
        public const string DMS_WM_EVENT_ABNORMAL_POST = "dms.wm.event.abnormal.post";

        /// <summary>
        /// 水表读数上报
        /// </summary>
        public const string DMS_WM_EVENT_READING_POST = "dms.wm.event.reading.post";

        /// <summary>
        /// 水表状态上报
        /// </summary>
        public const string DMS_WM_EVENT_STATUS_POST = "dms.wm.event.status.post";

        /// <summary>
        /// 水表历史读数上报
        /// </summary>
        public const string DMS_WM_EVENT_HISREADING_POST = "dms.wm.event.hisreading.post";

        /// <summary>
        /// 水表历史异常上报
        /// </summary>
        public const string DMS_WM_EVENT_HISABNORMAL_POST = "dms.wm.event.hisabnormal.post";

        /// <summary>
        /// 水表信息上报
        /// </summary>
        public const string DMS_WM_PROPERTY_INFO_POST = "dms.wm.property.info.post";
        #endregion

        #region 电表 Method
        /// <summary>
        /// 电表抄表
        /// </summary>
        public const string DMS_EM_SERVICES_READRECORD = "dms.em.services.readrecord";

        /// <summary>
        /// 电表拉合闸
        /// </summary>
        public const string DMS_EM_SERVICES_ELECSWITCH = "dms.em.services.elecswitch";

        /// <summary>
        /// 获取电表状态
        /// </summary>
        public const string DMS_EM_SERVICES_STATUS = "dms.em.services.status";

        /// <summary>
        /// 电表异常上报
        /// </summary>
        public const string DMS_EM_EVENT_ABNORMAL_POST = "dms.em.event.abnormal.post";

        /// <summary>
        /// 电表读数上报
        /// </summary>
        public const string DMS_EM_EVENT_READING_POST = "dms.em.event.reading.post";

        /// <summary>
        /// 电表状态上报
        /// </summary>
        public const string DMS_EM_EVENT_STATUS_POST = "dms.em.event.status.post";

        /// <summary>
        /// 电表信息上报
        /// </summary>
        public const string DMS_EM_PROPERTY_INFO_POST = "dms.em.property.info.post";
        #endregion

        #region Common
        /// <summary>
        /// OTA升级
        /// </summary>
        public const string GATEWAY_OTA = "dms.gw.services.ota";
        #endregion
    }
}
