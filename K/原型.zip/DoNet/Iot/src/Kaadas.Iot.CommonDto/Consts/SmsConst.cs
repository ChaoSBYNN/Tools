﻿
namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 短信模板常量
    /// </summary>
    public class SmsConst
    {
        /// <summary>
        /// 短信签名
        /// </summary>
        public const string SMS_SIGN = "凯迪仕智慧租住";
        /// <summary>
        /// 师傅预约短信模板
        /// </summary>
        public const string APPOINT_TEMPLATE = "SMS_462660004";
        /// <summary>
        /// 修改账号验证码模板
        /// </summary>
        public const string UPDATECODE_TEMPLATE= "SMS_207910119";

        /// <summary>
        /// 卡片指纹下发模板
        /// </summary>
        public const string CARDFINGERPRINT = "SMS_464085790";

        /// <summary>
        /// 在线密码下发模板
        /// </summary>
        public const string ONLINEPWD= "SMS_464065827";

        /// <summary>
        /// 离线密码下发模板
        /// </summary>
        public const string OFFLINEPWD = "SMS_464070755";

        /// <summary>
        /// 远程授权，本地在线添加指纹
        /// </summary>
        public const string LOCALFINGERPRINT = "SMS_465431652";
    }
}
