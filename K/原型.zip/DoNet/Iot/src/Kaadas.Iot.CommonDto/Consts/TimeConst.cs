﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 时间常量 单位：秒
    /// </summary>
    public class TimeConst
    {
        /// <summary>
        /// 五秒
        /// </summary>
        public const int FIVE_SECONDS = 5;

        /// <summary>
        /// 三十秒
        /// </summary>
        public const int THIRTY_SECONDS = 30;

        /// <summary>
        /// 两百秒
        /// </summary>
        public const int TWO_HUNDRED_SECONDS = 200;

        /// <summary>
        /// 一分钟
        /// </summary>
        public const int ONE_MINUTE = 60;

        /// <summary>
        /// 三分钟
        /// </summary>
        public const int THREE_MINUTES = 3 * 60;

        /// <summary>
        /// 四分钟
        /// </summary>
        public const int FOUR_MINUTES = 4 * 60;

        /// <summary>
        /// 五分钟
        /// </summary>
        public const int FIVE_MINUTES = 5 * 60;

        /// <summary>
        /// 十分钟
        /// </summary>
        public const int TEN_MINUTES = 10 * 60;

        /// <summary>
        /// 十五分钟
        /// </summary>
        public const int FIFTEEN_MINUTES = 15 * 60;

        /// <summary>
        /// 半小时
        /// </summary>
        public const int HALF_HOUR = 30 * 60;

        /// <summary>
        /// 一小时
        /// </summary>
        public const int ONE_HOUR = 60 * 60;

        /// <summary>
        /// 四小时
        /// </summary>
        public const int FOUR_HOURS = 4 * 60 * 60;

        /// <summary>
        /// 八小时
        /// </summary>
        public const int EIGHT_HOURS = 8 * 60 * 60;

        /// <summary>
        /// 一天
        /// </summary>
        public const int ONE_DAY = 24 * 60 * 60;

        /// <summary>
        /// 七天
        /// </summary>
        public const int SEVER_DAY = 7 * 24 * 60 * 60;

        /// <summary>
        /// 十五天
        /// </summary>
        public const int FIFTEEN_DAY = 15 * 24 * 60 * 60;

        /// <summary>
        /// 一个月
        /// </summary>
        public const int ONE_MONTH = 30 * 24 * 60 * 60;
    }
}
