﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 
    /// </summary>
    public class SeqCodeConst
    { 
        /// <summary>
        /// 菜单编号
        /// </summary>
        public const string MENU_CODE = "k.MeunNo";

        /// <summary>
        /// 菜单元素编号
        /// </summary>
        public const string MENU_ELEMENT_CODE = "k.ElementNo";

        /// <summary>
        /// 角色编号
        /// </summary>
        public const string ROLE_CODE = "k.RoleNo";

        /// <summary>
        /// 用户编号
        /// </summary>
        public const string USER_CODE = "k.UserNo";

        /// <summary>
        /// 部门编号
        /// </summary>
        public const string DEPARTMENT_CODE = "k.DepartmentNo";

        /// <summary>
        /// 运营方
        /// </summary>
        public const string OPERATOR_CODE = "r.OperNo";
        /// <summary>
        /// 运营方用户编号
        /// </summary>
        public const string OPERATOR_USER_CODE = "r.OperUserNo";

        /// <summary>
        /// 房源编号
        /// </summary>
        public const string OPERATION_HOUSE_CODE = "dms.OperHouseNo";

        /// <summary>
        /// 房间编号
        /// </summary>
        public const string ROOM_CODE = "dms.RoomNo";

        /// <summary>
        /// 工单编号
        /// </summary>
        public const string WORK_ORDER_CODE = "WOM.WorkNo";

        /// <summary>
        /// 设备编号
        /// </summary>
        public const string DEVICE_CODE = "dms.DeviceNo";

        /// <summary>
        /// 团队编号
        /// </summary>
        public const string TEAM_CODE = "WOM.TeamNo";

        /// <summary>
        /// 师傅编号
        /// </summary>
        public const string WORKER_CODE = "WOM.workerNo";

        /// <summary>
        /// 联网编号
        /// </summary>
        public const string NET_DEVICE_CODE = "DMS.NetDeviceNo";

        /// <summary>
        /// 授权编号
        /// </summary>
        public const string AUTHORIZATION_CODE = "RMS.AuthNo";

        /// <summary>
        /// 密码编号
        /// </summary>
        public const string SECRET_CODE = "RMS.SecretNo";

        /// <summary>
        /// 版本信息编号
        /// </summary>
        public const string VERSION_INFO_CODE = "OTA.VersionNo";

        /// <summary>
        /// 升级任务编号
        /// </summary>
        public const string UPGRADE_TASK_CODE = "OTA.UpgradeTaskNo";

        /// <summary>
        /// 升级任务明细编号
        /// </summary>
        public const string UPGRADE_TASK_DETAIL_CODE = "OTA.UpgradeTaskDetailNo";

        /// <summary>
        /// 手工抄表编号
        /// </summary>
        public const string MANUAL_READING_CODE = "DMS.ManualReadingNo";
    }
}
