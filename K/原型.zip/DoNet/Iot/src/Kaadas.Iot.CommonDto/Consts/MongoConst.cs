﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// MongoDb 库名、集合名 常量
    /// </summary>
    public class MongoConst
    {
        //*******************************************Mongo库***********************************************
        /// <summary>
        /// 日志库名
        /// </summary>
        public const string LOG_DB = "DB_Iot_Logs";

        /// <summary>
        /// 设备管理库名
        /// </summary>
        public const string DMS_DB = "DB_DMS";


        //*******************************************Mongo集合*********************************************
        /// <summary>
        /// 异常集合名
        /// </summary>
        public const string EXCEPTION_COLLECTION = "ExceptionLog";

        /// <summary>
        /// Action请求记录集合名
        /// </summary>
        public const string ACTION_COLLECTION = "ActionLog";

        /// <summary>
        /// Action请求结果记录集合名
        /// </summary>
        public const string ACTION_RESULT_COLLECTION = "ActionResult";

        /// <summary>
        /// 登录日志集合名
        /// </summary>
        public const string LOGIN_LOG_COLLECTION = "LoginLog";

        /// <summary>
        /// Monitor 接收消息记录
        /// </summary>
        public const string MONITOR_MESSAGE_COLLECTION = "MonitorMessage";

        /// <summary>
        /// Push 推送消息记录
        /// </summary>
        public const string PUSH_MESSAGE_COLLECTION = "PushMessage";

        /// <summary>
        /// 系统业务操作日志
        /// </summary>
        public const string BUSINESS_LOGS = "BusinessLogs";


        /// <summary>
        /// 平台研发推送的产测数据记录
        /// </summary>
        public const string PLATFORMPTPRODUCT_LOGS = "PlatformPTProductlogs";

        /// <summary>
        /// 设备操作记录
        /// </summary>
        public const string DEVICE_OPER_LOG_COLLECTION = "DeviceOperLog";


        /// <summary>
        /// 网关信息
        /// </summary>
        public const string GATEWAY_INFO_COLLECTION = "GatewayInfo";

        /// <summary>
        /// 网关预警
        /// </summary>
        public const string GATEWAY_WARNING_COLLECTION = "GatewayWarning";

        /// <summary>
        /// 设备事件推送运营方日志
        /// </summary>
        public const string EVENT_PUSH = "EventPush";

        /// <summary>
        /// 设备事件推送运营方异常错误日志
        /// </summary>
        public const string EVENT_PUSH_Error = "EventPushError";

    }
}
