﻿using System;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// Redis 缓存Key
    /// </summary>
    public class RedisKeyConst
    {
        /// <summary>
        /// 异常次数
        /// </summary>
        public const string EXCEPTION_COUNT = "Global:ExceptionCount";

        /// <summary>
        /// 师傅信息缓存
        /// </summary>
        public const string WORKERS_INFO = "Global:Workers";

        /// <summary>
        /// 管理员信息缓存
        /// </summary>
        public const string MANAGERS_INFO = "Global:Managers";

        /// <summary>
        /// 管理员+运营方信息缓存
        /// </summary>
        public const string MANAGERS_OPER_INFO = "Global:ManagersOper";

        /// <summary>
        /// 站点请求Id
        /// </summary>
        public const string REQUEST_ID = "Global:Request:{0}";

        /// <summary>
        /// CAP消息
        ///  string.Format(RedisKeyConst.CAP_MESSAGE,{MessageId})
        /// </summary>
        public const string CAP_MESSAGE = "CAP:Message:{0}";

        /// <summary>
        /// 验证码
        /// </summary>
        public const string CAPTCHA_KEY = "Captcha:{0}";

        /// <summary>
        /// 手机验证码
        /// </summary>
        public const string CAPTCHA_PHONE_KEY = "Captcha:Phone:{0}";

        /// <summary>
        /// 消息id锁
        /// </summary>
        public const string MSG_ID_LOCKER = "Global:Msg:Id";

        #region 登录  
        /// <summary>
        /// 删除 使用 授权 KEYS 批量删除某个用户的授权 
        ///  string.Format(RedisKeyConst.AUTHORIZE_KEYS,{ProjectType},{Platform},{no})
        /// </summary>
        public const string AUTHORIZE_KEYS = "Login:LoginToken:{0}:{1}:*:{2}";

        /// <summary>
        /// 站点Token Key 
        /// string.Format(RedisKeyConst.PROJECT_AUTHORIZE_KEY,{ProjectType},{Platform},{no})
        /// </summary>
        public const string PROJECT_AUTHORIZE_KEY = "Login:LoginToken:{0}:{1}:{2}";

        /// <summary>
        /// 用户登录失败 缓存key
        /// string.Format(RedisKeyConst.LOGIN_ERROR_KEY,{ProjectType},{用户号})
        /// </summary>
        public const string LOGIN_ERROR_KEY = "Login:LoginError:{0}:{1}";
        #endregion

        /// <summary>
        /// 字典数据缓存
        /// string.Format(RedisKeyConst.ITEM_DATA,{ItemCode})
        /// </summary>
        public const string ITEM_DATA = "Items:{0}";

        /// <summary>
        /// 区域数据缓存
        /// </summary>
        public const string AREA_KEY = "Area:List";

        /// <summary>
        /// 区域数据缓存
        /// </summary>
        public const string AREA_TREE_KEY = "Area:Tree";

        #region 师傅小程序
        /// <summary>
        /// 师傅顶部导航数据
        /// string.Format(RedisKeyConst.WORKER_TAB_DATA,{WorkerNo})
        /// </summary>
        public const string WORKER_TAB_DATA = "Worker:Tab:{0}";

        /// <summary>
        /// 师傅签到
        /// string.Format(RedisKeyConst.WORKER_SIGN,{WorkerNo})
        /// </summary>
        public const string WORKER_SIGN = "Worker:Sign:{0}";

        /// <summary>
        /// 师傅忘记密码
        /// </summary>
        public const string WORKER_FORGOTPWD = "WORKER:FORGOTPWD:{0}";
        #endregion

        /// <summary>
        /// 绑定设备请求
        /// string.Format(RedisKeyConst.DEVICE_BIND_REQUEST,{unique}) 
        /// </summary>
        public const string DEVICE_BIND_REQUEST = "Device:BindRequest:{0}";

        #region MQTT
        /// <summary>
        /// MQTT连接池子 
        /// 类型 : hash
        /// Filed: ESN  , Value:new MqttConnetedDto{}
        /// </summary>
        public const string MQTT_CONNECTED_POOL = "Mqtt:ConnectedPool";

        /// <summary>
        /// MQTT 主题
        /// </summary>
        public const string MQTT_TOPIC = "Mqtt:Topics";

        /// <summary>
        /// MQTT消息id锁
        /// </summary>
        public const string MQTT_MSG_ID_LOCKER = "Mqtt:Id";

        /// <summary>
        /// MQTT消息请求
        /// string.Format(RedisKeyConst.MQTT_PUSH_REQUEST,{Type}{唯一标识})
        /// </summary>
        public const string MQTT_PUSH_REQUEST = "Mqtt:Push:{0}:{1}";

        /// <summary>
        /// MQTT消息请求
        /// string.Format(RedisKeyConst.MQTT_PUSH_MSGID,{Type}{唯一标识})
        /// </summary>
        public const string MQTT_PUSH_MSGID = "Mqtt:PushMsgId:{0}:{1}";

        /// <summary>
        /// MQTT消息log
        /// string.Format(RedisKeyConst.MQTT_PUSH_LOG,{MsgId})
        /// </summary>
        public const string MQTT_PUSH_LOG = "Mqtt:PushLog:{0}";

        /// <summary>
        /// MQTT 下发指令，已处理（成功/超时）的指令会删除
        /// 类型：ZSet Member：MsgId， Score: ExpireTimeStamp:
        /// </summary>
        public const string MQTT_INSTRUCTION = "Mqtt:Instruction";

        /// <summary>
        /// MQTT已处理消息
        /// string.Format(RedisKeyConst.MQTT_Execute_Message,{MsgId})
        /// </summary>
        public const string MQTT_Execute_Message = "Mqtt:ExecuteMessage:{0}";

        /// <summary>
        /// MQTT 结果
        /// string.Format(RedisKeyConst.MQTT_RESULT,{Type},{设备ESN})
        /// </summary>
        public const string MQTT_RESULT = "Mqtt:Result:{0}:{1}";

        /// <summary>
        /// MQTT ACK
        /// string.Format(RedisKeyConst.MQTT_ACK,{Type},{设备ESN})
        /// </summary>
        public const string MQTT_ACK = "Mqtt:Receive:{0}:{1}";
        #endregion  

        /// <summary>
        /// 密码Id流水号
        /// string.Format(RedisKeyConst.PASSWORD_FREEZE_RESULT,{门锁ESN}{密码类型})
        /// </summary>
        public const string PASSWORD_ADD_ID = "Password:ADD:ID:{0}:{1}";

        /// <summary>
        /// 指纹文件地址KEY
        /// </summary>
        public const string FINGERPRINT = "PingerPrint:File:{0}";

        /// <summary>
        /// 设备活跃记录 - 类型：ZSet
        /// </summary>
        public const string DEVICES_ACTIVE_REOCRD = "Device:Active";

        /// <summary>
        /// 网关重启ACK
        /// </summary>
        public const string GATEWAY_RESTART_STATUS = "Gateway:RestartAck:{0}";

        /// <summary>
        /// 获取后台SEQ序号
        /// </summary>
        public const string MANAGER_SEQ_KEY = "Manager_Seq_Key:{0}";

        /// <summary>
        /// OTA任务
        /// </summary>
        public const string OTA_RUN_TASK = "OTA:RunTask:{0}";

        /// <summary>
        /// OTA终止任务
        /// </summary>
        public const string OTA_ENDTASK_KEY = "OTA:EndTask:{0}";

        #region OPENAPI相关
        /// <summary>
        /// 开放平台授权token
        /// </summary>
        public const string KOP_AUTH_TOKEN_KEY = "KOP:Auth:Token:{0}";

        /// <summary>
        /// 开放平台授访问频率
        /// </summary>
        public const string KOP_AUTH_FREQUENCY_KEY = "KOP:AUTH:Frequency:{0}:{1}";

        /// <summary>
        /// 调用运营方API重试
        /// </summary>
        public const string KOP_RETRYP_KEY = "KOP:Retryp:{0}";

        /// <summary>
        /// 调用运营方API错误次数
        /// </summary>
        public const string KOP_ERRORNUM_KEY = "KOP:ErrorNum:{0}";
        #endregion

        /// <summary>
        /// 发布工具 发布Key
        /// </summary>
        public const string DEVOPS_PUBLISH_SITE="DevOps:Publish:Site";

        /// <summary>
        /// 延迟队列
        /// </summary>
        public const string RABBITMQ_DELAY_QUEUES = "RabbitMQ:Delay:Queues";

        /// <summary>
        /// MQTT 连接加锁
        /// string.Format(RedisKeyConst.MQTT_CONNECT_LOCKER,{ClientId})
        /// </summary>
        public const string MQTT_CONNECT_LOCKER = "Mqtt:ConnectLocker:{0}";

        /// <summary>
        /// 推送消息MQTT使用计数
        /// </summary>
        public const string PUSH_CLIENT_INDEX_COUNTER = "Global:PushCounter";

        /// <summary>
        /// 下发的6位随机授权码
        /// </summary>
        public const string SEND_AUTH_SIXCODE = "Send:AuthSixCode:{0}";
    }
}
