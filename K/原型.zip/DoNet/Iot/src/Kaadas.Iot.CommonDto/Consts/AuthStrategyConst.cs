﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 权限等级
    /// </summary>
    public class AuthStrategyConst
    {
        /// <summary>
        /// 租住管理平台全部数据
        /// </summary>
        public const string ManageDataALL = "ManageDataALL";

        /// <summary>
        /// 部门数据
        /// </summary>
        public const string Department= "DepartmentData";
    }
}
