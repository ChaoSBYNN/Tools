﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 步骤条状态
    /// </summary>
    public class StepStatusConst
    {
        /// <summary>
        /// wait 状态
        /// </summary>
        public const string WAIT = "wait";

        /// <summary>
        /// process 状态
        /// </summary>
        public const string PROCESS = "process";

        /// <summary>
        /// finish 状态
        /// </summary>
        public const string FINISH = "finish";

        /// <summary>
        /// error 状态
        /// </summary>
        public const string ERROR = "error";

        /// <summary>
        /// success 状态
        /// </summary>
        public const string SUCCESS = "success";
    }
}
