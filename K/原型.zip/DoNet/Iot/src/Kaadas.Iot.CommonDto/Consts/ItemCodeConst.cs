﻿namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// 字典
    /// </summary>
    public class ItemCodeConst
    {
        /// <summary>
        /// 配置类型
        /// </summary>
        public const string CONFIG_CATEGORY = "Iot.Config.Category";

        /// <summary>
        /// 工单异常类型
        /// </summary>
        public const string WORK_EXCEPTION_TYPE = "WorkExceptionType";

        /// <summary>
        /// 售后取消工单安装原因
        /// </summary>
        public const string MANAGER_CANCEL_WORK_REASON = "ManagerCancelWorkReason";

        /// <summary>
        /// 师傅取消工单安装原因
        /// </summary>
        public const string WORKER_CANCEL_WORK_REASON = "WorkerCancelWorkReason";

        /// <summary>
        /// 师傅技能
        /// </summary>
        public const string WORKER_TECH = "WorkerTech";

        /// <summary>
        /// 设备属性
        /// </summary>
        public const string DEVICE_PROPERTY = "DeviceProperty";

        /// <summary>
        /// 事件类型
        /// </summary>
        public const string EVENT_TYPE = "EventType";

        /// <summary>
        /// Mqtt Host 连接校验用户
        /// </summary>

        public const string MQTT_HOST_USER = "MQTT.Host.Users";

        /// <summary>
        /// 电表最大电流 
        /// </summary>
        public const string ENERGY_METER_MAX_ELECTRIC = "EnergyMeterMaxElectric";

        /// <summary>
        /// 网关信道 
        /// </summary>
        public const string GATEWAY_CHANNELS = "GatewayChannels";
    }
}
