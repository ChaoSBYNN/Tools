﻿
namespace Kaadas.Iot.CommonDto.Consts
{
    /// <summary>
    /// MQTT 推送 Topic 常量
    /// </summary>
    public class MqttTopicConst
    {
        /// <summary>
        /// ACK确认Topic 平台 => 网关
        /// string.Format(MqttTopicConst.GATEWAY_ACK,{网关esn})
        /// </summary>
        public const string GATEWAY_ACK = "sys/down/{0}/ack";

        /// <summary>
        /// 网关服务推送 平台 => 网关
        /// string.Format(MqttTopicConst.GATEWAY_SERVICE,{网关esn})
        /// </summary>
        public const string GATEWAY_SERVICE = "sys/down/{0}/gw/service/post";

        /// <summary>
        /// 子设备管理服务 平台 => 网关
        /// string.Format(MqttTopicConst.DEVICE_SERVICE,{网关esn},{子设备esn})
        /// </summary>
        public const string DEVICE_SERVICE = "sys/down/{0}/device/{1}/service/post";

        /// <summary>
        /// OTA固件升级
        /// </summary>
        public const string OTA_UPGRADE = "ota/down/{0}/gw/upgrade/post";
    }
}
