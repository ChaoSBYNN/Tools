﻿namespace Kaadas.Iot.CommonDto.Interfaces
{
    /// <summary>
    /// 注入接口
    /// </summary>
    public interface IDenpendency
    {
    }
}
