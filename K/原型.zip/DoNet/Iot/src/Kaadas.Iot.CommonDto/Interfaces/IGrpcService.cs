﻿namespace Kaadas.Iot.CommonDto.Interfaces
{
    /// <summary>
    /// GRPC 服务
    /// </summary>
    public interface IGrpcService
    {
    }
}
