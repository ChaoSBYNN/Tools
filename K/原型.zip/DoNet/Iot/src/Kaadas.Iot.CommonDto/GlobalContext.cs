﻿using Kaadas.Iot.CommonDto.Enums;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Reflection;

namespace Kaadas.Iot.CommonDto
{
    /// <summary>
    /// 全局上下文
    /// </summary>
    public class GlobalContext
    {
        /// <summary>
        /// 所属项目
        /// </summary>
        public static ProjectTypeEnum ProjectType { get; set; }

        /// <summary>
        /// 是否记录日志
        /// </summary>
        public static bool IsLog { get; set; }

        /// <summary>
        /// Mongo 库名前缀
        /// </summary>
        public static string MongoDbNamePre { get; set; }

        /// <summary>
        /// ContentRootPath
        /// </summary>
        public static string EnvContentRootPath { get; set; }

        /// <summary>
        /// WebRootPath
        /// </summary>
        public static string EnvWebRootPath { get; set; }

        /// <summary>
        /// 是否开发环境
        /// </summary>
        public static bool IsDevelopment { get; set; }

        /// <summary>
        /// All registered service and class instance container. Which are used for dependency injection.
        /// </summary>
        public static IServiceCollection Services { get; set; }

        /// <summary>
        /// Configured service provider.
        /// </summary>
        public static IServiceProvider ServiceProvider { get; set; }

        /// <summary>
        /// 配置
        /// </summary>
        public static IConfiguration Configuration { get; set; }

        /// <summary>
        /// 获取当前version
        /// </summary>
        /// <returns></returns>
        public static string GetVersion()
        {
            Version version = Assembly.GetEntryAssembly().GetName().Version;
            return version.ToString();
        }

        /// <summary>
        /// 从注入容器中获取对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T GetService<T>()
        {
            return ServiceProvider.GetService<T>();
        }
    }
}
