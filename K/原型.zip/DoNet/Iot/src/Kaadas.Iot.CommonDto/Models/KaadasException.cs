﻿using Kaadas.Iot.CommonDto.Enums;
using System;

namespace Kaadas.Iot.CommonDto.Models
{
    /// <summary>
    /// 接口异常
    /// </summary>
    public class KaadasException : Exception
    {
        /// <summary>
        /// 接口响应状态码
        /// </summary>
        public ReqResultEnum Result { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="result">接口响应状态码</param>
        public KaadasException(string message, ReqResultEnum result = ReqResultEnum.Failure)
            : base(message)
        {
            Result = result;
        }
    }
}
