﻿using Kaadas.Iot.CommonDto.Enums;

namespace Kaadas.Iot.CommonDto.Models
{
    /// <summary>
    /// 接口响应数据
    /// </summary>
    public class KaadasResult
    {
        /// <summary>
        /// 消息ID
        /// </summary>
        public string MsgId { get; set; }

        /// <summary>
        /// 状态码
        /// </summary>
        public ReqResultEnum Code { get; set; }

        /// <summary>
        /// 返回消息
        /// </summary>
        public string Msg { get; set; }

        /// <summary>
        /// 返回消息
        /// </summary>
        public object Data { get; set; }
    }
}
