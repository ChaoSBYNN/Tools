﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 操作类型枚举
    /// </summary>
    public enum OperationTypeEnum
    {
        /// <summary>
        /// 新增
        /// </summary>
        /// 
        [Description("新增")]
        Add = 0,
        /// <summary>
        /// 更新
        /// </summary>
        /// 
        [Description("更新")]
        Update = 1,
        /// <summary>
        /// 查看
        /// </summary>
        /// 
        [Description("查看")]
        View = 2,
        /// <summary>
        /// 删除
        /// </summary>
        /// 
        [Description("删除")]
        Delete = 3,
        /// <summary>
        /// 导出
        /// </summary>
        /// 
        [Description("导出")]
        Export = 4,
        /// <summary>
        /// 导入
        /// </summary>
        /// 
        [Description("导入")]
        Import = 5
    }
}
