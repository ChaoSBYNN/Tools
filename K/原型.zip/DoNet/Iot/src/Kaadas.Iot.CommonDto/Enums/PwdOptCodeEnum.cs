﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum PwdOptCodeEnum
    {
        /// <summary>
        /// 添加
        /// </summary>
        [Description("添加")]
        Add =1,
        /// <summary>
        /// 修改
        /// </summary>
        [Description("修改")]
        Modify =2,
    }
}
