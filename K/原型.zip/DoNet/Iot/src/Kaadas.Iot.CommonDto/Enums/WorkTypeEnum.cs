﻿
using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 工单类型
    /// </summary>
    public enum WorkTypeEnum
    {
        /// <summary>
        /// 安装工单
        /// </summary>
        [Description("安装工单")]
        Install = 1,
        /// <summary>
        /// 维修工单
        /// </summary>
        [Description("维修工单")]
        Repair = 2,
        /// <summary>
        /// 拆卸工单
        /// </summary>
        [Description("拆卸工单")]
        TearDown = 3,
        /// <summary>
        /// 重装工单
        /// </summary>
        [Description("重装工单")]
        Reinstall = 4
    }
}
