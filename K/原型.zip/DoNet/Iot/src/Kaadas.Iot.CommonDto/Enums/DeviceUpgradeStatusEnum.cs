﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 设备升级状态
    /// </summary>
    public enum DeviceUpgradeStatusEnum
    {
        /// <summary>
        /// 指令下发
        /// </summary>
        [Description("指令下发")]
        InstructionIssued = 0,
        /// <summary>
        /// 指令下发失败
        /// </summary>
        [Description("指令下发失败")]
        InstructionFailed = 1,
        /// <summary>
        /// 固件下载
        /// </summary>
        [Description("固件下载")]
        FirmwareDownload = 2,
        /// <summary>
        /// 固件下载失败
        /// </summary>
        [Description("固件下载失败")]
        FirmwareDownloadFailed = 3,
        /// <summary>
        /// 升级中
        /// </summary>
        [Description("升级中")]
        Upgrading = 4,
        /// <summary>
        /// 升级完成
        /// </summary>
        [Description("升级完成")]
        UpgradeCompleted = 5,
    }
}
