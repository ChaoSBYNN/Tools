﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum BusinessTypeEnum
    {
        /// <summary>
        /// 敏感信息
        /// </summary>
        [Description("敏感信息")]
        Sensitive = 0,

        /// <summary>
        /// 账号处理
        /// </summary>
        [Description("账号处理")]
        AccountHandling = 1,

        /// <summary>
        /// 运营方管理
        /// </summary>
        [Description("运营方管理")]
        Operator = 2,

        /// <summary>
        /// 运营方房源管理
        /// </summary>
        [Description("运营方房源管理")]
        OperHouse = 3,

        /// <summary>
        /// 安维团队管理
        /// </summary>
        [Description("安维团队管理")]
        Team = 4,

    }
}
