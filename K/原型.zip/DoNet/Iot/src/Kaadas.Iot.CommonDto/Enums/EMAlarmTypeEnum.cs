﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum EMAlarmTypeEnum
    {
        /// <summary>
        /// 设备离线
        /// </summary>
        [Description("设备离线")]
        DeviceOffline = 0,
        /// <summary>
        /// 传输异常
        /// </summary>
        [Description("传输异常")]
        TransmissionException = 1,
        /// <summary>
        /// 读数上报异常预警
        /// </summary>
        [Description("读数上报异常预警")]
        AbnormalReadingReportAlert = 2,
        /// <summary>
        /// 跳表预警
        /// </summary>
        [Description("跳表预警")]
        MeterTamperingAlert = 3
    }
}
