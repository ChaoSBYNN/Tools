﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 资源状态
    /// </summary>
    public enum ResourceStatusEnum
    {
        /// <summary>
        /// 未上传
        /// </summary>
        [Description("未上传")]
        NotUploaded = 0,
        /// <summary>
        /// 已上传
        /// </summary>
        [Description("已上传")]
        Uploaded = 1
    }
}
