﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum AlarmTypeEnum
    {
        /// <summary>
        /// 电池
        /// </summary>
        [Description("电池")]
        Battery = 1,
        /// <summary>
        /// 门锁
        /// </summary>
        [Description("门锁")]
        DoorLock = 2
    }
}
