﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
   public enum OperatingModesEnum
    {
        /// <summary>
        /// 正常模式
        /// </summary>
        [Description("正常模式")]
        Normal =1,
        /// <summary>
        /// 假期模式
        /// </summary>
        [Description("假期模式")]
        Holiday =2,
        /// <summary>
        /// 反锁模式
        /// </summary>
        [Description("反锁模式")]
        Lockout =3,
        /// <summary>
        /// 常开模式
        /// </summary>
        [Description("常开模式")]
        ConstantlyOpen =4
    }
}
