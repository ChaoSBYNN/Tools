﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 设备类型
    /// </summary>
    public enum DeviceTypeEnum
    {
        /// <summary>
        /// 门锁网关
        /// </summary>
        [Description("门锁网关")]
        LockGateway = 1,

        /// <summary>
        /// 门锁
        /// </summary>
        [Description("门锁")]
        Lock = 2,

        /// <summary>
        /// 水电采集器
        /// </summary>
        [Description("水电采集器")]
        WEMeter = 3,

        /// <summary>
        /// 电表
        /// </summary>
        [Description("电表")]
        EnergyMeter = 4,

        /// <summary>
        /// 热水表
        /// </summary>
        [Description("热水表")]
        HotWaterMeter = 5,

        /// <summary>
        /// 冷水表
        /// </summary>
        [Description("冷水表")]
        ColdWaterMeter = 6
    }
}
