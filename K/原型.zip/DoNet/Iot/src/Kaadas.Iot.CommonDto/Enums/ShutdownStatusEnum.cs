﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 设备拉合闸状态
    /// </summary>
    public enum ShutdownStatusEnum
    {
        /// <summary>
        /// 断电
        /// </summary>
        [Description("断电")]
        OpenCircuit = 0,

        /// <summary>
        /// 通电
        /// </summary>
        [Description("通电")]
        ClosedCircuit = 1,
    }
}
