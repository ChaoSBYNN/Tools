﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 指令状态枚举
    /// </summary>
    public enum InstructionStatusEnum
    {
        /// <summary>
        /// 下发中
        /// </summary>
        [Description("下发中")]
        Issuing = 1,

        /// <summary>
        /// 已接收
        /// </summary>
        [Description("已接收")]
        Received = 2,

        /// <summary>
        /// 执行成功
        /// </summary>
        [Description("执行成功")]
        ExecutedSuccessfully = 3,

        /// <summary>
        /// 执行失败
        /// </summary>
        [Description("执行失败")]
        ExecutionFailed = 4,

        /// <summary>
        /// 执行超时
        /// </summary>
        [Description("执行超时")]
        ExecutedTimeout = 5 
    }
}
