﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 来源
    /// </summary>
    public enum SourceEnum
    {
        /// <summary>
        /// 平台
        /// </summary>
        [Description("平台")]
        Platform = 1,
        /// <summary>
        /// 接口
        /// </summary>
        [Description("接口")]
        Interface = 2
    }
}
