﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 授权角色类型
    /// </summary>
    public enum AuthRoleTypeEnum
    {
        /// <summary>
        /// 租客
        /// </summary>
        [Description("租客")]
        Tenant = 1,
        /// <summary>
        /// 安装师傅
        /// </summary>
        [Description("安装师傅")]
        Worker = 2,
        /// <summary>
        /// 员工
        /// </summary>
        [Description("员工")]
        Employee = 3
    }
}
