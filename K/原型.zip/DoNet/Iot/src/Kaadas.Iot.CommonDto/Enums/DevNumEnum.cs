﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    public enum DevNumEnum
    {
        /// <summary>
        /// WIFI模组
        /// </summary>
        [Description("WIFI模组")]
        WIFIModule = 1,
        /// <summary>
        /// WIFI锁
        /// </summary>
        [Description("WIFI锁")]
        WIFILock = 2,
        /// <summary>
        /// 人脸模组
        /// </summary>
        [Description("人脸模组")]
        Face = 3,
        /// <summary>
        /// 视频模组
        /// </summary>
        [Description("视频模组")]
        Video = 4,
        /// <summary>
        /// 讯美模组MCU
        /// </summary>
        [Description("讯美模组MCU")]
        MCU = 5,
        /// <summary>
        /// 前板
        /// </summary>
        [Description("前板")]
        FrontPanel = 6,
        /// <summary>
        /// 后板
        /// </summary>
        [Description("后板")]
        BackPanel = 7,
        /// <summary>
        /// 语音Flash
        /// </summary>
        [Description("语音Flash")]
        VoiceFlash = 8,
        /// <summary>
        /// 显示屏解码板
        /// </summary>
        [Description("显示屏解码板")]
        DisplayDecodeBoard = 9,
        /// <summary>
        /// 感应把手
        /// </summary>
        [Description("感应把手")]
        InductiveHandle = 10,
        /// <summary>
        /// 门磁
        /// </summary>
        [Description("门磁")]
        DoorMagnet = 11,
        /// <summary>
        /// 遥控器
        /// </summary>
        [Description("遥控器")]
        RemoteController = 12,
        /// <summary>
        /// 键盘
        /// </summary>
        [Description("键盘")]
        Keyboard = 13,
        /// <summary>
        /// 网关
        /// </summary>
        [Description("网关")]
        Gateway = 14,
        /// <summary>
        /// UVC摄像头
        /// </summary>
        [Description("UVC摄像头")]
        UVCCamera = 15,
        /// <summary>
        /// 指静脉模组
        /// </summary>
        [Description("指静脉模组")]
        Vein = 16,
        /// <summary>
        /// 超声波模组
        /// </summary>
        [Description("超声波模组")]
        Ultrasonic = 17,
        /// <summary>
        /// 雷达模组
        /// </summary>
        [Description("雷达模组")]
        Radar = 18,
        /// <summary>
        /// 指纹模组
        /// </summary>
        [Description("指纹模组")]
        Fingerprint = 19,
        /// <summary>
        /// 掌静脉模组
        /// </summary>
        [Description("掌静脉模组")]
        PalmVein = 20,
        /// <summary>
        /// 前板LCD块
        /// </summary>
        [Description("前板LCD块")]
        FrontPanelLCDBlock = 21,
        /// <summary>
        /// TOUCH芯片
        /// </summary>
        [Description("TOUCH芯片")]
        TOUCHChip = 22,
        /// <summary>
        /// 串口扩展模组
        /// </summary>
        [Description("串口扩展模组")]
        SerialPortExtension = 23,
        /// <summary>
        /// 模组代号
        /// </summary>
        [Description("模组代号")]
        ModuleCode = 24,
        /// <summary>
        /// 水电采集器
        /// </summary>
        [Description("水电采集器")]
        WEMeter = 999
    }

}
