﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 请求响应状态码
    /// </summary>
    public enum ReqResultEnum
    {
        /// <summary>
        /// 成功
        /// </summary>
        [Description("成功")]
        Success = 0,

        /// <summary>
        /// 失败
        /// </summary>
        [Description("失败")]
        Failure = 10,

        /// <summary>
        /// 登录无效
        /// </summary>
        [Description("登录无效")]
        Invalid = 20,

        /// <summary>
        /// 没有权限
        /// </summary>
        [Description("没有权限")]
        NoPermission = 30,

        /// <summary>
        /// 程序异常
        /// </summary>
        [Description("程序异常")]
        ProgramException = 40,

        /// <summary>
        /// 请求无效
        /// </summary>
        [Description("请求无效")]
        InvalidRequest = 50,

        /// <summary>
        /// topo关系不存在
        /// </summary>
        [Description("topo关系不存在")]
        TopoNotExists = 60,

        /// <summary>
        /// 消息重复
        /// </summary>
        [Description("消息重复")]
        DuplicateMessage = 70,

        /// <summary>
        /// Token过期
        /// </summary>
        [Description("Token过期")]
        TokenExpires = 80,

        /// <summary>
        /// Token错误
        /// </summary>
        [Description("Token错误")]
        TokenException = 90
    }
}
