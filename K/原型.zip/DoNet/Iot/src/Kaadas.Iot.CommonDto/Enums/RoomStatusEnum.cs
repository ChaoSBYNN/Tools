﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 房间状态
    /// </summary>
    public enum RoomStatusEnum
    {
        /// <summary>
        /// 无设备
        /// </summary>
        [Description("无设备")]
        NoDevice = 0,

        /// <summary>
        /// 招租中
        /// </summary>
        [Description("招租中")]
        ForRent = 1,

        /// <summary>
        /// 已入住
        /// </summary>
        [Description("已入住")]
        Occupied = 2,

        /// <summary>
        /// 暂停
        /// </summary>
        [Description("暂停")]
        Paused = 3
    }
}
