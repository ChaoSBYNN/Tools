﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 时区
    /// </summary>
    public enum TimeZoneEnum
    {
        /// <summary>
        /// 东八区
        /// </summary>
        [Description("东八区")]
        UTC8 = 32,
    }
}
