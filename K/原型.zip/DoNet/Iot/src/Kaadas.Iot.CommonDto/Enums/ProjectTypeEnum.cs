﻿using System;
using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 项目枚举
    /// </summary>
    public enum ProjectTypeEnum
    {
        /// <summary>
        /// 管理系统
        /// </summary>
        [Description("管理系统")]
        ManageHost = 1,

        /// <summary>
        /// 消息监听项目
        /// </summary>
        [Description("消息监听项目")] 
        MonitorHost = 2,

        /// <summary>
        /// MQTT鉴权项目
        /// </summary>
        [Description("Mqtt钩子-鉴权项目")]
        AuthHost = 3,

        /// <summary>
        /// MQTT消息推送项目
        /// </summary>
        [Description("MQTT消息推送项目")]
        PushHost = 4,

        /// <summary>
        /// CAP项目
        /// </summary>
        [Description("CAP项目")]
        CAPHost = 5,

        /// <summary>
        /// 师傅小程序
        /// </summary>
        [Description("师傅小程序")]
        WorkerHost = 6,

        /// <summary>
        /// 定时任务
        /// </summary>
        [Description("定时任务")]
        TaskHost = 7,

        /// <summary>
        /// 设备服务项目
        /// </summary>
        [Description("设备服务项目")]
        DeviceServer = 8,

        /// <summary>
        /// 开放平台API
        /// </summary>
        [Description("开放平台API")]
        OpenApi = 9, 

        /// <summary>
        /// 开发运维 WebApi项目
        /// </summary>
        [Description("开发运维 WebApi项目")]
        DevOps = 10
    }
}
