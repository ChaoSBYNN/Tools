﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 平台密码枚举
    /// </summary>
    public enum SecretStatusEnum
    {
        /// <summary>
        /// 未生效
        /// </summary>
        [Description("未生效")]
        NotActivated = 0,
        /// <summary>
        /// 已删除
        /// </summary>
        [Description("已删除")]
        Deleted = 1,
        /// <summary>
        /// 已生效
        /// </summary>
        [Description("已生效")]
        Active = 2,
        /// <summary>
        /// 已冻结
        /// </summary>
        [Description("已冻结")]
        Frozen = 3,
        /// <summary>
        /// 已过期
        /// </summary>
        [Description("已过期")]
        Expired =4

    }
}
