﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 工单系统用户类型
    /// </summary>
    public enum WorkUserTypeEnum
    {
        /// <summary>
        /// 售后
        /// </summary>
        [Description("售后")]
        AfterSale = 1,
        /// <summary>
        /// 师傅
        /// </summary>
        [Description("师傅")] 
        Worker = 2,
        /// <summary>
        /// 运营方
        /// </summary>
        [Description("运营方")]
        Operator = 3
    }
}
