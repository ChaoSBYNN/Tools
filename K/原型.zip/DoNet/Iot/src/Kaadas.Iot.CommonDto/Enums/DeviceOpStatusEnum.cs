﻿namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 设备操作状态
    /// </summary>
    public enum DeviceOpStatusEnum
    {
        /// <summary>
        /// 常态
        /// </summary>
        Normal = 1,

        /// <summary>
        /// 绑定中(换绑操作绑定)
        /// </summary>
        Binding = 2,

        /// <summary>
        /// 解绑中(换绑操作解绑)
        /// </summary>
        Unbinding = 3 
    }
}
