﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum LockOperEventCodeEnum
    {
        /// <summary>
        /// 未知的
        /// </summary>
        [Description("未知的")]
        Unknown = 0,
        /// <summary>
        /// 上锁
        /// </summary>
        [Description("上锁")]
        Lock = 1,
        /// <summary>
        /// 开锁
        /// </summary>
        [Description("开锁")]
        Unlock = 2,
        /// <summary>
        /// 错误密钥或ID上锁
        /// </summary>
        [Description("错误密钥或ID上锁")]
        ErrorKeyOrIDLock = 3,
        /// <summary>
        /// 错误密钥或ID开锁
        /// </summary>
        [Description("错误密钥或ID开锁")]
        ErrorKeyOrIDUnlock = 4,
        /// <summary>
        /// 无效的密钥或ID开锁
        /// </summary>
        [Description("无效的密钥或ID开锁")]
        InvalidKeyOrIDUnlock = 5,
        /// <summary>
        /// 无效的计划开锁
        /// </summary>
        [Description("无效的计划开锁")]
        InvalidPlanUnlock = 6,
        /// <summary>
        /// 一键上锁
        /// </summary>
        [Description("一键上锁")]
        OneKeyLock = 7,
        /// <summary>
        /// 钥匙上锁
        /// </summary>
        [Description("钥匙上锁")]
        KeyLock = 8,
        /// <summary>
        /// 钥匙开锁
        /// </summary>
        [Description("钥匙开锁")]
        KeyUnlock = 9,
        /// <summary>
        /// 自动上锁
        /// </summary>
        [Description("自动上锁")]
        AutoLock = 10,
        /// <summary>
        /// 计划上锁
        /// </summary>
        [Description("计划上锁")]
        PlanLock = 11,
        /// <summary>
        /// 计划开锁
        /// </summary>
        [Description("计划开锁")]
        PlanUnlock = 12,
        /// <summary>
        /// 手动上锁
        /// </summary>
        [Description("手动上锁")]
        ManualLock = 13,
        /// <summary>
        /// 手动开锁
        /// </summary>
        [Description("手动开锁")]
        ManualUnlock = 14,

    }
}
