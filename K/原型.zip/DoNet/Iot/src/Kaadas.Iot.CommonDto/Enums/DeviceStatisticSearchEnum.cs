﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 门锁警报
    /// </summary>
    public enum DeviceStatisticSearchEnum
    {
        /// <summary>
        /// 本月
        /// </summary>
        [Description("本月")]
        ThisMonth = 1,
        /// <summary>
        /// 近三个月
        /// </summary>
        [Description("近三个月")]
        NearThreeMonth = 2,
        /// <summary>
        /// 近半月
        /// </summary>
        [Description("近半月")]
        NearHalfMonth = 3,
        /// <summary>
        /// 近一年
        /// </summary>
        [Description("近一年")]
        NearOneYear = 4
    }
}
