﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 密钥类型
    /// </summary>
    public enum SecretTypeEnum
    {
        /// <summary>
        /// 限时
        /// </summary>
        [Description("限时")]
        LimitedTime = 1,
        /// <summary>
        /// 周期性
        /// </summary>
        [Description("周期性")]
        Periodic = 2,
        /// <summary>
        /// 限次
        /// </summary>
        [Description("限次")]
        LimitedCount = 3
    }
}
