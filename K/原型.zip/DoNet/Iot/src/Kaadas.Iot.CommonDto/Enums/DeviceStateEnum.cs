﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 联网设备状态
    /// </summary>
    public enum DeviceStateEnum
    {
        /// <summary>
        /// 在线
        /// </summary>
        [Description("在线")]
        Online = 1,
        /// <summary>
        /// 离线
        /// </summary>
        [Description("离线")]
        Offline = 2,
        /// <summary>
        /// 异常
        /// </summary>
        [Description("异常")]
        Abnormal = 3
    }
}
