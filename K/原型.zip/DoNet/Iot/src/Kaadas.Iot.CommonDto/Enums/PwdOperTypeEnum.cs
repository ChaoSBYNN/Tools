﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum PwdOperTypeEnum
    {
        /// <summary>
        /// 新增
        /// </summary>
        [Description("新增")]
        Add = 1,
        /// <summary>
        /// 删除
        /// </summary>
        [Description("删除")]
        Delete = 2,
        /// <summary>
        /// 冻结
        /// </summary>
        [Description("冻结")]
        Freeze = 3,
        /// <summary>
        /// 解冻
        /// </summary>
        [Description("解冻")]
        Unfreeze = 4,
        /// <summary>
        /// 修改
        /// </summary>
        [Description("修改")]
        Modify =5
    }
}
