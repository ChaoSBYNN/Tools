﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 微信类型
    /// </summary>
    public enum WxClassifyEnum
    {
        /// <summary>
        /// 师傅小程序
        /// </summary>
        [Description("师傅小程序")]
        WorkerApp = 1
    }
}
