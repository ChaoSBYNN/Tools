﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 网关预警类型
    /// </summary>
    public enum GwWarningTypeEnum
    {
        /// <summary>
        /// 设备平台没有
        /// </summary>
        [Description("设备平台没有")]
        PlatformNoDevice = 1,
        
        /// <summary>
        /// 设备网关没有
        /// </summary>
        [Description("设备网关没有")]
        GatewayNoDevice = 2
    }
}
