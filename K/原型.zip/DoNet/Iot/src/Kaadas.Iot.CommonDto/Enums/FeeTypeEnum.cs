﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 费用类型
    /// </summary>
    public enum FeeTypeEnum
    {
        /// <summary>
        /// 标准安装服务
        /// </summary>
        [Description("标准安装服务")]
        Standard = 10,
        /// <summary>
        /// 附加费用
        /// </summary>
        [Description("附加费用")]
        Additional = 20,
        /// <summary>
        /// 扣除费用
        /// </summary>
        [Description("扣除费用")]
        Deduction = 30
    }
}
