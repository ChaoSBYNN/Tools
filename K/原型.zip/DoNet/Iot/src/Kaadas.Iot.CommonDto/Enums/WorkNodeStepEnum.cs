﻿using Kaadas.Iot.CommonDto.Attributes;
using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 工单步骤节点枚举
    /// </summary>
    public enum WorkNodeStepEnum
    {
        /// <summary>
        /// 新建工单
        /// </summary>
        [NodeStepType(NodeTypeEnum.CreateWorkOrder)]
        [Description("新建工单")]
        CreateWorkOrder = 1,

        /// <summary>
        /// 售后派单
        /// </summary>
        [NodeStepType(NodeTypeEnum.DispatchAfterSales)]
        [Description("售后派单")]
        DispatchAfterSales = 2,

        /// <summary>
        /// 指派师傅
        /// </summary>
        [NodeStepType(NodeTypeEnum.AssignTechnician)]
        [Description("指派师傅")]
        AssignTechnician = 3,

        /// <summary>
        /// 预约上门
        /// </summary>
        [NodeStepType(NodeTypeEnum.ScheduleAppointment)]
        [Description("预约上门")]
        ScheduleAppointment = 4,

        /// <summary>
        /// 上门打卡
        /// </summary>
        [NodeStepType(NodeTypeEnum.PunchIn)]
        [Description("上门打卡")]
        PunchIn = 5,

        /// <summary>
        /// 安装完工
        /// </summary>
        [NodeStepType(NodeTypeEnum.InstallationCompletion)]
        [Description("安装完工")]
        InstallationCompletion = 6,

        /// <summary>
        /// 审核完成
        /// </summary>
        [NodeStepType(NodeTypeEnum.Approve, NodeTypeEnum.Reject)]
        [Description("审核完成")]
        AuditCompleted = 7
    }
}
