﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 上传资源类型 -  资源类型枚举定义不用中文 
    /// </summary>
    public enum ResourceTypeEnum
    {
        /// <summary>
        /// 预约图片
        /// </summary>
        [Description("预约图片")]
        Appoint = 1,

        /// <summary>
        /// 异常反馈图片
        /// </summary>
        [Description("异常反馈图片")]
        AbnormalFeedback = 2,

        /// <summary>
        /// OTA文件
        /// </summary>
        [Description("OTA文件")]
        OTA = 3,

        /// <summary>
        /// 升级设备导入文件
        /// </summary>
        [Description("升级设备导入文件")]
        UpgradeDevice = 4,

        /// <summary>
        /// 维修工单上传图片
        /// </summary>
        [Description("维修工单上传图片")]
        RepairWork = 5,

        /// <summary>
        /// 拆卸工单上传图片
        /// </summary>
        [Description("拆卸工单上传图片")]
        TearDownWork = 6,
    }
}
