﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum EventSourceEnum
    {
        /// <summary>
        /// 密码
        /// </summary>
        [Description("密码")]
        Password = 1,
        /// <summary>
        /// 无线
        /// </summary>
        [Description("无线")]
        Wireless = 2,
        /// <summary>
        /// 手动
        /// </summary>
        [Description("手动")]
        Manual = 3,
        /// <summary>
        /// 卡片
        /// </summary>
        [Description("卡片")]
        Card = 4,
        /// <summary>
        /// 指纹
        /// </summary>
        [Description("指纹")]
        Fingerprint = 5,
        /// <summary>
        /// 无定义
        /// </summary>
        [Description("无定义")]
        Undefined = 255
    }
}
