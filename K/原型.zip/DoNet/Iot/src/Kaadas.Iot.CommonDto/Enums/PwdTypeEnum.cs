﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 密码类型
    /// </summary>
    public enum PwdTypeEnum
    {
        /// <summary>
        /// 密码
        /// </summary>
        [Description("密码")]
        Password = 1,
        /// <summary>
        /// 卡片
        /// </summary>
        [Description("卡片")]
        Card = 2,
        /// <summary>
        /// 指纹
        /// </summary>
        [Description("指纹")]
        Fingerprint = 3
    }
}
