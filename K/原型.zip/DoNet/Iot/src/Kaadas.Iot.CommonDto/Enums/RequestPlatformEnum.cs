﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 请求平台
    /// </summary>
    public enum RequestPlatformEnum
    {
        /// <summary>
        /// PC
        /// </summary>
        [Description("PC")]
        PC = 1,
        /// <summary>
        /// Wechat
        /// </summary>
        [Description("Wechat")]
        Wechat = 2
    }
}
