﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
   public enum SoundVolumeEnum
    {
        /// <summary>
        /// 静音
        /// </summary>
        [Description("静音")]
        Mute = 0,
        /// <summary>
        /// 低音量
        /// </summary>
        [Description("低音量")]
        LowVolume = 1,
        /// <summary>
        /// 高音量
        /// </summary>
        [Description("高音量")]
        HighVolume = 2
    }
}
