﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 房间类型
    /// </summary>
    public enum RoomTypeEnum 
    {
        /// <summary>
        /// 房间
        /// </summary>
        [Description("房间")]
        Room = 1,
        /// <summary>
        /// 公区
        /// </summary>
        [Description("公区")]
        PublicArea = 2,
    }
}
