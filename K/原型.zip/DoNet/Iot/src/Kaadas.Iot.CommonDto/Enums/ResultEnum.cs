﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 结果
    /// </summary>
    public enum ResultEnum
    {
        /// <summary>
        /// 成功
        /// </summary>
        [Description("成功")]
        Success = 0,

        /// <summary>
        /// 失败
        /// </summary>
        [Description("失败")]
        Fail = 10,

        /// <summary>
        /// 重复操作
        /// </summary>
        [Description("重复操作")]
        Repeat =20
    }
}
