﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 设备操作类型
    /// </summary>
    public enum DeviceOperTypeEnum
    {
        /// <summary>
        /// 绑定设备
        /// </summary>
        [Description("绑定设备")]
        BindDevice = 1,

        /// <summary>
        /// 解绑设备
        /// </summary>
        [Description("解绑设备")]
        UnbindDevice = 2,

        /// <summary>
        /// 重启设备
        /// </summary>
        [Description("重启设备")]
        RebootDevice = 3,

        /// <summary>
        /// 远程开门
        /// </summary>
        [Description("远程开门")]
        RemoteOpenDoor = 4,

        /// <summary>
        /// 设置信道
        /// </summary>
        [Description("设置信道")]
        SetChannel = 5,

        /// <summary>
        /// 设备配网
        /// </summary>
        [Description("设备配网")]
        DeviceNetworking = 6,

        /// <summary>
        /// 网关换绑
        /// </summary>
        [Description("网关换绑")]
        GatewayRebinding = 7,
        /// <summary>
        /// 刷新门锁状态
        /// </summary>
        [Description("刷新门锁状态")]
        RefreshLockIsAlive = 8,
        /// <summary>
        /// 临时抄表
        /// </summary>
        [Description("临时抄表")]
        SuddenMeterReading = 9,
        /// <summary>
        /// 电表拉闸
        /// </summary>
        [Description("电表拉闸")]
        EnergySwitchOut = 10,
        /// <summary>
        /// 电表合闸
        /// </summary>
        [Description("电表合闸")]
        EnergySwitchOn = 11,
        /// <summary>
        /// 获取设备状态
        /// </summary>
        [Description("获取设备状态")]
        MeterStatus = 12,
    }
}
