﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 用户类型
    /// </summary>
    public enum UserTypeEnum
    {
        /// <summary>
        /// OpenAPI
        /// </summary>
        [Description("OpenAPI")]
        OpenAPI = 1,
        /// <summary>
        /// 员工
        /// </summary>
        [Description("员工")]
        Employee = 2,
        /// <summary>
        /// 平台
        /// </summary>
        [Description("平台")]
        Platform = 3,
        /// <summary>
        /// 师傅
        /// </summary>
        [Description("师傅")]
        Worker = 4,
        /// <summary>
        /// 租户
        /// </summary>
        [Description("租户")]
        Tenant = 5
    }
}
