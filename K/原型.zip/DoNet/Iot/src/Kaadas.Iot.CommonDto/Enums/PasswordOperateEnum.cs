﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum PasswordOperateEnum
    {
        /// <summary>
        /// 删除
        /// </summary>
        [Description("删除")]
        Delete = 1,
        /// <summary>
        /// 解冻
        /// </summary>
        [Description("解冻")]
        Unfreeze = 2,
        /// <summary>
        /// 冻结
        /// </summary>
        [Description("冻结")]
        Freeze = 3
    }
}
