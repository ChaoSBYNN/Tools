﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 師傅身份枚举
    /// </summary>
    public enum WorkerIdentityEnum
    {
        /// <summary>
        /// 团队负责人
        /// </summary>
        [Description("团队负责人")]
        TeamLeader = 1,

        /// <summary>
        /// 普通师傅
        /// </summary>
        [Description("普通师傅")]
        OrdinaryWorker = 2
    }
}
