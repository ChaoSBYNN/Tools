﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum WMReadingRecordTypeEnum
    {
        /// <summary>
        /// 定时上报
        /// </summary>
        [Description("定时上报")]
        AutoRecord = 0,
        /// <summary>
        /// 临时抄表
        /// </summary>
        [Description("临时抄表")]
        SuddenMeterReading = 1,
        /// <summary>
        /// 手工抄表
        /// </summary>
        [Description("手工抄表")]
        ManualMeterReading = 2,
        /// <summary>
        /// 历史读数上报
        /// </summary>
        [Description("历史读数上报")]
        HisMeterReadingRecord = 3
    }
}
