﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 工单状态枚举
    /// </summary>
    public enum WorkStatusEnum
    {
        /// <summary>
        /// 待派单
        /// </summary>
        [Description("待派单")]
        PendingDispatch = 1,
        /// <summary>
        /// 待指派
        /// </summary>
        [Description("待指派")]
        PendingAssignment = 2,
        /// <summary>
        /// 待预约
        /// </summary>
        [Description("待预约")]
        PendingAppointment = 3,
        /// <summary>
        /// 待安装
        /// </summary>
        [Description("待安装")]
        PendingInstallation = 4,
        /// <summary>
        /// 待核销
        /// </summary>
        [Description("待核销")]
        PendingVerification = 5,
        /// <summary>
        /// 已完结
        /// </summary>
        [Description("已完结")]
        Completed = 6,
        /// <summary>
        /// 待审核
        /// </summary>
        [Description("待审核")]
        PendingReview = 9,
        /// <summary>
        /// 已关闭
        /// </summary>
        [Description("已关闭")]
        Closed = 10
    }
}
