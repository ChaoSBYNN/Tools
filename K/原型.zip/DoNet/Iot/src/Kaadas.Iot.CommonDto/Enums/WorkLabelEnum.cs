﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum WorkLabelEnum
    {
        /// <summary>
        /// 二次上门
        /// </summary>
        [Description("二次上门")]
        SecondVisit = 1,
        /// <summary>
        /// 异常反馈
        /// </summary>
        [Description("异常反馈")]
        ExceptionFeedback = 2
    }
}
