﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    public enum DelPwdTypeEnum
    {
        /// <summary>
        /// 普通用户
        /// </summary>
        [Description("普通用户")]
        Users =1,
        /// <summary>
        /// 管理员
        /// </summary>
        [Description("管理员")]
        Admin =2,
        /// <summary>
        /// 普通用户和管理员
        /// </summary>
        [Description("普通用户和管理员")]
        UsersAndAdmin =3,
    }
}
