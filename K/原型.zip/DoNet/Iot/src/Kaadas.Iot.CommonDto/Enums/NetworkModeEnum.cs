﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 联网方式
    /// </summary>
    public enum NetworkModeEnum
    {
        /// <summary>
        /// 4G
        /// </summary>
        [Description("4G")]
        _4G = 1,
        /// <summary>
        /// 以太网
        /// </summary>
        [Description("以太网")]
        Ethernet = 2,
    }
}
