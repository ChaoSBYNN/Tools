﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum HomeTypeEnum
    {
        /// <summary>
        /// 分散型
        /// </summary>
        [Description("分散型")]
        Dispersed = 1,
        /// <summary>
        /// 集中型
        /// </summary>
        [Description("集中型")]
        Centralized = 2,

    }
}
