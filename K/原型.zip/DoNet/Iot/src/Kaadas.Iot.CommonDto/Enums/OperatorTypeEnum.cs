﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 运营方类型
    /// </summary>
    public enum OperatorTypeEnum
    {
        /// <summary>
        /// 品牌公寓
        /// </summary>
        [Description("品牌公寓")]
        BrandApartment = 1,
        /// <summary>
        /// 保障房
        /// </summary>
        [Description("保障房")]
        GuaranteedHousing = 2,
        /// <summary>
        /// 公租房
        /// </summary>
        [Description("公租房")]
        PublicRentalHousing = 3,
        /// <summary>
        /// 城中村
        /// </summary>
        [Description("城中村")]
        UrbanVillage = 4,
        /// <summary>
        /// 散户
        /// </summary>
        [Description("散户")]
        IndividualHousehold = 5,
        /// <summary>
        /// 企业宿舍
        /// </summary>
        [Description("企业宿舍")]
        CorporateDormitory = 6,
        /// <summary>
        /// 学校宿舍
        /// </summary>
        [Description("学校宿舍")]
        SchoolDormitory = 7,

    }
}
