﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 运营方用户角色
    /// </summary>
    public enum OperUserTypeEnum
    {
        /// <summary>
        /// 楼栋长
        /// </summary>
        [Description("楼栋长")]
        BuildingLeader = 1,
        /// <summary>
        /// 房东
        /// </summary>
        [Description("房东")]
        Landlord = 2,
        /// <summary>
        /// 物业
        /// </summary>
        [Description("物业")]
        PropertyManagement = 3,
    }
}
