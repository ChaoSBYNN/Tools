﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 
    /// </summary>
   public enum AlarmStatusEnum
    {
        /// <summary>
        /// 解除
        /// </summary>
        [Description("解除")]
        Resolved =0,
        /// <summary>
        /// 触发
        /// </summary>
        [Description("触发")]
        Triggered =1
    }
}
