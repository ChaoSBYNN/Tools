﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 工单节点类型
    /// </summary>
    public enum NodeTypeEnum
    {
        /// <summary>
        /// 新建工单
        /// </summary>
        [Description("新建工单")]
        CreateWorkOrder = 10,
        /// <summary>
        /// 编辑工单
        /// </summary>
        [Description("编辑工单")]
        EditWorkOrder = 20,
        /// <summary>
        /// 备注工单
        /// </summary>
        [Description("备注工单")]
        RemarkWorkOrder = 30,
        /// <summary>
        /// 售后派单
        /// </summary>
        [Description("售后派单")]
        DispatchAfterSales = 40,
        /// <summary>
        /// 指派师傅
        /// </summary>
        [Description("指派师傅")]
        AssignTechnician = 50,
        /// <summary>
        /// 预约上门
        /// </summary>
        [Description("预约上门")]
        ScheduleAppointment = 60,
        /// <summary>
        /// 改约
        /// </summary>
        [Description("改约")]
        ChangeAppointment = 70,
        /// <summary>
        /// 上门打卡
        /// </summary>
        [Description("上门打卡")]
        PunchIn = 80,
        /// <summary>
        /// 异常反馈
        /// </summary>
        [Description("异常反馈")]
        AbnormalFeedback = 90,
        /// <summary>
        /// 绑定设备
        /// </summary>
        [Description("绑定设备")]
        BindDevice = 100,
        /// <summary>
        /// 解绑设备
        /// </summary>
        [Description("解绑设备")]
        UnbindDevice = 110,
        /// <summary>
        /// 安装完工
        /// </summary>
        [Description("安装完工")]
        InstallationCompletion = 120,
        /// <summary>
        /// 取消安装
        /// </summary>
        [Description("取消安装")]
        CancelInstallation = 130,
        /// <summary>
        /// 审核通过
        /// </summary>
        [Description("审核通过")]
        Approve = 140,
        /// <summary>
        /// 审核不通过
        /// </summary>
        [Description("审核不通过")]
        Reject = 150,
        /// <summary>
        /// 设置信道
        /// </summary>
        [Description("设置信道")]
        SetChannel = 160,
        /// <summary>
        /// 设备配网
        /// </summary>
        [Description("设备配网")]
        DeviceNetworking = 170,

        /// <summary>
        /// 设备配网
        /// </summary>
        [Description("网关换绑")]
        GatewayRebinding = 180
    }
}
