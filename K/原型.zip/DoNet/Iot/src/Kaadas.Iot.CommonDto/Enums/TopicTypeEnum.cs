﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// MQTT Topic 类型
    /// </summary>
    public enum TopicTypeEnum
    {
        /// <summary>
        /// 服务
        /// </summary>
        [Description("服务")]
        Sevice = 1,

        /// <summary>
        /// 事件
        /// </summary>
        [Description("事件")]
        Event = 2,

        /// <summary>
        /// 属性
        /// </summary>
        [Description("属性")]
        Property = 3
    }
}
