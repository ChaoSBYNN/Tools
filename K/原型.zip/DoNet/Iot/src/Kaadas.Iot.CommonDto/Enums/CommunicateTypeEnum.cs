﻿using Kaadas.Iot.CommonDto.Attributes;
using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 通讯类型
    /// </summary>
    public enum CommunicateTypeEnum
    {
        /// <summary>
        /// LoRA网关
        /// </summary>
        [Description("LoRA网关")]
        [ShowDeviceType(DeviceTypeEnum.Lock, DeviceTypeEnum.EnergyMeter, DeviceTypeEnum.ColdWaterMeter, DeviceTypeEnum.HotWaterMeter)]
        LoRA = 1,

        /// <summary>
        /// NB_LOT
        /// </summary>
        [Description("NB")]
        [ShowDeviceType(DeviceTypeEnum.Lock, DeviceTypeEnum.EnergyMeter, DeviceTypeEnum.ColdWaterMeter, DeviceTypeEnum.HotWaterMeter)]
        NB = 2,

        /// <summary>
        /// 蓝牙
        /// </summary>
        [Description("蓝牙")]
        [ShowDeviceType(DeviceTypeEnum.Lock)]
        Bluetooth = 3,

        /// <summary>
        /// RS485
        /// </summary>
        [Description("RS485")]
        [ShowDeviceType(DeviceTypeEnum.EnergyMeter, DeviceTypeEnum.ColdWaterMeter, DeviceTypeEnum.HotWaterMeter)]
        RS485 =4,

        /// <summary>
        /// M-BUS
        /// </summary>
        [Description("M-BUS")]
        [ShowDeviceType( DeviceTypeEnum.EnergyMeter, DeviceTypeEnum.ColdWaterMeter, DeviceTypeEnum.HotWaterMeter)]
        M_BUS= 5
    }
}
