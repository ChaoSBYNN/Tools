﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 门锁警报
    /// </summary>
    public enum AlarmCodeEnum
    {
        /// <summary>
        /// 低电量报警
        /// </summary>
        [Description("低电量报警")]
        LowBattery = 1,
        /// <summary>
        /// 防撬报警
        /// </summary>
        [Description("防撬报警")]
        Tamper = 2,
        /// <summary>
        /// 锁定报警
        /// </summary>
        [Description("锁定报警")]
        Lock = 3,
        /// <summary>
        /// 堵转告警
        /// </summary>
        [Description("堵转告警")]
        Jammed =4
    }
}
