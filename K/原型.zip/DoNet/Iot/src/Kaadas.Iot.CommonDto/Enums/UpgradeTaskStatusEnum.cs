﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 升级任务状态
    /// </summary>
    public enum UpgradeTaskStatusEnum
    {
        /// <summary>
        /// 进行中
        /// </summary>
        [Description("进行中")]
        InProgress = 0,
        /// <summary>
        /// 已完成
        /// </summary>
        [Description("已完成")]
        Completed = 1,
        /// <summary>
        /// 已终止
        /// </summary>
        [Description("已终止")]
        Terminated = 2
    }
}
