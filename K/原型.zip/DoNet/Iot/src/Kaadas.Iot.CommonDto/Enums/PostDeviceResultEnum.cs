﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 跟设备交互结果
    /// </summary>
    public enum PostDeviceResultEnum
    {
        /// <summary>
        /// 成功
        /// </summary>
        [Description("成功")]
        Success = 1,
        /// <summary>
        /// 失败
        /// </summary>
        [Description("失败")]
        Failure = 2,
        /// <summary>
        /// 等待,需要开启定时轮询等待结果
        /// </summary>
        [Description("等待")]
        Waiting = 3
    }
}
