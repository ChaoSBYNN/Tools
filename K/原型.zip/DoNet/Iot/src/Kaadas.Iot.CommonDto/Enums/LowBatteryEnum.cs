﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 低电量
    /// </summary>
    public enum LowBatteryEnum
    {
        /// <summary>
        /// 低于10%
        /// </summary>
        [Description("低于10%")]
        LowTen = 10,
        /// <summary>
        /// 低于20%
        /// </summary>
        [Description("低于20%")]
        LowTwenty = 20,
    }
}
