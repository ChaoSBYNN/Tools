﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 协议类型
    /// </summary>
    public enum ProtocolEnum
    {
        /// <summary>
        /// MQTT协议
        /// </summary>
        [Description("MQTT协议")]
        MQTT = 1,
        /// <summary>
        /// HTTPS协议
        /// </summary>
        [Description("HTTPS协议")]
        HTTPS = 2
    }
}
