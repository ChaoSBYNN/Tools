﻿using System.ComponentModel;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 所属类型 枚举
    /// </summary>
    public enum BelongTypeEnum
    {
        /// <summary>
        /// 团队
        /// </summary>
        [Description("团队")]
        Team = 1,
        /// <summary>
        /// 师傅
        /// </summary>
        [Description("师傅")]
        Worker = 2
    }
}
