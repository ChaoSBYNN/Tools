﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.CommonDto.Enums
{
    /// <summary>
    /// 门锁状态
    /// </summary>
    public enum LockConditionEnum
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("未知")]
        Unknown = 0,
        /// <summary>
        /// 上锁
        /// </summary>
        [Description("上锁")]
        Lock = 1,
        /// <summary>
        /// 开锁
        /// </summary>
        [Description("开锁")]
        Unlock = 2
    }
}
