﻿namespace Kaadas.Iot.Configs
{
    public class KdsConfigKeys
    {
        public const string KDS_CONFIG_KEY = "KdsConfigs:{0}";

        /// <summary>
        /// 文件路径配置Key
        /// </summary>
        public const string FILES_PATH = "Config.FilesPath";

        // <summary>
        ///  管理员登录限制配置key
        /// </summary>
        public const string MANAGER_LOGIN_LIMIT = "Config.ManagerLoginLimit";

        // <summary>
        ///  师傅登录限制配置key
        /// </summary>
        public const string WORKER_LOGIN_LIMIT = "Config.WorkerLoginLimit";

        // <summary>
        /// 管理员修改密码限制配置key
        /// </summary>
        public const string MANAGER_CHANGE_PWD_LIMIT = "Config.ManagerChangePwdLimit";

        // <summary>
        /// 通用配置
        /// </summary>
        public const string COMMON_CONFIG = "Config.CommonConfig";

        /// <summary>
        /// 师傅微信小程序配置
        /// </summary>
        public const string WORKER_WXAPP = "Config.WorkerWxApp";

        /// <summary>
        /// 阿里云SMS配置Key
        /// </summary>
        public const string ALIYUN_SMS = "Config.AliYunSMS";

        /// <summary>
        /// 阿里OSS配置key
        /// </summary>
        public const string ALIYUN_OSS = "Config.AliYunOSS";

        /// <summary>
        /// 文件上传相关配置
        /// </summary>
        public const string FILE_UPLOAD = "Config.FileUpload";

        /// <summary>
        /// 文件上传相关配置
        /// </summary>
        public const string LOG = "Config.Log";

        /// <summary>
        /// 微信定位(腾讯地图)--地址解析Key
        /// </summary>
        public const string WX_LOCATION_ANALYSIS = "Config.WxLocationAnalysis";

        /// <summary>
        /// 证书配置
        /// </summary>
        public const string CERT_CONFIG = "Config.CertConfig";

        /// <summary>
        ///身份识别配置key
        /// </summary>
        public const string DistinguishKey = "Config.Distinguish";

        /// <summary>
        /// 公安部权威库核对认证
        /// </summary>
        public const string IdVerificationKey = "Config.IdVerification";

        #region 虚拟号相关
        public const string VirtualPhoneKey = "Config.VirtualPhone";
        #endregion

        /// <summary>
        /// 密码枚举映射
        /// </summary>
        public const string  PWDENUMCONVERT= "Config.PwdEnumConvert";

        /// <summary>
        /// 推送预警相关配置
        /// </summary>
        public const string EVENTWARNING = "Config.EventWarning";

        /// <summary>
        /// 设备操作类型
        /// </summary>
        public const string DEVICEOPERTYPE = "Config.DeviceOperType";

        /// <summary>
        /// 腾讯地址解析
        /// </summary>
        public const string WX_LOCATION = "Config.WxLocation";

        /// <summary>
        /// 服务器发布配置
        /// </summary>
        public const string SERVERPUBLISHKEY= "Config.ServerPublishConfig";

    }
}
