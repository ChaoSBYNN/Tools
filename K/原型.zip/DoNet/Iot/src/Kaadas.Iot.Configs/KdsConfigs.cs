﻿using Kaadas.Iot.Configs.ConfigEntity.Aliyun;
using Kaadas.Iot.Configs.ConfigEntity.ChangePwdLimit;
using Kaadas.Iot.Configs.ConfigEntity.KDF;
using Kaadas.Iot.Configs.ConfigEntity.Location;
using Kaadas.Iot.Configs.ConfigEntity.LoginLimit;
using Kaadas.Iot.Configs.ConfigEntity.OpenApi;
using Kaadas.Iot.Configs.ConfigEntity.System;
using Kaadas.Iot.Configs.ConfigEntity.Wechat;
using Kaadas.Iot.Configs.Helper;

namespace Kaadas.Iot.Configs
{
    /// <summary>
    /// kaadas 配置
    /// </summary>
    public class KdsConfigs
    {
        /// <summary>
        /// 文件路径配置
        /// </summary>
        public static FilesPath FilePath => KdsConfigInit.GetConfig<FilesPath>();

        /// <summary>
        /// Action日志记录配置
        /// </summary>
        public static LogConfig LogConfig => KdsConfigInit.GetConfig<LogConfig>(ConfigDefaultEnum.默认值);

        /// <summary>
        /// 管理员登录限制
        /// </summary>
        public static ManagerLoginLimit ManagerLoginLimit => KdsConfigInit.GetConfig<ManagerLoginLimit>(ConfigDefaultEnum.默认值);

        /// <summary>
        /// 师傅登录限制
        /// </summary>
        public static WorkerLoginLimit WorkerLoginLimit => KdsConfigInit.GetConfig<WorkerLoginLimit>(ConfigDefaultEnum.默认值);

        /// <summary>
        /// 管理员修改密码限制
        /// </summary>
        public static ManagerChangePwdLimit ManagerChangePwdLimit => KdsConfigInit.GetConfig<ManagerChangePwdLimit>(ConfigDefaultEnum.默认值);

        /// <summary>
        /// 通用配置
        /// </summary>
        public static CommonConfig CommonConfig => KdsConfigInit.GetConfig<CommonConfig>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 师傅微信小程序配置
        /// </summary>
        public static WorkerWxApp WorkerWxApp => KdsConfigInit.GetConfig<WorkerWxApp>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 阿里云短信配置
        /// </summary>
        public static AliYunSMS AliYunSMS => KdsConfigInit.GetConfig<AliYunSMS>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 阿里云OSS配置
        /// </summary>
        public static AliYunOSS AliYunOSS => KdsConfigInit.GetConfig<AliYunOSS>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 文件上传配置
        /// </summary>
        public static UploadFileConfig UploadFileConfig => KdsConfigInit.GetConfig<UploadFileConfig>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 微信地址解析
        /// </summary>
        public static WxLocationAnalysis WxLocationAnalysis => KdsConfigInit.GetConfig<WxLocationAnalysis>(ConfigDefaultEnum.必须配置); 

        /// <summary>
        /// 证书配置
        /// </summary>
        public static CertConfig CertConfig => KdsConfigInit.GetConfig<CertConfig>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 身份识别配置
        /// </summary>
        public static Distinguish Distinguish => KdsConfigInit.GetConfig<Distinguish>(ConfigDefaultEnum.必须配置);


        /// <summary>
        /// 公安部权威库核对认证
        /// </summary>
        public static IdVerification IdVerification => KdsConfigInit.GetConfig<IdVerification>(ConfigDefaultEnum.必须配置);

        #region 虚拟号相关
        /// <summary>
        /// 虚拟号配置
        /// </summary>
        public static AliyunVirtualPhone AliyunVirtualPhone => KdsConfigInit.GetConfig<AliyunVirtualPhone>(ConfigDefaultEnum.必须配置);
        #endregion

        /// <summary>
        /// 密码枚举映射
        /// </summary>
        public static PwdConvertConfig PwdConvertConfig => KdsConfigInit.GetConfig<PwdConvertConfig>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 事件预警配置
        /// </summary>
        public static EventWarning EventWarning => KdsConfigInit.GetConfig<EventWarning>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 设备对应操作类型
        /// </summary>
        public static DeviceOperType DeviceOperType => KdsConfigInit.GetConfig<DeviceOperType>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 腾讯地址解析
        /// </summary>
        public static WxLocation WxLocation => KdsConfigInit.GetConfig<WxLocation>(ConfigDefaultEnum.必须配置);

        /// <summary>
        /// 服务器发布配置
        /// </summary>
        public static ServerPublishConfig ServerPublishConfig => KdsConfigInit.GetConfig<ServerPublishConfig>(ConfigDefaultEnum.必须配置);

    }
}
