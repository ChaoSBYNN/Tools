﻿using Kaadas.Iot.Configs.ConfigEntity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace Kaadas.Iot.Configs.Helper
{
    public class KdsConfigInit
    {
        /// <summary>
        /// Configured service provider.
        /// </summary>
        public static IServiceProvider ServiceProvider { get; set; }

        #region 从缓存获取配置
        /// <summary>
        /// 从缓存获取配置
        /// </summary>
        /// <param name="configKey"></param>
        /// <returns></returns>
        private static string GetConfigFromCache(string configKey)
        {
            var cacheKey = string.Format(KdsConfigKeys.KDS_CONFIG_KEY, configKey); 
            var config = MemoryCacheHelper.Get(cacheKey) as string;
            if (config == null)
            {
                var result = GetConfigFromRedisCache(configKey);
                if (result != null)
                {
                    MemoryCacheHelper.Set(cacheKey, result, 5);
                }
                return result;
            }
            return config;
        }
        #endregion

        #region 从Redis缓存获取配置
        /// <summary>
        /// 从Redis缓存获取配置
        /// </summary>
        /// <param name="configKey"></param>
        /// <returns></returns>
        private static string GetConfigFromRedisCache(string configKey)
        {
            if (ServiceProvider == null)
                throw new Exception("未初始化ServiceProvider");
            var redisCacheKey = string.Format(KdsConfigKeys.KDS_CONFIG_KEY, configKey);
            var data = RedisHelper.Get(redisCacheKey);
            if (data == null)
            {
                var service = ServiceProvider.GetService<IKdsConfigService>();
                var cofingValue = service.GetConfigValue(configKey).Result;
                if (!string.IsNullOrEmpty(cofingValue))
                {
                    data = cofingValue;
                    RedisHelper.Set(redisCacheKey, data);
                }
                else
                    throw new Exception($"DB未配置该{configKey}");
            }
            return data;
        }
        #endregion

        #region 获取配置
        /// <summary>
        /// 获取配置
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T GetConfig<T>(ConfigDefaultEnum defaultEnum = ConfigDefaultEnum.必须配置) where T : class, IKdsConfig, new()
        {
            try
            {
                var data = new T();
                var key = data.ConfigKey;
                var chcheData = GetConfigFromCache(key);
                return string.IsNullOrEmpty(chcheData)
                       ? null
                       : JsonConvert.DeserializeObject<T>(chcheData);
            }
            catch (Exception ex)
            {
                switch (defaultEnum)
                {
                    case ConfigDefaultEnum.默认值:
                        return new T();
                    case ConfigDefaultEnum.默认null:
                        return null;
                    default:
                        throw ex;
                }
            }
        }
        #endregion
    }

    public enum ConfigDefaultEnum
    {
        必须配置 = 1,
        默认值 = 2,
        默认null = 3
    }
}
