﻿using System.Threading.Tasks;

namespace Kaadas.Iot.Configs.Helper
{
    public interface IKdsConfigService
    {
        /// <summary>
        /// 根据配置key 获取配置
        /// </summary>
        /// <param name="configKey"></param>
        /// <returns></returns>
        Task<string> GetConfigValue(string configKey);
    }
}
