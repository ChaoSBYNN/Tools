﻿namespace Kaadas.Iot.Configs.ConfigEntity
{
    public interface IKdsConfig
    {
        string ConfigKey { get; }
    }
}
