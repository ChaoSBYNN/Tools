﻿namespace Kaadas.Iot.Configs.ConfigEntity.ChangePwdLimit
{
    public abstract class BaseChangePwdLimit : IKdsConfig
    {
        public abstract string ConfigKey { get; }

        /// <summary>
        /// 最小长度
        /// </summary>
        public int MinLength { get; set; } = 8;

        /// <summary>
        /// 最大长度
        /// </summary>
        public int MaxLength { get; set; } = 16;

        /// <summary>
        /// 校验的正则表达式
        /// </summary>
        public string RegexExpression { get; set; } = @"^(?=.*\d)(?=.*[a-zA-Z])(?=.*[~!@#$%^&*.()])[\s\da-zA-Z~!@#$%^&*.=\-+()|\\]{8,16}$";

        /// <summary>
        /// 正则提示 -- 前端提示语句
        /// </summary>
        public string RegexPrompt { get; set; } = "密码需包含数字、字母以及特殊字符，长度为8至16位";

        /// <summary>
        /// 禁用的密码
        /// </summary>
        public string DisablePwd { get; set; } = "12345678,kds@888,kds@123456,kds@12345,kds123456,kds12345";
    }
}
