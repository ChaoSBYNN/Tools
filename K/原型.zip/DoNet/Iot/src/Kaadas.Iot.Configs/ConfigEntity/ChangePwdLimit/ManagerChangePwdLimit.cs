﻿namespace Kaadas.Iot.Configs.ConfigEntity.ChangePwdLimit
{
    public class ManagerChangePwdLimit : BaseChangePwdLimit
    {
        public override string ConfigKey => KdsConfigKeys.MANAGER_CHANGE_PWD_LIMIT;
    }
}
