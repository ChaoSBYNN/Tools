﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Configs.ConfigEntity.KDF
{
    public class ServerPublishConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.SERVERPUBLISHKEY;

        /// <summary>
        /// 允许发布的域名
        /// </summary>
        public string WebSite { get; set; }
        /// <summary>
        /// 服务器发布配置
        /// </summary>
        public List<ServerPublish> ServerPublish { get; set; }
    }

    public class ServerPublish
    {
        /// <summary>
        /// 服务器IP地址
        /// </summary>
        public string IP { get; set; }

        ///// <summary>
        ///// Nginx磁盘物理路径
        ///// </summary>
        //public string NginxPath { get; set; }

        /// <summary>
        /// 服务器上发布接口路径
        /// </summary>
        public string SiteUrl { get; set; }
    }
}
