﻿namespace Kaadas.Iot.Configs.ConfigEntity.Aliyun
{
    /// <summary>
    /// 阿里云SMS配置
    /// </summary>
    public class AliYunSMS : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.ALIYUN_SMS;
        public string AccessKeyId { get; set; }
        public string AccessKeySecret { get; set; }
        public string Domain { get; set; }

        /// <summary>
        /// 是否关闭短信通道
        /// </summary>
        public bool IsClose { get; set; }
    }
}
