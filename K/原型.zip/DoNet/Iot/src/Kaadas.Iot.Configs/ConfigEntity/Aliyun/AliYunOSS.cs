﻿namespace Kaadas.Iot.Configs.ConfigEntity.Aliyun
{
    /// <summary>
    /// 阿里云OSS配置
    /// </summary>
    public class AliYunOSS : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.ALIYUN_OSS;

        public string Endpoint { get; set; }
        public string AccessKeyId { get; set; }
        public string AccessKeySecret { get; set; }

        /// <summary>
        /// 文件存储空间
        /// </summary>
        public string FileBucketName { get; set; }


        public STSOssConfig STSOssConfig { get; set; }
    }

    /// <summary>
    /// STS 模式 配置
    /// </summary>
    public class STSOssConfig
    {
        /// <summary>
        /// AccessKeyId
        /// </summary>
        public string AccessKeyId { get; set; }


        /// <summary>
        /// AccessKeySecret
        /// </summary>
        public string AccessKeySecret { get; set; }

        /// <summary>
        /// RoleArn
        /// </summary>
        public string RoleArn { get; set; }
    }
}
