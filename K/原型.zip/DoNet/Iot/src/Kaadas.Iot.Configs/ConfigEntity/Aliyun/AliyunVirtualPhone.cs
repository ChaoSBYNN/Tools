﻿
namespace Kaadas.Iot.Configs.ConfigEntity.Aliyun
{
    public class AliyunVirtualPhone : IKdsConfig
    {
        public string ConfigKey { get { return KdsConfigKeys.VirtualPhoneKey; } }
        public string AccessKeyId { get; set; }
        public string accessKeySecret { get; set; }
        public string PoolKey { get; set; }
        public string Endpoint { get; set; }

        public string IsClose { get; set; }
    }
}
