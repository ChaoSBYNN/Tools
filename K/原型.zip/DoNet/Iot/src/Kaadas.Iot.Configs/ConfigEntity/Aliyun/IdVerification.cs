﻿namespace Kaadas.Iot.Configs.ConfigEntity.Aliyun
{
    /// <summary>
    /// 公安部权威库核对认证配置
    /// </summary>
    public class IdVerification : IKdsConfig
    {
        public string ConfigKey { get { return KdsConfigKeys.IdVerificationKey; } }
        public string Appcode { get; set; }
        public string Host { get; set; }
        public string Path { get; set; }
        public string Method { get; set; }
    }
}
