﻿namespace Kaadas.Iot.Configs.ConfigEntity.Aliyun
{
    /// <summary>
    /// 身份识别配置
    /// </summary>
    public class Distinguish : IKdsConfig
    {
        public string ConfigKey { get { return KdsConfigKeys.DistinguishKey; } }
        public string Appcode { get; set; }
        public string Url { get; set; }
        public string Method { get; set; }
    }
}
