﻿namespace Kaadas.Iot.Configs.ConfigEntity.LoginLimit
{
    public abstract class BaseLoginLimit : IKdsConfig
    {
        public abstract string ConfigKey { get; }

        /// <summary>
        /// 时间间隔 - 单位：分
        /// </summary>
        public int Interval { get; set; } = 10;

        /// <summary>
        /// 限制登录次数
        /// </summary>
        public int LimitCount { get; set; } = 5;

        /// <summary>
        /// 多次登录失败账号冷却时间 - 单位：分
        /// </summary>
        public int CoolingTime { get; set; } = 5;
    }
}
