﻿namespace Kaadas.Iot.Configs.ConfigEntity.LoginLimit
{
    public class ManagerLoginLimit : BaseLoginLimit
    {
        public override string ConfigKey => KdsConfigKeys.MANAGER_LOGIN_LIMIT;
    }
}
