﻿namespace Kaadas.Iot.Configs.ConfigEntity.LoginLimit
{
    public class WorkerLoginLimit : BaseLoginLimit
    {
        public override string ConfigKey => KdsConfigKeys.WORKER_LOGIN_LIMIT;
    }
}
