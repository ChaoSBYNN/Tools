﻿namespace Kaadas.Iot.Configs.ConfigEntity.Wechat
{
    public class WorkerWxApp : BaseWxApp
    {
        public override string ConfigKey => KdsConfigKeys.WORKER_WXAPP;
    }
}
