﻿namespace Kaadas.Iot.Configs.ConfigEntity.Wechat
{
    /// <summary>
    /// 微信小程序配置基类
    /// </summary>
    public abstract class BaseWxApp : IKdsConfig
    {
        public abstract string ConfigKey { get; }

        public string AppId { get; set; }

        public string AppSecret { get; set; }

        public string Grant_type { get; set; }

        public string Url { get; set; }
    }
}
