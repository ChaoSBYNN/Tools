﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaadas.Iot.Configs.ConfigEntity.OpenApi
{
    public class EventWarning : IKdsConfig
    {
        public string ConfigKey { get { return KdsConfigKeys.EVENTWARNING; } }

        /// <summary>
        /// 错误次数
        /// </summary>
        public int ErrorNum { get; set; }

        /// <summary>
        /// 错误次数过期时间
        /// </summary>
        public int ErrorExpiredTime { get; set; }

        /// <summary>
        /// 过期时间
        /// </summary>
        public int RetryExpiredTime { get; set; }

        /// <summary>
        /// 重试信息
        /// </summary>
        public List<RetryConfig> RetryInfo { get; set; }

        /// <summary>
        /// 重试的最大次数
        /// </summary>
        public int RetryMaximum { get; set; }

        public string RetryUrl { get; set; }
    }

    public class RetryConfig
    {
        /// <summary>
        /// 重试次数
        /// </summary>
        public int RetryNum { get; set; }

        /// <summary>
        /// 重试时间
        /// </summary>
        public int RetryTime { get; set; }
    }
}
