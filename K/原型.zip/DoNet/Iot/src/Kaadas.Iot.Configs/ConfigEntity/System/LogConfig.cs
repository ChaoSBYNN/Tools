﻿using System.Collections.Generic;

namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    /// <summary>
    /// Action日志记录配置
    /// </summary>
    public class LogConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.LOG;

        /// <summary>
        /// 项目是否记录日志
        /// <ProjectType,bool>  -- <项目类型，是否记录Action日志>
        /// </summary>
        public Dictionary<int, bool> ProjectLogs { get; set; } = new Dictionary<int, bool>();
    }
}
