﻿using System.Collections.Generic;

namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    public class UploadFileConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.FILE_UPLOAD;

        /// <summary>
        /// 文件地址超时时间 
        /// </summary>
        public double FileExpire { get; set; } = 1;

        /// <summary>
        /// 管理上传文件最大
        /// </summary>
        public int ManageMaxFileSize { get; set; } = 100;

        /// <summary>
        /// 文件 扩展配置
        /// </summary>
        public List<FileExtendConfigs> ExtendConfigs { get; set; }
    }

    /// <summary>
    /// 文件扩展配置
    /// </summary>
    public class FileExtendConfigs
    {
        /// <summary>
        /// 文件类型
        /// </summary>
        public int ResourceType { get; set; }

        /// <summary>
        /// 文件扩展
        /// </summary>
        public string FileExtend { get; set; }

        /// <summary>
        /// 是否返回地址 - 根据文件重要性 重要性文件不直接返回地址
        /// 否 则直接返回文件MD5
        /// </summary>
        public bool IsBackPath { get; set; }
    }
}
