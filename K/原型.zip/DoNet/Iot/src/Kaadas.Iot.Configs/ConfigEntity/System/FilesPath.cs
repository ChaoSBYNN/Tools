﻿namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    /// <summary>
    /// 文件位置配置
    /// </summary>
    public class FilesPath : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.FILES_PATH;

        /// <summary>
        /// 上传地址
        /// </summary>
        public string Upload { get; set; }

        /// <summary>
        /// 下载地址
        /// </summary>
        public string Down { get; set; }

        /// <summary>
        /// Grpc下载路径
        /// </summary>
        public string GrpcDown { get; set; }

        /// <summary>
        /// 设备授权文件路径
        /// </summary>
        public string DeviceAuthorize { get; set; }

        /// <summary>
        /// 设备授权文件下载地址
        /// </summary>
        public string DeviceAuthorizeDownload { get; set; }
    }
}
