﻿using System.Collections.Generic;

namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    public class PwdConvertConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.PWDENUMCONVERT;

        public List<EunumConvert> PwdStatus { get; set; }
    }

    public class EunumConvert
    { 
        public int Convert { get; set; }

        public int value { get; set; }
    }
}
