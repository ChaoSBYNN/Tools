﻿namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    public class CertConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.CERT_CONFIG;

        public string Https { get; set; }

        public string Mqtts { get; set; }
    }
}
