﻿namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    public class WxLocation : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.WX_LOCATION;

        public string Key { get; set; }

        public string Url { get; set; }
    }
}
