﻿namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    /// <summary>
    /// 通用配置
    /// </summary>
    public class CommonConfig : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.COMMON_CONFIG;

        public int IsLogMqtt { get; set; }

        /// <summary>
        /// 预警请求路径
        /// </summary>
        public string WarningUrl { get; set; }
    }
}
