﻿using System.Collections.Generic;

namespace Kaadas.Iot.Configs.ConfigEntity.System
{
    public class DeviceOperType : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.DEVICEOPERTYPE;

        public List<DeviceTypeConfigDto> DeviceTypes { get; set; }
    }

    public class DeviceTypeConfigDto
    { 
        /// <summary>
        /// 设备类型
        /// </summary>
        public int DeviceType { get; set; }

        /// <summary>
        /// 操作记录类型(用,隔开）
        /// </summary>
        public string OperType { get; set; }
    }
}
