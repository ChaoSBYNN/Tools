﻿namespace Kaadas.Iot.Configs.ConfigEntity.Location
{
    public class WxLocationAnalysis : IKdsConfig
    {
        public string ConfigKey => KdsConfigKeys.WX_LOCATION_ANALYSIS;

        public string Key { get; set; }

        /// <summary>
        /// 地址解析地址
        /// </summary>
        public string AddressUrl { get; set; }

        /// <summary>
        /// 经纬度解析地址
        /// </summary>
        public string LocationUrl { get; set; }

        public int Get_poi { get; set; }
    }
}
