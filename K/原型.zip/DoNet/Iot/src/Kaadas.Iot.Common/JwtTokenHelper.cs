﻿using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Kaadas.Iot.Common
{
    public class JwtTokenHelper
    {
        #region 颁发JWT字符串  
        /// <summary>
        /// 颁发JWT字符串
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public static string GetJwtToken(string uid, DateTime expireTime, out string nonceStr)
        {
            var jwtData = new JwtData { Uid = uid };
            nonceStr = jwtData.NonceStr;
            var claims = new List<Claim>();
            claims.AddRange(new[] { new Claim(ClaimTypes.Name, EncryptAuthentication(jwtData.ToJson())) });
            // 可以将一个用户的多个角色全部赋予
            //claims.AddRange(tokenModel.Role.Split(',').Select(s => new Claim(ClaimTypes.Role, s))); 
            //秘钥 (SymmetricSecurityKey 对安全性的要求，密钥的长度太短会报出异常)
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(ApiJwtAuthKey.SecurityKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var jwt = new JwtSecurityToken(
                issuer: ApiJwtAuthKey.Issuer,
                audience: ApiJwtAuthKey.Audience,
                signingCredentials: creds,
                claims: claims,
                notBefore: DateTime.Now,
                expires: expireTime);
            var jwtHandler = new JwtSecurityTokenHandler();
            var encodedJwt = jwtHandler.WriteToken(jwt);
            return encodedJwt;
        }
        #endregion

        #region 加密
        /// <summary>
        /// MD5加密
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Md5(string str)
        {
            var md5Hasher = MD5.Create();
            var data = md5Hasher.ComputeHash(Encoding.GetEncoding("UTF-8").GetBytes(str));
            var sBuilder = new StringBuilder();
            foreach (var t in data)
            {
                sBuilder.Append(t.ToString("x2"));
            }
            return sBuilder.ToString();
        }
        public static string EncryptAuthentication(string encryptStr)
        {
            var sKeyMd5 = Md5(ApiJwtAuthKey.AuthKey);
            using (var des = new DESCryptoServiceProvider())
            {
                var inputByteArray = Encoding.Default.GetBytes(encryptStr);
                des.Key = Encoding.ASCII.GetBytes(sKeyMd5.Substring(0, 8));
                des.IV = Encoding.ASCII.GetBytes(sKeyMd5.Substring(0, 8));
                var ms = new System.IO.MemoryStream();
                using (var cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(inputByteArray, 0, inputByteArray.Length);
                    cs.FlushFinalBlock();
                    var ret = new StringBuilder();
                    foreach (var b in ms.ToArray())
                    {
                        ret.AppendFormat("{0:X2}", b);
                    }
                    return ret.ToString();
                }
            }
        }
        #endregion

        #region 解密身份认证
        /// <summary>
        /// 解密身份认证
        /// </summary>
        /// <param name="Text"></param>
        /// <returns></returns>
        public static string DecryptAuthentication(string Text)
        {
            var sKeyMd5 = Md5(ApiJwtAuthKey.AuthKey);
            using (var des = new DESCryptoServiceProvider())
            {
                var len = Text.Length / 2;
                var inputByteArray = new byte[len];
                int x;
                for (x = 0; x < len; x++)
                {
                    var i = Convert.ToInt32(Text.Substring(x * 2, 2), 16);
                    inputByteArray[x] = (byte)i;
                }
                des.Key = Encoding.ASCII.GetBytes(sKeyMd5.Substring(0, 8));
                des.IV = Encoding.ASCII.GetBytes(sKeyMd5.Substring(0, 8));
                var ms = new System.IO.MemoryStream();
                using (var cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(inputByteArray, 0, inputByteArray.Length);
                    cs.FlushFinalBlock();
                    return Encoding.Default.GetString(ms.ToArray());
                }
            }
        }
        #endregion

        #region 获取请求头信息
        public static JwtData GetJwtData(HttpContext context)
        {
            try
            {
                var uid = context.User.Identity.Name;//uid
                if (uid.IsNullOrEmpty())
                {
                    var authorization = context.Request.Headers["Authorization"];
                    if (string.IsNullOrEmpty(authorization) || authorization.ToString().Trim() == "Bearer")
                        return null;
                    return GetJwtData(authorization);
                }
                return uid.IsEmpty() ? null : DecryptAuthentication(uid).ToObject<JwtData>();
            }
            catch
            {
                return null;
            }
        }

        public static JwtData GetJwtData(string authorization)
        {
            if (authorization.IsNullOrEmpty())
                return null;
            var jwtHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken jwtToken = jwtHandler.ReadJwtToken(authorization.ToString().Replace("Bearer ", ""));
            var uid = jwtToken.Payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"].ToString();
            return uid.IsNullOrEmpty() ? null : DecryptAuthentication(uid).ToObject<JwtData>();
        }
        #endregion
    }

    public class JwtData
    {
        /// <summary>
        /// 唯一key
        /// </summary>
        public string Uid { get; set; }

        /// <summary>
        /// 随机数
        /// </summary>
        public string NonceStr { get; set; } = Guid.NewGuid().ToString("N").ToUpper();
    }

    public class ApiJwtAuthKey
    {
        /// <summary>
        /// SecurityKey
        /// </summary>
        public const string SecurityKey = "ZDSwZWFycy5jbgoYXBwZWFycy5jzxljsz=";

        /// <summary>
        /// 发行人
        /// </summary>
        public const string Issuer = "com.kaadas.www";

        /// <summary>
        /// 订阅人
        /// </summary>
        public const string Audience = "kaadas";

        /// <summary>
        /// 加密种子
        /// </summary>
        public const string AuthKey = "kaadas.iot.encrypt";
    }
}
