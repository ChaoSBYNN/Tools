﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kaadas.Iot.Common
{
    public static class RedisCacheHelper
    {
        /// <summary>
        /// 获取缓存数据对象 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="redisKey"></param>
        /// <param name="func"></param>
        /// <param name="seconds"></param>
        /// <returns></returns>
        public static T GetCacheData<T>(this string redisKey, Func<T> func, int seconds = 5 * 60)
            where T : class
        {
            var cacheData = RedisHelper.Get<T>(redisKey);
            if (cacheData == null)
            {
                cacheData = func();
                if (cacheData != null)
                    RedisHelper.Set(redisKey, cacheData, seconds);
            }
            return cacheData;
        }

        /// <summary>
        /// 获取缓存数据对象 Async
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="redisKey"></param>
        /// <param name="func"></param>
        /// <param name="seconds"></param>
        /// <returns></returns>
        public static async Task<T> GetCacheData<T>(this string redisKey, Func<Task<T>> func, int seconds = 5 * 60)
            where T : class
        {
            var cacheData = RedisHelper.Get<T>(redisKey);
            if (cacheData == null)
            {
                cacheData = await func();
                if (cacheData != null)
                    RedisHelper.Set(redisKey, cacheData, seconds);
            }
            return cacheData;
        }

        /// <summary>
        /// 批量删除 - 键包含 *
        /// </summary>
        /// <param name="redisKey"></param>
        /// <returns></returns>
        public static async Task BatchDeleteCache(this string redisKey)
        {
            var cursor = 0;
            var red = await RedisHelper.ScanAsync(cursor, redisKey, 100);
            List<string> keys = new List<string>();
            keys.AddRange(red.Items);
            while (red.Cursor != 0)
            {
                red = await RedisHelper.ScanAsync(red.Cursor, redisKey, 100);
                keys.AddRange(red.Items);
            }
            if (keys.Any())
                await RedisHelper.DelAsync(keys.ToArray());
        }
    }
}
