﻿using Microsoft.Extensions.Configuration;
using System.IO;


namespace Kaadas.Iot.Common
{
    public class thirdConfigHelper
    {
        /// <summary>
        /// 读取json配置文件thirdConfig.json
        /// </summary>
        /// <returns></returns>
        public static IConfiguration GetConnectionString()
        {
            var configurationBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("thirdConfig.json");
            IConfiguration thirdConfig = configurationBuilder.Build();
            return thirdConfig;
        }

    }
}
