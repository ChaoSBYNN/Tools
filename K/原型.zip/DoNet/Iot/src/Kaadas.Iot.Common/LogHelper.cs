﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace Kaadas.Iot.Common
{
    public class LogHelper
    {
        private static object lockHelper = new object();
        private static object lockSharedHelper = new object();

        #region 写文本日志
        /// <summary>
        /// 写日志 异步
        /// 默认路径：根目录/Log/yyyy-MM/
        /// 默认文件：yyyy-MM-dd.log
        /// </summary>
        /// <param name="logContent">日志内容 自动附加时间</param>
        public static void Write(string logContent)
        {
            string logPath = DateTime.Now.ToString("yyyy-MM");
            Write(logPath, logContent);
        }

        public static void WriteWithTime(string logContent)
        {
            string logPath = DateTime.Now.ToString("yyyy-MM");
            logContent = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine + logContent;
            Write(logPath, logContent);
        }
        #endregion

        #region 写异常日志
        /// <summary>
        /// 写异常日志
        /// </summary>
        /// <param name="ex"></param>
        public static void Write(Exception ex)
        {
            string logContent = string.Empty;
            string logPath = DateTime.Now.ToString("yyyy-MM");
            logContent += GetExceptionMessage(ex);
            Write(logPath, logContent);
        }

        public static void WriteWithTime(Exception ex)
        {
            string logContent = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine;
            string logPath = DateTime.Now.ToString("yyyy-MM");
            logContent += GetExceptionMessage(ex);
            Write(logPath, logContent);
        }

        public static string GetExceptionMessage(Exception ex)
        {
            string message = string.Empty;
            if (ex != null)
            {
                message += ex.Message;
                message += Environment.NewLine;
                Exception originalException = ex.GetOriginalException();
                if (originalException != null)
                {
                    if (originalException.Message != ex.Message)
                    {
                        message += originalException.Message;
                        message += Environment.NewLine;
                    }
                }
                message += ex.StackTrace;
                message += Environment.NewLine;
            }
            return message;
        }
        #endregion

        #region 写日志到指定路径
        /// <summary>
        /// 写日志 异步
        /// 默认文件：yyyy-MM-dd.log
        /// </summary>
        /// <param name="logPath">日志目录[默认程序根目录\Log\下添加，故使用相对路径，如：营销任务]</param>
        /// <param name="logContent">日志内容 自动附加时间</param>
        public static void Write(string logPath, string logContent)
        {
            string logFileName = DateTime.Now.ToString("yyyy-MM-dd") + ".log";
            //string LogWay = ConfigHelper.GetSectionValue("SystemConfig:LogWay");
            WriteShared(logPath, logFileName, logContent);
            //if (string.IsNullOrWhiteSpace(LogWay))
            //    LogWay = "Local";
            //switch (LogWay)
            //{
            //    case "Local":
            //        Write(logPath, logFileName, logContent);
            //        break;
            //    case "FileShared":
            //        //先在本地也写一份，共享文件夹稳定以后再去
            //        Write(logPath, logFileName, logContent);
            //        WriteShared(logPath, logFileName, logContent);
            //        break;
            //}
        }


        /// <summary>
        /// 写日志 异步 共享文件夹
        /// </summary>
        /// <param name="logPath">日志目录</param>
        /// <param name="logFileName">日志文件名</param>
        /// <param name="logContent">日志内容 自动附加时间</param>
        public static void WriteShared(string logPath, string logFileName, string logContent)
        {

            //string IP = ConfigHelper.GetSectionValue("FileShared:IP");
            //string UserName = ConfigHelper.GetSectionValue("FileShared:UserName");
            //string Password = ConfigHelper.GetSectionValue("FileShared:Password");
            string FilePath = ConfigHelper.GetSectionValue("SystemConfig:LogBasePath") ?? AppDomain.CurrentDomain.BaseDirectory + "logs\\";
            if (string.IsNullOrWhiteSpace(logContent))
            {
                return;
            }
            if (string.IsNullOrWhiteSpace(logPath))
            {
                logPath = FilePath + $"{System.Reflection.Assembly.GetEntryAssembly().GetName().Name}\\{Environment.MachineName}\\" + DateTime.Now.ToString("yyyy-MM");
            }
            else
            {
                logPath = FilePath + $"{System.Reflection.Assembly.GetEntryAssembly().GetName().Name}\\{Environment.MachineName}\\" + logPath.Trim('\\');
            }
            Action taskAction = () =>
            {
                lock (lockSharedHelper)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(logFileName))
                        {
                            logFileName = DateTime.Now.ToString("yyyy-MM-dd") + ".log";
                        }
                        if (!Directory.Exists(logPath))
                        {
                            Directory.CreateDirectory(logPath);
                        }
                        string fileName = Path.Combine(logPath, logFileName);
                        //Console.WriteLine($"LogPath:{fileName}");
                        using (StreamWriter sw = File.AppendText(fileName))
                        {
                            sw.WriteLine(logContent + Environment.NewLine);
                            sw.Flush();
                            sw.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        logPath = DateTime.Now.ToString("yyyy-MM");
                        logFileName = DateTime.Now.ToString("yyyy-MM-dd") + ".log";

                        Write(logPath, logFileName, "写入文件夹错误Message:" + ex.Message);
                        Write(logPath, logFileName, "写入文件夹错误StackTrace:" + ex.StackTrace);
                        Write(logPath, logFileName, logContent);
                    }

                }
            };
            Task task = new Task(taskAction);
            task.Start();
        }

        /// <summary>
        /// 写日志 异步
        /// </summary>
        /// <param name="logPath">日志目录</param>
        /// <param name="logFileName">日志文件名</param>
        /// <param name="logContent">日志内容 自动附加时间</param>
        public static void Write(string logPath, string logFileName, string logContent)
        {
            string basePath = ConfigHelper.GetSectionValue("LogBasePath") ?? AppDomain.CurrentDomain.BaseDirectory;
            if (string.IsNullOrWhiteSpace(logContent))
            {
                return;
            }
            if (string.IsNullOrWhiteSpace(logPath))
            {
                logPath = Path.Combine(basePath, "logs", DateTime.Now.ToString("yyyy-MM"));
            }
            else
            {
                logPath = Path.Combine(basePath, "logs", logPath.Trim('\\'));
            }
            if (string.IsNullOrWhiteSpace(logFileName))
            {
                logFileName = DateTime.Now.ToString("yyyy-MM-dd") + ".log";
            }
            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }
            string fileName = Path.Combine(logPath, logFileName);
            Console.WriteLine($"LogPath:{fileName}");
            Action taskAction = () =>
            {
                lock (lockHelper)
                {
                    using (StreamWriter sw = File.AppendText(fileName))
                    {
                        sw.WriteLine(logContent + Environment.NewLine);
                        sw.Flush();
                        sw.Close();
                    }
                }
            };
            Task task = new Task(taskAction);
            task.Start();
        }
        #endregion
    }
}
