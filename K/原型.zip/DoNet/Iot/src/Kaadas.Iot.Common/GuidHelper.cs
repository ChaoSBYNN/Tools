﻿using System;
using System.Net.NetworkInformation;

namespace Kaadas.Iot.Common
{
    public class GuidHelper
    {
        private static readonly object createlock = new object();

        private int pid = 0;
        private string pidmask = string.Empty;

        private string macaddress = string.Empty;
        private string timelast = string.Empty;
        private int count = 0;

        public GuidHelper()
        {
            this.macaddress = this.GetAddressBytes();

            var curProcess = System.Diagnostics.Process.GetCurrentProcess();
            this.pid = curProcess != null && curProcess.Id >= 0 ? curProcess.Id : 0;
            this.pidmask = this.pid.ToString().PadLeft(3, '0');
            if (this.pidmask.Length > 3) this.pidmask = this.pidmask.Substring(this.pidmask.Length - 3, 3);
        }

        private static GuidHelper _Default;

        /// <summary>
        /// 创建guid
        /// </summary>
        public static GuidHelper Default
        {
            get
            {
                if (_Default == null)
                {
                    _Default = new GuidHelper();
                }

                return _Default;
            }
        }

        /// <summary>
        /// 生成一个新id
        /// </summary>
        /// <returns></returns>
        public static string NewID()
        {
            return Default.CreateID();
        }

        private string CreateID()
        {
            string nowmask = string.Empty;
            string countmask = string.Empty;
            string randommask = string.Empty;
            lock (createlock)
            {
                nowmask = DateTime.Now.ToString("yyyyMMdd-HHmm-ssSSS-S");

                if (this.timelast == nowmask)
                {
                    this.count++;
                }
                else
                {
                    this.count = 0;
                }

                this.timelast = nowmask;

                countmask = this.count.ToString().PadLeft(4, '0');
                if (countmask.Length > 4) countmask = countmask.Substring(countmask.Length - 4, 4);

                Random rd = new Random(Guid.NewGuid().GetHashCode() + this.pid);
                randommask = rd.Next(1, 100000).ToString().PadLeft(5, '0');
            }

            return string.Format("{0}{1}-{2}{3}{4}", nowmask, countmask, randommask, this.pidmask, this.macaddress);
        }

        private string GetAddressBytes()
        {
            string macaddress = "000000";
            NetworkInterface[] nic = NetworkInterface.GetAllNetworkInterfaces();
            if (nic != null && nic.Length >= 1)
            {
                var physicalAddress = nic[0].GetPhysicalAddress();
                if (physicalAddress != null)
                {
                    macaddress = physicalAddress.ToString();
                    macaddress = macaddress.PadLeft(6, '0');
                    if (macaddress.Length > 6) macaddress = macaddress.Substring(macaddress.Length - 6, 6);
                }
            }

            return macaddress;
        }
    }
}
