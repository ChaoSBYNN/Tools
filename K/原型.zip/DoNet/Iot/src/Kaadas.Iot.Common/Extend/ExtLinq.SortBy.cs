﻿/*******************************************************************************
 * Copyright © 2016 WaterCloud.Framework 版权所有
 * Author: WaterCloud
 * Description: WaterCloud快速开发平台
 * Website：
*********************************************************************************/
using System;
using System.Linq;
using System.Linq.Expressions;

namespace Kaadas.Iot.Common
{
    public static partial class ExtLinq
    {
        public static IQueryable<T> OrderBy<T>(this IQueryable<T> query, string orderName)
        {
            var mce = Call(query, "OrderBy", orderName);
            return query.Provider.CreateQuery<T>(mce);
        }

        public static IQueryable<T> OrderByDescending<T>(this IQueryable<T> query, string orderName)
        {
            var mce = Call(query, "OrderByDescending", orderName);
            return query.Provider.CreateQuery<T>(mce);
        }

        private static MethodCallExpression Call<T>(IQueryable<T> query, string method, string orderName)
        {
            var param = Expression.Parameter(typeof(T), "p");
            var prop = Expression.Property(param, orderName);
            var exp = Expression.Lambda(prop, param);
            Type[] types = new Type[] { query.ElementType, exp.Body.Type };
            var mce = Expression.Call(typeof(Queryable), method, types, query.Expression, exp);
            return mce;
        }
    }
}
