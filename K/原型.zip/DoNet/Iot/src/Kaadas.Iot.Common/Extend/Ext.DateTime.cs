﻿using System;
using System.Text;

namespace Kaadas.Iot.Common
{
    public static partial class Ext
    {
        #region 获取格式化字符串，带时分秒，格式："yyyy-MM-dd HH:mm:ss"
        /// <summary>
        /// 获取格式化字符串，带时分秒，格式："yyyy-MM-dd HH:mm:ss"
        /// </summary>
        /// <param name="dateTime">日期</param>
        /// <param name="isRemoveSecond">是否移除秒</param>
        public static string ToDateTimeString(this DateTime dateTime, bool isRemoveSecond = false)
        {
            if (isRemoveSecond)
                return dateTime.ToString("yyyy-MM-dd HH:mm");
            return dateTime.ToString("yyyy-MM-dd HH:mm:ss");
        }
        #endregion

        #region 获取格式化字符串，带时分秒，格式："yyyy-MM-dd HH:mm:ss"
        /// <summary>
        /// 获取格式化字符串，带时分秒，格式："yyyy-MM-dd HH:mm:ss"
        /// </summary>
        /// <param name="dateTime">日期</param>
        /// <param name="isRemoveSecond">是否移除秒</param>
        public static string ToDateTimeString(this DateTime? dateTime, bool isRemoveSecond = false)
        {
            if (dateTime == null)
                return string.Empty;
            return ToDateTimeString(dateTime.Value, isRemoveSecond);
        }
        #endregion

        #region 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// <summary>
        /// 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToDateString(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd");
        }
        #endregion

        #region 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// <summary>
        /// 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToDateString()
        {
            return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }
        #endregion

        #region 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// <summary>
        /// 获取格式化字符串，不带时分秒，格式："yyyy-MM-dd"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToDateString(this DateTime? dateTime)
        {
            if (dateTime == null)
                return string.Empty;
            return ToDateString(dateTime.Value);
        }
        #endregion

        #region 获取格式化字符串，不带年月日，格式："HH:mm:ss"
        /// <summary>
        /// 获取格式化字符串，不带年月日，格式："HH:mm:ss"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToTimeString(this DateTime dateTime)
        {
            return dateTime.ToString("HH:mm:ss");
        }
        #endregion

        #region 获取格式化字符串，不带年月日，格式："HH:mm:ss"
        /// <summary>
        /// 获取格式化字符串，不带年月日，格式："HH:mm:ss"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToTimeString(this DateTime? dateTime)
        {
            if (dateTime == null)
                return string.Empty;
            return ToTimeString(dateTime.Value);
        }
        #endregion

        #region 获取格式化字符串，带毫秒，格式："yyyy-MM-dd HH:mm:ss.fff"
        /// <summary>
        /// 获取格式化字符串，带毫秒，格式："yyyy-MM-dd HH:mm:ss.fff"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToMillisecondString(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }
        #endregion

        #region 获取格式化字符串，带毫秒，格式："yyyy-MM-dd HH:mm:ss.fff"
        /// <summary>
        /// 获取格式化字符串，带毫秒，格式："yyyy-MM-dd HH:mm:ss.fff"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToMillisecondString(this DateTime? dateTime)
        {
            if (dateTime == null)
                return string.Empty;
            return ToMillisecondString(dateTime.Value);
        }
        #endregion

        #region 获取格式化字符串，不带时分秒，格式："yyyy年MM月dd日"
        /// <summary>
        /// 获取格式化字符串，不带时分秒，格式："yyyy年MM月dd日"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToChineseDateString(this DateTime dateTime)
        {
            return string.Format("{0}年{1}月{2}日", dateTime.Year, dateTime.Month, dateTime.Day);
        }
        #endregion

        #region 获取格式化字符串，不带时分秒，格式："yyyy年MM月dd日"
        /// <summary>
        /// 获取格式化字符串，不带时分秒，格式："yyyy年MM月dd日"
        /// </summary>
        /// <param name="dateTime">日期</param>
        public static string ToChineseDateString(this DateTime? dateTime)
        {
            if (dateTime == null)
                return string.Empty;
            return ToChineseDateString(dateTime.SafeValue());
        }
        #endregion

        #region 获取格式化字符串，带时分秒，格式："yyyy年MM月dd日 HH时mm分"
        /// <summary>
        /// 获取格式化字符串，带时分秒，格式："yyyy年MM月dd日 HH时mm分"
        /// </summary>
        /// <param name="dateTime">日期</param>
        /// <param name="isRemoveSecond">是否移除秒</param>
        public static string ToChineseDateTimeString(this DateTime dateTime, bool isRemoveSecond = false)
        {
            StringBuilder result = new StringBuilder();
            result.AppendFormat("{0}年{1}月{2}日", dateTime.Year, dateTime.Month, dateTime.Day);
            result.AppendFormat(" {0}时{1}分", dateTime.Hour, dateTime.Minute);
            if (isRemoveSecond == false)
                result.AppendFormat("{0}秒", dateTime.Second);
            return result.ToString();
        }
        #endregion

        #region 获取格式化字符串，带时分秒，格式："yyyy年MM月dd日 HH时mm分"
        /// <summary>
        /// 获取格式化字符串，带时分秒，格式："yyyy年MM月dd日 HH时mm分"
        /// </summary>
        /// <param name="dateTime">日期</param>
        /// <param name="isRemoveSecond">是否移除秒</param>
        public static string ToChineseDateTimeString(this DateTime? dateTime, bool isRemoveSecond = false)
        {
            if (dateTime == null)
                return string.Empty;
            return ToChineseDateTimeString(dateTime.Value);
        }
        #endregion

        #region 毫秒转天时分秒
        /// <summary>
        /// 毫秒转天时分秒
        /// </summary>
        /// <param name="ms"></param>
        /// <returns></returns>
        public static string FormatTime(long ms)
        {
            int ss = 1000;
            int mi = ss * 60;
            int hh = mi * 60;
            int dd = hh * 24;

            long day = ms / dd;
            long hour = (ms - day * dd) / hh;
            long minute = (ms - day * dd - hour * hh) / mi;
            long second = (ms - day * dd - hour * hh - minute * mi) / ss;
            long milliSecond = ms - day * dd - hour * hh - minute * mi - second * ss;

            string sDay = day < 10 ? "0" + day : "" + day; //天
            string sHour = hour < 10 ? "0" + hour : "" + hour;//小时
            string sMinute = minute < 10 ? "0" + minute : "" + minute;//分钟
            string sSecond = second < 10 ? "0" + second : "" + second;//秒
            string sMilliSecond = milliSecond < 10 ? "0" + milliSecond : "" + milliSecond;//毫秒
            sMilliSecond = milliSecond < 100 ? "0" + sMilliSecond : "" + sMilliSecond;

            return string.Format("{0} 天 {1} 小时 {2} 分 {3} 秒", sDay, sHour, sMinute, sSecond);
        }
        #endregion

        #region 时间戳转本地时间
        /// <summary>
        /// 时间戳转本地时间
        /// </summary>
        /// <param name="unix">时间戳</param>
        /// <returns></returns>
        public static DateTime TimestampToTime(this long unix)
        {
            var unixLength = unix.ToString().Length;
            DateTimeOffset dto;
            if (unixLength >= 13)
                dto = DateTimeOffset.FromUnixTimeMilliseconds(unix);
            else
                dto = DateTimeOffset.FromUnixTimeSeconds(unix);
            return dto.ToLocalTime().DateTime;
        }
        #endregion

        #region 时间戳转本地时间
        /// <summary>
        /// 时间戳转本地时间()
        /// </summary>
        /// <param name="unix">时间戳</param>
        /// <returns></returns>
        public static DateTime TimestampToTime(this object unix)
        {
            return TimestampToTime(unix.ToLong());
        }
        #endregion

        #region 时间转时间戳Unix
        /// <summary>
        /// 时间转时间戳Unix
        /// </summary>
        /// <param name="dt">时间</param>
        /// <param name="isToSecond">是否时间戳精确到秒 否 则精确到毫秒</param>
        /// <returns></returns>
        public static long ToTimestamp(this DateTime dt, bool isToSecond = true)
        {
            DateTimeOffset dto = new DateTimeOffset(dt);
            return isToSecond
                   ? dto.ToUnixTimeSeconds()
                   : dto.ToUnixTimeMilliseconds();
        }
        #endregion


        #region  时间转时间戳 带时区
        /// <summary>
        /// 时间转时间戳 带时区
        /// </summary>
        /// <param name="dt">时间</param>
        /// <param name="minute">时区偏移时间（分）</param>
        /// <param name="isToSecond">是否时间戳精确到秒 否 则精确到毫秒</param>
        /// <returns></returns>
        public static long ToTimestampZone(this DateTime dt,int minute, bool isToSecond = true)
        {
            dt = dt.AddMinutes(minute);
            DateTimeOffset dto = new DateTimeOffset(dt);
            return isToSecond
                   ? dto.ToUnixTimeSeconds()
                   : dto.ToUnixTimeMilliseconds();
        }
        #endregion

        #region 时间戳转UTC+0时区。因为锁端上报的本地时间带了时区。
        /// <summary>
        /// 时间戳转本地时间()
        /// </summary>
        /// <param name="unix">时间戳</param>
        /// <returns></returns>
        public static DateTime TimestampToTimeUTC0(this object unix)
        {
            return TimestampToTime(unix.ToLong()).ToUniversalTime();
        }
        #endregion
    }
}
