﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Kaadas.Iot.Common
{
    public static partial class Ext
    {
        public static DateTime ToDateTime(this string dateTimeString, String defaultDateTimeString = "")
        {
            var dateTimeValue = DateTime.Now;
            var defaultDateTimeValue = DateTime.Now;
            var rs = DateTime.TryParse(dateTimeString, out dateTimeValue);
            if (rs)
            {
                return dateTimeValue;
            }
            else
            {
                var rs2 = DateTime.TryParse(defaultDateTimeString, out defaultDateTimeValue);
                if (rs2)
                {
                    return defaultDateTimeValue;
                }
            }
            return DateTime.Now;
        }

        /// <summary>
        /// 将地址QueryString转化为Dictionary
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public static Dictionary<string, string> QueryToDictionary(this string queryString)
        {
            var str = queryString.Trim().Trim('?');
            return str.Split('&').ToDictionary(m => m.Split('=')[0], m => m.Split('=')[1]);
        }

        /// <summary>
        /// 将地址QueryString转化为Object
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public static T QueryToObject<T>(this string queryString)
            where T : class, new()
        {
            var dictionary = QueryToDictionary(queryString);
            var obj = new T();
            var type = obj.GetType();
            var pros = type.GetProperties();
            foreach (var item in pros)
            {
                if (dictionary.ContainsKey(item.Name))
                {
                    item.SetValue(obj, dictionary[item.Name]);
                }
            }
            return obj;
        }


        /// <summary>
        /// 将字符串转化为数据流
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static Stream StringToStream(this string str)
        {
            byte[] byteArray = Encoding.UTF8.GetBytes(str);
            MemoryStream stream = new MemoryStream(byteArray);
            return stream;
        }
    }
}
