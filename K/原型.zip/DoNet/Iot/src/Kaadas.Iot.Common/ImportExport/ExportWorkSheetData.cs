﻿using System.Collections.Generic;

namespace Kaadas.Iot.Common
{
    public class ExportWorkSheetData<T> where T : IBaseExport
    {
        /// <summary>
        /// 导出数据
        /// </summary>
        public List<T> Datas { get; set; }

        /// <summary>
        /// Sheet 名称
        /// </summary>
        public string SheetName { get; set; }
    }
}
