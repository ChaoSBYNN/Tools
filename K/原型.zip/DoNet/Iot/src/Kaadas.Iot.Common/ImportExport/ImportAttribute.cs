﻿using System;

namespace Kaadas.Iot.Common
{
    /// <summary>
    /// 导入
    /// </summary>
    public class ImportAttribute : Attribute
    {
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 第几列
        /// </summary>
        public int ColumnIndex;

        /// <summary>
        /// 校验方式
        /// </summary>
        public ValidateWayEnum? ValidateWay;

        /// <summary>
        /// 正则
        /// @"^\d*$"  数字包含0
        /// @"^([1-9]\d*)(\.\d+)?$"  大于0 可带小数点
        /// </summary>
        public string Regex { get; set; }

        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrorMsg { get; set; }

        public ImportAttribute(int column)
        {
            ColumnIndex = column;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="column">读取列</param>
        /// <param name="title">标题</param>
        /// <param name="validateWay">校验方式</param>
        public ImportAttribute(int column, string title, ValidateWayEnum validateWay)
        {
            ColumnIndex = column;
            Title = title;
            ValidateWay = validateWay;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="column">读取列</param>
        /// <param name="regex">校验正则表达式</param>
        /// <param name="errorMsg">错误信息</param>
        public ImportAttribute(int column, string regex, string errorMsg)
        {
            ColumnIndex = column;
            Regex = regex;
            ErrorMsg = errorMsg;
        }

    }

    /// <summary>
    /// 校验类型
    /// </summary>
    public enum ValidateWayEnum
    {
        Required,
        Phone,
        Email
    }
}
