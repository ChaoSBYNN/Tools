﻿namespace Kaadas.Iot.Common
{
    /// <summary>
    /// 导入基类
    /// </summary>
    public class BaseImport
    {
        /// <summary>
        /// 是否错误
        /// </summary>
        public bool IsError { get; set; } = false;

        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrorMsg { get; set; } = "";
    }
}
