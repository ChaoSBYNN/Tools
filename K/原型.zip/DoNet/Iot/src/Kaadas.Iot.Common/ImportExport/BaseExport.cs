﻿namespace Kaadas.Iot.Common
{
    public interface IBaseExport
    {
    }

    public interface IFailExport : IBaseExport
    {
        /// <summary>
        /// 错误信息
        /// </summary>  
        public string ErrorMsg { get; set; }
    }
}
