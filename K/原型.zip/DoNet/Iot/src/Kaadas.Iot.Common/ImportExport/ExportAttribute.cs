﻿using System;
using System.Drawing;

namespace Kaadas.Iot.Common
{
    /// <summary>
    /// 导出
    /// </summary>
    public class ExportAttribute : Attribute
    {
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; } = 0;

        /// <summary>
        /// 展示类型
        /// </summary>
        public ShowTypeEnum ShowType { get; set; }

        /// <summary>
        /// 标题颜色
        /// </summary>
        public Color TitleColor { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="title">列标题</param>
        /// <param name="sort">排序</param>
        /// <param name="showType">展示类型</param>
        /// <param name="colorEnum">列标题颜色</param>
        public ExportAttribute(string title, int sort = 0, ShowTypeEnum showType = ShowTypeEnum.Text,
            ExportColorEnum colorEnum = ExportColorEnum.Black)
        {
            Title = title;
            Sort = sort;
            ShowType = showType;
            TitleColor = GetColor(colorEnum);
        }

        private Color GetColor(ExportColorEnum colorEnum)
        {
            switch (colorEnum)
            {
                case ExportColorEnum.Red:
                    return Color.Red;
                case ExportColorEnum.Green:
                    return Color.Green;
                case ExportColorEnum.Black:
                default:
                    return Color.Black;
            }
        }
    }

    public enum ExportColorEnum
    {
        Red = 1,
        Black = 2,
        Green = 3
    }

    public enum ShowTypeEnum
    {
        /// <summary>
        /// 文字展示
        /// </summary>
        Text = 1,
        /// <summary>
        /// 日期 - yyyy-MM-dd HH:mm:ss
        /// </summary>
        DateTime = 2,
        /// <summary>
        /// 展示百分比
        /// </summary>
        Percent = 3,
        /// <summary>
        /// 是否
        /// </summary>
        YesNo = 4,
        /// <summary>
        /// 是否一致
        /// </summary>
        Accord=5
    }
}
