﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Kaadas.Iot.Common
{
    public class ImportHelper
    {
        #region 读取导入Excel数据 - 根据文件路径
        /// <summary>
        /// 读取导入Excel数据 - 根据文件路径
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">文件路径</param>
        /// <param name="beginCount">开始读取行</param>
        /// <returns></returns>
        public static List<T> GetImportData<T>(string path, int beginCount = 3)
            where T : BaseImport, new()
        {
            if (!path.EndsWith(".xlsx"))
                throw new Exception("仅支持.xlsx后缀的文件导入");
            FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            return GetImportData<T>(stream, beginCount);
        }
        #endregion

        /// <summary>
        /// HTTP请求下载文件，生成文件流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path"></param>
        /// <param name="beginCount"></param>
        /// <returns></returns>
        public static List<T> GetHttpImportData<T>(string path, int beginCount = 3)
            where T : BaseImport, new()
        {
            using (WebClient client = new WebClient())
            {
                byte[] fileData = client.DownloadData(path);
                using (MemoryStream stream = new MemoryStream(fileData))
                {
                    ExcelPackage package = new ExcelPackage(stream);
                    return GetImportData<T>(stream, beginCount);
                }
            }

        }

        #region 读取导入Excel数据 - 根据文件数据流
        /// <summary>
        /// 读取导入Excel数据 - 根据文件数据流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="stream">文件数据流</param>
        /// <param name="beginCount">开始读取行</param>
        /// <returns></returns>
        public static List<T> GetImportData<T>(Stream stream, int beginCount = 3)
            where T : BaseImport, new()
        {
            List<T> list = new List<T>();
            using (ExcelPackage pck = new ExcelPackage(stream))//读取excel
            {
                stream.Dispose();
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                ExcelWorksheet ws = pck.Workbook.Worksheets[0];
                //拿到导入的行数
                int rowCount = ws.Dimension.Rows;
                //循环读取工单信息数据
                for (int i = beginCount; i <= rowCount; i++)
                {
                    var data = GetData<T>(ws.Cells, i);
                    if (data != null)
                        list.Add(data);
                }
            }
            return list;
        }
        #endregion

        #region 读取行数据
        /// <summary>
        /// 读取行数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="cell"></param>
        /// <param name="rowIndex">读取行</param>
        /// <returns></returns>
        private static T GetData<T>(ExcelRange cell, int rowIndex) where T : BaseImport, new()
        {
            var type = typeof(T);
            var properties = type.GetProperties();
            T data = new T();
            bool isAllEmpty = true; //排除空白行
            bool isGetError = false;
            try
            {
                foreach (var pro in properties)
                {
                    var attr = (ImportAttribute)Attribute.GetCustomAttribute(pro, typeof(ImportAttribute));
                    if (attr != null)
                    {
                        var columnData = cell[rowIndex, attr.ColumnIndex].GetValue<string>()?.Trim() ?? "";
                        isAllEmpty = isAllEmpty && (columnData == null || columnData.Trim().IsEmpty());
                        if (attr.ValidateWay.HasValue || !attr.Regex.IsEmpty())
                            ValidateData(attr, columnData, ref data);
                        pro.SetValue(data, columnData, null);
                    }
                }
            }
            catch (Exception ex)
            {
                isGetError = true;
                data.IsError = true;
                data.ErrorMsg = ex.Message;
            }
            return isAllEmpty && !isGetError ? null : data;
        }
        #endregion

        #region 校验数据
        /// <summary>
        /// 校验数据
        /// </summary>
        /// <param name="way"></param>
        /// <param name="columnData"></param>
        /// <param name="rowIndex"></param>
        /// <param name="columnIndex"></param>
        private static void ValidateData<T>(ImportAttribute attr, string columnData, ref T data)
            where T : BaseImport, new()
        {
            if (attr.ValidateWay.HasValue)
                switch (attr.ValidateWay.Value)
                {
                    case ValidateWayEnum.Required:
                        if (columnData.IsEmpty())
                        {
                            data.IsError = true;
                            data.ErrorMsg += $"{attr.Title}不能为空；";
                        }
                        break;
                    case ValidateWayEnum.Phone:
                        if (!columnData.IsMobile() && !columnData.IsTel())
                        {
                            data.IsError = true;
                            data.ErrorMsg += $"{attr.Title}不是有效的联系方式；";
                        }
                        break;
                    case ValidateWayEnum.Email:
                        if (!columnData.IsEmail())
                        {
                            data.IsError = true;
                            data.ErrorMsg += $"{attr.Title}不是有效的邮箱；";
                        }
                        break;
                }
            else
            {
                if (!Regex.IsMatch(columnData, attr.Regex))
                {
                    data.IsError = true;
                    data.ErrorMsg = attr.ErrorMsg;
                }
            }
        }
        #endregion
    }
}
