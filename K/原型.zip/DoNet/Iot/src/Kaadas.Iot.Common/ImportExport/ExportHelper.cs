﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Kaadas.Iot.Common
{
    public class ExportHelper
    {
        #region 导出数据到Excel 返回文件保存路径
        /// <summary>
        /// 导出数据到Excel 返回文件保存路径
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">导出路径 到文件名</param>
        /// <param name="exportDatas">导出数据</param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string Export<T>(string path, List<T> exportDatas, string name = "Sheet1")
            where T : IBaseExport, new()
        {
            if (exportDatas == null || !exportDatas.Any())
                throw new Exception("没有可导出的数据");
            var filename = path.Substring(path.LastIndexOf('\\'));
            var dic = path.Substring(0, path.Length - filename.Length);
            if (!FileHelper.IsExistDirectory(dic))
                FileHelper.CreateSuffic(dic);
            FileInfo file = new FileInfo(path);
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage package = new ExcelPackage(file))
            {
                SetWorkSheetData(package, exportDatas, name);
                package.Save(); //Save the workbook.
                return path;
            }
        }
        #endregion

        #region 导出数据到Excel 返回数据流
        /// <summary>
        /// 导出数据到Excel 返回数据流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">导出路径 到文件名</param>
        /// <param name="exportDatas">导出数据</param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static async Task<Stream> Export<T>(List<T> exportDatas, string name = "Sheet1")
            where T : IBaseExport, new()
        {
            if (exportDatas == null || !exportDatas.Any())
                throw new Exception("没有可导出的数据");
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage package = new ExcelPackage())
            {
                SetWorkSheetData(package, exportDatas, name);
                var stream = new MemoryStream();
                await package.SaveAsAsync(stream);
                stream.Position = 0;
                return stream;
            }
        }
        #endregion

        #region 导出数据到Excel 两个Sheet 返回数据流
        /// <summary>
        /// 导出数据到Excel 返回数据流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">导出路径 到文件名</param>
        /// <param name="exportDatas">导出数据</param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static async Task<Stream> Export<T, TR>(ExportWorkSheetData<T> sheet, ExportWorkSheetData<TR> sheet2)
            where T : IBaseExport, new()
            where TR : IBaseExport, new()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage package = new ExcelPackage())
            {
                SetWorkSheetData(package, sheet.Datas, sheet.SheetName);
                SetWorkSheetData(package, sheet2.Datas, sheet2.SheetName);
                var stream = new MemoryStream();
                await package.SaveAsAsync(stream);
                stream.Position = 0;
                return stream;
            }
        }
        #endregion

        #region 设置数据
        /// <summary>
        /// 设置数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="package"></param>
        /// <param name="exportDatas"></param>
        /// <param name="sheetName"></param>
        private static void SetWorkSheetData<T>(ExcelPackage package, List<T> exportDatas, string sheetName)
            where T : IBaseExport, new()
        {
            // add a new worksheet to the empty workbook
            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(sheetName);
            var type = typeof(T);
            var properties = type.GetProperties();
            int rowCount = 1;
            int columnIndex = 1;

            Dictionary<ExportAttribute, PropertyInfo> pros = new Dictionary<ExportAttribute, PropertyInfo>();
            //排序
            foreach (var pro in properties)
            {
                var attr = (ExportAttribute)Attribute.GetCustomAttribute(pro, typeof(ExportAttribute));
                if (attr != null)
                    pros.Add(attr, pro);
            }
            var proDic = pros.OrderBy(m => m.Key.Sort);

            //添加标题
            foreach (var item in proDic)
            {
                var attr = item.Key;
                worksheet.Cells[rowCount, columnIndex].Value = attr.Title;
                worksheet.Cells[rowCount, columnIndex].Style.Font.Bold = true;//字体为粗体
                worksheet.Cells[rowCount, columnIndex].Style.Font.Name = "微软雅黑";//字体
                worksheet.Cells[rowCount, columnIndex].Style.Font.Size = 15;//字体大小 
                worksheet.Cells[rowCount, columnIndex].Style.Font.Color.SetColor(attr.TitleColor);//字体大小 
                columnIndex++;
            }
            //添加数据
            exportDatas.ForEach(m =>
            {
                rowCount++;
                columnIndex = 1;
                foreach (var item in proDic)
                {
                    var attr = item.Key;
                    var pro = item.Value;
                    var proValue = pro.GetValue(m);
                    var valueText = string.Empty;
                    switch (attr.ShowType)
                    {
                        case ShowTypeEnum.DateTime:
                            valueText = proValue.ToDateOrNull().ToDateTimeString() ?? "";
                            break;
                        case ShowTypeEnum.Percent:
                            valueText = proValue.ToDecimalOrNull().FormatPercent();
                            break;
                        case ShowTypeEnum.YesNo:
                            valueText = proValue.ToBool().Description();
                            break;
                        case ShowTypeEnum.Text:
                        default:
                            valueText = proValue?.ToString() ?? "";
                            break;
                    }
                    worksheet.Cells[rowCount, columnIndex].Value = valueText;
                    columnIndex++;
                }
            });
            worksheet.Cells.AutoFitColumns();
        }
        #endregion
    }
}
