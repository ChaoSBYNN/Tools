﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Kaadas.Iot.Common.Security
{
    public class RSAHelper
    {
        /// <summary>
        /// 生成公私钥对
        /// </summary>
        public void CreateKey()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            using (StreamWriter writer = new StreamWriter("PrivateKey.xml"))  //这个文件要保密...
            {

                writer.WriteLine(rsa.ToXmlString(true));

            }
            using (StreamWriter writer = new StreamWriter("PublicKey.xml"))
            {

                writer.WriteLine(rsa.ToXmlString(false));

            }


        }



        /// <summary>
        /// 非对称加密A
        /// </summary>
        /// <param name="data">明文</param>
        /// <returns></returns>
        public string RSAEncryptA(string data, string PublicKeyA)
        {
            //C#默认只能使用[公钥]进行加密(想使用[公钥解密]可使用第三方组件BouncyCastle来实现)
            //string publicKeyPath = @"d:\\PublicKey.xml";
            //string publicKey = File.ReadAllText(publicKeyPath);

            //创建RSA对象并载入[公钥]
            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(PublicKeyA);

            //对数据进行加密
            byte[] publicValue = rsaPublic.Encrypt(Encoding.UTF8.GetBytes(data), false);
            string publicStr = Convert.ToBase64String(publicValue);//使用Base64将byte转换为string
            return publicStr;
        }
        /// <summary>
        /// 非对称解密A
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string RSADecryptA(string data)
        {
            //C#默认只能使用[私钥]进行解密(想使用[私钥加密]可使用第三方组件BouncyCastle来实现)
            //string privateKeyPath = @"d:\\PrivateKey.xml";
            //string privateKey = File.ReadAllText(privateKeyPath);
            string PrivateKeyA = "<RSAKeyValue><Modulus>q6DNgoTWj1bao6viUgwC4NlYziW5q8ShdIYF7vhw/dOqeVtWgue5fs2cyJzD9WIgL4g2bNLjHpUXUC4WKRmQNQrmAW7GtpznabRJmK+saouX+5gwI8pvjPCeEftww1LqRsRJBR4gSn6hsBK3o3fSAhFxV/fMRXYQFg8eBY78xOk=</Modulus><Exponent>AQAB</Exponent><P>yzD9xyHZksqHmYC4eHP0XqyYYS+yaJ8fevYTyveb3AF9ts48O+YLKlaHKnPXVTAqWqB7Sz9i/wEl5qcScsiyTw==</P><Q>2DvNezHsHgJQ/2WticLESrEYgVCfsdFRRlwtcgnC50t6m5DCqk+fPc7lO7mLDP6tAmvUQsiA/nRIuChVzFhfRw==</Q><DP>TP+ku8htDb5oAliQDz1JtnLLT9DmV9Us9ci4mWqZipaaECM5Gi3Dv2iI0iKR0DtvYWZ9MnezyRSjSzO2vv6k6w==</DP><DQ>wSTxzwfxm4CALxD4aKQTR5BWjjOg4WlRyqJNaZ50fLs74jb02sHSQJhMxANgxBO8H/yHFbwZFLBzwCMvOB77ww==</DQ><InverseQ>lxrU3ONV+IPH+GZloemiZd37oFzFw4xGBdTqzBMpj/MBTvkffoR03CyGjQPrTwIjORosM0q1Q/xSZSKENkRqcQ==</InverseQ><D>lJkytoobV5okzcdZuh4qM9IboMlrG/ywqjoMUx8KfcrRdCeQHOFTayXNVKjexcwDAASY0to4yVbfC44Lo+Q9RTSW7z/G+TADxJWI6uzi1XSBcgQjSZNvd1C//OmVeuUZlzzsGhw56gft6Y4vWjDIyIXOYF1rKdWJWeXUO0JUf80=</D></RSAKeyValue>";
            //创建RSA对象并载入[私钥]
            RSACryptoServiceProvider rsaPrivate = new RSACryptoServiceProvider();
            rsaPrivate.FromXmlString(PrivateKeyA);
            //对数据进行解密
            byte[] privateValue = rsaPrivate.Decrypt(Convert.FromBase64String(data), false);//使用Base64将string转换为byte
            string privateStr = Encoding.UTF8.GetString(privateValue);
            return privateStr;
        }




        /// <summary>
        /// 非对称加密B
        /// </summary>
        /// <param name="data">明文</param>
        /// <returns></returns>
        public string RSAEncryptB(string data)
        {
            //C#默认只能使用[公钥]进行加密(想使用[公钥解密]可使用第三方组件BouncyCastle来实现)
            //string publicKeyPath = @"d:\\PublicKey.xml";
            //string publicKey = File.ReadAllText(publicKeyPath);
            string PublicKeyB = "<RSAKeyValue><Modulus>ydgpX50LQVnpEnSiGwdgr+wlrPnEFAUBz4aCgbBfjUnzWK95ulvRnSRnsMhR4c8O0LdywkPIOQqYlZwLrI9QVZ+GzCLUHoCvha/Z9gU1E9sRTkn3OlMwIDgbLGa/z6BvxqGLcXTmOQeqeQF++JucBltBYklYnC3D9osEN0ZH0gk=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

            //创建RSA对象并载入[公钥]
            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(PublicKeyB);

            //对数据进行加密
            byte[] publicValue = rsaPublic.Encrypt(Encoding.UTF8.GetBytes(data), false);
            string publicStr = Convert.ToBase64String(publicValue);//使用Base64将byte转换为string
            return publicStr;
        }
        /// <summary>
        /// 非对称解密B
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string RSADecryptB(string data)
        {
            //C#默认只能使用[私钥]进行解密(想使用[私钥加密]可使用第三方组件BouncyCastle来实现)
            //string privateKeyPath = @"d:\\PrivateKey.xml";
            //string privateKey = File.ReadAllText(privateKeyPath);
            string PrivateKeyB = "<RSAKeyValue><Modulus>ydgpX50LQVnpEnSiGwdgr+wlrPnEFAUBz4aCgbBfjUnzWK95ulvRnSRnsMhR4c8O0LdywkPIOQqYlZwLrI9QVZ+GzCLUHoCvha/Z9gU1E9sRTkn3OlMwIDgbLGa/z6BvxqGLcXTmOQeqeQF++JucBltBYklYnC3D9osEN0ZH0gk=</Modulus><Exponent>AQAB</Exponent><P>26t+P59JWPrNygNeTPzoxJCgBhs/ht8mTRFS7/EQgJXx7iF5SM+45DE1PcVIOh73aDcW3X5GC5Ry3QAsUQQgRw==</P><Q>6zn2Ph89vaAjNin6RgdraQNNxgFotSHGKVzOwr8JDASZ9H8rKlU2/HmRDNgber6wmr32o0pBjN8JsTnfTMpzLw==</Q><DP>FTUGODAxjZSQ/3q5xOb5tdhcippg1K2AbhpJDn8QX8maFKpIoj3jlKwnfrIoGexZaEdBPtrs+js3p5xXqu6iCw==</DP><DQ>0FCBgVx7eg5ygIpGaXQyrEpPuxYOW7LwYjsdpJw379u3WC6y1Ieo7YjfayeLlnV/w1qOLOgbCx2O4NPmrIPx4w==</DQ><InverseQ>oNnK6HchB6fsbfBV3vl4UEHljOn66/BsF/TAehx7sAT1q5ietHEkf8e79+3LQbceensDnnj3ntdVm9JT4cJ+4g==</InverseQ><D>rk3odLQ2qwnM1243KyY03dcNNhI+vJcSWDctbnd0HJw29Ggcs81k99IfZS+oXlsjzSQOiypjtraqy9AE2NCuKqoRspFSUv59pWULqK+a33wfoHsujChPT9+54ltakf8QjXmfZMhWNSjjeV6q8Z5N2UVhLXpByjSjWaTupcMIaP0=</D></RSAKeyValue>";
            //创建RSA对象并载入[私钥]
            RSACryptoServiceProvider rsaPrivate = new RSACryptoServiceProvider();
            rsaPrivate.FromXmlString(PrivateKeyB);
            //对数据进行解密
            byte[] privateValue = rsaPrivate.Decrypt(Convert.FromBase64String(data), false);//使用Base64将string转换为byte
            string privateStr = Encoding.UTF8.GetString(privateValue);
            return privateStr;
        }
    }
}
