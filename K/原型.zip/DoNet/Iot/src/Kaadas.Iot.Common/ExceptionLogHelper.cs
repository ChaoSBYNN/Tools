﻿using Microsoft.AspNetCore.Http;
using System;

namespace Kaadas.Iot.Common
{
    public class ExceptionLogHelper
    {
        /// <summary>
        /// 递归获取全部异常信息
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="outErrorMessage"></param>
        /// <returns></returns>
        public static string GetExceptionMessage(Exception ex, string outErrorMessage = "")
        {
            outErrorMessage += JoinExceptionMessage(ex);
            if (ex.InnerException == null)
                return outErrorMessage;
            return GetExceptionMessage(ex.InnerException, outErrorMessage);
        }

        private static string JoinExceptionMessage(Exception ex)
        {
            var str = string.Empty;
            if (ex == null) return str;
            str += Environment.NewLine;
            str += $"异常(Message)：{ex.Message}\r\n";
            str += $"来源(Source)：{ex.Source}\r\n";
            str += $"堆栈(StackTrace)：{ex.StackTrace}\r\n";
            str += "--------------------------------------------------------------- End.";
            return str;
        }

        /// <summary>
        /// 获取webapi的 错误消息
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public static string GetExceptionMessageByWeb(Exception ex, HttpContext httpContext)
        {
            var request = httpContext?.Request;
            var url = string.Empty;
            var body = string.Empty;
            var method = string.Empty;
            if (request != null)
            {
                url = $"{request.Scheme}://{request.Host}{request.PathBase}{request.Path}{request.QueryString.Value}";
                method = request.Method;
                //这里的 Key_ActionBody 来自于另外的控制器,取的统一个上下文
                body = httpContext?.Items["Key_ActionBody"]?.ToString();
            }
            var error = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine;
            //获取模块名称
            var moduleInfo = System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
            error += $"模块名称：{moduleInfo} \r\n";
            error += $"应用服务器：" + Environment.MachineName + "\r\n";
            error += $"URL：" + url + "\r\n";
            error += $"Method：" + method + "\r\n";
            error += $"Body：\r\n" + body + "\r\n";
            error += $"错误信息：{ex.Message}\r\n";
            error += $"异常详情：";
            error += GetExceptionMessage(ex);
            return error;
        }
    }
}
