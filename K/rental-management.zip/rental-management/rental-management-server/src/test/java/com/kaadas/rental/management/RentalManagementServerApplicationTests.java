package com.kaadas.rental.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalManagementServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
