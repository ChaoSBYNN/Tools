package com.kaadas.common.config;

import org.apache.ibatis.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
/**
 * @author hjf
 * @version 1.0
 * @description 用于MyBaits 日志输出SQL
 *              如果不使用 请在 application.yml
 *              mybatis-plus.configuration.log-impl = org.apache.ibatis.logging.stdout.StdOutImpl
 * @date 2021-09-08 16:01
 */
 
public class MyBaitsLogConfiguration implements Log {
 
    private Logger log;
 
    public MyBaitsLogConfiguration(String clazz) {
        log = LoggerFactory.getLogger(clazz);
    }
 
    @Override
    public boolean isDebugEnabled() {
//        return log.isDebugEnabled();
        return true; // 默认开启 Debug
    }
 
    @Override
    public boolean isTraceEnabled() {
//        return log.isTraceEnabled();
        return true; // 默认开启 Trace
    }
 
    @Override
    public void error(String s, Throwable e) {
        log.error(s,e);
    }
 
    @Override
    public void error(String s) {
        log.error(s);
    }
 
    @Override
    public void debug(String s) {
        log.info(s);  //SQL 获取参数输出至 info 
    }
 
    @Override
    public void trace(String s) {
        log.info(s); //SQL 信息输出至 info 
    }
 
    @Override
    public void warn(String s) {
        log.info(s);
    }
}