package com.kaadas.common.utils;
 
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
 
public class BeanUtils {
 
    public static <T> T convertCopyBean(Object source, Class<T> clazz) {
        if (source == null) {
            return null;
        }
        try {
            T target = clazz.newInstance();
            org.springframework.beans.BeanUtils.copyProperties(source, target);
            return target;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
 
    public static <T, E> List<T> convertCopyList(Collection<E> oldList, Class<T> clazz) {
        List<T> newList = new ArrayList<>();
        if (oldList != null && !oldList.isEmpty()) {
            try {
                for (Object item : oldList) {
                    T newObj = clazz.newInstance();
                    org.springframework.beans.BeanUtils.copyProperties(item, newObj);
                    newList.add(newObj);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return newList;
    }
}