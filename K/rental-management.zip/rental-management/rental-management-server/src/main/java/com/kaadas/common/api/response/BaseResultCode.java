package com.kaadas.common.api.response;

import lombok.Getter;
import org.springframework.http.HttpStatus;

/**
 * @ClassName ResultCode
 * @Description
 * @Author Spike_Zhang
 * @DATE 2024/4/15 16:38
 * @Version 1.0
 */
@Getter
public enum BaseResultCode implements ResultCode {

    /**
     * 200_00X 成功
     */
    /**
     * 成功了。服务器已成功处理了请求。
     */
    OK(HttpStatus.OK, 200_000, "OK"),
    /**
     * 资源已创建。请求成功并且服务器创建了新的资源。
     */
    CREATED(HttpStatus.CREATED, 201_000,"Created"),
    /**
     * 已接受但未处理。服务器已接受请求，但尚未处理。
     */
    ACCEPTED(HttpStatus.ACCEPTED, 202_000, "Accepted"),

    /**
     * 400_00X 客户端异常 Client Error
     */
    /** 非法参数 */
    INVALID_PARAMETER(HttpStatus.BAD_REQUEST, 400_000, "非法参数"),
    /** 用户名或密码不匹配 */
    ACCOUNT_PASSWORD_NOT_MATCH(HttpStatus.BAD_REQUEST, 400_001, "用户名或密码不匹配"),
    /** 缺少路径参数 */
    MISSING_PATH_VARIABLE(HttpStatus.BAD_REQUEST, 400_002, "缺少路径参数"),
    /** 缺少请求头 */
    MISSING_REQUEST_HEADER(HttpStatus.BAD_REQUEST, 400_003, "缺少请求头"),

    /**
     * 401_00X 认证异常 Authorization Error
     */
    /** 无权限访问 */
    UNAUTHORIZED(HttpStatus.UNAUTHORIZED, 401_000, "无权限访问"),
    /** 请求未找到 */
    REQUEST_NOT_FOUND(HttpStatus.NOT_FOUND, 404_000, "请求未找到"),
    /** 请求方法不支持 */
    METHOD_NOT_ALLOWED(HttpStatus.METHOD_NOT_ALLOWED, 405_000, "请求方法不支持"),
    /** 拒绝访问 */
    FORBIDDEN( HttpStatus.FORBIDDEN,403_000, "拒绝访问"),
    
    /**
     * 500_00X 服务器异常 Server Error
     */
    /** 未知错误 */
    UNKNOWN_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, 500_000, "未知错误"),
    /** 内部服务器错误 */
    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, 500_001, "内部服务器错误"),
    /** 脏数据 */
    DIRTY_DATA(HttpStatus.INTERNAL_SERVER_ERROR, 500_002, "脏数据"),
    ;

    /**
     * Http 状态码
     * @return
     */
    HttpStatus httpStatus;

    /**
     * 错误码
     * @return
     */
    long code;

    /**
     * 错误信息
     * @return
     */
    String message;

    BaseResultCode(HttpStatus httpStatus, long code, String message) {
        this.httpStatus = httpStatus;
        this.code = code;
        this.message = message;
    }
}
