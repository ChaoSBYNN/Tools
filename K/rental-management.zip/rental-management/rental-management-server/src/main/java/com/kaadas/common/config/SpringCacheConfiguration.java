package com.kaadas.common.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import javax.annotation.Resource;
import java.time.Duration;

/**
 * @author Spike_Zhang
 * @Class SpringCacheConfiguration
 * @Description 缓存配置
 * <br>1. 解决序列化乱码问题
 * <br>2. 解决双冒号问题
 * <br>3. 增加过期时间
 * @Date 2024/4/9 17:26
 */
@EnableCaching
@Configuration
public class SpringCacheConfiguration extends CachingConfigurerSupport {

    @Resource
    private RedisConnectionFactory redisConnectionFactory;

    @Bean
    public RedisCacheConfiguration redisCacheConfiguration() {

        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig();

        // 序列化值
        return config.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
                // 设置过期时间
                .entryTtl(Duration.ofMinutes(120))
                // 解决双冒号问题
                .computePrefixWith(name -> name + ":");
    }

    @Bean
    public CacheManager cacheManager() {
        CustomRedisCacheManager redisCacheManager = new CustomRedisCacheManager(RedisCacheWriter.nonLockingRedisCacheWriter(redisConnectionFactory), redisCacheConfiguration());
        return redisCacheManager;
    }
}