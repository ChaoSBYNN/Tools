package com.kaadas.common.api.response;


/**
 * @ClassName BaseResponse
 * @Description 通用返回对象
 * @Author Spike_Zhang
 * @DATE 2024/4/7 9:39
 * @Version 1.0
 */
public class BaseResponse<T> {
    private long code;
    private String message;
    private T data;

    protected BaseResponse() {
    }

    protected BaseResponse(long code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * 成功返回结果
     *
     * @param data 获取的数据
     */
    public static <T> BaseResponse<T> success(T data) {
        return new BaseResponse<T>(BaseResultCode.OK.getCode(), BaseResultCode.OK.getMessage(), data);
    }

    /**
     * 成功返回结果
     *
     * @param data 获取的数据
     * @param  message 提示信息
     */
    public static <T> BaseResponse<T> success(T data, String message) {
        return new BaseResponse<T>(BaseResultCode.OK.getCode(), message, data);
    }

    /**
     * 失败返回结果
     * @param errorCode 错误码
     */
    public static <T> BaseResponse<T> failed(ResultCode errorCode) {
        return new BaseResponse<T>(errorCode.getCode(), errorCode.getMessage(), null);
    }

    /**
     * 失败返回结果
     * @param errorCode 错误码
     * @param message 错误信息
     */
    public static <T> BaseResponse<T> failed(ResultCode errorCode, String message) {
        return new BaseResponse<T>(errorCode.getCode(), message, null);
    }

    /**
     * 失败返回结果
     * @param message 提示信息
     */
    public static <T> BaseResponse<T> failed(String message) {
        return new BaseResponse<T>(BaseResultCode.INTERNAL_SERVER_ERROR.getCode(), message, null);
    }

    /**
     * 失败返回结果
     */
    public static <T> BaseResponse<T> failed() {
        return failed(BaseResultCode.INTERNAL_SERVER_ERROR.getMessage());
    }

    /**
     * 参数验证失败返回结果
     */
    public static <T> BaseResponse<T> invalidation() {
        return invalidation(BaseResultCode.INVALID_PARAMETER.getMessage());
    }

    /**
     * 参数验证失败返回结果
     * @param message 提示信息
     */
    public static <T> BaseResponse<T> invalidation(String message) {
        return new BaseResponse<T>(BaseResultCode.INVALID_PARAMETER.getCode(), message, null);
    }


    /**
     * 认证失败
     */
    public static <T> BaseResponse<T> unauthorized() {
        return new BaseResponse<T>(BaseResultCode.UNAUTHORIZED.getCode(), BaseResultCode.UNAUTHORIZED.getMessage(), null);
    }

    /**
     * 认证失败
     */
    public static <T> BaseResponse<T> unauthorized(T data) {
        return new BaseResponse<T>(BaseResultCode.UNAUTHORIZED.getCode(), BaseResultCode.UNAUTHORIZED.getMessage(), data);
    }

    /**
     * 认证失败
     */
    public static <T> BaseResponse<T> unauthorized(String message, T data) {
        return new BaseResponse<T>(BaseResultCode.UNAUTHORIZED.getCode(), message, data);
    }

    /**
     * 未授权返回结果
     */
    public static <T> BaseResponse<T> forbidden(T data) {
        return new BaseResponse<T>(BaseResultCode.FORBIDDEN.getCode(), BaseResultCode.FORBIDDEN.getMessage(), data);
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

}