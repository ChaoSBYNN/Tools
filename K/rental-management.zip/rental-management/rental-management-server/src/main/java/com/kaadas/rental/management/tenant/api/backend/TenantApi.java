package com.kaadas.rental.management.tenant.api.backend;

import com.kaadas.rental.management.tenant.api.backend.dto.TenantDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName TenantApi
 * @Description 客户表 后端Api
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0.0
 */
@Api(tags = "客户表 Backend Controller")
@FeignClient(name = "open-client-server", contextId = "client")
public interface TenantApi {

    @ApiOperation(value = "通过主键查询单条数据")
    @GetMapping("/{id}")
    TenantDTO detail(@PathVariable("id") Long id);

    @ApiOperation(value = "创建第三方平台应用")
    @PostMapping
    TenantDTO create(@RequestBody TenantDTO tenantDTO);

    @ApiOperation(value = "编辑数据")
    @PutMapping
    TenantDTO update(@RequestBody TenantDTO tenantDTO);

    @ApiOperation(value = "删除数据")
    @DeleteMapping("/{id}")
    Boolean delete(@PathVariable("id") Long id);
}

