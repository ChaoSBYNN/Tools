package com.kaadas.common.config;


import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;
import java.util.List;

@Log4j2
@Configuration
@EnableSwagger2
public class SwaggerConfiguration implements WebMvcConfigurer {

    @Value("${spring.application.name:default}")
    private String applicationName;
    private static final String DEFAULT_PACKAGE = "com.kaadas";

    @Bean
    public Docket docket() {
        //指定使用Swagger2规范
        Docket docket = new Docket(DocumentationType.SWAGGER_2)
                //添加token的参数
                .securityContexts(mySecurityContexts())
                .securitySchemes(mySecuritySchemes())
                .apiInfo(new ApiInfoBuilder()
                        .title(applicationName + " API文档")
//                        .termsOfServiceUrl("http://localhost:10002/")
//                        .contact(new Contact("Spike_Zhang", "", "zhangxianchen@kaadas.com"))
                        .version("v1.0.0")
                        .build())
                //分组名称
                .groupName(applicationName)
                .select()
                //这里指定Controller扫描包路径
                .apis(RequestHandlerSelectors.basePackage(DEFAULT_PACKAGE))
                .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
                .paths(PathSelectors.any())
                .build();
        return docket;
    }


    /**
     * 这里设置 swagger 认证的安全上下文
     */
    public List<SecurityContext> mySecurityContexts() {
        return Collections.singletonList(SecurityContext.builder()
                .securityReferences(Collections.singletonList(SecurityReference.builder()
                        .reference("Authorization")
                        .scopes(new AuthorizationScope[]{new AuthorizationScope("global",
                                "accessEverything")}).build())).build());
    }

    public List<SecurityScheme> mySecuritySchemes() {
        //注意，这里应对应登录token鉴权对应的k-v
        return Collections.singletonList(new ApiKey("Authorization", "Authorization", "header"));
    }

}
