package com.kaadas.rental.management.tenant.application.query;


import com.kaadas.rental.management.tenant.domain.repository.TenantRepository;
import com.kaadas.rental.management.tenant.domain.Tenant;
import com.kaadas.rental.management.tenant.api.backend.dto.TenantDTO;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.kaadas.common.redis.RedisRepository;
import com.kaadas.common.utils.BeanUtils;

import javax.annotation.Resource;
import java.util.List;


/**
 * @ClassName TenantQueryService
 * @Description 客户表 查询业务层
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0.0
 */
@Service
public class TenantQueryService {

    @Resource
    private TenantRepository tenantRepository;


    /**
     * 通过主键查询单条数据
     */
    public TenantDTO detail(Long id) {
        return null;
    }
}

