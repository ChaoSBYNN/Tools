package com.kaadas.rental.management.tenant.api.frontend;

import com.kaadas.rental.management.tenant.api.frontend.vo.TenantReq;
import com.kaadas.rental.management.tenant.api.frontend.vo.TenantResp;
import com.kaadas.rental.management.tenant.application.query.TenantQueryService;
import com.kaadas.rental.management.tenant.application.command.TenantCommandService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;
import com.kaadas.common.api.response.BaseResponse;
import org.springframework.http.HttpStatus;

import java.util.List;

@Slf4j
@Api(tags = "客户表 Frontend Controller")
@RestController
@RequestMapping("/v1/tenant/frontend")
public class TenantFrontendController {

    /**
     * 查询
     */
    @Resource
    private TenantQueryService tenantQueryService;

    /**
     * 指令
     */
    @Resource
    private TenantCommandService tenantCommandService;

    @ApiOperation(value = "通过主键查询单条数据")
    @GetMapping("/{id}")
    public BaseResponse<TenantResp> detail(@PathVariable("id") Long id) {
//        return BaseResponse.success(tenantQueryService.detail(id));
        return BaseResponse.success(null);
    }

    @ApiOperation(value = "创建第三方平台应用")
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping
    public BaseResponse<TenantResp> create(@RequestBody TenantReq tenantReq) {
//        return BaseResponse.success(tenantCommandService.create(tenantReq));

        return BaseResponse.success(null);
    }

    @ApiOperation(value = "编辑数据")
    @PutMapping
    public BaseResponse<TenantResp> update(@RequestBody TenantReq tenantReq) {
//        return BaseResponse.success(tenantCommandService.update(tenantReq));

        return BaseResponse.success(null);
    }

    @ApiOperation(value = "删除数据")
    @DeleteMapping("/{id}")
    public BaseResponse<Boolean> delete(@PathVariable("id") Long id) {
        return BaseResponse.success(tenantCommandService.delete(id));
    }
}

