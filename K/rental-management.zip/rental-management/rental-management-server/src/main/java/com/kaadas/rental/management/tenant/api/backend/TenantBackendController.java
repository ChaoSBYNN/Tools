package com.kaadas.rental.management.tenant.api.backend;

import com.kaadas.rental.management.tenant.api.backend.dto.TenantDTO;
import com.kaadas.rental.management.tenant.application.query.TenantQueryService;
import com.kaadas.rental.management.tenant.application.command.TenantCommandService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import java.util.List;


@RestController
public class TenantBackendController implements TenantApi {

    /**
     * 查询
     */
    @Resource
    private TenantQueryService tenantQueryService;

    /**
     * 指令
     */
    @Resource
    private TenantCommandService tenantCommandService;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    public TenantDTO detail(Long id) {
        return tenantQueryService.detail(id);
    }

    /**
     * 新增数据
     *
     * @param tenantDTO 实体
     * @return 新增结果
     */
    public TenantDTO create(TenantDTO tenantDTO) {
        return tenantCommandService.create(tenantDTO);
    }

    /**
     * 编辑数据
     *
     * @param tenantDTO 实体
     * @return 编辑结果
     */
    public TenantDTO update(TenantDTO tenantDTO) {
        return tenantCommandService.update(tenantDTO);
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    public Boolean delete(Long id) {
        return tenantCommandService.delete(id);
    }
}

