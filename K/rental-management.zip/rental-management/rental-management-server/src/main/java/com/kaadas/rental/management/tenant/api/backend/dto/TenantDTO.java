package com.kaadas.rental.management.tenant.api.backend.dto;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @ClassName TenantDTO
 * @Description Tenant
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:06
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiOperation(value = "Tenant数据传输对象")
public class TenantDTO {

    /**
     * ID
     */
    @ApiModelProperty(value = "ID")
    private Long id;

    /**
     * 客户编号
     */
    @ApiModelProperty(value = "客户编号")
    private String tenantNo;

    /**
     * 客户名称
     */
    @ApiModelProperty(value = "客户名称")
    private String tenantName;

    /**
     * 客户地址
     */
    @ApiModelProperty(value = "客户地址")
    private String tenantAddress;

    /**
     * 删除状态 0 未删除 1 删除
     */
    @ApiModelProperty(value = "删除状态 0 未删除 1 删除")
    private Integer deleted;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 创建用户
     */
    @ApiModelProperty(value = "创建用户")
    private Long createBy;

    /**
     * 修改时间
     */
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    /**
     * 修改用户
     */
    @ApiModelProperty(value = "修改用户")
    private Long updateBy;

}

