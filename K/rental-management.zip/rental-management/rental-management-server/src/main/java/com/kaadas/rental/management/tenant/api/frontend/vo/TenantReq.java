package com.kaadas.rental.management.tenant.api.frontend.vo;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @ClassName TenantReq
 * @Description Tenant
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiOperation(value = "Tenant请求参数")
public class TenantReq {

    @ApiModelProperty(value = "ID")
    private Long id;

    @ApiModelProperty(value = "客户编号")
    private String tenantNo;

    @ApiModelProperty(value = "客户名称")
    private String tenantName;

    @ApiModelProperty(value = "客户地址")
    private String tenantAddress;

    @ApiModelProperty(value = "删除状态 0 未删除 1 删除")
    private Integer deleted;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建用户")
    private Long createBy;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "修改用户")
    private Long updateBy;
}

