package com.kaadas.rental.management.tenant.domain;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName
 * @Description 客户表 实体
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0.0
 */
@Data
@TableName("open_tenant")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Tenant implements Serializable {

    /**
     * 主键
     */
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 客户编号
     */
    private String tenantNo;

    /**
     * 客户名称
     */
    private String tenantName;

    /**
     * 客户地址
     */
    private String tenantAddress;

    /**
     * 删除状态 0 未删除 1 删除
     */
    private Integer deleted;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建用户
     */
    private Long createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改用户
     */
    private Long updateBy;

}

