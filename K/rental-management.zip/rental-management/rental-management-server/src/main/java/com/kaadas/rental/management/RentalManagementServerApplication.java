package com.kaadas.rental.management;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
//@MapperScan("com.kaadas.**.mapper")
@SpringBootApplication(scanBasePackages = {"com.kaadas"})
public class RentalManagementServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RentalManagementServerApplication.class, args);
    }

}
