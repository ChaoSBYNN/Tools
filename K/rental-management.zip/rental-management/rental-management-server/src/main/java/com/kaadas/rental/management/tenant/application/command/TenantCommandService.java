package com.kaadas.rental.management.tenant.application.command;


import com.kaadas.rental.management.tenant.domain.repository.TenantRepository;
import com.kaadas.rental.management.tenant.domain.Tenant;
import com.kaadas.rental.management.tenant.api.backend.dto.TenantDTO;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.kaadas.common.redis.RedisRepository;
import com.kaadas.common.utils.BeanUtils;

import javax.annotation.Resource;
import java.util.List;


/**
 * @ClassName TenantCommandService
 * @Description 客户表 指令业务层
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0.0
 */
@Service
public class TenantCommandService {

    @Resource
    private TenantRepository tenantRepository;

    /**
     * 新增数据
     */
    public TenantDTO create(TenantDTO tenantDTO) {
        Tenant tenant = BeanUtils.convertCopyBean(tenantDTO, Tenant.class);
        tenantRepository.save(tenant);
        return BeanUtils.convertCopyBean(tenant, TenantDTO.class);
    }

    /**
     * 编辑数据
     */
    public TenantDTO update(TenantDTO tenantDTO) {
        Tenant tenant = BeanUtils.convertCopyBean(tenantDTO, Tenant.class);
        tenantRepository.updateById(tenant);
        return BeanUtils.convertCopyBean(tenant, TenantDTO.class);
    }

    /**
     * 删除数据
     */
    public Boolean delete(Long id) {
        return tenantRepository.removeById(id);
    }
}

