package com.kaadas.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * @ClassName GuidUtils
 * @Description
 * @Author Spike_Zhang
 * @DATE 2024/4/10 8:49
 * @Version 1.0
 */
public class GuidUtils {

    private static Integer count = 0;
    private static String LAST_TIME = "";

    /**
     *
     * @return
     * Example:  20240311-1308-2374-70000-01978920C2B8DF
     *          20240311        年, 月, 日
     *          1308            时, 分
     *          2374            秒, 毫秒数(前2位)
     *          70000           毫秒数(第3位), 计数器(4位)
     *          01978920C2B8DF  进程ID(后3位), 随机数(5位), MAC地址(后6位)
     */
    public static synchronized String generated() {

        String nowSymbol = nowSymbol();

        String countSymbol = countSymbol();

        String randomSymbol = randomSymbol();

        String pidSymbol = pidSymbol();

        String macAddress = macAddress();

        return String.format("%s%s-%s%s%s", nowSymbol, countSymbol, randomSymbol, pidSymbol, macAddress).toUpperCase();
    }

    private static String macAddress() {
        InetAddress inetAddress = null;
        try {
            inetAddress = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }

        //第一种方式：利用自己写的方法获取本地mac地址
        String localMacAddress1 = getLocalMac(inetAddress);
        return localMacAddress1.substring(localMacAddress1.length() - 6).toUpperCase();
    }

    private static String pidSymbol() {
        // 获取当前Java进程的ID
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        long pid = Long.parseLong(runtimeMXBean.getName().split("@")[0]);

        String pidSymbol = String.format("%03d", pid);
        return pidSymbol.substring(pidSymbol.length() - 3);
    }

    private static String randomSymbol() {
        Random random = new Random();
        return String.format("%05d", random.nextInt(10000));
    }

    private static String countSymbol() {
        if (count > 9999) {
            count = 0;
        } else {
            count ++;
        }
        return String.format("%04d", count);
    }

    private static String nowSymbol() {
        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMMdd-HHmm-ssSSS");

        char charToInsert = '-';
        int index = 18;
        StringBuilder sb = new StringBuilder(sdf3.format(new Date()).toString());
        sb.insert(index, charToInsert);
        sb.toString();

        String nowSymbol = sb.toString();
        if (StringUtils.isNotEmpty(LAST_TIME) && !LAST_TIME.equals(nowSymbol)) {
            LAST_TIME = nowSymbol;
        }

        return nowSymbol;
    }

    // 20240311-1308-2374-70000-01978920C2B8DF
    // 20240410-0943-120000-8543326660MACADDRESS
    // 20240410-0923-050000-73519PIDSymbolMACADDRESS

    private static String executeCommand(String command) throws Exception {
        Process process = Runtime.getRuntime().exec(command);
        process.waitFor();
        return new String(process.getInputStream().readAllBytes()).trim();
    }

    /**
     * 获取本地mac地址
     * 注意：物理地址是48位，别和ipv6搞错了
     * @param inetAddress
     * @return 本地mac地址
     */
    private static String getLocalMac(InetAddress inetAddress) {
        try {
            //获取网卡，获取地址
            byte[] mac = NetworkInterface.getByInetAddress(inetAddress).getHardwareAddress();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < mac.length; i++) {
                if (i != 0) {
                    sb.append("-");
                }
                //字节转换为整数
                int temp = mac[i] & 0xff;
                String str = Integer.toHexString(temp);
                if (str.length() == 1) {
                    sb.append("0").append(str);
                } else {
                    sb.append(str);
                }
            }
            return sb.toString().replace("-", "");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }


}
