package com.kaadas.rental.management.tenant.domain.repository;


import java.util.List;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kaadas.rental.management.tenant.domain.Tenant;
import com.kaadas.rental.management.tenant.domain.repository.mapper.TenantMapper;
import org.springframework.stereotype.Repository;
import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName TenantRepository
 * @Description 客户表 仓储层
 * @Author Spike_Zhang
 * @DATE 2024-04-19 20:22:07
 * @Version 1.0.0
 */
@Slf4j
@Repository
public class TenantRepository extends ServiceImpl<TenantMapper, Tenant> implements IService<Tenant> {

}

