package com.kaadas.common.exception;

/**
 * @ClassName ClientExceptIon
 * @Description
 * @Author Spike_Zhang
 * @DATE 2024/4/15 17:30
 * @Version 1.0
 */
public class ClientException extends RuntimeException {

    public ClientException() {
        super();
    }

    public ClientException(String message) {
        super(message);
    }
}
