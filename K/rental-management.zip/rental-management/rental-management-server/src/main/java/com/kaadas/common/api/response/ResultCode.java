package com.kaadas.common.api.response;

import org.springframework.http.HttpStatus;

import java.io.Serializable;

/**
 * @ClassName ResultCode
 * @Description
 * @Author Spike_Zhang
 * @DATE 2024/4/15 16:39
 * @Version 1.0
 */
public interface ResultCode extends Serializable {

    /**
     * Http 状态码
     * @return
     */
    HttpStatus getHttpStatus();

    /**
     * 错误码
     * @return
     */
    long getCode();

    /**
     * 错误信息
     * @return
     */
    String getMessage();
}
