package com.kaadas.rental.management;

/**
 * @author Spike_Zhang
 * @date 2024/4/9 15:45
 * @deprecated 租住管理系统
 */