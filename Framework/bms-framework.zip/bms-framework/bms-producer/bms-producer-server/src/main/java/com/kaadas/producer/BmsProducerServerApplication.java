package com.kaadas.producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BmsProducerServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(BmsProducerServerApplication.class, args);
    }

}
