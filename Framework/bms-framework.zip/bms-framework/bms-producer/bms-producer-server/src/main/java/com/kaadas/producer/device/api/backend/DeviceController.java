package com.kaadas.producer.device.api.backend;

import com.kaadas.producer.device.api.dto.DeviceDTO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeviceController implements DeviceApi{


    @Override
    public DeviceDTO find(String deviceId) {
        return DeviceDTO.builder()
                .deviceId("deviceId-a")
                .deviceName("deviceName-a")
                .esn("esn-a")
                .build();
    }
}
