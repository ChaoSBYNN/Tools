package com.kaadas.producer.device.api.dto;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DeviceDTO {

    private String deviceId;

    private String deviceName;

    private String esn;

}
