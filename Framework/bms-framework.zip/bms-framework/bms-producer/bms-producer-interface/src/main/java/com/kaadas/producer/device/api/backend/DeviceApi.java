package com.kaadas.producer.device.api.backend;

import com.kaadas.producer.device.api.dto.DeviceDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("bms-producer-server") // 指向服务提供者应用
public interface DeviceApi {

    @GetMapping("/device/{deviceId}")
    DeviceDTO find(@PathVariable("deviceId") String deviceId);

}
