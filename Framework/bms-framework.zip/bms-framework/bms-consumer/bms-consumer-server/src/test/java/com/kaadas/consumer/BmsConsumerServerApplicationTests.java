package com.kaadas.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsConsumerServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
