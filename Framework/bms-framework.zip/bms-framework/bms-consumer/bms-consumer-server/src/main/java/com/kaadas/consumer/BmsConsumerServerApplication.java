package com.kaadas.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
public class BmsConsumerServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(BmsConsumerServerApplication.class, args);
    }

}
