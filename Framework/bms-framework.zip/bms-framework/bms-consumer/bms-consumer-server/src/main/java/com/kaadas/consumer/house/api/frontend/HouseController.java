package com.kaadas.consumer.house.api.frontend;

import com.kaadas.producer.device.api.backend.DeviceApi;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/house")
public class HouseController {

    @Resource
    private DeviceApi deviceApi;

    @GetMapping("/device")
    public String getDevice() {
        return deviceApi.find("aaa").toString();
    }
}
