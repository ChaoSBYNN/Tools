package com.kaadas;

import com.kaadas.util.Lists;
import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.changestream.ChangeStreamDocument;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-12-11
 * @since 1.0.0
 */
public class ChangeStreamTest2 {
  public static void main(String[] args) {
    MongoClient readMongo1 =
      MongoClients.create("mongodb://flink:flink@10.1.0.146:27017,10.1.0.147:27017,10.1.0.148:27017");
    MongoDatabase paasDb110 = readMongo1.getDatabase("paasdb");
    MongoCollection<Document> test = paasDb110.getCollection("test");
    List<Bson> pipeline =
      Lists.newArrayList(Aggregates.match(Filters.in("operationType", "insert", "update", "replace", "delete")),
        Aggregates.addFields());
    try (MongoCursor<ChangeStreamDocument<Document>> cursor = test.watch(pipeline)
                                                                  //      .fullDocument(FullDocument.UPDATE_LOOKUP)
                                                                  .batchSize(100).iterator()) {
      while (cursor.hasNext()) {
        ChangeStreamDocument<Document> document = cursor.next();
        System.out.println(System.currentTimeMillis());
        System.out.println(document);
        System.out.println(document.getFullDocument());
      }
    }
  }
}
