package com.kaadas.test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.util.EsnUtils;
import com.kaadas.util.JsonUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.LineIterator;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-16
 * @since 1.0.0
 */
public class MqttFileLoader {
  public static void main1(String[] args) throws IOException {
    Files.newDirectoryStream(Paths.get("C:\\Users\\ZhangDuanFeng\\Desktop\\test")).forEach(path -> {
      try {
        Files.lines(path).forEach(line -> {
          System.out.println(line);
        });
      } catch (IOException e) {
        e.printStackTrace();
      }
    });
  }

  //[2023-02-16 06:39:26:696] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:UW42201614683","mqttMsgType":6,
  // "ip":"124.234.112.247","mqttMsg":"PUBREL: 6"}
  //[2023-02-16 06:39:26:696] [INFO] - mqtt-process:{"to":"client","clientId":"wf:UW42201614683","mqttMsgType":7,
  // "ip":"124.234.112.247","mqttMsg":"PUBCOMP: 6"}
  //[2023-02-16 06:39:26:696] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:KFV1212514706","mqttMsgType":1,
  // "ip":"27.17.176.210","mqttMsg":"CONNECT: MQTT 4 clientId[wf:KFV1212514706] cleanSession[true]
  // credentials[KFV1212514706/be0a74fc282a07de0969c482182a04b0ef1ab34a] willMessage[null] keepAlive[10]"}
  //[2023-02-16 06:39:26:697] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:10V1214213531","mqttMsgType":4,
  // "mqttMsgId":1,"ip":"119.184.88.60","mqttMsg":"PUBACK: 1"}
  //[2023-02-16 06:39:26:698] [INFO] - mqtt-process:{"to":"client","clientId":"wf:UW42201614683","mqttMsgType":3,
  // "mqttMsgId":6,"ip":"124.234.112.247","mqttMsg":"PUBLISH: 6 topic[/orangeiot/UW42201614683/call] payload
  // length[104] qos[EXACTLY_ONCE] retain[false] dup[false]","payload":"{\"msgtype\":\"eventResponse\",
  // \"func\":\"wfevent\",\"msgId\":4,\"eventtype\":\"list\",\"time\":\"1676500766\",\"result\":1}"}
  //[2023-02-16 06:39:26:699] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:KVP1221412670","mqttMsgType":14,
  // "ip":"183.189.108.254","mqttMsg":"DISCONNECT"}
  //[2023-02-16 06:39:26:699] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:A5W1212110933","mqttMsgType":7,
  // "ip":"171.113.29.10","mqttMsg":"PUBCOMP: 9"}
  //[2023-02-16 06:39:26:700] [INFO] - mqtt-process:{"to":"client","clientId":"wf:KFV1212514706","mqttMsgType":2,
  // "ip":"27.17.176.210","mqttMsg":"CONNACK: sessionPresent[false] returnCode[CONNECTION_ACCEPTED]"}
  //[2023-02-16 06:39:26:701] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:10V1212211164","mqttMsgType":4,
  // "mqttMsgId":1,"ip":"36.48.104.66","mqttMsg":"PUBACK: 1"}
  //[2023-02-16 06:39:26:702] [INFO] - mqtt-process:{"to":"srv:mqtt","clientId":"wf:UPS1204111865","mqttMsgType":5,
  // "ip":"112.32.40.180","mqttMsg":"PUBREC: 5"}
  //[2023-02-16 06:39:26:702] [INFO] - mqtt-process:{"to":"client","clientId":"wf:UPS1204111865","mqttMsgType":6,
  // "ip":"112.32.40.180","mqttMsg":"PUBREL: 5"}
  public static void main(String[] args) throws IOException {
    //    System.out.println("本日志采集时间为2022-08-08 23:26:00 ~ 2022-08-08 23:45:59");
    String filename = "C:\\Users\\ZhangDuanFeng\\Desktop\\test\\mqttProcessInfo-2023-02-16-3.log";
    FileInputStream in = new FileInputStream(filename);
    Pattern pattern = Pattern.compile("\\[(.*)]\\s\\[.*] - mqtt-process:(.*)");
    String outfile = "C:\\Users\\ZhangDuanFeng\\Desktop\\test\\mqtt.log";
    List<ObjectNode> objectNodes = new ArrayList<>();
    LineIterator lineIterator = IOUtils.lineIterator(in, "UTF-8");

    while (lineIterator.hasNext()) {
      String line = lineIterator.nextLine();
      Matcher matcher = pattern.matcher(line);
      if (!matcher.matches()) {
        continue;
      }
      MatchResult matchResult = matcher.toMatchResult();
      String sysTime = matchResult.group(1);
      ObjectNode jsonNode = (ObjectNode) JsonUtils.toJsonNode(matchResult.group(2));
      if (jsonNode == null) {
        continue;
      }
      jsonNode.put("sysTime", sysTime);
      String to = jsonNode.get("to").textValue();
      String mqttMsg = jsonNode.get("mqttMsg").textValue();
      String clientId = jsonNode.get("clientId").textValue();
      if (!Objects.equals(to, "client") && clientId.startsWith("wf") && !mqttMsg.startsWith("PUBCOMP") &&
          !mqttMsg.startsWith("PUBREL") && !mqttMsg.startsWith("PUBACK")) {
        //        System.out.println(jsonNode);
        objectNodes.add(jsonNode);
      }
    }
    IOUtils.closeQuietly(in);

    Map<String, ObjectNode> esnList = objectNodes.stream().map(objectNode -> {
      return objectNode.get("clientId").textValue().substring(3);
    }).distinct().collect(Collectors.toMap(esn -> esn, esn -> {
      ObjectNode objectNode = JsonUtils.getObjectMapper().createObjectNode();
      objectNode.put("esn", esn);
      objectNode.set("vers", JsonUtils.getObjectMapper().createObjectNode());
      objectNode.set("events", JsonUtils.getObjectMapper().createObjectNode());
      return objectNode;
    }));
    System.out.println("采集时间段内在线设备总量: " + esnList.size());
    List<Map.Entry<String, Long>> pidCount = esnList
      .keySet()
      .stream()
      .collect(Collectors.groupingBy(esn -> {
        try {
          return EsnUtils.getPid(esn);
        } catch (Exception t) {
          return esn;
        }
      }, Collectors.counting()))
      .entrySet()
      .stream()
      .sorted((e1, e2) -> (int) (e2.getValue() - e1.getValue()))
      .collect(Collectors.toList());
    System.out.println("采集时间段内在线机型(数量)含: " + JsonUtils.serialize(pidCount));

    objectNodes
      .stream()
      .parallel()
      //根据clientId分组
      .collect(Collectors.groupingBy(objectNode -> objectNode.get("clientId").textValue().substring(3)))
      .forEach((k, v) -> {
        // Vers
        v.stream().parallel().map(objectNode -> {
          return objectNode.get("payload");
        }).filter(Objects::nonNull).filter(payload -> payload.has("eventtype")).filter(payload -> {
          String eventtype = payload.get("eventtype").asText("");
          return eventtype.equals("lockInf") || eventtype.equals("cameraInf");
        }).forEach(payload -> {
          String eventtype = payload.get("eventtype").asText("");
          JsonNode eventparams = payload.get("eventparams");
          ObjectNode vers = (ObjectNode) esnList.get(k).get("vers");
          if (eventparams.has("firmware")) {
            vers.put("firmware", eventparams.get("firmware").textValue());
          }

          if (eventparams.has("software")) {
            vers.put("software", eventparams.get("software").textValue());
          }
          if (eventparams.has("BLEversion")) {
            vers.put("BLEversion", eventparams.get("BLEversion").textValue());
          }
          if (eventparams.has("WIFIversion")) {
            vers.put("WIFIversion", eventparams.get("WIFIversion").textValue());
          }
          if (eventparams.has("MQTTversion")) {
            vers.put("MQTTversion", eventparams.get("MQTTversion").textValue());
          }
          if (eventparams.has("camera_version")) {
            vers.put("camera_version", eventparams.get("camera_version").textValue());
          }
          if (eventparams.has("mcu_version")) {
            vers.put("mcu_version", eventparams.get("mcu_version").textValue());
          }
        });
        // CONNECT
        esnList
          .get(k)
          .put("connectCount",
            v
              .stream()
              .parallel()
              .filter(objectNode -> objectNode.get("mqttMsg").textValue().startsWith("CONNECT"))
              .count());
        esnList
          .get(k)
          .put("publishCount",
            v
              .stream()
              .parallel()
              .filter(objectNode -> objectNode.get("mqttMsg").textValue().startsWith("PUBLISH"))
              .count());
        // PUBLISH & event
        v
          .stream()
          .parallel()
          .filter(objectNode -> {
            String mqttMsg = objectNode.get("mqttMsg").textValue();
            return mqttMsg.startsWith("PUBLISH") && mqttMsg.contains("/orangeiot/" + k + "/event");
          })
          .map(objectNode -> {
            if (!objectNode.get("payload").has("eventtype")) {
              return "";
            }
            return objectNode.get("payload").get("eventtype").asText("");
          })
          .collect(Collectors.groupingBy(eventtype -> eventtype, Collectors.counting()))
          .forEach((k1, v1) -> ((ObjectNode) esnList.get(k).get("events")).put(k1, v1));
      });
    Map<String, Map<String, Long>> verMap = esnList.entrySet().stream().collect(Collectors.groupingBy(entry -> {
      try {
        return EsnUtils.getPid(entry.getKey());
      } catch (Exception t) {
        return entry.getKey();
      }
    })).entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> {
      return entry
        .getValue()
        .stream()
        .map(Map.Entry::getValue)
        .filter(objectNode -> objectNode.get("vers").has("WIFIversion"))
        .map(objectNode -> objectNode.get("vers").get("WIFIversion").textValue())
        .collect(Collectors.groupingBy(str -> str, Collectors.counting()));
    }));

    List<Map.Entry<String, Map<String, Long>>> verCount = pidCount.stream().map(entry -> {
      return new AbstractMap.SimpleEntry<>(entry.getKey(), verMap.get(entry.getKey()));
    }).collect(Collectors.toList());
    System.out.println("采集时间段内在线机型WIFI版本分布(只根据lockInf和cameraInf统计): " + JsonUtils.serialize(verCount));

    // 连接排序
    List<ObjectNode> connectSort = esnList
      .values()
      .stream()
      .filter(objectNode -> objectNode.has("connectCount"))
      .sorted(((o1, o2) -> o2.get("connectCount").intValue() - o1.get("connectCount").intValue()))
      .limit(100)
      .collect(Collectors.toList());
    System.out.println("采集时间段内上线次数排序(前100): " + JsonUtils.serialize(connectSort));

    // 发布排序
    List<ObjectNode> publishSort = esnList
      .values()
      .stream()
      .filter(objectNode -> objectNode.has("publishCount"))
      .sorted(((o1, o2) -> o2.get("publishCount").intValue() - o1.get("publishCount").intValue()))
      .limit(100)
      .collect(Collectors.toList());
    System.out.println("采集时间段内发布消息次数排序(前100): " + JsonUtils.serialize(publishSort));

  }
}
