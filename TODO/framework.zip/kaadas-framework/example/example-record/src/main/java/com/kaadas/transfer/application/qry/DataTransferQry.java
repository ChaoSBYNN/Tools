package com.kaadas.transfer.application.qry;

import lombok.Data;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-27
 * @since 1.0.0
 */
@Data
public class DataTransferQry {
  private MongoProps readDb;
  private MongoProps writeDb;
  private Map<String, String> mapping;
}
