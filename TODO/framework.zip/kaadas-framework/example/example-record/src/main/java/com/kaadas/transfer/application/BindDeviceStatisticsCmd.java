package com.kaadas.transfer.application;

import com.kaadas.transfer.infrastructure.DateUtils;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import com.kaadas.util.StringUtils;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
import lombok.extern.log4j.Log4j2;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-01
 * @since 1.0.0
 */
@Log4j2(topic = "BindDeviceStatistics")
@Component
public class BindDeviceStatisticsCmd {

  MongoClient readMongo;
  MongoDatabase kaadasDB;
  MongoCollection<Document> initStatus;
  MongoCollection<Document> kdsWifiUserDeviceList;
  MongoCollection<Document> deviceStatistics;

  public BindDeviceStatisticsCmd(MongoClient readMongo) {
    this.readMongo = readMongo;
    this.kaadasDB = readMongo.getDatabase("kaadasDB");
    this.initStatus = kaadasDB.getCollection("init_status");
    this.kdsWifiUserDeviceList = kaadasDB.getCollection("kdsWifiUserDeviceList");
    this.deviceStatistics = kaadasDB.getCollection("device_statistics");
  }

  private void statistics(boolean override) {
    if (!override) {
      // 不覆盖时，检查状态
      Document deviceStatisticsInitData = initStatus.find(new Document("name", "DeviceStatistics")).first();
      if (deviceStatisticsInitData != null && deviceStatisticsInitData.getInteger("status", 0) == 1) {
        log.info("DeviceStatistics 处理完成，不执行覆盖。");
        return;
      }
    }
    MongoCursor<Document> indexCursor = deviceStatistics.listIndexes().iterator();
    boolean hasIndex = false;
    while (indexCursor.hasNext()) {
      Document document = indexCursor.next();
      if ("esn_1_uid_1".equals(document.getString("name"))) {
        hasIndex = true;
        break;
      }
    }
    indexCursor.close();
    if (!hasIndex) {
      Document indexDoc = new Document("esn", 1).append("uid", 1);
      log.info("DeviceStatistics ，为集合 device_statistics 创建索引：{}", indexDoc.toJson());
      deviceStatistics.createIndex(indexDoc, new IndexOptions().unique(true).background(true));
    }
    MongoCursor<Document> cursor = kdsWifiUserDeviceList
      .find()
      .projection(new Document("_id", 1).append("uid", 1).append("createTime", 1).append("wifiSN", 1))
      .batchSize(50)
      .cursor();
    Document document;
    AtomicLong total = new AtomicLong(0);
    long startTime = DateUtils.millis();
    while (cursor.hasNext()) {
      document = cursor.next();
      String uid = document.getString("uid");
      if (StringUtils.isBlank(uid)) {
        continue;
      }
      long singleStartTime = DateUtils.millis();
      Long bindTime = document.getLong("createTime");
      if (bindTime == null) {
        ObjectId id = document.getObjectId("_id");
        bindTime = id.getDate().getTime() / 1000L;
      }
      Document existed = deviceStatistics
        .find(new Document("esn", document.getString("wifiSN")).append("uid", document.getString("uid")))
        .first();
      if (existed == null) {
        deviceStatistics.insertOne(new Document("esn", document.getString("wifiSN"))
          .append("uid", document.getString("uid"))
          .append("bindTime", bindTime)
          .append("unlock", 0)
          .append("locked", 0));
      }
      long singleEndTime = DateUtils.millis();
      total.incrementAndGet();
      log.info("DeviceStatistics ，单次处理时间：{} 毫秒，已处理：{}", (singleEndTime - singleStartTime), total.get());
    }
    long endTime = DateUtils.millis();
    log.info("DeviceStatistics ，已完成，处理时间：{} 毫秒，处理总数：{}", (endTime - startTime), total.get());

    initStatus.updateOne(new Document("name", "DeviceStatistics"),
      new Document("$set", new Document("total", total.get()).append("status", 1)));
  }

  public void deviceStatistics(boolean override) {
    SingleThreadPool.execute(new RunFunc("DeviceStatistics", () -> {
      log.info("DeviceStatistics ，开始处理。");
      statistics(override);
      log.info("DeviceStatistics ，处理结束。");
    }));
  }
}
