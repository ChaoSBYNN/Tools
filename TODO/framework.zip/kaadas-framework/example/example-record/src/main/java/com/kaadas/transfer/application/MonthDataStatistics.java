package com.kaadas.transfer.application;

import com.kaadas.transfer.infrastructure.DateUtils;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import lombok.extern.log4j.Log4j2;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-01-31
 * @since 1.0.0
 */
//@Component
@Log4j2(topic = "MonthDataStatistics")
public class MonthDataStatistics {

  MongoClient readMongo;

  public MonthDataStatistics(MongoClient readMongo) {
    this.readMongo = readMongo;
  }

  public static void main(String[] args) {

    System.out.println(new ObjectId("63e262f883f489933d1f276c").getDate());
  }

  private static void load(MongoClient mongoClient, YearMonth month, boolean override) {
    String suffix = DateUtils.PATTERN_YEAR_MONTH.format(month);
    MongoDatabase kaadasDB = mongoClient.getDatabase("kaadasDB");
    MongoCollection<Document> initStatus = kaadasDB.getCollection("init_status");
    if (!override) {
      // 不覆盖时，检查状态
      Document recordCountInitData = initStatus.find(new Document("name", "RecordCount" + suffix)).first();
      if (recordCountInitData != null && recordCountInitData.getInteger("status", 0) == 1) {
        log.info("RecordCount{} 已完成，不执行覆盖。", suffix);
        return;
      }
    }
    String recordCountTableName = "record_count_" + suffix;
    AtomicLong total = new AtomicLong(0L);
    LocalDateTime startDateTime = DateUtils.getEndDayOfMonth(month.minusMonths(1L));
    LocalDateTime endDateTime = DateUtils.getEndDayOfMonth(month);
    log.info("RecordCount{} ，即将查询Record，时间段为：{} - {}",
      suffix,
      DateUtils.format(startDateTime.plusSeconds(1L)),
      DateUtils.format(endDateTime));
    MongoDatabase operationDB = mongoClient.getDatabase("OperationDB");
    MongoCollection<Document> kdsWifiOperationRecord = operationDB.getCollection("kdsWifiOperationRecord");
    MongoCollection<Document> recordCount = operationDB.getCollection("record_count");
    MongoCursor<Document> indexCursor = recordCount.listIndexes().iterator();
    boolean hasIndex = false;
    while (indexCursor.hasNext()) {
      Document document = indexCursor.next();
      if ("status_1".equals(document.getString("name"))) {
        hasIndex = true;
        break;
      }
    }
    indexCursor.close();
    if (!hasIndex) {
      Document indexDoc = new Document("status", 1);
      log.info("RecordCount{}，为集合 {} 创建索引：{}", suffix, recordCountTableName, indexDoc.toJson());
      recordCount.createIndex(indexDoc);
    }
    // 编号
    int num = 1;
    // 默认的最小ID和最大ID
    ObjectId minId = new ObjectId(DateUtils.toDate(startDateTime)), maxId = new ObjectId(DateUtils.toDate(endDateTime));


    Document latestDoc = recordCount.find().limit(1).sort(new Document("_id", -1)).first();
    if (latestDoc != null) {
      // 如果有最后一条数据，从最后一条数据中取出当前的minId 和 num
      minId = latestDoc.getObjectId("maxId");
      num = latestDoc.getInteger("num", 1);
      int count = latestDoc.getInteger("count", 0);
      if (count % 10000 != 0) {
        return;
      }
      List<Document> pipeline = new ArrayList<>();
      pipeline.add(new Document("$group",
        new Document("_id", "total").append("totalCount", new Document("$sum", "$count"))));
      recordCount.aggregate(pipeline).forEach(document -> {
        total.set(document.getInteger("totalCount"));
      });
    }

    long startTime = DateUtils.millis();
    List<Document> records;

    while (true) {
      long singleStartTime = DateUtils.millis();
      records = queryRecord(kdsWifiOperationRecord, minId, maxId);
      // 查不到数据了就结束
      if (records.size() == 0) {
        break;
      }
      ObjectId curMaxId = getMaxId(records);
      recordCount.insertOne(new Document("num", num)
        .append("minId", minId)
        .append("maxId", curMaxId)
        .append("count", records.size())
        .append("status", 0));
      total.addAndGet(records.size());
      minId = curMaxId;

      long singleEndTime = DateUtils.millis();
      log.info("RecordCount{} ，为 {} 写入数据，当前页数：{} ，当前查询数：{} ，已写入总数：{} 。 单次处理耗时：{} 毫秒",
        suffix,
        recordCountTableName,
        num,
        records.size(),
        total.get(),
        (singleEndTime - singleStartTime));
      records.clear();
      num++;
    }
    long endTime = DateUtils.millis();
    log.info("RecordCount{} 集合 {} 创建已完成，共 {} 页，查询总数：{}，耗时：{} 毫秒。",
      suffix,
      recordCountTableName,
      num,
      total.get(),
      (endTime - startTime));

    initStatus.updateOne(new Document("name", "RecordCount" + suffix),
      new Document("$set", new Document("total", total.get()).append("status", 1)));
  }

  private static List<Document> queryRecord(MongoCollection<Document> kdsWifiOperationRecord, ObjectId minId,
                                            ObjectId maxId) {
    List<Document> records = new ArrayList<>(10000);
    kdsWifiOperationRecord
      // 查询_id小于queryId的
      .find(new Document("_id", new Document("$gt", minId).append("$lte", maxId)))
      .projection(new Document("_id", 1))
      .limit(10000)
      .sort(new Document("_id", 1))
      .forEach(records::add);
    return records;
  }

  private static ObjectId getMinId(List<Document> records) {
    if (records == null || records.size() == 0) {
      return null;
    }
    return records.get(0).getObjectId("_id");
  }

  private static ObjectId getMaxId(List<Document> records) {
    if (records == null || records.size() == 0) {
      return null;
    }
    return records.get(records.size() - 1).getObjectId("_id");
  }

  public void statistics(YearMonth month, boolean override) {
    String monthStr = DateUtils.PATTERN_YEAR_MONTH.format(month);
    SingleThreadPool.execute(new RunFunc("RecordCount" + monthStr, () -> {
      log.info("RecordCount{} ，开始处理。", monthStr);
      load(readMongo, month, override);
      log.info("RecordCount{} ，处理结束。", monthStr);
    }));
  }
}
