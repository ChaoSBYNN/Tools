package com.kaadas.transfer.infrastructure;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-01
 * @since 1.0.0
 */
public class DateUtils {
  public static final DateTimeFormatter PATTERN_DATETIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
  public static final DateTimeFormatter PATTERN_YEAR_MONTH = DateTimeFormatter.ofPattern("yyyyMM");
  private static final Clock CLOCK = Clock.systemDefaultZone();

  public static LocalDateTime getStartDayOfMonth(YearMonth month) {
    return LocalDate.of(month.getYear(), month.getMonth(), 1).atStartOfDay();
  }

  public static LocalDateTime getEndDayOfMonth(YearMonth month) {
    return LocalDateTime.of(month.atEndOfMonth(),
      LocalTime.ofSecondOfDay(Duration.ofDays(1L).minusSeconds(1L).getSeconds()));
  }

  public static Date toDate(LocalDateTime localDateTime) {
    return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
  }

  public static String format(LocalDateTime localDateTime) {
    return PATTERN_DATETIME.format(localDateTime);
  }

  public static long millis() {
    return CLOCK.millis();
  }
}
