package com.kaadas.transfer.application.qry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-06
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IncrementalDataTransferQry {
  @NotBlank
  private String minId;
  private String maxId;
}
