package com.kaadas.transfer.infrastructure;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-02
 * @since 1.0.0
 */
@Configuration
@EnableConfigurationProperties({ReadMongoProps.class, WriteMongoProps.class})
public class MongoConfig {

  @Primary
  @Bean(name = "readMongo", destroyMethod = "close")
  public MongoClient readMongo(ReadMongoProps props) {
    return MongoClients.create(props.getUri());
  }

  @Bean(name = "writeMongo", destroyMethod = "close")
  public MongoClient writeMongo(WriteMongoProps props) {
    return MongoClients.create(props.getUri());
  }
}
