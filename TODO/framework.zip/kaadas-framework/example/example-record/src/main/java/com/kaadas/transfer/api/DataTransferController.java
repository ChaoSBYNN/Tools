package com.kaadas.transfer.api;

import com.kaadas.transfer.application.DataTransferCmd;
import com.kaadas.transfer.application.qry.IncrementalDataTransferQry;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.StringUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.log4j.Log4j2;
import org.bson.types.ObjectId;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.UUID;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-06
 * @since 1.0.0
 */
@Log4j2(topic = "DataTransfer")
@Api(tags = "数据传输")
@RequestMapping("data/transfer")
@RestController
public class DataTransferController {
  @Resource
  DataTransferCmd cmd;

  @ApiOperation("增量传输")
  @PostMapping("incremental")
  public String incremental(@RequestBody IncrementalDataTransferQry qry) {
    String uuid = UUID.randomUUID().toString();
    SingleThreadPool.execute(new RunFunc("IncrementalData_" + uuid, () -> {
      ObjectId minId = new ObjectId(qry.getMinId());
      ObjectId maxId = null;
      if (StringUtils.isNotBlank(qry.getMaxId())) {
        maxId = new ObjectId(qry.getMaxId());
      }
      List<String> ids = cmd.createIncrementalTask(uuid, minId, maxId);
      log.info("IncrementalData. Condition: {} .Create tasks: {} .",
        JsonUtils.serialize(qry),
        JsonUtils.serialize(ids));
    }));
    return uuid;
  }

  @ApiOperation("全量传输")
  @PostMapping("full")
  public String full() {
    String uuid = UUID.randomUUID().toString();

    return uuid;
  }

  @ApiOperation("传输状态")
  @GetMapping("status")
  public void status() {

  }

  @ApiOperation("写入到write库")
  @GetMapping("write")
  public void write(@ApiParam @RequestParam String uuid) {
    SingleThreadPool.execute(new RunFunc("DataTransfer_" + uuid, () -> {
      cmd.transfer(uuid);
      log.info("DataTransfer. uuid: {} .", uuid);
    }));
  }
}
