package com.kaadas.transfer;

import com.fasterxml.classmate.TypeResolver;
import com.github.xiaoymin.knife4j.spring.annotations.EnableKnife4j;
import com.kaadas.result.ErrorResult;
import com.kaadas.result.ResultCode;
import com.kaadas.util.JsonUtils;
import com.kaadas.web.page.SwaggerConfigurer;
import com.kaadas.web.version.ApiVersion;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.builders.*;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2WebMvc;

import java.util.ArrayList;
import java.util.List;

/**
 * Swagger OpenAPI 3.0配置
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */

@EnableSwagger2WebMvc
@EnableKnife4j
@Profile({"dev", "test", "pre"})
@Configuration
@SuppressWarnings("unused")
public class SwaggerConfiguration extends SwaggerConfigurer {
  private final TypeResolver typeResolver;

  public SwaggerConfiguration(TypeResolver typeResolver) {this.typeResolver = typeResolver;}

  /**
   * 名为“api”的分组，
   *
   * @return springfox.documentation.spring.web.plugins.Docket
   * @date 2022-03-08 13:31
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  @Bean
  public Docket api() {
    Docket docket = new Docket(DocumentationType.SWAGGER_2)
      .groupName("api")
      .apiInfo(apiInfo())
      .globalOperationParameters(defaultParameters())
      .select()
      .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
      .paths(PathSelectors.any())
      .build();
    globalResponses(docket);
    return docket;
  }

  /**
   * 名为“apiv1”的分组，要求在
   *
   * @return springfox.documentation.spring.web.plugins.Docket
   * @date 2022-03-08 13:31
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  @Bean
  public Docket apiV1() {
    int ver = 1;
    Docket docket = new Docket(DocumentationType.SWAGGER_2)
      .groupName("apiv" + ver)
      .apiInfo(apiInfo(ver))
      .globalOperationParameters(getApiVersionGlobalRequestParameter(ver))
      .select()
      .apis(handler -> handler.isAnnotatedWith(ApiOperation.class) && (handler
                                                                         .findControllerAnnotation(ApiVersion.class)
                                                                         .map(apiVersion -> apiVersion.value() == 1)
                                                                         .orElse(false) || handler
                                                                         .findAnnotation(ApiVersion.class)
                                                                         .map(apiVersion -> apiVersion.value() == 1)
                                                                         .orElse(false)
      ))
      .paths(PathSelectors.any())
      .build();
    globalResponses(docket);
    return docket;
  }

  //  public Predicate<RequestHandler> selector(int apiVer) {
  //
  //  }

  @Bean
  public Docket apiV2() {
    int ver = 2;
    Docket docket = new Docket(DocumentationType.SWAGGER_2)
      .groupName("apiv" + ver)
      .apiInfo(apiInfo(ver))
      .globalOperationParameters(getApiVersionGlobalRequestParameter(ver))
      .select()
      .apis(handler -> handler.isAnnotatedWith(ApiOperation.class) && handler
        .findControllerAnnotation(ApiVersion.class)
        .map(apiVersion -> apiVersion.value() == 2)
        .orElse(false))
      .paths(PathSelectors.any())
      .build();
    globalResponses(docket);
    return docket;
  }

  /**
   * API基本信息
   *
   * @return springfox.documentation.service.ApiInfo
   * @date 2021-10-27 15:23
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public ApiInfo apiInfo() {
    return apiInfo(0);
  }

  /**
   * API基本信息
   *
   * @param ver param1 版本
   * @return springfox.documentation.service.ApiInfo
   * @date 2021-10-27 15:23
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  private ApiInfo apiInfo(int ver) {
    String verStr = ver != 0 ? "v" + ver : "合集";
    return new ApiInfoBuilder()
      .title(String.format("Boss接口文档(%s)", verStr))
      .description("此文档根据接口版本分组，请查阅对应版本的接口文档。")
      .contact(new Contact("张端锋", "http://www.kaadas.com", "zhangduanfeng@kaadas.com"))
      .version("1.0")
      .build();
  }

  /**
   * 版本存在时，设置全局版本号
   *
   * @param defaultValue param1
   * @return java.util.List&lt;springfox.documentation.service.RequestParameter&gt;
   * @date 2021-10-27 15:23
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  private List<Parameter> getApiVersionGlobalRequestParameter(int defaultValue) {
    List<Parameter> parameters = new ArrayList<>(defaultParameters());
    parameters.add(new ParameterBuilder()
      .allowEmptyValue(false)
      .defaultValue(defaultValue + "")
      .name("Ver")
      .description("版本号，默认值为：" + defaultValue)
      .required(true)
      .modelRef(new ModelRef("integer"))
      .parameterType("header")
      .build());
    return parameters;
  }

  private List<Parameter> defaultParameters() {
    List<Parameter> parameters = new ArrayList<>();
    parameters.add(new ParameterBuilder()
      .name("Accept")
      .allowEmptyValue(false)
      .defaultValue(MediaType.APPLICATION_JSON_VALUE)
      .modelRef(new ModelRef("string"))
      .parameterType("header")
      .build());
    return parameters;
  }


  /**
   * 设置全局响应
   *
   * @param docket param1
   * @date 2021-10-27 15:28
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  private void globalResponses(Docket docket) {
    docket.additionalModels(typeResolver.resolve(ErrorResult.class));
    List<ResponseMessage> responses = new ArrayList<>();
    ResultCode[] resultCodes = ResultCode.values();

    for (ResultCode rc : resultCodes) {

      if (rc != ResultCode.OK) {
        ErrorResult errorResult = new ErrorResult();
        errorResult.setCode(rc.getCode());
        errorResult.setMsg(rc.getMsg());
        errorResult.setErrCode("{{errCode}}");
        errorResult.setErrDes("{{errDes}}");
        responses.add(new ResponseMessageBuilder()
          .code(rc.getCode())
          .message(rc.getMsg())
          //            .responseModel(new ModelRef("DefaultErrorResult", new ModelRef(JsonUtils.serialize
          //            (errorResult))))
          .responseModel(new ModelRef(JsonUtils.serialize(errorResult)))
          .build());
      }
    }
    docket.useDefaultResponseMessages(false);
    docket.globalResponseMessage(RequestMethod.GET, responses);
    docket.globalResponseMessage(RequestMethod.POST, responses);
    docket.globalResponseMessage(RequestMethod.PUT, responses);
    docket.globalResponseMessage(RequestMethod.DELETE, responses);
    docket.globalResponseMessage(RequestMethod.PATCH, responses);
  }

  @ApiModel
  public static class DefaultErrorResult extends ErrorResult {
    private static final long serialVersionUID = -809362869686321089L;

    @Override
    @ApiModelProperty(name = "结果码", notes = "结果码", dataType = "integer")
    public int getCode() {
      return super.getCode();
    }

    @Override
    @ApiModelProperty(name = "消息", notes = "消息")
    public String getMsg() {
      return super.getMsg();
    }

    @Override
    @ApiModelProperty(name = "错误码", notes = "错误码")
    public String getErrCode() {
      return super.getErrCode();
    }

    @Override
    @ApiModelProperty(name = "错误明细", notes = "错误明细")
    public String getErrDes() {
      return super.getErrDes();
    }
  }
}
