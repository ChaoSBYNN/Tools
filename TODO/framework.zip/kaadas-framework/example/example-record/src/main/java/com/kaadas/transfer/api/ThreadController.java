package com.kaadas.transfer.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.transfer.infrastructure.threadpool.MultiThreadPool;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import com.kaadas.transfer.infrastructure.threadpool.TransferThreadPool;
import com.kaadas.util.JsonUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-07
 * @since 1.0.0
 */
@Api(tags = "数据传输")
@RequestMapping("thread")
@RestController
public class ThreadController {

  @ApiOperation(value = "设置多线程线程池")
  @PostMapping("multi")
  public JsonNode multi(int poolSize) {
    MultiThreadPool.setPoolSize(poolSize);
    return MultiThreadPool.status();
  }

  @ApiOperation(value = "设置数据传输线程池")
  @PostMapping("transfer")
  public JsonNode transfer(int poolSize) {
    TransferThreadPool.setPoolSize(poolSize);
    return TransferThreadPool.status();
  }


  @ApiOperation(value = "查询线程池状态")
  @GetMapping("status")
  public JsonNode status() {
    ObjectNode status = JsonUtils.getObjectMapper().createObjectNode();
    status.set("single", SingleThreadPool.status());
    status.set("multi", MultiThreadPool.status());
    status.set("transfer", TransferThreadPool.status());
    return status;
  }
}
