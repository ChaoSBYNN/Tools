package com.kaadas.transfer.application;

import com.kaadas.transfer.application.qry.WriteCount;
import com.kaadas.transfer.infrastructure.DateUtils;
import com.kaadas.transfer.infrastructure.threadpool.MultiThreadPool;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.InsertManyOptions;
import com.mongodb.client.model.UpdateOptions;
import lombok.extern.log4j.Log4j2;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-01-31
 * @since 1.0.0
 */
@Log4j2(topic = "Write")
//@Component
public class RecordWriteCmd {

  static ConcurrentMap<String, Map<String, WriteCount>> writeCountConcurrentMap = new ConcurrentHashMap<>();

  MongoClient readMongo;
  MongoClient writeMongo;

  public RecordWriteCmd(@Qualifier("readMongo") MongoClient readMongo,
                        @Qualifier("writeMongo") MongoClient writeMongo) {
    this.readMongo = readMongo;
    this.writeMongo = writeMongo;
  }

  public Map<String, WriteCount> getStatus(String id) {
    return writeCountConcurrentMap.get(id);
  }

  public void write(String id) {
    Map<String, WriteCount> monthWriteCount = new ConcurrentHashMap<>();
    writeCountConcurrentMap.put(id, monthWriteCount);
    /* 读库需要用到 record_count 和 kdsWifiOperationRecord ， record_count 在 MonthDataStatistics 中写入数据 */
    MongoDatabase readDb = readMongo.getDatabase("OperationDB");
    MongoCollection<Document> readCount = readDb.getCollection("record_count");
    MongoCollection<Document> readRecord = readDb.getCollection("kdsWifiOperationRecord");
    /* 写库只需要 kdsWifiOperationRecord 源库与目标库相同时需要指定不同集合名，目前写死 */
    MongoDatabase writeDb = writeMongo.getDatabase("OperationDB");
    MongoCollection<Document> writeRecord = writeDb.getCollection("kdsWifiOperationRecord");

    MongoDatabase kaadasDB = readMongo.getDatabase("kaadasDB");
    MongoCollection<Document> initStatus = kaadasDB.getCollection("init_status");
    Document document;
    while (true) {
      document = readCount.findOneAndUpdate(new Document("status", 0), new Document("$set", new Document("status", 1)));
      if (document == null) {
        break;
      }
      String month = document.getString("month");
      WriteCount wc = monthWriteCount.computeIfAbsent(month, key -> {
        Document initCount = initStatus.find(new Document("name", "RecordCount" + month)).first();

        WriteCount writeCount = new WriteCount();
        if (initCount != null) {
          Long total = initCount.getLong("total");
          if (total == null) {
            total = 0L;
          }
          writeCount.getTotal().set(total);
          writeCount.getWaiting().set(total);
        }
        return writeCount;
      });
      final Document readCountDoc = document;
      MultiThreadPool.execute(new RunFunc("RecordWrite" + month + "_" + document.getObjectId("_id"), () -> {
        try {
          writeSingle(readCountDoc, readRecord, writeRecord, wc);
          readCount.updateOne(new Document("_id", readCountDoc.getObjectId("_id")),
            new Document("$set", new Document("status", 2)),
            new UpdateOptions().upsert(false));
        } catch (Exception e) {
          log.error("RecordWrite ，数据回滚：{}. 异常描述为：{}", readCountDoc.toJson(), e.getMessage(), e);
          readCount.updateOne(new Document("_id", readCountDoc.getObjectId("_id")),
            new Document("$set", new Document("status", 0).append("error", e.getMessage())),
            new UpdateOptions().bypassDocumentValidation(true).upsert(false));
        }
      }));
    }
  }

  private void writeSingle(Document readCountDoc, MongoCollection<Document> readRecord,
                           MongoCollection<Document> writeRecord, WriteCount wc) {
    long singleStartTime = DateUtils.millis();
    ObjectId minId = readCountDoc.getObjectId("minId");
    ObjectId maxId = readCountDoc.getObjectId("maxId");
    int count = readCountDoc.getInteger("count", 0);
    if (count == 0) {
      log.info("RecordWrite ，写入批数据：{}，无数据写入。", readCountDoc.toJson());
      return;
    }
    List<Document> records = new ArrayList<>(count);
    readRecord
      // 查询_id小于queryId的
      .find(new Document("_id", new Document("$gte", minId).append("$lte", maxId)))
      .limit(count)
      .sort(new Document("_id", 1))
      .forEach(records::add);
    writeRecord.insertMany(records, new InsertManyOptions().bypassDocumentValidation(true).ordered(false));
    wc.getWaiting().addAndGet(-records.size());
    wc.getSucceed().addAndGet(records.size());
    records.clear();
    long singleEndTime = DateUtils.millis();
    log.info("RecordWrite ，写入批数据：{}，单次处理时间：{} 毫秒 。", readCountDoc.toJson(), (singleEndTime - singleStartTime));
  }

}