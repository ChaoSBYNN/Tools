package com.kaadas;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-01-13
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class Main {

  public static void main(String[] args) {
    SpringApplication.run(Main.class, args);
    log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Kaadas Record Starter!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  }

}
