package com.kaadas.transfer.infrastructure;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-02
 * @since 1.0.0
 */
@Data
@ConfigurationProperties(prefix = "mongodb.read")
public class ReadMongoProps {
  private String uri;
  private String db;
  private String source;
}
