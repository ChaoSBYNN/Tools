package com.kaadas.transfer.infrastructure.threadpool;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class RunFunc implements Runnable {
  private String id;
  private Runnable runnable;
  private String info;

  public RunFunc(String id, Runnable runnable) {
    this.id = id;
    this.runnable = runnable;
  }

  @Override
  public void run() {
    runnable.run();
  }
}