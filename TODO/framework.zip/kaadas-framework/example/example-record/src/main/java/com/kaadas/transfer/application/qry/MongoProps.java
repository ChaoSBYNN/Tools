package com.kaadas.transfer.application.qry;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-27
 * @since 1.0.0
 */
@Data
public class MongoProps {
  private String connStr;
  private String database;
  private String collection;
}
