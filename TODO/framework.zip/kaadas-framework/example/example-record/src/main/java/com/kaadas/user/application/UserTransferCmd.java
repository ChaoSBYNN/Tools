package com.kaadas.user.application;

import com.kaadas.transfer.application.qry.WriteCount;
import com.kaadas.transfer.infrastructure.DateUtils;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.kaadas.transfer.infrastructure.threadpool.TransferThreadPool;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.InsertManyOptions;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.result.InsertOneResult;
import lombok.extern.log4j.Log4j2;
import org.bson.BsonValue;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-06
 * @since 1.0.0
 */
@Log4j2(topic = "UserTransfer")
@Component
public class UserTransferCmd {
  public static final int MAX_TRANSFER_COUNT = 10000;
  public static ConcurrentMap<String, Map<String, WriteCount>> DATA_TRANSFER_STATUS_MAP = new ConcurrentHashMap<>();
  static AtomicBoolean transferStart;
  MongoClient readMongo;
  MongoDatabase readDb;
  MongoCollection<Document> readRecord;
  MongoCollection<Document> readRecordTransferTask;
  MongoClient writeMongo;
  MongoDatabase writeDb;
  MongoCollection<Document> writeRecord;

  public UserTransferCmd(@Qualifier("readMongo") MongoClient readMongo,
                         @Qualifier("writeMongo") MongoClient writeMongo) {
    this.readMongo = readMongo;
    this.readDb = readMongo.getDatabase("OperationDB");
    this.readRecord = readDb.getCollection("kdsWifiOperationRecord");
    this.readRecordTransferTask = readDb.getCollection("record_transfer_task");
    this.writeMongo = writeMongo;
    this.writeDb = writeMongo.getDatabase("OperationDB");
    this.writeRecord = writeDb.getCollection("kdsWifiOperationRecord");
  }

  public static void main2(String[] args) {
    System.out.println(new ObjectId("63dc0f79cb94b343f319ad63").getTimestamp());
  }

  public static void main(String[] args) throws IOException {
    //    MongoClient readMongo1 = MongoClients.create("mongodb://oegrt:qweqwecz123dsfs12shawe@10.1.0
    //    .124:27018/orangeDB");
    MongoClient readMongo1 =
      MongoClients.create("mongodb://oegrt:qweqwecz123dsfs12shawe@10.1.0.110:27018/OperationDB?authSource=admin");
    //    MongoDatabase orangeiot = readMongo1.getDatabase("orangeiot");
    MongoDatabase paasDb110 = readMongo1.getDatabase("PaasDB");
    MongoCollection<Document> products110 = paasDb110.getCollection("products");

    MongoClient readMongo2 =
      MongoClients.create("mongodb://asdymsin:dzWB%238881@10.1.0.146:27017,10.1.0.147:27017,10.1.0.148:27017/admin");
    MongoDatabase paasDb = readMongo2.getDatabase("paasdb_dev");
    MongoCollection<Document> products146 = paasDb.getCollection("products");

    ObjectId minId = new ObjectId("624f93021990ca1a0d83c33a");
    while (true) {
      Document qry = new Document();
      if (minId != null) {
        qry.append("$gt", minId);
      }
      Document condition = new Document("_id", qry);
      List<Document> documents = new ArrayList<>(MAX_TRANSFER_COUNT);
      products110.find(condition).limit(MAX_TRANSFER_COUNT).sort(new Document("_id", 1)).forEach(documents::add);
      if (documents.isEmpty()) {
        break;
      }

      minId = getMaxId(documents);
      try {
        products146.insertMany(documents.stream().peek(document -> {
          document.put("appId", "saas_dev");
        }).collect(Collectors.toList()), new InsertManyOptions().bypassDocumentValidation(true).ordered(false));
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  private static ObjectId getMinId(List<Document> records) {
    if (records == null || records.size() == 0) {
      return null;
    }
    return records.get(0).getObjectId("_id");
  }

  private static ObjectId getMaxId(List<Document> records) {
    if (records == null || records.size() == 0) {
      return null;
    }
    return records.get(records.size() - 1).getObjectId("_id");
  }

  public List<String> createIncrementalTask(String uuid, ObjectId minId, ObjectId maxId) {
    List<String> createdIds = new ArrayList<>();
    while (true) {
      Document qry = new Document();
      if (minId != null) {
        qry.append("$gt", minId);
      }
      if (maxId != null) {
        qry.append("$lt", maxId);
      }
      Document condition = new Document("_id", qry);
      List<Document> documents = new ArrayList<>(MAX_TRANSFER_COUNT);
      readRecord
        // 查询_id小于queryId的
        .find(condition)
        .projection(new Document("_id", 1))
        .limit(MAX_TRANSFER_COUNT)
        .sort(new Document("_id", 1))
        .forEach(documents::add);
      if (documents.isEmpty()) {
        return createdIds;
      }

      minId = getMinId(documents);
      ObjectId curMaxId = getMaxId(documents);
      Document task = new Document("uuid", uuid)
        .append("minId", minId)
        .append("maxId", curMaxId)
        .append("count", documents.size())
        .append("status", 0);
      InsertOneResult insertOneResult = readRecordTransferTask.insertOne(task);
      BsonValue bsonValue = insertOneResult.getInsertedId();
      if (bsonValue == null) {
        continue;
      }
      minId = curMaxId;
      log.info("Insert into record_transfer_task, Document: {}", task.toJson());
      createdIds.add(bsonValue.asObjectId().getValue().toHexString());
    }
  }

  public void transfer(String uuid) {
    Map<String, WriteCount> writeCountMap = new ConcurrentHashMap<>();
    DATA_TRANSFER_STATUS_MAP.put(uuid, writeCountMap);
    Document document;
    while (true) {
      document = readRecordTransferTask.findOneAndUpdate(new Document("status", 0).append("uuid", uuid),
        new Document("$set", new Document("status", 1)));
      if (document == null) {
        break;
      }
      int count = document.getInteger("count", 0);
      if (count == 0) {
        break;
      }

      WriteCount writeCount = new WriteCount();
      String _id = document.getObjectId("_id").toHexString();
      writeCount.getTotal().set(count);
      writeCount.getWaiting().set(count);


      final Document readCountDoc = document;

      TransferThreadPool.execute(new RunFunc("DataTransfer_" + uuid + "_" + _id, () -> {
        try {
          transfer(readCountDoc, readRecord, writeRecord, writeCount);
          readRecordTransferTask.updateOne(new Document("_id", readCountDoc.getObjectId("_id")),
            new Document("$set", new Document("status", 2)),
            new UpdateOptions().upsert(false));
        } catch (Exception e) {
          log.error("RecordWrite ，数据回滚：{}. 异常描述为：{}", readCountDoc.toJson(), e.getMessage(), e);
          readRecordTransferTask.updateOne(new Document("_id", readCountDoc.getObjectId("_id")),
            new Document("$set", new Document("status", 4).append("error", e.getMessage())),
            new UpdateOptions().upsert(false));
        }
      }));
    }
  }

  private void transfer(Document readCountDoc, MongoCollection<Document> readRecord,
                        MongoCollection<Document> writeRecord, WriteCount wc) {
    long singleStartTime = DateUtils.millis();
    ObjectId minId = readCountDoc.getObjectId("minId");
    ObjectId maxId = readCountDoc.getObjectId("maxId");
    int count = readCountDoc.getInteger("count", 0);
    if (count == 0) {
      log.info("RecordWrite ，写入批数据：{}，无数据写入。", readCountDoc.toJson());
      return;
    }
    List<Document> records = new ArrayList<>(count);
    readRecord
      // 查询_id小于queryId的
      .find(new Document("_id", new Document("$gte", minId).append("$lte", maxId)))
      .limit(count)
      .sort(new Document("_id", 1))
      .forEach(records::add);
    writeRecord.insertMany(records, new InsertManyOptions().ordered(false));
    //.bypassDocumentValidation(true)
    wc.getWaiting().addAndGet(-records.size());
    wc.getSucceed().addAndGet(records.size());
    records.clear();
    long singleEndTime = DateUtils.millis();
    log.info("RecordWrite ，写入批数据：{}，单次处理时间：{} 毫秒 。", readCountDoc.toJson(), (singleEndTime - singleStartTime));
  }
}
