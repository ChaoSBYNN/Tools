package com.kaadas.transfer.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.kaadas.transfer.application.BindDeviceStatisticsCmd;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-07
 * @since 1.0.0
 */
@RestController
public class DeviceStatisticsController {
  @Resource
  BindDeviceStatisticsCmd cmd;

  @ApiOperation(value = "初始化绑定设备统计数据")
  @PostMapping("device/statistics")
  public JsonNode deviceStatistics(
    @ApiParam(value = "是否清空并重写数据") @RequestParam(defaultValue = "false") boolean override) {
    cmd.deviceStatistics(override);
    return SingleThreadPool.status();
  }
}
