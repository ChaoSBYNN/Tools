package com.kaadas.transfer.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.kaadas.transfer.infrastructure.threadpool.SingleThreadPool;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-07
 * @since 1.0.0
 */
@Api(tags = "拆表接口")
@RequestMapping("split")
@RestController
public class RecordSplitController {
  @ApiOperation(value = "按月拆表")
  @GetMapping()
  public JsonNode split(@ApiParam(value = "是否清空并重写数据") @RequestParam(defaultValue = "false") boolean override) {
    return SingleThreadPool.status();
  }
}
