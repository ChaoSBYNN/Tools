package com.kaadas.transfer.application;

import com.kaadas.transfer.infrastructure.DateUtils;
import com.kaadas.transfer.infrastructure.threadpool.MultiThreadPool;
import com.kaadas.transfer.infrastructure.threadpool.RunFunc;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.InsertManyOptions;
import com.mongodb.client.model.UpdateOptions;
import lombok.extern.log4j.Log4j2;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

import java.time.YearMonth;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-01-31
 * @since 1.0.0
 */
@Log4j2(topic = "Split")
@Component
public class RecordSplitCmd {

  MongoClient readMongo;
  MongoDatabase readDb;
  MongoCollection<Document> readCount;
  MongoCollection<Document> readRecord;

  public RecordSplitCmd(MongoClient readMongo) {
    this.readMongo = readMongo;
    this.readDb = readMongo.getDatabase("OperationDB");
    this.readCount = readDb.getCollection("record_count");
    this.readRecord = readDb.getCollection("kdsWifiOperationRecord");
  }

  public static void main(String[] args) {
    MongoClient readMongo = MongoClients.create("mongodb://kds_prod:5aYqgFMgcfYCksqpZcD45@10.1.0.146/kdsOpen");
    MongoDatabase readDb;
    MongoCollection<Document> readCount;
    MongoCollection<Document> readRecord;
    readDb = readMongo.getDatabase("OperationDB");
    readCount = readDb.getCollection("record_count_2");
    readRecord = readDb.getCollection("kdsWifiOperationRecord");
    Document first = readRecord.find().projection(new Document("_id", 1)).sort(new Document("_id", 1)).limit(1).first();
    System.out.println(first);
    Document last = readRecord.find().projection(new Document("_id", 1)).sort(new Document("_id", -1)).limit(1).first();
    System.out.println(last);
    if (first == null || last == null) {
      return;
    }
    ObjectId minId = first.getObjectId("_id");
    ObjectId maxId = last.getObjectId("_id");
    YearMonth minMonth = YearMonth.from(minId.getDate().toInstant().atZone(ZoneOffset.systemDefault()));
    YearMonth maxMonth = YearMonth.from(maxId.getDate().toInstant().atZone(ZoneOffset.systemDefault()));
    while (minMonth.isBefore(maxMonth)) {

      minMonth = minMonth.plusMonths(1L);
    }
  }

  public void splitMonthData() {
    Document first = readRecord.find().projection(new Document("_id", 1)).sort(new Document("_id", 1)).limit(1).first();
    Document last = readRecord.find().projection(new Document("_id", 1)).sort(new Document("_id", -1)).limit(1).first();
    if (first == null || last == null) {
      return;
    }
    ObjectId minId = first.getObjectId("_id");
    ObjectId maxId = last.getObjectId("_id");
    YearMonth minMonth = YearMonth.from(minId.getDate().toInstant().atZone(ZoneOffset.systemDefault()));
    YearMonth maxMonth = YearMonth.from(maxId.getDate().toInstant().atZone(ZoneOffset.systemDefault()));
    while (minMonth.isAfter(maxMonth)) {

      minMonth = minMonth.plusMonths(1L);
    }
  }
  //
  //  private void load(YearMonth yearMonth, boolean override) {
  //    String monthStr = DateUtils.PATTERN_YEAR_MONTH.format(yearMonth);
  //    AtomicLong total = new AtomicLong(0L);
  //    LocalDateTime startDateTime = DateUtils.getEndDayOfMonth(yearMonth.minusMonths(1L));
  //    LocalDateTime endDateTime = DateUtils.getEndDayOfMonth(yearMonth);
  //    log.info("RecordCount{} ，即将查询Record，时间段为：{} - {}",
  //      monthStr,
  //      DateUtils.format(startDateTime.plusSeconds(1L)),
  //      DateUtils.format(endDateTime));
  //    // 编号
  //    int num = 1;
  //    // 默认的最小ID和最大ID
  //    ObjectId minId = new ObjectId(DateUtils.toDate(startDateTime)), maxId = new ObjectId(DateUtils.toDate
  //    (endDateTime));
  //    Document latestDoc = readCount.find(new Document("month", monthStr)).sort(new Document("_id", -1)).limit(1)
  //    .first();
  //    if (latestDoc != null) {
  //      // 如果有最后一条数据，从最后一条数据中取出当前的minId 和 num
  //      minId = latestDoc.getObjectId("maxId");
  //      num = latestDoc.getInteger("num", 1);
  //      int count = latestDoc.getInteger("count", 0);
  //      if (count % 10000 != 0) {
  //        return;
  //      }
  //      List<Document> pipeline = new ArrayList<>();
  //      pipeline.add(new Document("$group",
  //        new Document("_id", "total").append("totalCount", new Document("$sum", "$count"))));
  //      recordCount.aggregate(pipeline).forEach(document -> {
  //        total.set(document.getInteger("totalCount"));
  //      });
  //    }
  //
  //    long startTime = DateUtils.millis();
  //    List<Document> records;
  //
  //    while (true) {
  //      long singleStartTime = DateUtils.millis();
  //      records = queryRecord(kdsWifiOperationRecord, minId, maxId);
  //      // 查不到数据了就结束
  //      if (records.size() == 0) {
  //        break;
  //      }
  //      ObjectId curMaxId = getMaxId(records);
  //      recordCount.insertOne(new Document("num", num)
  //        .append("minId", minId)
  //        .append("maxId", curMaxId)
  //        .append("count", records.size())
  //        .append("status", 0));
  //      total.addAndGet(records.size());
  //      minId = curMaxId;
  //
  //      long singleEndTime = DateUtils.millis();
  //      log.info("RecordCount{} ，为 {} 写入数据，当前页数：{} ，当前查询数：{} ，已写入总数：{} 。 单次处理耗时：{} 毫秒",
  //        suffix,
  //        recordCountTableName,
  //        num,
  //        records.size(),
  //        total.get(),
  //        (singleEndTime - singleStartTime));
  //      records.clear();
  //      num++;
  //    }
  //    long endTime = DateUtils.millis();
  //    log.info("RecordCount{} 集合 {} 创建已完成，共 {} 页，查询总数：{}，耗时：{} 毫秒。",
  //      suffix,
  //      recordCountTableName,
  //      num,
  //      total.get(),
  //      (endTime - startTime));
  //
  //    initStatus.updateOne(new Document("name", "RecordCount" + suffix),
  //      new Document("$set", new Document("total", total.get()).append("status", 1)));
  //  }

  private static void split(MongoClient mongoClient, YearMonth month) {
    String suffix = DateUtils.PATTERN_YEAR_MONTH.format(month);
    String recordTableName = "record_" + suffix;
    AtomicLong total = new AtomicLong(0L);
    MongoDatabase operationDB = mongoClient.getDatabase("OperationDB");
    MongoCollection<Document> recordCount = operationDB.getCollection("record_count_" + suffix);
    MongoCollection<Document> kdsWifiOperationRecord = operationDB.getCollection("kdsWifiOperationRecord");

    MongoCollection<Document> recordTable = operationDB.getCollection(recordTableName);
    //    boolean hasWifiSNAndTimeAndTypeIndex = false;
    //    MongoCursor<Document> indexCursor = recordTable.listIndexes().iterator();
    //    while (indexCursor.hasNext()) {
    //      Document document = indexCursor.next();
    //      if ("wifiSN_1_time_-1_type_1".equals(document.getString("name"))) {
    //        hasWifiSNAndTimeAndTypeIndex = true;
    //        break;
    //      }
    //    }
    //    indexCursor.close();
    //    if (!hasWifiSNAndTimeAndTypeIndex) {
    //      Document indexDoc = new Document("wifiSN", 1).append("time", -1).append("type", 1);
    //      log.info("RecordSplit{} ，为集合 {} 创建索引：{}", suffix, recordTableName, indexDoc.toJson());
    //      recordTable.createIndex(indexDoc, new IndexOptions().unique(true).background(true));
    //    }
    List<Document> records;
    long startTime = DateUtils.millis();
    while (true) {
      long singleStartTime = DateUtils.millis();
      Document document =
        recordCount.findOneAndUpdate(new Document("status", 0), new Document("$set", new Document("status", 1)));
      if (document == null) {
        break;
      }
      try {
        ObjectId minId = document.getObjectId("minId");
        ObjectId maxId = document.getObjectId("maxId");
        int count = document.getInteger("count", 0);
        if (count == 0) {
          break;
        }
        records = new ArrayList<>(count);
        kdsWifiOperationRecord
          // 查询_id小于queryId的
          .find(new Document("_id", new Document("$gt", minId).append("$lte", maxId)))
          .limit(count)
          .sort(new Document("_id", 1))
          .forEach(records::add);
        recordTable.insertMany(records, new InsertManyOptions().ordered(false));
        total.addAndGet(records.size());
        records.clear();
        recordCount.updateOne(new Document("_id", document.getObjectId("_id")),
          new Document("$set", new Document("status", 2)),
          new UpdateOptions().upsert(false));
        long singleEndTime = DateUtils.millis();
        log.info("RecordSplit{} ，向集合 {} 写入批数据：{}，单次处理时间：{} 毫秒，已写入数量：{}",
          suffix,
          recordTableName,
          document.toJson(),
          (singleEndTime - singleStartTime),
          total.get());
      } catch (Exception e) {
        log.error("RecordSplit{} ，集合 {} 数据回滚：{}. 异常描述为：{}",
          suffix,
          recordTableName,
          document.toJson(),
          e.getMessage(),
          e);
        recordCount.updateOne(new Document("_id", document.getObjectId("_id")),
          new Document("$set", new Document("status", 0).append("error", e.getMessage())),
          new UpdateOptions().upsert(false));
      }
    }
    long endTime = DateUtils.millis();
    log.info("RecordSplit{} ，全部写入已完成，写入总数：{}，耗时：{} 毫秒。", suffix, total.get(), (endTime - startTime));
  }

  public void split(YearMonth month) {
    String monthStr = DateUtils.PATTERN_YEAR_MONTH.format(month);
    MultiThreadPool.execute(new RunFunc("RecordSplit" + monthStr, () -> {
      log.info("RecordSplit{} ，开始处理。", monthStr);
      split(readMongo, month);
      log.info("RecordSplit{} ，处理结束。", monthStr);
    }));
  }

  public void clearFailed(YearMonth month) {
    String monthStr = DateUtils.PATTERN_YEAR_MONTH.format(month);
    MultiThreadPool.execute(new RunFunc("RecordSplit" + monthStr, () -> {
      log.info("RecordSplit{} ，开始清理。", monthStr);
      String suffix = DateUtils.PATTERN_YEAR_MONTH.format(month);
      MongoDatabase operationDB = readMongo.getDatabase("OperationDB");
      MongoCollection<Document> recordCount = operationDB.getCollection("record_count_" + suffix);
      MongoCollection<Document> record = operationDB.getCollection("record_" + suffix);
      recordCount.updateMany(new Document("status", 1), new Document("$set", new Document("status", 0)));
      record.drop();
      log.info("RecordSplit{} ，清理结束。", monthStr);
    }));
  }

  public void clear(YearMonth month) {
    String monthStr = DateUtils.PATTERN_YEAR_MONTH.format(month);
    MultiThreadPool.execute(new RunFunc("RecordSplit" + monthStr, () -> {
      log.info("RecordSplit{} ，开始清理。", monthStr);
      String suffix = DateUtils.PATTERN_YEAR_MONTH.format(month);
      MongoDatabase operationDB = readMongo.getDatabase("OperationDB");
      MongoCollection<Document> recordCount = operationDB.getCollection("record_count_" + suffix);
      MongoCollection<Document> record = operationDB.getCollection("record_" + suffix);
      recordCount.updateMany(new Document(), new Document("$set", new Document("status", 0)));
      record.drop();
      log.info("RecordSplit{} ，清理结束。", monthStr);
    }));
  }
}