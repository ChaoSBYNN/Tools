package com.kaadas.transfer.infrastructure.threadpool;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.util.JsonUtils;

import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-06
 * @since 1.0.0
 */
public class TransferThreadPool {
  private static final ThreadPoolExecutor THREAD_POOL_EXECUTOR =
    new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(Integer.MAX_VALUE));

  public static void setPoolSize(int corePoolSize) {
    THREAD_POOL_EXECUTOR.setCorePoolSize(corePoolSize);
  }

  public static void execute(Runnable runnable) {
    THREAD_POOL_EXECUTOR.execute(new RunFunc(UUID.randomUUID().toString(), runnable, "No task description."));
  }

  public static void execute(RunFunc runFunc) {
    THREAD_POOL_EXECUTOR.execute(runFunc);
  }

  public static JsonNode status() {
    ObjectNode objectNode = JsonUtils.getObjectMapper().createObjectNode();
    objectNode.put("tasks", THREAD_POOL_EXECUTOR.getTaskCount());
    objectNode.put("completed", THREAD_POOL_EXECUTOR.getCompletedTaskCount());
    objectNode.put("active", THREAD_POOL_EXECUTOR.getActiveCount());
    objectNode.put("poolSize", THREAD_POOL_EXECUTOR.getPoolSize());

    ArrayNode waiting = JsonUtils.getObjectMapper().createArrayNode();
    THREAD_POOL_EXECUTOR.getQueue().forEach(runnable -> {
      RunFunc runFunc = (RunFunc) runnable;
      waiting.add(runFunc.getId());
    });
    objectNode.set("waiting", waiting);
    return objectNode;
  }
}
