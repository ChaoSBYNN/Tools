package com.kaadas.transfer.application.qry;

import lombok.Getter;

import java.util.concurrent.atomic.AtomicLong;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-02
 * @since 1.0.0
 */
@Getter
public class WriteCount {
  AtomicLong waiting = new AtomicLong(0);
  AtomicLong succeed = new AtomicLong(0);
  AtomicLong total = new AtomicLong(0);
}
