package com.kaadas.example;

import com.kaadas.util.JsonUtils;
import com.kaadas.util.http.HttpOperations;
import okhttp3.*;

import javax.net.ssl.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-11-23
 * @since 1.0.0
 */
public class ApnsExample {
  public static void main(String[] args)
    throws KeyStoreException, NoSuchAlgorithmException, IOException, CertificateException, UnrecoverableKeyException,
    KeyManagementException, InterruptedException {
    String token = "610bd161acd4d12b78b6390e301093d815696e1df05e47be44bc75c69e4314b2";
    char[] pwd = "123456".toCharArray();
    String filepath = "kaadas_push.p12";
    File file =  new File(ApnsExample.class.getResource("/").getFile(), filepath);
    X509TrustManager x509TrustManager = x509TrustManager();
    OkHttpClient apnsClient = new OkHttpClient.Builder()
      .connectionPool(new ConnectionPool())
      .sslSocketFactory(sslSocketFactory(keyManagers(file, pwd), x509TrustManager), x509TrustManager)
      .connectTimeout(Duration.of(30, ChronoUnit.SECONDS))
      .callTimeout(Duration.of(10, ChronoUnit.SECONDS))
      .build();

    ApnsPushBody.Aps aps = new ApnsPushBody.Aps();
    aps.setSound("default");
    aps.setAlert(new ApnsPushBody.Alert("test", "test"));
    String serialize = JsonUtils.serialize(new ApnsPushBody(aps, ""));

    for(int i =0;i<10;i++){
      Request request = new Request.Builder()
        .url("https://api.push.apple.com/3/device/" + token)
        .post(RequestBody.create(HttpOperations.APPLICATION_JSON, serialize))
        .addHeader("apns-id", UUID.randomUUID().toString())
        .header("apns-topic", "com.kaidishi.lock")
        .header("Content-length", String.valueOf(serialize.getBytes().length))
        .build();

      try {
        Response response = apnsClient.newCall(request).execute();
        String responseBody = "";
        if (response.body() != null) {
          responseBody = new String(response.body().bytes());
        }
        System.out.printf(
          "APNS Push body -> %s; response.status -> %d, response.body -> %s, response.header.apns-id " + "-> %s",
          serialize,
          response.code(),
          responseBody,
          response.header("apns-id"));
        System.out.println();

      } catch (Exception e) {
        e.printStackTrace();
      }
      Thread.sleep(40000L);
    }
  }

  public static KeyManager[] keyManagers(File file, char[] pwd)
    throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException {
    KeyStore keyStore = KeyStore.getInstance("PKCS12");
    FileInputStream fileInputStream = new FileInputStream(file);
    keyStore.load(fileInputStream, pwd);
    KeyManagerFactory trustManager = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
    trustManager.init(keyStore, pwd);
    return trustManager.getKeyManagers();
  }

  public static SSLSocketFactory sslSocketFactory(KeyManager[] km, X509TrustManager x509TrustManager)
    throws NoSuchAlgorithmException, KeyManagementException {
    // 信任任何链接
    SSLContext sslContext = SSLContext.getInstance("TLS");
    sslContext.init(km, new X509TrustManager[]{x509TrustManager}, new SecureRandom());
    return sslContext.getSocketFactory();
  }

  public static X509TrustManager x509TrustManager() {
    return new X509TrustManager() {
      @Override
      public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
      }

      @Override
      public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
      }

      @Override
      public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
      }
    };
  }
}
