package com.kaadas.example;

import lombok.Data;
import org.jetbrains.annotations.NotNull;

/**
 * @author PYF
 * @className ApnsPushBody
 * @description
 * @date 2022/10/31
 */
@Data
public class ApnsPushBody {

  public ApnsPushBody(@NotNull Aps aps, @NotNull Object extras) {
    this.aps = aps;
    this.extras = extras;
  }

  private Aps aps;
  private Object extras;

  @Data
  public static class Aps {
    private Alert alert;
    private String sound;
  }

  @Data
  public static class Alert {
    /**
     * 通知栏消息的标题。
     */
    private String title;
    /**
     * 通知栏消息的内容。
     */
    private String body;
    /**
     * 用户自定义的通知栏消息右侧小图片URL，如果不设置，则不展示通知栏右侧图片。URL使用的协议必须是HTTPS协议，取值样例：https://example.com/image.png。
     * <p>
     * 说明
     * 图片文件须小于512KB，规格建议为40dp x 40dp，弧角大小为8dp。超出建议规格的图片会存在图片压缩或图片显示不全的情况。图片格式无限制。
     */
    private String image;

    public Alert(String title, String body) {
      this.title = title;
      this.body = body;
    }
  }

}
