package com.kaadas.test;

import com.kaadas.Main;
import com.kaadas.service.CacheBean;
import com.kaadas.service.CacheService;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-09-21
 * @since 1.0.0
 */
@Log4j2
@Configuration
@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = Main.class)
class CacheTest {
  @Resource
  CacheService cacheService;

  @Test
  void test() {
    String key = "123";
    Object value = "New";
    CacheBean cacheBean = cacheService.get(key);
    if (cacheBean == null) {
      cacheBean = cacheService.get(key);
    }
    if (cacheBean == null) {
      cacheBean = new CacheBean(key, value);
    }
    cacheBean = cacheService.createNew(cacheBean);
    cacheBean = cacheService.get(key);
    cacheBean.setValue("Update");
    cacheBean = cacheService.update(cacheBean);
    cacheBean = cacheService.get(key);
    cacheService.remove(key);
    cacheBean = cacheService.get(key);
    assert cacheBean == null;
  }
}
