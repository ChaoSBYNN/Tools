package com.kaadas.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-09-21
 * @since 1.0.0
 */
@Log4j2
@Service
@CacheConfig(cacheNames = "test:cache:")
public class CacheService {
  Map<String, CacheBean> db = new HashMap<>();

  @CachePut(key = "#cacheBean.key")
  public CacheBean createNew(CacheBean cacheBean) {
    db.put(cacheBean.key, cacheBean);
    log.info("Do createNew key={}, value={}", cacheBean.getKey(), cacheBean);
    return cacheBean;
  }

  @CacheEvict(key = "#key")
  public void remove(String key) {
    log.info("Do remove key={}, value={}", key, db.remove(key));
  }

  @Cacheable(key = "#key")
  public CacheBean get(String key) {
    CacheBean cacheBean = db.get(key);
    log.info("Do get key={}, value={}", key, cacheBean);
    return cacheBean;
  }

  @CachePut(key = "#cacheBean.key")
  public CacheBean update(CacheBean cacheBean) {
    db.put(cacheBean.key, cacheBean);
    log.info("Do update key={}, value={}", cacheBean.getKey(), cacheBean);
    return cacheBean;
  }
}
