package com.kaadas;


import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-09-21
 * @since 1.0.0
 */
@EnableCaching
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class Main {
  public static void main(String[] args) {
    SpringApplication.run(Main.class, args);
  }
}