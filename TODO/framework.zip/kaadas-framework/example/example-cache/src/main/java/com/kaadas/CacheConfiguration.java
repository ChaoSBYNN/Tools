package com.kaadas;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-09-21
 * @since 1.0.0
 */
@Configuration
public class CacheConfiguration {
  @Bean
  public CacheManager cacheManager() {
    CaffeineCacheManager cacheManager = new CaffeineCacheManager();
    cacheManager.setCaffeine(Caffeine
      .newBuilder()
      .expireAfterAccess(10, TimeUnit.MINUTES)
      .initialCapacity(100)
      .maximumSize(300_000));
    return cacheManager;
  }
}
