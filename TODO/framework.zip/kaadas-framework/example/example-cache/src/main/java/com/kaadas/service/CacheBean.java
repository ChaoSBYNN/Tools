package com.kaadas.service;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-09-21
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CacheBean {
  String key;
  Object value;

  @Override
  public String toString() {
    return "CacheBean{" + "key='" + key + '\'' + ", value=" + value + '}';
  }
}
