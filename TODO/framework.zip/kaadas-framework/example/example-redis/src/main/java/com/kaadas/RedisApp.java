package com.kaadas;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.ScanOptions;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-08
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication
public class RedisApp implements CommandLineRunner {
  @Resource
  RedisConnectionFactory redisConnectionFactory;

  public static void main(String[] args) {
    SpringApplication.run(RedisApp.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    List<byte[]> keys = new ArrayList<>();

    RedisConnection conn = redisConnectionFactory.getConnection();
    Cursor<byte[]> cursor = conn.scan(ScanOptions.scanOptions()
      .match("kdsMqttMessage:wf:*")
      .count(5000L)
      .build());
    while (cursor.hasNext()) {
      keys.add(cursor.next());
    }
    log.info("{}", keys.size());
    log.info("{}", keys.stream().map(String::new).collect(Collectors.toList()));
    keys.forEach(key -> {
      byte[] field0 = "0".getBytes(StandardCharsets.UTF_8);
      byte[] field1 = "1".getBytes(StandardCharsets.UTF_8);
      String value0 = "", value1 = "";
      byte[] value = conn.hGet(key, field0);
      if (value == null) {
        return;
      }
      try {
        Thread.sleep(10);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      value0 = new String(value);
      Boolean b = conn.hExists(key, field1);
      if (Boolean.TRUE.equals(b)) {
        conn.hDel(key, field0);
        log.info("Delete: {}-{}", new String(key), value0);
        return;
      }
      try {
        Thread.sleep(10);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      value0 = value0.replace("\"messageId\":0", "\"messageId\":1").replace("\\\"msgId\\\":0", "\\\"msgId\\\":1");
      conn.hSet(key, field1, value0.getBytes(StandardCharsets.UTF_8));
      conn.hDel(key, field0);
      log.info("Update: {}-{}", new String(key), value0);
    });
    conn.close();
  }
}
