package com.kaadas.function;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-09
 * @since 1.0.0
 */
public interface DeviceFunction {
}
