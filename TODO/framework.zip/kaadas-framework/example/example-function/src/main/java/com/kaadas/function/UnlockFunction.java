package com.kaadas.function;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-09
 * @since 1.0.0
 */
public class UnlockFunction {
  public static void main(String[] args) {
    DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSz");

    System.out.println(pattern.parse("2022-11-04T14:50:12.001+08:00"));
    System.out.println(LocalDateTime.parse("2022-11-04T14:50:12.001+08:00", pattern));
    System.out.println(ZonedDateTime.parse("2022-11-04T14:50:12.001+08:00", pattern));
  }
}
