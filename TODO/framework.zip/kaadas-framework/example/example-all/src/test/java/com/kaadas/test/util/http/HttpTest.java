package com.kaadas.test.util.http;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;
import com.kaadas.ServiceException;
import com.kaadas.util.http.HttpUtils;
import lombok.experimental.FieldNameConstants;
import okhttp3.Response;
import okhttp3.ResponseBody;

import java.io.IOException;
import java.util.List;

/**
 * D210221310008
 *
 * @author ZhangDuanFeng
 * @date 2022-04-06
 * @since 1.0.0
 */
public class HttpTest {
  public static void main(String[] args) throws IOException {
//    new HttpTest().asyncGetTest();
//    new HttpTest().syncGetTest();
//    new HttpTest().jsonGetTest();
  }

  public void asyncGetTest() {
    HttpUtils.async().get("https://www.zhihu.com/api/v3/oauth/sms/supported_countries")
      .thenAcceptAsync(response -> {
        ResponseBody body = response.body();
        // TODO 成功
      })
      .exceptionally(e -> {
        // TODO 异常
        return null;
      });
  }

  public void syncGetTest() throws IOException {
    try {
      Response response = HttpUtils.sync().get("https://www.zhihu.com/api/v3/oauth/sms/supported_countries");
      ResponseBody body = response.body();
      // TODO 成功
    } catch (ServiceException e) {
      // TODO 异常
      e.getCause();
    }
  }

  public void jsonGetTest() throws IOException {
    JsonBody jsonBody = HttpUtils.json().get("https://www.zhihu.com/api/v3/oauth/sms/supported_countries",
      new TypeReference<JsonBody>() {});
  }

  @lombok.Data
  @FieldNameConstants
  public static class JsonBody {
    private int count;
    private List<Data> data;
  }

  @lombok.Data
  public static class Data {
    @JsonProperty("is_host")
    private boolean host;
    private String code;
    private String name;
    private String abbr;
  }
}
