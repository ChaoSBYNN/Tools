package com.kaadas.test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.http.HttpOperations;
import com.kaadas.util.http.HttpUtils;
import com.kaadas.util.http.JsonHttpClient;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import org.apache.commons.codec.digest.DigestUtils;

import java.time.Clock;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-12-15
 * @since 1.0.0
 */
public class WenXinTest {
  public static void main(String[] args) {
    String url = "https://duer-kids.baidu.com/sandbox/botwatch/api/operation/faq";
    String ak = "Kaadas";
    String sk = "n0e987bbiaef2jnoseg";
    Scanner scanner = new Scanner(System.in);
    JsonHttpClient JSON = new JsonHttpClient(new OkHttpClient.Builder()
      .connectionPool(HttpOperations.DEFAULT_CONNECTION_POOL)
      .connectTimeout(Duration.of(600, ChronoUnit.SECONDS))
      .callTimeout(Duration.of(600, ChronoUnit.SECONDS))
      .build());
    while (true) {
      System.out.print("提问：");
      String question = scanner.nextLine();
      if (question.equalsIgnoreCase("exit")) {
        break;
      }
      System.out.println();
      long timestamp = Clock.systemUTC().millis() / 1000;
      String sign = DigestUtils.md5Hex(ak + sk + timestamp) + ":" + timestamp;
      Headers headers =
        Headers.of("Content-Type", "application/json", "Client-Id", ak, "Device-Id", "KaadasTest", "Sign", sign);
      ObjectNode objectNode = JsonUtils.getObjectMapper().createObjectNode();
      objectNode.put("query", question);
      try {
        JsonNode jsonNode = HttpUtils.json().post(url, objectNode, headers, JsonNode.class);
        int status = jsonNode.get("status").intValue();
        if (status == 0) {
          int noAnswer = jsonNode.at("/data/no_answer").asInt(1);
          if (noAnswer == 1) {
            System.out.println("无答案");
            continue;
          }
          System.out.println(jsonNode.at("/data/answer").asText());
        } else {
          System.err.println("服务异常：\n" + jsonNode.toPrettyString());
        }
      } catch (Exception e) {
        System.err.println("已超时5分钟，重新提问");
      }

      System.out.println();
      System.out.println();
    }
  }
}
