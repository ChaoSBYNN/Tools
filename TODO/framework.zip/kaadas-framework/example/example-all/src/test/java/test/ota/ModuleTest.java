package test.ota;

import com.kaadas.example.ExampleApplication;
import com.kaadas.example.ota.domain.Module;
import com.kaadas.example.ota.domain.repository.ModuleRepository;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ExampleApplication.class)
public class ModuleTest {
  @Resource
//  private ModuleMapper moduleMapper;
  private ModuleRepository repository;
  @Test
  @Order(1)
  public void testSave() {
    Module module = new Module();
    module.setNum(2);
    module.setName("WIFI2");
    module.setType("WIFI2");
    repository.save(module);

//    moduleMapper.insert(module);
  }
}
