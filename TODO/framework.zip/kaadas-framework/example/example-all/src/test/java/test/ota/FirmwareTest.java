package test.ota;

import com.kaadas.example.ExampleApplication;
import com.kaadas.example.ota.domain.Firmware;
import com.kaadas.example.ota.infrastructure.mapper.FirmwareMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;

@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ExampleApplication.class)
public class FirmwareTest {
  @Resource
  private FirmwareMapper mapper;

  @Test
  @Order(1)
  public void testSave() {
    Firmware firmware = new Firmware();

    firmware.setModule("2");
    firmware.setDescription("hao");
    mapper.insert(firmware);
  }
}
