package test.ota;

import com.kaadas.example.ExampleApplication;
import com.kaadas.example.ota.domain.OtaTask;
import com.kaadas.example.ota.domain.repository.OtaTaskRepository;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;

@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ExampleApplication.class)
public class OtaTaskTest {
  @Resource
  private OtaTaskRepository otaTaskRepository;

  @Test
  @Order(1)
  public void testSave() {
    OtaTask otaTask = new OtaTask();
    otaTask.setSn("123456");
    otaTask.setTime(System.currentTimeMillis() + "");
    otaTaskRepository.save(otaTask);
//    moduleMapper.insert(module);
  }
}
