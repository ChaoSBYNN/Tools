package test.function;

import com.kaadas.example.ExampleApplication;
import com.kaadas.example.function.domain.FunctionSet;
import com.kaadas.example.function.domain.repository.FunctionRepositoryImpl;
import com.kaadas.example.function.domain.repository.FunctionSetRepository;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ExampleApplication.class)
public class FunctionSetTest {
  @Resource
  FunctionSetRepository repository;
  @Resource
  FunctionRepositoryImpl functionRepositoryImpl;

  @Test
  @Order(1)
  public void testDel() {
  }

  @Test
  @Order(2)
  public void testSave() {
    FunctionSet functionSet = new FunctionSet();
    functionSet.setIdentifier(0);
    functionSet.setName("老锁精简版功能");
    functionSet.setRemark("1，2，3，10只支持开锁，获取开锁记录，获取电量和设备共享");
    functionRepositoryImpl.findByIdentifierIn(1, 2, 3, 10).forEach(functionSet::addFunction);
    repository.save(functionSet);
    assert Objects.nonNull(functionSet.getId());
  }

  @Test
  @Order(3)
  public void testFind() {
    List<FunctionSet> functions = repository.findAll();
    assert functions.size() > 0;
  }
}
