package test.function;

import com.fasterxml.jackson.core.type.TypeReference;
import com.kaadas.example.ExampleApplication;
import com.kaadas.example.function.domain.Function;
import com.kaadas.example.function.domain.repository.FunctionRepository;
import com.kaadas.example.function.domain.repository.FunctionRepositoryImpl;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Log4j2
@Profile("dev")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ExampleApplication.class)
public class FunctionTest {

  @Resource
  FunctionRepositoryImpl functionRepositoryImpl;

  @Resource
  FunctionRepository functionRepository;


  @Test
  @Order(1)
  public void testDel() {
//    repository.findByIdentifier(1)
//      .ifPresent(func -> repository.delete(func));
  }

  @Test
  @Order(2)
  public void testSave() throws IOException {
    org.springframework.core.io.Resource functionsResource = new ClassPathResource("functions.json");
    List<Function> functions = JsonUtils.getObjectMapper().readValue(functionsResource.getInputStream(),
      new TypeReference<List<Function>>() {});
    assert functions.size() > 0;
    functions.forEach(function -> {
      functionRepositoryImpl.findByIdentifier(function.getIdentifier())
        .ifPresent(func -> {
          function.setId(func.getId());
        });
    });
    functionRepositoryImpl.saveAll(functions);
  }

  @Test
  @Order(3)
  public void testFind() {
    List<Function> functions = functionRepository.findAll();
    assert functions.size() > 0;
  }
}
