package com.kaadas.example.protocol.infrastructure.rocketmq;

import org.apache.rocketmq.client.exception.MQClientException;
import org.springframework.context.annotation.Configuration;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */

@Configuration
public class RocketMQConfiguration {


  public void inti() throws MQClientException {

  }
}
