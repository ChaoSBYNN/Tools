package com.kaadas.example.function.api;

import com.kaadas.web.model.PageQry;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
public class FunctionQuery extends PageQry {
}
