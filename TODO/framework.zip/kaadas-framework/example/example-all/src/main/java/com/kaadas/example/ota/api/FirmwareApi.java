package com.kaadas.example.ota.api;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Api(tags = "固件管理")
@RequestMapping("ota/firmware")
public interface FirmwareApi {
  @GetMapping
  @ApiOperation(value = "获取模组列表")
  List<ModuleVO> modules();

  @PutMapping("{filename}")
  @ApiOperation(value = "put上传文件")
  String upload(@PathVariable(value = "filename") String filename, HttpServletRequest request);

  @PostMapping
  @ApiOperation(value = "添加固件")
  void add(@RequestBody FirmwareQry qry);

  @Data
  @ApiModel("模组信息")
  class ModuleVO{
    @ApiModelProperty(notes = "模组编号")
    private String code;
    @ApiModelProperty(notes = "模组名称")
    private String name;
  }

  @Data
  @ApiModel("模组信息")
  class FirmwareQry {
    @ApiModelProperty(notes = "文件ID", required = true)
    private String file;
    @ApiModelProperty(notes = "模组编号", required = true)
    private String module;
    @ApiModelProperty(notes = "版本号", required = true)
    private String version;
    @ApiModelProperty(notes = "版本描述", required = true)
    private String description;
    @ApiModelProperty(notes = "PID集合", required = true)
    private List<String> pid;
    @ApiModelProperty(notes = "客户ID", required = true)
    private String customer;
  }
}