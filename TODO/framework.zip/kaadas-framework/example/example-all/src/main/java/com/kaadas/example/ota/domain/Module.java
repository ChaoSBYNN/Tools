package com.kaadas.example.ota.domain;

import com.kaadas.mybatis.MybatisEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Getter
@Setter
@RedisHash("kaadas:module")
//@TableName("ota_module")
public class Module extends MybatisEntity {
  private String name;
  @Indexed
  private Integer num;
  private String type;

}
