package com.kaadas.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.bson.Document;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.UUID;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class ExampleApplication {
  public static void main2(String[] args) {
    SpringApplication.run(ExampleApplication.class, args);
    log.info("Example starting");
  }

  public static void main(String[] args) {

    Criteria criteria = Criteria.where("pid").is("K2A").andOperator(Criteria.where("version").is("SEV3X_3_V1.12.011"));
    System.out.println(criteria.getCriteriaObject());

    System.out.println(UUID.randomUUID().toString());

    JsonNode jsonNode = JsonUtils.toJsonNode("{" + "  \"pid\": {\"$in\": [\"K2A\", \"K2B\"]}" + "}");
    System.out.println(jsonNode);


    System.out.println(Document.parse("{" + "  \"pid\": {\"$in\": [\"K2A\", \"K2B\"]}" + "}"));
  }
}
