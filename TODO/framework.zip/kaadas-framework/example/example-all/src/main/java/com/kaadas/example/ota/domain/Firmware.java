package com.kaadas.example.ota.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.kaadas.mybatis.MybatisEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Getter
@Setter
@TableName("ota_firmware")
public class Firmware extends MybatisEntity {
  private String module;
  private String version;
  private String description;
  private List<String> pid;
  private String customer;
  private String fileUrl;
  private String fileMd5;
  private String fileLength;
  private String testReportName;
  private String testReportUrl;
//  private File file;
//  private TestReport testReport;

  @Getter
  @Setter
  @Deprecated
  public static class File {
    private String url;
    private String md5;
    private String length;
  }

  @Getter
  @Setter
  @Deprecated
  public static class TestReport {
    private String name;
    private String url;
  }
}
