package com.kaadas.example.function.domain.repository;

import com.kaadas.example.function.domain.FunctionHistory;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
public interface FunctionHistoryRepository extends MongoRepository<FunctionHistory, String> {
  Optional<FunctionHistory> findByIdAndVersionLike(String id, String version);
}
