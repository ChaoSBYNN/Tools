package com.kaadas.example.ota.domain;

import com.kaadas.mybatis.MybatisEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

@Getter
@Setter
@RedisHash("kaadas:ota")
public class OtaTask extends MybatisEntity {
  @Indexed
  private String sn;
  private String time;
}
