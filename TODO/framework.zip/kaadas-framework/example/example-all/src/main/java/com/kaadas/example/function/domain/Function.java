package com.kaadas.example.function.domain;

import com.kaadas.mongo.MongoEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Getter
@Setter
@Document("function")
public class Function extends MongoEntity {
  /** 功能编号 */
  @Indexed(unique = true, name = "uk_identifier")
  private int identifier;
  /** 功能编码 */
  private String code;
  /** 功能名称 */
  private String name;
  /** 功能类型 */
  private FunctionType type;
  /** 功能说明 */
  private String remark;
}
