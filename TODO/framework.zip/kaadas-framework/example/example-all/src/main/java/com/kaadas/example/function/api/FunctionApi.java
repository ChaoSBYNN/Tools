package com.kaadas.example.function.api;

import com.kaadas.example.function.domain.Function;
import com.kaadas.example.function.domain.repository.FunctionRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@Log4j2
@RestController
public class FunctionApi {

  @Resource
  private FunctionRepository repository;

  @GetMapping
  public Page<Function> page(@RequestBody FunctionQuery qry) {
    qry.getPage().getSorts().forEach(sort -> {
      System.out.println(sort);
    });

    return repository.findAll(qry.getPage().toPageable(Pageable.class));
  }
}
