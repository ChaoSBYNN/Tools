package com.kaadas.example.ota.api;

import com.kaadas.web.version.ApiVersion;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Log4j2
@ApiVersion
@RestController
public class FirmwareControllerV1 implements FirmwareApi {
  @Override
  public List<ModuleVO> modules() {
    log.debug("debug");
    log.info("info");
    log.warn("warn");
    log.error("error");
    return null;
  }

  @Override
  public String upload(String filename, HttpServletRequest request) {
    return null;
  }

  @Override
  public void add(FirmwareQry qry) {

  }
}
