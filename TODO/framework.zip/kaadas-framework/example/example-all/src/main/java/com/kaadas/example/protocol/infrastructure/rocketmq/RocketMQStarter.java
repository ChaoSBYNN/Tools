package com.kaadas.example.protocol.infrastructure.rocketmq;

import com.kaadas.util.CollectionUtils;
import com.kaadas.util.StringUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.MQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Log4j2
//@Component
@ConditionalOnClass(MQPushConsumer.class)
@EnableConfigurationProperties(RocketMQConsumerConfig.class)
@ConditionalOnProperty(value = "rocketmq.consumer.enabled", havingValue = "true")
public class RocketMQStarter implements CommandLineRunner {

  private RocketMQConsumerConfig config;

  public RocketMQStarter(RocketMQConsumerConfig config) {
    this.config = config;
  }


  @Override
  public void run(String... args) throws Exception {
    // 实例化消费者
    DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(config.getGroup());
    // 设置NameServer的地址
    consumer.setNamesrvAddr(config.getNamesrvAddr());
    List<RocketMQConsumerConfig.Subscribe> subscribes = config.getSubscribes();
    if (CollectionUtils.isEmpty(subscribes)) {
      log.warn("RocketMQ subscribes not found");
      return;
    }

    for (RocketMQConsumerConfig.Subscribe subscribe : subscribes) {
      String subExpression = subscribe.getSubExpression(); ;
      if (StringUtils.isBlank(subExpression)) {
        subExpression = "*";
      }
      consumer.subscribe(subscribe.getTopic(), subExpression);
    }

    consumer.registerMessageListener((MessageListenerConcurrently) (msgs, context) -> {
      msgs.forEach(messageExt ->{}
//        mqHandlers.handle(messageExt.getTopic(), Buffer.buffer(messageExt.getBody()).toJsonObject())
      );
      // 标记该消息已经被成功消费
      return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
    });

    // 启动消费者实例
    consumer.start();
  }
}
