package com.kaadas.example.product.domain;

import com.kaadas.example.function.domain.FunctionSetId;
import com.kaadas.model.BaseEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Getter
@Setter
@Document("product")
public class Product extends BaseEntity<String> {
  private String pid;
  private String type;
  private String devType;
  private FunctionSetId functionSet;
}