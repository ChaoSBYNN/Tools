package com.kaadas.example.function.domain;

import com.kaadas.mongo.MongoEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Getter
@Setter
@Document("function_set")
public class FunctionSet extends MongoEntity {
  /** 功能集编号 */
  @Indexed(unique = true, name = "uk_identifier")
  private int identifier;
  /** 功能集名称 */
  private String name;
  /** 功能集说明 */
  private String remark;
  /** 功能ID集合 */
  private List<FunctionId> functions = new ArrayList<>(0);

  public void addFunction(Function function) {
    functions.add(new FunctionId(function.getIdentifier(), function.getCode(), function.getType()));
  }

  public void addFunction(FunctionId functionId) {
    functions.add(functionId);
  }
}
