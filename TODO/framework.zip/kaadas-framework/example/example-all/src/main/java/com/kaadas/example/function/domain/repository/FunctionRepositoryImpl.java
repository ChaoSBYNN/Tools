package com.kaadas.example.function.domain.repository;

import com.kaadas.example.function.domain.Function;
import com.kaadas.mongo.MongoEntityInformationCreator;
import com.kaadas.mongo.MongoOperationRepositoryImpl;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Repository
public class FunctionRepositoryImpl extends MongoOperationRepositoryImpl<Function> {
  public FunctionRepositoryImpl(MongoEntityInformationCreator mongoEntityInformationCreator) {
    super(mongoEntityInformationCreator);
  }

  public Optional<Function> findByIdentifier(int identifier) {
    return findOne(Query.query(Criteria.where("identifier").is(identifier)));
  }

  public List<Function> findByIdentifierIn(int... identifier) {
    return find(Query.query(Criteria.where("identifier").in(identifier)));
  }
}
