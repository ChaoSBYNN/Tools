package com.kaadas.example.function;
/**
 * MongoDB Demo
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */