package com.kaadas.example.ota.domain.factory;

import com.kaadas.example.ota.domain.repository.FirmwareRepository;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Component
public class FirmwareFactory {
  FirmwareRepository repository;

  public FirmwareFactory(FirmwareRepository repository) {
    this.repository = repository;
  }
}
