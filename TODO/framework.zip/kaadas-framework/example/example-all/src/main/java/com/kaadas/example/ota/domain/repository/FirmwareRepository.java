package com.kaadas.example.ota.domain.repository;

import com.kaadas.example.ota.infrastructure.mapper.FirmwareMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Repository
public class FirmwareRepository {
  @Resource
  FirmwareMapper mapper;

  public FirmwareRepository(FirmwareMapper mapper) {
    this.mapper = mapper;
  }


}
