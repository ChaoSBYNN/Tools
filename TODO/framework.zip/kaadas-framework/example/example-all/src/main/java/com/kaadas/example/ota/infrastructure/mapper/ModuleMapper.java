package com.kaadas.example.ota.infrastructure.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaadas.example.ota.domain.Module;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Mapper
public interface ModuleMapper extends BaseMapper<Module> {
}