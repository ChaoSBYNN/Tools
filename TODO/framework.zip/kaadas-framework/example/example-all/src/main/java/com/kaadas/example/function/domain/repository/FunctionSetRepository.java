package com.kaadas.example.function.domain.repository;

import com.kaadas.example.function.domain.FunctionSet;
import com.kaadas.mongo.MongoOperationRepository;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
public interface FunctionSetRepository extends MongoOperationRepository<FunctionSet> {
}
