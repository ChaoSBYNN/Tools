package com.kaadas.example.ota.domain.repository;

import com.kaadas.example.ota.domain.OtaTask;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OtaTaskRepository extends CrudRepository<OtaTask, String> {
}
