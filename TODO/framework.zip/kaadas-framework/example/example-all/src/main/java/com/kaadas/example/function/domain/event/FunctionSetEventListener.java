package com.kaadas.example.function.domain.event;

import com.kaadas.example.function.domain.FunctionSet;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Component
public class FunctionSetEventListener {
  @EventListener
  public void onSync(FunctionSet functionSet) {
    functionSet.getFunctions();
  }
}
