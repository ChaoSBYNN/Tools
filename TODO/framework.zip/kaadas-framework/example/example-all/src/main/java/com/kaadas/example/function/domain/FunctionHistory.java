package com.kaadas.example.function.domain;

import com.kaadas.mongo.MongoEntity;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 功能变更记录
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Getter
@Setter
@Document("function_history")
public class FunctionHistory extends MongoEntity {
  /** 变更版本 */
  private String version;
  /** 变更内容 */
  private String content;
  /** 变更说明 */
  private String remark;
}
