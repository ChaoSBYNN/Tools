package com.kaadas.example.protocol.infrastructure.rocketmq;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Data
@ConfigurationProperties(prefix = "rocketmq.consumer")
public class RocketMQConsumerConfig {
  @Value("${rocketmq.namesrvAddr}")
  private String namesrvAddr;
  private String group;
  private List<Subscribe> subscribes;

  @Data
  public static class Subscribe {
    private String topic;
    private String subExpression;
  }
}
