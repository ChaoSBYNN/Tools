package com.kaadas.example.function.domain;

import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Data
public class FunctionSetId {
  /** 功能集编号 */
  private int identifier;
  /** 功能编号ID集合 */
  private List<FunctionId> functionIds;
}
