package com.kaadas.example.product.domain.repository;

import com.kaadas.example.product.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
public interface ProductRepository extends MongoRepository<Product, String> {


}
