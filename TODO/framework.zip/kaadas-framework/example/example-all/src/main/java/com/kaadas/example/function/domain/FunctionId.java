package com.kaadas.example.function.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 功能ID，包含用于MongoDB中数据集成
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Data
@AllArgsConstructor
public class FunctionId {
  /** 功能编号 */
  private int identifier;
  /** 功能编码 */
  private String code;
  /** 功能类型 */
  private FunctionType type;
}
