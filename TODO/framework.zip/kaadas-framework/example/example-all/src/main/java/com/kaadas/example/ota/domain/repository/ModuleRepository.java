package com.kaadas.example.ota.domain.repository;

import com.kaadas.example.ota.domain.Module;
import org.springframework.data.repository.CrudRepository;

public interface ModuleRepository extends CrudRepository<Module, String> {
}
