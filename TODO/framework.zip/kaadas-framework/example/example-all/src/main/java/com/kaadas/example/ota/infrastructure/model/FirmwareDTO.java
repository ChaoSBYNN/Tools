package com.kaadas.example.ota.infrastructure.model;

import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-24
 * @since 1.0.0
 */
@Data
public class FirmwareDTO {
  private String id;
  private String module;
  private String version;
  private String description;
  private List<String> pid;
  private String customer;
  private String fileUrl;
  private String fileMd5;
  private String fileLength;
  private String testReportName;
  private String testReportUrl;
}
