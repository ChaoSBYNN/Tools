package com.kaadas.example.function.domain.repository;

import com.kaadas.example.function.domain.Function;
import com.kaadas.mongo.MongoOperationRepository;

import java.util.List;
import java.util.Optional;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
public interface FunctionRepository extends MongoOperationRepository<Function> {
  Optional<Function> findByIdentifier(int identifier);

  List<Function> findByIdentifierIn(int... identifier);


}
