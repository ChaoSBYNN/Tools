package com.kaadas.example.ota.infrastructure.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaadas.example.ota.domain.Firmware;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Optional;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Mapper
public interface FirmwareMapper extends BaseMapper<Firmware> {
  Optional<Firmware> getById(String id);

  @Select("SELECT module, version FROM ota_firmware WHERE file=#{file}")
  Optional<Firmware> findByFile(@Param("file") String file);
}
