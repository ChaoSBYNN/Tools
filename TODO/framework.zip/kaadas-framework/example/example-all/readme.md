# 示例说明

目录结构采用异形的MVC三层

com.kaadas --> 域名

com.kaadas.example --> 项目名或服务名

com.kaadas.example.function | ota | product --> 模块名

com.kaadas.example.*.domain --> 领域层及相关实体，等同于 Model 层

com.kaadas.example.*.domain.repository --> 持久化层，等同于 DAO

com.kaadas.example.*.domain.event --> 事件，常用于内部或服务外部事件，后续会支持 RocketMQ

## MongoDB （com.kaadas.example.function）

使用 Spring Data Mongo

支持 class extends MongoOperationRepositoryImpl 和 interface extends MongoOperationRepository 两种方式

## MySQL （com.kaadas.example.ota）

使用 Mybatis Plus

## Redis （com.kaadas.example.ota）

查看 Module 类

目前只支持注解 @RedisHash 和 @Indexed

存储key为（例）：

- kaadas:module:${uuid} --> @RedisHash + 主键ID
- kaadas:module:num:${num} --> Indexed