package com.kaadas.simulator.appuser.application.dto;

import com.kaadas.model.BaseQry;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-03-20
 * @since 1.0.0
 */
@Data
@AllArgsConstructor
public class TelLoginQry implements BaseQry {
  /** 用户账户 */
  private String tel;
  /** 用户token */
  private String password;
}
