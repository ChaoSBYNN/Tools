import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TODO
 *
 * @author df
 * @date 2022-03-18
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class Mqtt implements CommandLineRunner {
  public static void main(String[] args) {
    SpringApplication.run(Mqtt.class, args);
    log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Kaadas Boss Starter!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  }

  @Override
  public void run(String... args) throws Exception {
    DeviceConnector deviceConnector = new DeviceConnector("tcp://10.1.0.156:1883",
      "wf:K2A0184210874",
      "K2A0184210874",
      "132a55045bb1e3156f655ca8191df7a8832d8145");

    deviceConnector.setMqttActionListener(new IMqttActionListener() {
      @SneakyThrows
      @Override
      public void onSuccess(IMqttToken asyncActionToken) {
        try {
          asyncActionToken.getClient().subscribe("/orangeiot/K2A0184210874/call", 2, (topic, message) -> {
          });
          //          asyncActionToken.getClient().subscribe("/orangeiot/K2A0184210874/reply", 2, (topic, message) -> {
          //          });
        } catch (MqttException e) {
          e.printStackTrace();
        }
        try {
          while (true) {
            Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
            String msg =
              "{\"lockId\":\"W9120C2109270DC0290455\",\"devtype\":\"kdswflock\",\"mqttPayloadVersion\":\"2.0" +
              ".4\",\"eventparams\":{\"sn\":\"K2A0184210874\",\"SEV2C_3\":\"" + UUID.randomUUID() + "\"," +
              "\"K9A0A_6\":\"" + UUID.randomUUID() +
              "\",\"AL09V_7\":\"V1.38.007\",\"voiceVersion\":\"050104\",\"MQTTversion\":\"1.1.8\"," +
              "\"functionSet\":227,\"lockModel\":\"K9A0A\",\"power\":" + ThreadLocalRandom.current().nextInt(100) +
              "," + "\"devErrCode" + "\":\"00000000" + "\"}," +
              "\"func\":\"wfevent\",\"msgId\":184,\"eventtype\":\"lockInf\",\"msgtype\":\"event\"," +
              "\"wfId\":\"K2A0222510008\",\"timestamp\":\"" + System.currentTimeMillis() / 1000L + "\"}";

            deviceConnector.mqttClient.publish("/orangeiot/K2A0184210874/event",
              msg.getBytes(StandardCharsets.UTF_8),
              0,
              false);

          }
        } catch (MqttException e) {
          e.printStackTrace();
        }
      }

      @Override
      public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

      }
    });
    deviceConnector.connect();
  }
}