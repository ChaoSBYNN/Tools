package com.kaadas.simulator.appuser.application.dto;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-03-20
 * @since 1.0.0
 */
@Data
public class Result<T> {
  protected Integer code;
  protected String msg;
  protected T data;
  protected Integer pageNum;
  protected Integer pageSize;
  protected Long total;
}
