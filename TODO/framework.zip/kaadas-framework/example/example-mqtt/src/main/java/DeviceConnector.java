import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.eclipse.paho.client.mqttv3.*;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-11-17
 * @since 1.0.0
 */
@Log4j2
public class DeviceConnector {
  MqttAsyncClient mqttClient;
  @Getter
  private String connUrl;
  @Getter
  private String clientid;
  @Getter
  private String username;
  @Getter
  private String password;
  @Setter
  private MqttCallback mqttCallback;
  @Setter
  private IMqttActionListener mqttActionListener;

  public DeviceConnector(String connUrl, String clientid) {
    this.connUrl = connUrl;
    this.clientid = clientid;
  }

  public DeviceConnector(String connUrl, String clientid, String username, String password) {
    this.connUrl = connUrl;
    this.clientid = clientid;
    this.username = username;
    this.password = password;
  }


  public void connect() throws MqttException {
    mqttClient = new MqttAsyncClient(connUrl, clientid);
    MqttConnectOptions options = new MqttConnectOptions();
    if (username != null && password != null) {
      options.setUserName(username);
      options.setPassword(password.toCharArray());
    }
    mqttClient.setManualAcks(true);

    mqttClient.setCallback(new MqttCallback() {
      @Override
      public void connectionLost(Throwable cause) {
        if (log.isDebugEnabled()) {
          log.debug("{} ConnectionLost. {}", mqttClient.getClientId(), cause.getMessage());
        }
        log.error(cause.getMessage(), cause);
        if (mqttCallback != null) {
          mqttCallback.connectionLost(cause);
        }
      }

      @Override
      public void messageArrived(String topic, MqttMessage message) throws Exception {
        if (log.isDebugEnabled()) {
          log.debug("{} MessageArrived. {}", mqttClient.getClientId(), message.toString());
        }
        if (mqttCallback != null) {
          mqttCallback.messageArrived(topic, message);
        }
      }

      @Override
      public void deliveryComplete(IMqttDeliveryToken token) {
        if (log.isDebugEnabled()) {
          log.debug("{} DeliveryComplete. {}", mqttClient.getClientId(), token.toString());
        }

        if (mqttCallback != null) {
          mqttCallback.deliveryComplete(token);
        }
      }
    });


    mqttClient.connect(options, null, new IMqttActionListener() {
      @Override
      public void onSuccess(IMqttToken asyncActionToken) {
        if (log.isDebugEnabled()) {
          log.debug("{} onSuccess. {}",
            asyncActionToken.getClient().getClientId(),
            asyncActionToken.getResponse().toString());
        }
        if (mqttActionListener != null) {
          mqttActionListener.onSuccess(asyncActionToken);
        }


      }

      @Override
      public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
        if (log.isDebugEnabled()) {
          log.error("{} onFailure. {}", asyncActionToken.getClient().getClientId(), exception);
        }
        if (mqttActionListener != null) {
          mqttActionListener.onFailure(asyncActionToken, exception);
        }
      }
    });
  }

  public static void main(String[] args) throws MqttException {
    while (true) {
      DeviceConnector deviceConnector = new DeviceConnector("tcp://10.1.0.156:1883",
        "wf:K2A0184210874",
        "K2A0184210874",
        "132a55045bb1e3156f655ca8191df7a8832d8145");

      deviceConnector.setMqttActionListener(new IMqttActionListener() {
        @SneakyThrows
        @Override
        public void onSuccess(IMqttToken asyncActionToken) {
          try {
            asyncActionToken.getClient().subscribe("/orangeiot/K2A0184210874/call", 2, (topic, message) -> {
            });
            //          asyncActionToken.getClient().subscribe("/orangeiot/K2A0184210874/reply", 2, (topic, message)
            //          -> {
            //          });
          } catch (MqttException e) {
            e.printStackTrace();
          }
          try {
            while (true) {
              Thread.sleep(ThreadLocalRandom.current().nextInt(1000));
              String msg =
                "{\"lockId\":\"W9120C2109270DC0290455\",\"devtype\":\"kdswflock\",\"mqttPayloadVersion\":\"2.0" +
                ".4\",\"eventparams\":{\"sn\":\"K2A0184210874\",\"SEV2C_3\":\"" + UUID.randomUUID() + "\"," +
                "\"K9A0A_6\":\"" + UUID.randomUUID() +
                "\",\"AL09V_7\":\"V1.38.007\",\"voiceVersion\":\"050104\",\"MQTTversion\":\"1.1.8\"," +
                "\"functionSet\":227,\"lockModel\":\"K9A0A\",\"power\":" + ThreadLocalRandom.current().nextInt(100) +
                "," + "\"devErrCode" + "\":\"00000000" + "\"}," +
                "\"func\":\"wfevent\",\"msgId\":184,\"eventtype\":\"lockInf\",\"msgtype\":\"event\"," +
                "\"wfId\":\"K2A0222510008\",\"timestamp\":\"" + System.currentTimeMillis() / 1000L + "\"}";

              deviceConnector.mqttClient.publish("/orangeiot/K2A0184210874/event",
                msg.getBytes(StandardCharsets.UTF_8),
                0,
                false);

            }
          } catch (MqttException e) {
            e.printStackTrace();
          }
        }

        @Override
        public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

        }
      });
      deviceConnector.connect();
    }
  }
}
