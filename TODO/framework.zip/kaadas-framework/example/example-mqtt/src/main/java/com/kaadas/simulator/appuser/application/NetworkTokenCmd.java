package com.kaadas.simulator.appuser.application;

import com.fasterxml.jackson.core.type.TypeReference;
import com.kaadas.model.BaseQry;
import com.kaadas.simulator.appuser.AppUserConstants;
import com.kaadas.simulator.appuser.application.dto.Result;
import com.kaadas.util.http.HttpUtils;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.function.Function;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-03-20
 * @since 1.0.0
 */
public class NetworkTokenCmd implements Function<NetworkTokenCmd.Req, Result<NetworkTokenCmd.Res>> {


  @Override
  public Result<Res> apply(Req telLoginQry) {
    return HttpUtils
      .json()
      .post(AppUserConstants.URL + "/wifi/device/networkToken", telLoginQry, new TypeReference<Result<Res>>() {});
  }

  @Data
  @AllArgsConstructor
  public static class Req implements BaseQry {
    /** 用户账户 */
    private String tel;
    /** 用户token */
    private String password;
  }

  @Data
  public static class Res {
    private String uid;
    private String token;
  }
}
