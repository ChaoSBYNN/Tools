package com.kaadas.simulator.appuser;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-03-20
 * @since 1.0.0
 */
public class AppUserConstants {
  public final static String URL = "http://127.0.0.1:8091";
}
