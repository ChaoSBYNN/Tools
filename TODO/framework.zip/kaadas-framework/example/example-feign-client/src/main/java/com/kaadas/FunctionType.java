package com.kaadas;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
public enum FunctionType {
  /** 硬件功能，不需要软件处理 */
  Hardware,
  /** 软件功能，需要服务端处理 */
  Software
}
