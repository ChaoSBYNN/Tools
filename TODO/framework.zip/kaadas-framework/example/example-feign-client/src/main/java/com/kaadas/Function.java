package com.kaadas;

import lombok.Getter;
import lombok.Setter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Getter
@Setter
public class Function {
  /** 功能编号 */
  private int identifier;
  /** 功能编码 */
  private String code;
  /** 功能名称 */
  private String name;
  /** 功能类型 */
  private FunctionType type;
  /** 功能说明 */
  private String remark;
}
