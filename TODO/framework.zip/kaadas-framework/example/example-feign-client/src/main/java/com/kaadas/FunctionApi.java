package com.kaadas;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@FeignClient(name = "FunctionApi", url = "http://127.0.0.1")
public interface FunctionApi {

  @RequestMapping(value = "func/page", method = RequestMethod.POST)
  PageResponse<Function> pagePost(@RequestBody FunctionRequest qry);

  @RequestMapping(value = "func/page", method = RequestMethod.GET)
  PageResponse<Function> pageGet(@SpringQueryMap FunctionRequest qry);
}