package com.kaadas;

import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-11
 * @since 1.0.0
 */
@Data
public class PageResponse<T> {
  com.kaadas.model.page.Page page;
  List<T> data;
}
