package com.kaadas;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-11
 * @since 1.0.0
 */
@Data
public class FunctionRequest extends PageRequest {
  String func;
  private String id;
}
