package com.kaadas;

import com.kaadas.model.page.Pageable;
import feign.Feign;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import feign.querymap.BeanQueryMapEncoder;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-11
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication
@EnableFeignClients
public class ClientApp implements CommandLineRunner {
  @Resource
  FunctionApi functionApi;

  public static void main(String[] args) {
    SpringApplication.run(ClientApp.class, args);
  }

  @Bean
  RequestInterceptor requestBodyInterceptor() {
    return new RequestInterceptor() {
      @Override
      public void apply(RequestTemplate requestTemplate) {
        if ("GET".equals(requestTemplate.method())) {
          requestTemplate.body(null, StandardCharsets.UTF_8);
        }
      }
    };
  }

  @Bean
  public Feign.Builder feignBuilder() {
    return new Feign.Builder()
      .queryMapEncoder(new BeanQueryMapEncoder());
  }

  @Override
  public void run(String... args) throws Exception {
    Pageable pageable = new Pageable();
    pageable.setNum(1);
    pageable.setSize(20);
    pageable.setSort(new String[]{"value+", "pink-"});
    FunctionRequest functionRequest = new FunctionRequest();
    functionRequest.setPage(pageable);
    PageResponse<Function> pageResponse = functionApi.pageGet(functionRequest);
    log.info(pageResponse);
  }
}
