package com.kaadas;

import com.kaadas.schema.ObjectTypeDefinition;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class ElasticsearchApplication {
  public static void main(String[] args) {
    SpringApplication.run(ElasticsearchApplication.class, args);
    log.info("Elasticsearch example starting");
    ObjectTypeDefinition typeDefinition = new ObjectTypeDefinition();
    String json = "";
  }
}
