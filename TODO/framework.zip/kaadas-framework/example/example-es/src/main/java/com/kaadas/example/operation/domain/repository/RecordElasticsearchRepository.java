package com.kaadas.example.operation.domain.repository;


import com.kaadas.elasticsearch.ElasticsearchOperationRepository;
import com.kaadas.example.operation.domain.Record;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-15
 * @since 1.0.0
 */
public interface RecordElasticsearchRepository extends ElasticsearchOperationRepository<Record> {
  List<Record> findByEsn(String esn);

  List<Record> findByEsn(String esn, Pageable pageable);
}
