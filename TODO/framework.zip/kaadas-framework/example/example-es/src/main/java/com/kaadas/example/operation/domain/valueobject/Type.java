package com.kaadas.example.operation.domain.valueobject;

public enum Type {
  Message,
  Alarm,
  Error,
  Guest;
}