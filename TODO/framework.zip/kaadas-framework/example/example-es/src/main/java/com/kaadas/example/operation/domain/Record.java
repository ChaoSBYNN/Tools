package com.kaadas.example.operation.domain;

import com.kaadas.example.operation.domain.valueobject.Type;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.DoorBellRinging;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.event.secret.SecretPayload;
import com.kaadas.util.JsonUtils;
import lombok.Data;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-15
 * @since 1.0.0
 */
@Data
@Document(indexName = "records")
public class Record {
  protected String id;
  protected String esn;
  protected long time;
  protected Type type;
  protected String name;
  protected Map<String, Object> payload;
  @Field(value = "@timestamp", type = FieldType.Date, format = DateFormat.date_hour_minute_second_millis)
  private LocalDateTime timestamp;

  public Record() {
  }

  public Record(IotEvent<?> iotEvent) {
    if (iotEvent.getClass() == DoorBellRinging.class) {
      setType(Type.Guest);
    } else {
      setType(Type.valueOf(iotEvent.getEventType().name()));
    }
    setEsn(iotEvent.getEsn());
    setName(iotEvent.getId());
    setTime(iotEvent.getTime());
    setPayload(JsonUtils.beanToMap(iotEvent.getPayload()));
    setTimestamp(LocalDateTime.now());
    setId(genId(iotEvent));
  }

  protected String genId(IotEvent<?> iotEvent) {
    String idKeyStr = getEsn() + ";" + getName() + ";" + getType().name() + ";" + getTime();
    if (iotEvent.getPayload() instanceof SecretPayload) {
      // K2A0123456789;AddSecret;Message;1660644507;Keypad;1
      SecretPayload secretPayload = (SecretPayload) iotEvent.getPayload();
      LockSecret lockSecret = secretPayload.getLockSecret();
      if (lockSecret != null) {
        idKeyStr += ";" + lockSecret.getMode() + ";" + lockSecret.getNum();
      }
    }
    // K2A0123456789;Unlock;Message;1660644507
    return DigestUtils.md5Hex(idKeyStr);
  }
}
