package com.kaadas.test.example;

import com.kaadas.ElasticsearchApplication;
import com.kaadas.asserts.Assert;
import com.kaadas.example.operation.domain.Record;
import com.kaadas.example.operation.domain.repository.RecordElasticsearchRepository;
import com.kaadas.iot.event.lock.Unlock;
import com.kaadas.iot.event.lock.UnlockPayload;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.Maps;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

import javax.annotation.Resource;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-16
 * @since 1.0.0
 */
@Log4j2
@Profile("dev")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes = ElasticsearchApplication.class)
public class RecordElasticsearchTest {
  @Resource
  RecordElasticsearchRepository recordElasticsearchRepository;

  public static void main(String[] args) {
    LockSecret lockSecret = new LockSecret();
    lockSecret.setMode("Keypad");
    lockSecret.setNum(1);
    lockSecret.setUser(0);
    UnlockPayload unlockPayload = new UnlockPayload();
    unlockPayload.setUnlockSecret(lockSecret);
    unlockPayload.setLockState(0);
    unlockPayload.setExtra(Maps.<String, Object>newHashMap().put("nickname", "大拇指").put("duress", true).getMap());
    Unlock unlock = new Unlock(unlockPayload);
    //    unlock.setTime(System.currentTimeMillis() / 1000);
    unlock.setTime(1660644507);
    unlock.setEsn("K2A0123456789");
    Record unlockRecord = new Record(unlock);
    System.out.println(unlockRecord.getId());
  }

  @Test
  public void testSave() {
    LockSecret lockSecret = new LockSecret();
    lockSecret.setMode("Keypad");
    lockSecret.setNum(1);
    lockSecret.setUser(0);
    UnlockPayload unlockPayload = new UnlockPayload();
    unlockPayload.setUnlockSecret(lockSecret);
    unlockPayload.setLockState(0);
    unlockPayload.setExtra(Maps.<String, Object>newHashMap().put("nickname", "大拇指2").put("duress", true).getMap());
    Unlock unlock = new Unlock(unlockPayload);
    unlock.setTime(1660957309);
    unlock.setEsn("K2A0123456789");


    // rocketmq -> IotEvent

    Record unlockRecord = new Record(unlock);
    recordElasticsearchRepository.save(unlockRecord);

    System.out.println(JsonUtils.serialize(unlockRecord));
  }

  @Test
  public void testQuery() {
    List<Record> records = recordElasticsearchRepository.findByEsn("79F0220810001");
    Assert.isTrue(records.isEmpty());
    records.forEach(record -> {
      System.out.println(record.getPayload());
    });
  }
}
