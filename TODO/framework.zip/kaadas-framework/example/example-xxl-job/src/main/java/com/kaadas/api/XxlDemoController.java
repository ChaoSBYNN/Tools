package com.kaadas.api;

import com.kaadas.xxl.job.api.JobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @Author: guohao
 * @Date: 2022/4/11 13:13
 * @Description:
 */
@RestController
public class XxlDemoController implements XxlDemoApi{

  private static final Logger logger = LoggerFactory.getLogger(XxlDemoController.class);
  @Autowired
  JobService jobService;

  @Override
  public void add() {
    // 创建任务
    Date date = new Date(System.currentTimeMillis() + 10000);
    String paramJson = "测试参数";
    jobService.create("otaTestHandler", date, paramJson);
    logger.info("testXxlJob创建任务 {} {}", date, paramJson);
  }


}
