package com.kaadas.api;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 定时任务示例
 */
@Api(tags = "定时任务示例")
@RequestMapping("xxl/demo")
public interface XxlDemoApi {
  @GetMapping("add")
  void add();

}
