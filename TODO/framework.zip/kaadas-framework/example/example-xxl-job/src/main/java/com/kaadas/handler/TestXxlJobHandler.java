package com.kaadas.handler;

import com.kaadas.xxl.job.annotation.XxlRegister;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class TestXxlJobHandler {
  private final Logger logger = LoggerFactory.getLogger(TestXxlJobHandler.class);


  @XxlJob("otaTestHandler")
  public ReturnT<String> otaTestHandler() throws Exception {
    String jobParam = XxlJobHelper.getJobParam();
    logger.info("xxl-job demo hello world...2..." + jobParam);
//    XxlJobExecutor.registJobHandler("demoJobHandler", new DemoJobHandler());
    return ReturnT.SUCCESS;
  }

  @XxlJob("xxlOtaTest1")
  @XxlRegister(cron = "0 * * * * ? *",
               author = "kaadas-xxl-job-ota",
               jobDesc = "测试任务-包子",
               triggerStatus = 0)
  public void xxlOtaTest1() throws Exception {
    logger.info("广东十年爱情故事");
  }

  @XxlJob("xxlOtaTest2")
//  @XxlRegister(cron = CronUtils,
//    author = "kaadas-xxl-job-ota",
//    jobDesc = "测试任务-菠菜")
  public void xxlOtaTest2() throws Exception {
    logger.info("菠菜菠菜菠菜菠菜菠菜");

  }

}
