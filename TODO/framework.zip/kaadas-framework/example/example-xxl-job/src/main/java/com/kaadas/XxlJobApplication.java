package com.kaadas;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TODO
 *
 * @author liuqinxian
 * @date 2022-03-02
 * @since 1.0.0
 */
@Log4j2
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class XxlJobApplication {
  public static void main(String[] args) {
    SpringApplication.run(XxlJobApplication.class, args);
  }


}
