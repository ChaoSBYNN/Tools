package com.kaadas.test.triple;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.util.EsnUtils;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.Maps;
import com.kaadas.util.http.HttpUtils;
import com.mongodb.client.*;
import org.bson.BsonDocument;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-09
 * @since 1.0.0
 */
public class TripleCleanTest {
  public static void main2(String[] args) {
    MongoDatabase mongoDatabase;
    try (MongoClient mongoClient = MongoClients.create("mongodb://oegrt:qweqwecz123dsfs12shawe@10.1.0" +
                                                       ".110:27018/PaasDB?authSource=orangeiot&readPreference=primary" +
                                                       "&&directConnection=true&ssl=false")) {
      mongoDatabase = mongoClient.getDatabase("PaasDB");
    }
    MongoCollection<Document> mongoCollection = mongoDatabase.getCollection("triples");
    Map allUsedCondition = Maps.newHashMap().put("status", "USED").getMap();
    FindIterable<Document> triples = mongoCollection.find(BsonDocument.parse(JsonUtils.serialize(allUsedCondition)));

    List<String> allUsedEsn = new ArrayList<>();
    for (Document document : triples) {
      allUsedEsn.add((String) document.get("esn"));
    }
    mongoCollection = mongoDatabase.getCollection("devices");
    Map allDeviceCondition = Maps.newHashMap().put("esn", Maps.newHashMap().put("$in", allUsedEsn).getMap()).getMap();
    FindIterable<Document> devices = mongoCollection.find(BsonDocument.parse(JsonUtils.serialize(allDeviceCondition)));
    List<String> allExpiredEsn = new ArrayList<>();
    for (Document document : devices) {
      long updateTime = (long) document.get("updateTime");
      if (updateTime + (86400 * 7 * 1000) < System.currentTimeMillis()) {
        System.out.println(document.get("esn") + ", " + DateTimeFormatter
          .ofPattern("yyyy-MM-dd hh:mm:ss")
          .format(Instant.ofEpochMilli(updateTime).atOffset(ZoneOffset.ofHours(8))));
        allExpiredEsn.add((String) document.get("esn"));
        HttpUtils.sync().delete("http://10.1.0.110:11199/shadow/clean/" + document.get("esn"));
      }
    }
    System.out.println(JsonUtils.serialize(allExpiredEsn));
  }

  public static void main33(String[] args) throws IOException {
    InputStream inputStream =
      Files.newInputStream(Paths.get("C:\\Users\\ZhangDuanFeng\\Desktop\\04796941-fd56-4fad-b5ab-c0bbb35776fe.txt"));
    //    InputStream inputStream = Files.newInputStream(Paths.get
    //    ("C:\\Users\\ZhangDuanFeng\\Desktop\\2d773f20-9ea7-43ea-9ad2-92debe0024b8.txt"));

    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
    bufferedReader.readLine();
    //
    //    bufferedReader.lines().filter(str -> str.contains("10V1211112042"))
    //      .forEach(str->{
    //        System.out.println(str);
    //      });
    bufferedReader
      .lines()
      .filter(str -> str.contains(",publish,"))
      .map(str -> {
        String[] strings = str.split(",");
        return strings[strings.length - 1];
      })
      .filter(str -> str.length() == 13)
      .sorted()
      .collect(Collectors.groupingBy(str -> str, Collectors.counting()))
      .entrySet()
      .stream()
      .sorted(Map.Entry.comparingByValue())
      .forEach(e -> {
        System.out.println(e.getKey() + ", " + e.getValue());
      });
    ;
  }

  public static void main(String[] args) throws IOException {
    //    System.out.println("本日志采集时间为2022-08-08 23:26:00 ~ 2022-08-08 23:45:59");
    System.out.println("本日志采集时间为2022-08-14 23:20:00 ~ 2022-08-14 23:45:59");
    InputStream inputStream =
      Files.newInputStream(Paths.get("C:\\Users\\ZhangDuanFeng\\Desktop\\mqttProcessInfo-2023-02-16-7.log.gz"));
    //      Files.newInputStream(Paths.get("C:\\Users\\ZhangDuanFeng\\Downloads\\mqtt-server-0823-26-45 (1).log"));
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
    Pattern pattern = Pattern.compile("mqttProcessInfo-.*\\.log.gz:\\[(.*)]\\s\\[.*] - mqtt-process:(.*)");
    List<ObjectNode> objectNodes =
      bufferedReader.lines().parallel().map(pattern::matcher).filter(Matcher::matches).map(matcher -> {
        MatchResult matchResult = matcher.toMatchResult();
        String sysTime = matchResult.group(1);
        ObjectNode jsonNode = (ObjectNode) JsonUtils.toJsonNode(matchResult.group(2));
        if (jsonNode == null) {
          return null;
        }
        jsonNode.put("sysTime", sysTime);
        return jsonNode;
      }).filter(jsonNode -> {
        if (jsonNode == null) {
          return false;
        }
        String to = jsonNode.get("to").textValue();
        String mqttMsg = jsonNode.get("mqttMsg").textValue();
        String clientId = jsonNode.get("clientId").textValue();
        return Objects.equals(to, "server") && clientId.startsWith("wf") && !mqttMsg.startsWith("PUBCOMP") &&
               !mqttMsg.startsWith("PUBREL") && !mqttMsg.startsWith("PUBACK");
      }).collect(Collectors.toList());

    bufferedReader.close();

    Map<String, ObjectNode> esnList = objectNodes.stream().map(objectNode -> {
      return objectNode.get("clientId").textValue().substring(3);
    }).distinct().collect(Collectors.toMap(esn -> esn, esn -> {
      ObjectNode objectNode = JsonUtils.getObjectMapper().createObjectNode();
      objectNode.put("esn", esn);
      objectNode.set("vers", JsonUtils.getObjectMapper().createObjectNode());
      objectNode.set("events", JsonUtils.getObjectMapper().createObjectNode());
      return objectNode;
    }));
    System.out.println("采集时间段内在线设备总量: " + esnList.size());
    List<Map.Entry<String, Long>> pidCount = esnList
      .keySet()
      .stream()
      .collect(Collectors.groupingBy(esn -> {
        try {
          return EsnUtils.getPid(esn);
        } catch (Exception t) {
          return esn;
        }
      }, Collectors.counting()))
      .entrySet()
      .stream()
      .sorted((e1, e2) -> (int) (e2.getValue() - e1.getValue()))
      .collect(Collectors.toList());
    System.out.println("采集时间段内在线机型(数量)含: " + JsonUtils.serialize(pidCount));

    objectNodes
      .stream()
      .parallel()
      //根据clientId分组
      .collect(Collectors.groupingBy(objectNode -> objectNode.get("clientId").textValue().substring(3)))
      .forEach((k, v) -> {
        // Vers
        v.stream().parallel().map(objectNode -> {
          return objectNode.get("payload");
        }).filter(Objects::nonNull).filter(payload -> payload.has("eventtype")).filter(payload -> {
          String eventtype = payload.get("eventtype").asText("");
          return eventtype.equals("lockInf") || eventtype.equals("cameraInf");
        }).forEach(payload -> {
          String eventtype = payload.get("eventtype").asText("");
          JsonNode eventparams = payload.get("eventparams");
          ObjectNode vers = (ObjectNode) esnList.get(k).get("vers");
          if (eventparams.has("firmware")) {
            vers.put("firmware", eventparams.get("firmware").textValue());
          }

          if (eventparams.has("software")) {
            vers.put("software", eventparams.get("software").textValue());
          }
          if (eventparams.has("BLEversion")) {
            vers.put("BLEversion", eventparams.get("BLEversion").textValue());
          }
          if (eventparams.has("WIFIversion")) {
            vers.put("WIFIversion", eventparams.get("WIFIversion").textValue());
          }
          if (eventparams.has("MQTTversion")) {
            vers.put("MQTTversion", eventparams.get("MQTTversion").textValue());
          }
          if (eventparams.has("camera_version")) {
            vers.put("camera_version", eventparams.get("camera_version").textValue());
          }
          if (eventparams.has("mcu_version")) {
            vers.put("mcu_version", eventparams.get("mcu_version").textValue());
          }
        });
        // CONNECT
        esnList
          .get(k)
          .put("connectCount",
            v
              .stream()
              .parallel()
              .filter(objectNode -> objectNode.get("mqttMsg").textValue().startsWith("CONNECT"))
              .count());
        esnList
          .get(k)
          .put("publishCount",
            v
              .stream()
              .parallel()
              .filter(objectNode -> objectNode.get("mqttMsg").textValue().startsWith("PUBLISH"))
              .count());
        // PUBLISH & event
        v
          .stream()
          .parallel()
          .filter(objectNode -> {
            String mqttMsg = objectNode.get("mqttMsg").textValue();
            return mqttMsg.startsWith("PUBLISH") && mqttMsg.contains("/orangeiot/" + k + "/event");
          })
          .map(objectNode -> {
            if (!objectNode.get("payload").has("eventtype")) {
              return "";
            }
            return objectNode.get("payload").get("eventtype").asText("");
          })
          .collect(Collectors.groupingBy(eventtype -> eventtype, Collectors.counting()))
          .forEach((k1, v1) -> ((ObjectNode) esnList.get(k).get("events")).put(k1, v1));
      });
    Map<String, Map<String, Long>> verMap = esnList.entrySet().stream().collect(Collectors.groupingBy(entry -> {
      try {
        return EsnUtils.getPid(entry.getKey());
      } catch (Exception t) {
        return entry.getKey();
      }
    })).entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> {
      return entry
        .getValue()
        .stream()
        .map(Map.Entry::getValue)
        .filter(objectNode -> objectNode.get("vers").has("WIFIversion"))
        .map(objectNode -> objectNode.get("vers").get("WIFIversion").textValue())
        .collect(Collectors.groupingBy(str -> str, Collectors.counting()));
    }));

    List<Map.Entry<String, Map<String, Long>>> verCount = pidCount.stream().map(entry -> {
      return new AbstractMap.SimpleEntry<>(entry.getKey(), verMap.get(entry.getKey()));
    }).collect(Collectors.toList());
    System.out.println("采集时间段内在线机型WIFI版本分布(只根据lockInf和cameraInf统计): " + JsonUtils.serialize(verCount));

    // 连接排序
    List<ObjectNode> connectSort = esnList
      .values()
      .stream()
      .filter(objectNode -> objectNode.has("connectCount"))
      .sorted(((o1, o2) -> o2.get("connectCount").intValue() - o1.get("connectCount").intValue()))
      .limit(100)
      .collect(Collectors.toList());
    System.out.println("采集时间段内上线次数排序(前100): " + JsonUtils.serialize(connectSort));

    // 发布排序
    List<ObjectNode> publishSort = esnList
      .values()
      .stream()
      .filter(objectNode -> objectNode.has("publishCount"))
      .sorted(((o1, o2) -> o2.get("publishCount").intValue() - o1.get("publishCount").intValue()))
      .limit(100)
      .collect(Collectors.toList());
    System.out.println("采集时间段内发布消息次数排序(前100): " + JsonUtils.serialize(publishSort));

  }
}
