package com.kaadas.test;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-04-10
 * @since 1.0.0
 */
public class DemoTest {
  public static void main(String[] args) {
    String ver = "20211027";
    OkHttpClient httpClient = new OkHttpClient.Builder().build();
    try (Response response = httpClient
      .newCall(new Request.Builder()
        .get()
        .url("http://127.0.0.1/demo?token=test_token")
        .header("Ver", ver)
        .header("Accept", "application/json")
        .build())
      .execute()) {
      assert response.isSuccessful();
      ResponseBody body = response.body();
      assert body != null;
      assert body.string().contains(ver);
      // result is {"ver":"20211027","desc":"版本为 20211027 ，带token=test_token"}
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Test
  void testQ() {
    Assertions.assertTrue(true);
  }
}
