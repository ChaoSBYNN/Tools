package com.kaadas.test.triple;

import com.kaadas.util.BeanUtils;
import lombok.Data;

import java.io.File;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-11-08
 * @since 1.0.0
 */
public class TestFileToJson {
  public static void main(String[] args) {
    TestFile testFile = new TestFile();
    testFile.setFile(new File(
      "C:\\Users\\ZhangDuanFeng\\Documents\\WeChat " + "Files\\luoyuchou\\FileStorage\\File\\2022-11\\视频上传失败.zip"));
    testFile.setName("视频上传失败.zip");
    Map<String, Object> map = BeanUtils.toMap(testFile);

    System.out.println(map.get("file").getClass());
  }

  @Data
  static class TestFile {
    File file;
    String name;
  }
}
