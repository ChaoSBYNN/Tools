package com.kaadas.example.function.api;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * VO 视图 View Object
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@ApiModel
@Data
public class FunctionVO {
  protected String id;
  protected Long createTime;
  protected Long updateTime;
  /** 功能编号 */
  private int identifier;
  /** 功能编码 */
  private String code;
  /** 功能名称 */
  private String name;
  /** 功能说明 */
  private String remark;
}
