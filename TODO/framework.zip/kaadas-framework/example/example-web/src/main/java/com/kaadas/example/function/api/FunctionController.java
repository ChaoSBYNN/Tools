package com.kaadas.example.function.api;

import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Clock;
import java.util.ArrayList;

/**
 * Controller
 *
 * @author ZhangDuanFeng
 * @date 2023-04-07
 * @since 1.0.0
 */
@RestController
@RequestMapping
@Log4j2
public class FunctionController implements FunctionApi {
  @Override
  public void post(FunctionPostQuery qry) {
    // 未实现的功能
  }

  @Override
  public FunctionVO get(String id) {
    FunctionVO vo = new FunctionVO();
    vo.setId(id);
    vo.setCode("DemoFunction");
    vo.setIdentifier(1);
    vo.setCreateTime(Clock.systemUTC().millis());
    vo.setName("示例功能");
    vo.setRemark("这只是一个用作示例的功能，没有任何实际用处。");
    return vo;
  }

  @Override
  public void put(String id, FunctionPostQuery qry) {
    // 未实现的功能
  }

  @Override
  public Page<FunctionVO> pagePost(FunctionQuery qry) {
    return new PageImpl<>(new ArrayList<>());
  }

  @Override
  public Page<FunctionVO> pageGet(FunctionQuery qry) {
    return new PageImpl<>(new ArrayList<>());
  }
}
