package com.kaadas.example.function.api;

import com.kaadas.web.model.PageQry;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * Query 查询类
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel
@ToString(callSuper = true)
public class FunctionQuery extends PageQry {
  @ApiModelProperty(notes = "名称，模糊查询")
  private String name;
}
