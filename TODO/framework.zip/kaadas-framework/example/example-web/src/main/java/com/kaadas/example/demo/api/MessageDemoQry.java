package com.kaadas.example.demo.api;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-11-08
 * @since 1.0.0
 */
@Data
public class MessageDemoQry {
  private String id;
  private String topic;
  private String clientId;
  private int qos;
  private String peerhost;
  private String payload;
}
