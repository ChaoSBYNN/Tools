package com.kaadas.example;

import com.kaadas.web.version.EnableApiVersion;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.Clock;

/**
 * 启动类
 *
 * @author ZhangDuanFeng
 * @date 2022-02-22
 * @since 1.0.0
 */
@Log4j2
@EnableApiVersion
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class DemoApplication {
  public static void main(String[] args) {
    Clock.systemUTC().millis();
    SpringApplication.run(DemoApplication.class, args);
    log.info("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Kaadas Boss Starter!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  }
}
