package com.kaadas.example.demo.api;

import com.kaadas.web.ApiException;
import com.kaadas.web.version.ApiVersion;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RestController;

@ApiVersion(20230410)
@RestController
public class DemoControllerV20230410 extends DemoControllerV20211118 {
  @Override
  public DemoVO throwException() {
    throw new ApiException(DemoErrorCode.VERSION_V3);
  }

  @Override
  @ApiOperation(value = "V20230410-Demo示例")
  public DemoVO getDemo3() {
    return new DemoVO("20230410", "V20230410-Demo示例");
  }
}
