package com.kaadas.example.demo.api;

import com.kaadas.web.ApiException;
import lombok.extern.log4j.Log4j2;

/**
 * 默认版本, 无版本示例
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Log4j2
//@RestController
public class DemoController implements DemoApi {
  @Override
  public DemoVO getDemo(String token) {
    return new DemoVO("0", "这是一个无版本示例");
  }

  @Override
  public DemoVO throwException() {
    throw new ApiException(DemoErrorCode.VERSION_V0);
  }
}
