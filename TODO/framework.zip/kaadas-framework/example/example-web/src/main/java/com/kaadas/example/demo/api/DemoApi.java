package com.kaadas.example.demo.api;

import io.swagger.annotations.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * API版本示例
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Api(tags = "API版本示例")
@RequestMapping("demo")
public interface DemoApi {

  @GetMapping
  @ApiOperation(value = "根据版本获取一个Demo对象")
  DemoVO getDemo(@ApiParam("令牌") @RequestParam String token);

  @GetMapping("throwException")
  @ApiOperation(value = "根据版本抛出一个异常示例")
  DemoVO throwException();

  @Data
  @ApiModel
  @NoArgsConstructor
  @AllArgsConstructor
  class DemoVO {
    @ApiModelProperty(notes = "版本号")
    private String ver;
    @ApiModelProperty(notes = "示例说明，成功状态没有code和msg")
    private String desc;
  }
}
