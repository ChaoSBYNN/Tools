package com.kaadas.example.function.api;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

/**
 * 功能
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@Api(tags = "功能")
public interface FunctionApi {

  @PostMapping("function")
  @ApiOperation(value = "添加一个功能")
  void post(@RequestBody FunctionPostQuery qry);

  @GetMapping("function/{id}")
  @ApiOperation(value = "查询一个功能", notes = "必须传入ID。")
  FunctionVO get(@PathVariable @ApiParam(required = true, value = "功能ID") String id);

  @PutMapping("function/{id}")
  @ApiOperation(value = "修改一个功能", notes = "必须传入ID。系统不支持自定义ID，故PUT接口不支持自定义ID的功能新增")
  void put(@PathVariable @ApiParam(required = true, value = "功能ID") String id, @RequestBody FunctionPostQuery qry);

  @PostMapping("functions")
  @ApiOperation(value = "POST分页查询", notes = "POST分页查询，支持查询条件为Json Body")
  Page<FunctionVO> pagePost(@RequestBody FunctionQuery qry);

  @GetMapping("functions")
  @ApiOperation(value = "Get分页查询", notes = "Get分页查询，只支持URL参数")
  Page<FunctionVO> pageGet(FunctionQuery qry);
}