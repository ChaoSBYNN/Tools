package com.kaadas.example.function.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Query 查询类
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@Data
@ApiModel
public class FunctionPostQuery {
  @ApiModelProperty(notes = "func")
  private String func;


}
