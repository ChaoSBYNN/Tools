package com.kaadas.example.function;
/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */