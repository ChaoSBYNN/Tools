package com.kaadas.example.demo.api;

import com.kaadas.web.version.ApiVersion;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 20211118 需求版本
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@ApiVersion(20211118)
@RestController
public class DemoControllerV20211118 extends DemoControllerV20211027 {
  @Override
  public DemoVO getDemo(String token) {
    return new DemoVO("20211118", "版本为 20211118 ，带token=" + token);
  }

  @GetMapping("example")
  @ApiOperation(value = "V20211118-Demo示例")
  public DemoVO getDemo3() {
    return new DemoVO("20211118", "V20211118-Demo示例");
  }
}
