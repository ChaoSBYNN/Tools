package com.kaadas.example.demo.api;

import com.kaadas.result.ErrorCode;
import com.kaadas.result.ResultCode;
import lombok.Getter;

public enum DemoErrorCode implements ErrorCode {

  /** 参数为空 */
  VERSION_V0(ResultCode.BAD_REQUEST, "version_v0", "无版本接口抛异常示例"),
  VERSION_V1(ResultCode.BAD_REQUEST, "version_v20211027", "v20211027版本接口抛异常示例"),
  VERSION_V2(ResultCode.BAD_REQUEST, "version_v20211118", "v20211118版本接口抛异常示例"),
  VERSION_V3(ResultCode.BAD_REQUEST, "version_v20230410", "v20230410版本接口抛异常示例"),
  ;

  @Getter
  private final ResultCode resultCode;
  @Getter
  private final String errCode;
  @Getter
  private final String errDes;

  DemoErrorCode(ResultCode resultCode, String errCode, String errDes) {
    this.resultCode = resultCode;
    this.errCode = errCode;
    this.errDes = errDes;
  }
}
