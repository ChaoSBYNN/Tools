package com.kaadas.example;

import com.github.xiaoymin.knife4j.spring.annotations.EnableKnife4j;
import com.kaadas.util.Lists;
import com.kaadas.web.version.ApiVersion;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import springfox.documentation.RequestHandler;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.AllowableListValues;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.RequestHandlerCombiner;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2WebMvc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Swagger 配置
 *
 * @author ZhangDuanFeng
 * @date 2023-03-30
 * @since 1.0.0
 */
@Log4j2
@EnableSwagger2WebMvc
@EnableKnife4j
@Profile({"dev", "test", "pre"})
@ConditionalOnProperty(value = "swagger.enabled", havingValue = "true")
@Configuration
public class SwaggerConfiguration {
  private static final String DEFAULT_PACKAGE = "com.kaadas";

  @Bean
  public Docket apiV20211027() {
    return genDocket(20211027);
  }

  @Bean
  public Docket apiV20211118() {
    return genDocket(20211118);
  }

  @Bean
  public Docket apiV20230410() {
    return genDocket(20230410);
  }

  @Bean
  RequestHandlerCombiner requestHandlerCombiner() {
    return source -> source;
  }

  @Bean
  @ConditionalOnMissingBean(ApiInfo.class)
  public ApiInfo apiInfo() {
    return new ApiInfoBuilder()
      .title("API接口文档(合集)")
      .description("此文档根据接口版本分组，请查阅对应版本的接口文档。")
      .contact(new Contact("API", "http://www.kaadas.com", "api@kaadas.com"))
      .version("1.0")
      .build();
  }

  @Bean
  @ConditionalOnMissingBean(name = "defaultDocket")
  public Docket defaultDocket() {
    Docket docket = new Docket(DocumentationType.SWAGGER_2);
    docket
      .groupName("default")
      .apiInfo(apiInfo())
      .select()
      .apis(RequestHandlerSelectors.basePackage(DEFAULT_PACKAGE))
      .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
      .paths(PathSelectors.any())
      .apis(defaultDocketSelector())
      .build();
    return docket;
  }


  private Docket genDocket(int ver) {
    return new Docket(DocumentationType.SWAGGER_2)
      .groupName("api_v" + ver)
      .enableUrlTemplating(false)
      .apiInfo(apiInfo())
      .globalOperationParameters(getApiVersionGlobalRequestParameter(ver))
      .select()
      .apis(RequestHandlerSelectors.basePackage(DEFAULT_PACKAGE))
      .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
      .paths(PathSelectors.any())
      .apis(apiVersionDocketSelector(ver))
      .build();
  }


  Predicate<RequestHandler> defaultDocketSelector() {
    return handler -> {
      boolean hasTypeApiVersion = handler.findControllerAnnotation(ApiVersion.class).isPresent();
      boolean hasMethodApiVersion = handler.isAnnotatedWith(ApiVersion.class);
      return !hasTypeApiVersion && !hasMethodApiVersion;
    };
  }

  Predicate<RequestHandler> apiVersionDocketSelector(int ver) {
    return handler -> {
      boolean hasTypeApiVersion =
        handler.findControllerAnnotation(ApiVersion.class).filter(apiVersion -> apiVersion.value() == ver).isPresent();
      boolean hasMethodApiVersion =
        handler.findAnnotation(ApiVersion.class).filter(apiVersion -> apiVersion.value() == ver).isPresent();
      return hasTypeApiVersion || hasMethodApiVersion;
    };
  }

  private List<Parameter> getApiVersionGlobalRequestParameter(int defaultValue) {
    List<Parameter> parameters = new ArrayList<>(defaultParameters());
    parameters.add(new ParameterBuilder()
      .allowEmptyValue(false)
      .defaultValue(defaultValue + "")
      .name("Ver")
      .description("版本号，默认值为：" + defaultValue)
      .required(true)
      .modelRef(new ModelRef("integer"))
      .allowableValues(new AllowableListValues(Lists.newArrayList(defaultValue + ""), "integer"))
      .parameterType("header")
      .build());
    return parameters;
  }

  private List<Parameter> defaultParameters() {
    List<Parameter> parameters = new ArrayList<>();
    parameters.add(new ParameterBuilder()
      .name("Accept")
      .allowEmptyValue(false)
      .defaultValue(MediaType.APPLICATION_JSON_VALUE)
      .modelRef(new ModelRef("string"))
      .parameterType("header")
      .build());
    return parameters;
  }
}
