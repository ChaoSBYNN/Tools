package com.kaadas.example.demo.api;

import com.kaadas.web.ApiException;
import com.kaadas.web.version.ApiVersion;
import org.springframework.web.bind.annotation.RestController;

/**
 * 20211027 需求版本
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@ApiVersion(20211027)
@RestController
public class DemoControllerV20211027 implements DemoApi {
  @Override
  public DemoVO getDemo(String token) {
    return new DemoVO("20211027", "版本为 20211027 ，带token=" + token);
  }

  @Override
  public DemoVO throwException() {
    throw new ApiException(DemoErrorCode.VERSION_V1);
  }
}
