package com.kaadas.product.domain;

import com.kaadas.schema.ObjectTypeDefinition;
import lombok.Data;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2024/3/7
 * @since 1.0.0
 */
@Data
public class PropertyTemplate {
  private String id;
  private String code;
  private String title;
  private String description;
  private ObjectTypeDefinition schema;
  private Map<String, Object> uiSchema;

  public static void main(String[] args) {
    PropertyTemplate propertyTemplate = new PropertyTemplate();
    propertyTemplate.setTitle("产品信息");
    propertyTemplate.setCode("product_info");
  }
}
