package com.kaadas;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kaadas.schema.ObjectTypeDefinition;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.Resource;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2024/3/7
 * @since 1.0.0
 */
@Log4j2
//@EnableApiVersion
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class Main implements CommandLineRunner {
  @Value("classpath:productInfo.json")
  Resource schemaJson;

  public static void main(String[] args) {
    SpringApplication.run(Main.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    ObjectMapper mapper = JsonUtils.getObjectMapper();
    ObjectTypeDefinition typeDefinition = mapper.readValue(schemaJson.getURL(), ObjectTypeDefinition.class);
    System.out.println(JsonUtils.serializePretty(typeDefinition));
  }
}