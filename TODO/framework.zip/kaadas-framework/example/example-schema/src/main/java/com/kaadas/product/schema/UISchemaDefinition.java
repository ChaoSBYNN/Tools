package com.kaadas.product.schema;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2024/3/7
 * @since 1.0.0
 */
public class UISchemaDefinition {
  private Map<String, Object> properties;
}
