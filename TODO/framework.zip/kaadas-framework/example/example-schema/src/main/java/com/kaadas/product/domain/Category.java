package com.kaadas.product.domain;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2024/3/7
 * @since 1.0.0
 */
@Data
public class Category {
  private String id;
  private String code;
  private String name;
}
