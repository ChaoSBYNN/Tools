package com.kaadas.product.domain;

import com.kaadas.schema.ObjectTypeDefinition;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2024/3/7
 * @since 1.0.0
 */
@Data
public class ProductTemplate {
  private String id;
  private String code;
  private List<String> categories;
  private String description;
  private ObjectTypeDefinition schema;
  private Map<String, Object> uiSchema;
}
