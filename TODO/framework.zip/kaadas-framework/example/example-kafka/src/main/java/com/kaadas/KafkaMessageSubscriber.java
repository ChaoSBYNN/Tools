package com.kaadas;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;
import java.util.Properties;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-01
 * @since 1.0.0
 */
public class KafkaMessageSubscriber {
  public static void main(String[] args) {
    //    LocalDateTime.now().plusHours(6).toInstant(ZoneOffset.systemDefault())
    System.out.println(Date.from(Instant.now().plus(Duration.ofHours(6))));
    // 设置Kafka服务器地址和端口号
    String bootstrapServers = "10.1.0.156:9092";
    // 配置Kafka消费者属性
    Properties props = new Properties();
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    props.put(ConsumerConfig.GROUP_ID_CONFIG, "console-consumer-86783");
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
    props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

    // 创建Kafka消费者实例
    try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
      // 订阅主题
      consumer.subscribe(Collections.singletonList("mqtt_client_connected"));
      // 循环消费消息
      while (true) {
        // 从Kafka服务器拉取消息记录
        ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(20));
        for (ConsumerRecord<String, String> record : records) {
          // 处理接收到的消息数据
          System.out.println("Received message:" + record);
        }
      }
    }
  }
}
