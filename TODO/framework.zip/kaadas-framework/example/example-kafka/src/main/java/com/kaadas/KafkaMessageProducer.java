package com.kaadas;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-01
 * @since 1.0.0
 */
public class KafkaMessageProducer {
  public static void main(String[] args) throws Exception {
    // 设置Kafka服务器地址和端口号
    String bootstrapServers = "10.1.0.156:9092";

    // 配置Kafka生产者属性
    Properties props = new Properties();
    props.put("bootstrap.servers", bootstrapServers);
    props.put("acks", "all");
    props.put("retries", 0);
    props.put("batch.size", 100000);
    props.put("linger.ms", 1);
    props.put("buffer.memory", 33554432);
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

    // 创建Kafka生产者实例
    Producer<String, String> producer = new org.apache.kafka.clients.producer.KafkaProducer<>(props);

    // 准备消息数据
    String topic = "mqtt_client_connected";
    String key = "my-key";
    String value = "Hello, Kafka!";
    // 创建消息记录并发送到Kafka服务器
    ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);
    producer.send(record, (recordMetadata, e) -> {
      if (e != null) {
        e.printStackTrace();
      }
      System.out.println(recordMetadata.topic() + " " + recordMetadata.partition() + " " + recordMetadata.offset());
    });
    // 关闭Kafka生产者实例
    producer.close();
  }
}
