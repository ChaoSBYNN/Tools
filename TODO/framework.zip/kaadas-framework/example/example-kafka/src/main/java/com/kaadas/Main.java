package com.kaadas;

import org.apache.commons.imaging.ImageReadException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-05-30
 * @since 1.0.0
 */
public class Main {
  public static void main(String[] args) throws IOException, ImageReadException, InterruptedException {
    System.out.println(("{\"timestamp\":1689905285,\"sign\":\"18a87395ea6f02eca38dd0205e393506\",\"type\":1," +
                        "\"customer\":1,\"data\":[{\"sn\":\"K573232910371\"," +
                        "\"password1\":\"B24428674C6F64D79ED70AC6\",\"mac\":\"a4e57c3f72b5\"," +
                        "\"lockSn\":\"Z5352A2307200AA0015656\",\"verList\":null,\"model\":\"F1\"}],\"relay\":true," +
                        "\"customerCode\":\"1\",\"salesModel\":\"F1\",\"research\":\"K5923\"}"
    ).getBytes(StandardCharsets.UTF_8).length);
  }
}