package com.kaadas.protocol.v2x.impl;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public enum Func {
  /** wifi锁事件上报及回复时固定使用 */ wfevent,
  /** 设置门锁时固定使用 */ setLock
}
