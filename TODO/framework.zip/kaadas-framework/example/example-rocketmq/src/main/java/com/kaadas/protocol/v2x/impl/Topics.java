package com.kaadas.protocol.v2x.impl;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public class Topics {
  public static final String EVENT_TEMPLATE = "/orangeiot/{esn}/event";
  public static final String CALL_TEMPLATE = "/orangeiot/{esn}/call";
  public static final String REPLY_TEMPLATE = "/orangeiot/{esn}/reply";

  public static String getEventTopic(String esn) {
    return EVENT_TEMPLATE.replace("{esn}", esn);
  }

  public static String getCallTopic(String esn) {
    return CALL_TEMPLATE.replace("{esn}", esn);
  }

  public static String getReplyTopic(String esn) {
    return REPLY_TEMPLATE.replace("{esn}", esn);
  }
}
