package com.kaadas.mqtt;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@Data
public class ClientDisconnected {
  private String node = "emqx@172.16.3.77";
  private String clientid;
  private String username;
  private String peerhost = "172.16.3.77";
  private String protocol;
  private long timestamp = System.currentTimeMillis();
  private String reason = "normal";
}
