package com.kaadas;

import com.kaadas.rocketmq.RocketmqMessageSubscriber;
import lombok.extern.log4j.Log4j2;
import org.apache.rocketmq.common.message.MessageExt;
import org.jetbrains.annotations.NotNull;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-28
 * @since 1.0.0
 */
@Log4j2
//@Component
public class RocketmqMessageConsumer implements RocketmqMessageSubscriber {

  @Override
  public @NotNull String getTopic() {
    return "test_ref_topic";
  }

  @Override
  public void subscribe(MessageExt message) throws Exception {

  }
}
