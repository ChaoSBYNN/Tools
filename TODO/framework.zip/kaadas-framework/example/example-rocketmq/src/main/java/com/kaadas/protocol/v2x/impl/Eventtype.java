package com.kaadas.protocol.v2x.impl;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public enum Eventtype {
  /** 报警事件，固定使用 */ alarm,
  /** 操作事件，固定使用 */ record,
  /** 记录上报（操作记录和报警记录），固定使用 */ record4binary,
  /** 操作事件，固定使用 */ action,
  /** wifi锁信息上报，固定使用 */ lockInf,
  /** 锁秘钥列表：固定使用 */ list,
  /** 锁最新记录查询，固定使用 */ recordCheck,
  /** wifi锁解绑通知，固定使用 */ unbindNotify,
  /** 设备上报绑定信息通知，固定使用 */ bindInfoNotify,
  /** 通知设备绑定结果，固定使用 */ bindResultNotify,
  network
}
