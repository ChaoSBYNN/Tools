package com.kaadas.protocol.v2x.impl;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public enum Devtype {
  /** 1、纯凯迪仕wifi锁固定用kdswflock表示 */
  kdswflock,
  /** 讯美方案wifi锁固定使用xmkdswflock表示 */
  xmkdswflock,
}
