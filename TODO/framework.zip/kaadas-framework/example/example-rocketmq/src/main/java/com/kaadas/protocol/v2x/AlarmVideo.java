package com.kaadas.protocol.v2x;

import com.kaadas.protocol.v2x.impl.BaseEvent;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-21
 * @since 1.0.0
 */
public class AlarmVideo extends BaseEvent<AlarmVideo.Eventparams> {

  @Data
  public static class Eventparams {
    private String eventId;
    private int txEventId;
    private int alarmCode;
    private int videoStartTime;
    private int videoEndTime;
  }
}
