package com.kaadas.protocol.v2x;

import com.kaadas.protocol.v2x.impl.BaseEvent;
import com.kaadas.protocol.v2x.impl.Eventtype;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @formatter:off
 * {
 *   "msgtype": "event",
 *   "func": "wfevent",
 *   "msgId": 1,
 *   "devtype": "kdswflock",
 *   "eventtype": "network",
 *   "wfId": "{esn}",
 *   "timestamp": "1647840166",
 *   "eventparams": {
 *     "randomCode": "f7263cd529364110bb9ea9fdd0f1a6d9"
 *   }
 * }
 * @formatter:on
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ReportRandomCode extends BaseEvent<ReportRandomCode.Eventparams> {


  @Override
  public final Eventtype getEventtype() {
    return Eventtype.network;
  }

  @Data
  public static class Eventparams {
    /**  */
    private String randomCode;
  }
}
