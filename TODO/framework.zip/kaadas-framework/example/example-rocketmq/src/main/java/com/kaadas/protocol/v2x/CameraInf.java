package com.kaadas.protocol.v2x;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kaadas.protocol.v2x.impl.BaseEvent;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-21
 * @since 1.0.0
 */
public class CameraInf extends BaseEvent<CameraInf.Eventparams> {

  @Data
  public static class Eventparams {
    private String mqttPayloadVersion;
    @JsonProperty("camera_version")
    private String cameraVersion;
    @JsonProperty("WIFIversion")
    private String WIFIversion;
    @JsonProperty("mcu_version")
    private String mcu_version;
    @JsonProperty("screen_version")
    private String screen_version;
    @JsonProperty("device_model")
    private String device_model;
    @JsonProperty("keep_alive_status")
    private String keep_alive_status;
    @JsonProperty("stay_status")
    private String stay_status;
    @JsonProperty("stay_allow_max_times")
    private String stay_allow_max_times;
    @JsonProperty("screenLightSwitch")
    private String screenLightSwitch;
    @JsonProperty("screenLightTime")
    private String screenLightTime;
    @JsonProperty("screenLightLevel")
    private String screenLightLevel;
    @JsonProperty("rssi")
    private String rssi;
    @JsonProperty("wifiStrength")
    private String wifiStrength;
    @JsonProperty("mac")
    private String mac;
  }
}
