package com.kaadas;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-28
 * @since 1.0.0
 */
@Log4j2
//@EnableApiVersion
@SpringBootApplication(scanBasePackages = "com.kaadas")
public class RocketmqStarter implements CommandLineRunner {

  public static void main(String[] args) {
    SpringApplication.run(RocketmqStarter.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    log.info("Running");
  }
}
