package com.kaadas.protocol.v2x.impl;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public enum Msgtype {
  event
}
