package com.kaadas;

import com.kaadas.mqtt.MessagePublish;
import com.kaadas.protocol.v2x.Record;
import com.kaadas.protocol.v2x.Record4binary;
import com.kaadas.protocol.v2x.impl.Devtype;
import com.kaadas.protocol.v2x.impl.Topics;
import com.kaadas.rocketmq.RocketmqProducer;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.rocketmq.common.message.Message;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-02-28
 * @since 1.0.0
 */
@Log4j2
@Order(Ordered.LOWEST_PRECEDENCE)
@Component
//@Configuration()
public class RocketmqMessageProducer implements CommandLineRunner {
  @Resource
  RocketmqProducer rocketmqProducer;

  @Override
  public void run(String... args) throws Exception {
    new Thread(() -> {
      while (true) {
        try {
          BufferedReader reader = Files.newBufferedReader(Paths.get("F:\\CSG023.csv"));
          reader.readLine();
          reader.lines().forEach(line -> {
            String esn = line.split(",")[1];


            List<Record4binary.Eventparam> eventparams = new ArrayList<>();
            Record4binary.Eventparam eventparam = null;

            eventparam = new Record4binary.Eventparam();
            eventparam.setEventType((short) 1);
            eventparam.setEventSource((short) 9);
            eventparam.setEventCode((short) 2);
            eventparam.setUserId((short) 100);
            eventparam.setAppId((short) 0);
            eventparam.setTime((int) (System.currentTimeMillis() / 1000L));
            eventparams.add(eventparam);

            Record4binary record4binary = new Record4binary();
            record4binary.setWfId(esn);
            record4binary.setDevtype(Devtype.kdswflock);
            record4binary.setEventparams(eventparams);

            Record record = new Record();
            record.setWfId(esn);
            Record.Eventparams recordEventparams = new Record.Eventparams();
            recordEventparams.setEventType((short) 1);
            recordEventparams.setEventSource((short) 9);
            recordEventparams.setEventCode((short) 2);
            recordEventparams.setUserId((short) 100);
            recordEventparams.setAppId((short) 0);
            record.setEventparams(recordEventparams);

            MessagePublish messagePublish = new MessagePublish();
            messagePublish.setId(UUID.randomUUID().toString());
            messagePublish.setNode("mqtt@172.16.3.77");
            messagePublish.setFrom("wf:" + esn);
            messagePublish.setQos(0);
            messagePublish.setTopic(Topics.getEventTopic(esn));
            messagePublish.setPayload(record4binary);

            Message message = new Message();
            message.setTopic("mqtt_message_publish");
            message.setBody(JsonUtils.serialize(messagePublish).getBytes(Charset.defaultCharset()));

            System.out.println(JsonUtils.serialize(messagePublish));
            rocketmqProducer.send(message);
            try {
              Thread.sleep(10L);
            } catch (InterruptedException e) {
              throw new RuntimeException(e);
            }
          });
          reader.close();
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }).start();
  }
}
