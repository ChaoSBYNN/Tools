//package com.kaadas.example;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.node.JsonNodeFactory;
//import com.fasterxml.jackson.databind.node.ObjectNode;
//import com.kaadas.AdapterStarter;
//import com.kaadas.iot.event.network.ConfigToken;
//import com.kaadas.iot.event.secret.Cipher;
//import com.kaadas.paas.device.infrastructure.message.DeviceMqttMessageSubscriber;
//import com.kaadas.paas.device.infrastructure.rocketmq.DeviceConnectedMessageSubscriber;
//import com.kaadas.paas.device.infrastructure.rocketmq.DeviceDisconnectedMessageSubscriber;
//import com.kaadas.paas.openapi.infrastructure.redis.ConfigTokenRedisRepository;
//import com.kaadas.paas.shadow.Instruction;
//import com.kaadas.paas.shadow.Shadow;
//import com.kaadas.paas.shadow.ShadowFactory;
//import com.kaadas.protocol.ota.OtaNotify;
//import com.kaadas.protocol.v2.V20Topic;
//import com.kaadas.util.JsonUtils;
//import com.kaadas.util.Lists;
//import com.kaadas.util.Maps;
//import com.kaadas.util.TimestampUtils;
//import org.junit.jupiter.api.*;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.context.annotation.Profile;
//
//import javax.annotation.Resource;
//import java.nio.ByteBuffer;
//import java.util.Base64;
//import java.util.List;
//import java.util.Map;
//import java.util.UUID;
//
///**
// * TODO
// *
// * @author df
// * @date 2022-03-24
// * @since 1.0.0
// */
//public class DeviceMessageTest {
//  private ObjectMapper objectMapper = JsonUtils.getObjectMapper();
//  private String esn = "79F0220810001";
//
//  Maps.NewMap<String, Object> newEventMap(int msgId, String eventType) {
//    return Maps
//      .<String, Object>newHashMap()
//      .put("msgtype", "event")
//      .put("func", "wfevent")
//      .put("lockId", "W9120C2104270DC0287961")
//      .put("msgId", msgId)
//      .put("devtype", "kdswflock")
//      .put("eventtype", eventType)
//      .put("wfId", esn)
//      .put("timestamp", TimestampUtils.seconds());
//  }
//
//  Maps.NewMap<String, Object> newReplyMap(int msgId, String func) {
//    return Maps
//      .<String, Object>newHashMap()
//      .put("msgtype", "response")
//      .put("func", func)
//      .put("msgId", msgId)
//      .put("devtype", "kdswflock")
//      .put("wfId", esn)
//      .put("code", 200)
//      .put("timestamp", TimestampUtils.seconds());
//  }
//
//  public void testOnline() {
//    deviceConnectedMessageSubscriber.subscribe(newOnline(esn));
//  }
//
//  public void testOffline() {
//    deviceDisconnectedMessageSubscriber.subscribe(newOffline(esn));
//  }
//
//  public void testNetwork() throws Exception {
//    String uuid = "61c9847f0307a135d2a1135f";
//    ConfigToken configToken =
//      configTokenRedisRepository.getToken(uuid, 15, Maps.<String, Object>newHashMap().put("uid", uuid).getMap());
//    //"\"triple\":\"ZF39IBNGP2;KDS_69610537_7;aANONWLbWXh7ZQZF2grNaw==\"
//    Map<String, Object> map = newEventMap(2, "network")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("randomCode", "BEFD7E5B497AAB50333F238FF24BA3A011BA946FB76A26BAF4F68D6BA4A28D5200KVP02137100027B")
//          .put("token", configToken.getToken())
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(2)
//  public void testNetworkReply() throws Exception {
//    //"\"triple\":\"ZF39IBNGP2;KDS_69610537_7;aANONWLbWXh7ZQZF2grNaw==\"
//    Map<String, Object> map = newReplyMap(2, "network").put("params", Maps.newHashMap().getMap()).getMap();
//    deviceMqttMessageSubscriber.subscribe(newReplyMessage(map));
//  }
//
//
//  @Test
//  @Order(3)
//  public void testLockInf() throws Exception {
//    Map<String, Object> map = newEventMap(3, "lockInf")
//      .put("mqttPayloadVersion", "2.0.4")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("sn", esn)
//          .put("D8M21_1", "V1.32.004")
//          .put("D8M21_3", "V1.01.010")
//          .put("D8M21_6", "V1.33.005")
//          .put("709VP_7", "V1.32.008")
//          .put("voiceVersion", "050104")
//          .put("MQTTversion", "3.1.1")
//          .put("functionSet", 185)
//          .put("lockModel", "D8M21")
//          .put("RSSI", "-43dBm")
//          .put("mac", "04:78:63:95:e9:36")
//          .put("BISSID", "10:5d:dc:6b:8c")
//          .put("wifiStrength", 100)
//          .put("power", 31)
//          .getMap())
//      .getMap();
//
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(4)
//  public void testList() throws Exception {
//    Map<String, Object> map = newEventMap(4, "list")
//      .put("mqttPayloadVersion", "2.0.4")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("p", "AABiQtHHYkLRx2JC0ccA")
//          .put("f",
//            "AAFiQtHHYkLRx2JC0ccAAAJiQtHHYkLRx2JC0ccAAANiQtHHYkLRx2JC0ccAAARiQtHHYkLRx2JC0ccAAAViQtHHYkLRx2JC0ccAAAZiQtHHYkLRx2JC0ccA")
//          .put("c", "")
//          .put("r",
//            "AABiQtHHYkLRx2JC0ccAAAFiQtHHYkLRx2JC0ccAAAJiQtHHYkLRx2JC0ccAAANiQtHHYkLRx2JC0ccAAARiQtHHYkLRx2JC0ccA")
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  public void testGet() {
//    shadowFactory.get(esn).getProp("faces", new TypeReference<List<Cipher>>() {}).forEach(cipher -> {
//      System.out.println(cipher);
//    });
//  }
//
//  @Test
//  @Order(5)
//  public void testCameraInf() throws Exception {
//    Map<String, Object> map = newEventMap(5, "cameraInf")
//      .put("devtype", "xmkdswflock")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("mqttPayloadVersion", "2.0.4")
//          .put("camera_version", "2.0.17-20201229")
//          .put("WIFIversion", "1.2.6-20210204")
//          .put("mcu_version", "0.1.3")
//          .put("device_model", "K10V01")
//          .put("stay_status", 0)
//          .put("setPir", Maps.newHashMap().put("stay_time", 30).put("pir_sen", 35).getMap())
//          .put("keep_alive_status", 0)
//          .put("alive_time",
//            Maps
//              .newHashMap()
//              .put("snooze_start_time", 0)
//              .put("snooze_end_time", 86400)
//              .put("keep_alive_snooze", Lists.newArrayList(1, 2, 3, 4, 5, 6, 7))
//              .getMap())
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(6)
//  public void testRecord() throws Exception {
//    Map<String, Object> map = newEventMap(6, "record")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("eventType", 1)
//          .put("eventSource", 0)
//          .put("eventCode", 2)
//          .put("userID", 0)
//          .put("appID", 0)
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(7)
//  public void testAction() throws Exception {
//    Map<String, Object> map = newEventMap(13, "action")
//      .put("devtype", "xmkdswflock")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("amMode", 0)
//          .put("safeMode", 1)
//          .put("defences", 0)
//          .put("language", "zh")
//          .put("operatingMode", 0)
//          .put("volLevel", 2)
//          .put("powerSave", 0)
//          .put("openForce", 1)
//          .put("lockingMethod", 1)
//          .put("openDirection", 1)
//          .put("hoverAlarm", 0)
//          .put("hoverAlarmLevel", 1)
//          .put("faceStatus", 1)
//          .put("bodySensor", 1)
//          .put("touchHandleStatus", 1)
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(9)
//  public void testAlarm() throws Exception {
//    Map<String, Object> map = newEventMap(14, "alarm")
//      .put("devtype", "xmkdswflock")
//      .put("eventparams", Maps.newHashMap().put("alarmCode", 96).put("clusterID", 257).put("txEventId", 2).getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(10)
//  public void testAlarmVideo() throws Exception {
//    Map<String, Object> map = newEventMap(14, "alarm_video")
//      .put("devtype", "xmkdswflock")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("eventId", "62e2000e36fc3f6352559c88")
//          .put("videoStartTime", 1647960371)
//          .put("videoEndTime", 1647960386)
//          .put("alarmCode", 96)
//          .put("clusterID", 257)
//          .put("txEventId", 2)
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(10)
//  public void testOta() throws Exception {
//    int msgId = 15;
//    OtaNotify.NotifyPayload notifyPayload = new OtaNotify.NotifyPayload();
//    notifyPayload.setDevNum("1");
//    notifyPayload.setFileMd5("6934ad76b7be4698fffe73c0aa638493");
//    notifyPayload.setFileLen(834608);
//    notifyPayload.setFileExpires(32400);
//    notifyPayload.setFileUrl(
//      "47.106.94.189/otaFiles/f173c0bd3ea24a3f9eac52b04ecb2a89?filename=D8M21_WIFI$1_OTA_V1.32" + ".004.bin");
//    notifyPayload.setVersion("V1.32.004");
//    OtaNotify otaNotify = new OtaNotify();
//    otaNotify.setMsgId(msgId);
//    otaNotify.setParams(notifyPayload);
//    Shadow shadow = shadowFactory.get(esn);
//    shadow.putIns(OtaNotify.class.getSimpleName() + "_" + msgId, Instruction.published(otaNotify));
//
//    Map<String, Object> map = newReplyMap(msgId, "otaNotify").getMap();
//    deviceMqttMessageSubscriber.subscribe(newReplyMessage(map));
//  }
//
//  @Test
//  @Order(11)
//  public void testRecordCheck() throws Exception {
//    String recordCheck = "{\"lockId\":\"W9120C2104270DC0287961\",\"devtype\":\"xmkdswflock\",\"eventparams\":{}," +
//                         "\"func\":\"wfevent\",\"msgId\":3,\"eventtype\":\"recordCheck\",\"msgtype\":\"event\"," +
//                         "\"wfId\":\"K201234567890\",\"timestamp\":\"1609769200\"}";
//    Map<String, Object> map = newEventMap(16, "recordCheck").put("devtype", "xmkdswflock").getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//static   Base64.Encoder encoder = Base64.getEncoder();
//
////  public static void main(String[] args) {
////    ByteBuffer buffer = ByteBuffer.allocate(9);
////    buffer.put((byte) 1);
////    buffer.put((byte) 0);
////    buffer.put((byte) 2);
////    buffer.put((byte) 0);
////    buffer.put((byte) 0);
////    buffer.putInt((int) (System.currentTimeMillis() / 1000L));
//////    buffer.position(0);
////    buffer.flip();
////    System.out.println(encoder.encodeToString(buffer.array()));
////  }
//  @Test
//  @Order(12)
//  public void testRecord4Binary() throws Exception {
//    ByteBuffer buffer = ByteBuffer.allocate(9);
//    buffer.put((byte) 1);
//    buffer.put((byte) 0);
//    buffer.put((byte) 2);
//    buffer.put((byte) 0);
//    buffer.put((byte) 0);
//    buffer.putInt((int) (System.currentTimeMillis() / 1000L));
//    Map<String, Object> map = newEventMap(17, "record4binary")
//      .put("devtype", "xmkdswflock")
//      .put("eventparams", "AQACAABi/gD9")
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(13)
//  public void testOtaResult() throws Exception {
//    int msgId = 18;
//    OtaNotify.NotifyPayload notifyPayload = new OtaNotify.NotifyPayload();
//    notifyPayload.setDevNum("1");
//    notifyPayload.setFileMd5("6934ad76b7be4698fffe73c0aa638493");
//    notifyPayload.setFileLen(834608);
//    notifyPayload.setFileExpires(32400);
//    notifyPayload.setFileUrl(
//      "47.106.94.189/otaFiles/f173c0bd3ea24a3f9eac52b04ecb2a89?filename=D8M21_WIFI$1_OTA_V1.32" + ".004.bin");
//    notifyPayload.setVersion("V1.32.004");
//
//    Map<String, Object> map = newEventMap(msgId, "otaResult")
//      .put("eventparams",
//        Maps
//          .newHashMap()
//          .put("devNum", "1")
//          .put("resultCode", 0)
//          .put("currentVersion", "V1.32.004")
//          .put("otaTime", 0)
//          .getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  @Test
//  @Order(14)
//  public void testP2pInfo() throws Exception {
//    int msgId = 19;
//    Map<String, Object> map = newEventMap(msgId, "p2p_info")
//      .put("eventparams", Maps.newHashMap().put("p2pInfo", "XP2PKOo73Q7u+J2x5bCjRSH0Lg==%2.4.26").getMap())
//      .getMap();
//    deviceMqttMessageSubscriber.subscribe(newEventMessage(map));
//  }
//
//  private byte[] newOnline(String username) {
//    ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
//    objectNode.put("node", "emqx@127.0.0.1");
//    objectNode.put("clientid", "wf:" + username);
//    objectNode.put("username", username);
//    objectNode.put("peerhost", "127.0.0.1");
//    objectNode.put("protocol", "3.1");
//    objectNode.put("timestamp", System.currentTimeMillis());
//    try {
//      return objectMapper.writeValueAsBytes(objectNode);
//    } catch (JsonProcessingException e) {
//      return new byte[0];
//    }
//  }
//
//  private byte[] newOffline(String username) {
//    ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
//    objectNode.put("node", "emqx@127.0.0.1");
//    objectNode.put("clientid", "wf:" + username);
//    objectNode.put("username", username);
//    objectNode.put("peerhost", "127.0.0.1");
//    objectNode.put("protocol", "3.1");
//    objectNode.put("reason", "Timeout");
//    objectNode.put("timestamp", System.currentTimeMillis());
//    try {
//      return objectMapper.writeValueAsBytes(objectNode);
//    } catch (JsonProcessingException e) {
//      return new byte[0];
//    }
//  }
//
//  private byte[] newEventMessage(Map<String, Object> map) {
//    ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
//    objectNode.put("id", UUID.randomUUID().toString());
//    objectNode.put("node", "emqx@127.0.0.1");
//    objectNode.put("from", "wf:" + esn);
//    objectNode.put("topic", V20Topic.Device.EVENT.get(esn));
//    objectNode.put("qos", 1);
//    objectNode.putPOJO("payload", map);
//    objectNode.put("timestamp", System.currentTimeMillis());
//    try {
//      return objectMapper.writeValueAsBytes(objectNode);
//    } catch (JsonProcessingException e) {
//      return new byte[0];
//    }
//  }
//
//  private byte[] newReplyMessage(Map<String, Object> map) {
//    ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
//    objectNode.put("id", UUID.randomUUID().toString());
//    objectNode.put("node", "emqx@127.0.0.1");
//    objectNode.put("from", "wf:" + esn);
//    objectNode.put("topic", V20Topic.Device.REPLY.get(esn));
//    objectNode.put("qos", 1);
//    objectNode.putPOJO("payload", map);
//    objectNode.put("timestamp", System.currentTimeMillis());
//    try {
//      return objectMapper.writeValueAsBytes(objectNode);
//    } catch (JsonProcessingException e) {
//      return new byte[0];
//    }
//  }
//
//  private byte[] newMessage(String sn, V20Topic topic, String payload) {
//    ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
//    objectNode.put("id", UUID.randomUUID().toString());
//    objectNode.put("node", "emqx@127.0.0.1");
//    objectNode.put("from", "wf:" + sn);
//    objectNode.put("topic", topic.get(sn));
//    objectNode.put("qos", 1);
//    objectNode.putPOJO("payload", JsonUtils.toMap(payload));
//    objectNode.put("timestamp", System.currentTimeMillis());
//    try {
//      return objectMapper.writeValueAsBytes(objectNode);
//    } catch (JsonProcessingException e) {
//      return new byte[0];
//    }
//  }
//
//
//}