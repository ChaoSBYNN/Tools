package com.kaadas.protocol.v2x;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kaadas.protocol.v2x.impl.BaseEvent;
import com.kaadas.protocol.v2x.impl.Eventtype;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @formatter:off
 * {
 *   "msgtype": "event",
 *   "func": "wfevent",
 *   "msgId": 4,
 *   "devtype": "kdswflock",
 *   "eventtype": "bindInfoNotify",
 *   "wfId": "wfuuid",
 *   "timestamp": "1541468973342",
 *   "eventparams": {
 *     "uid": "xxxxxx",
 *     "randomCode": " XXXX",
 *     "device_sn": "xxxxxx",
 *     "device_model": " XXXX",
 *     "mac": "xxxxxx",
 *     "device_did": " XXXX",
 *     "p2p_password": " XXXX"
 *   }
 * }
 * @formatter:on
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BindInfoNotify extends BaseEvent<BindInfoNotify.Eventparams> {

  @Override
  public final Eventtype getEventtype() {
    return Eventtype.bindInfoNotify;
  }

  @Data
  public static class Eventparams {
    /** 用户ID */
    private String uid;
    /**  */
    private String randomCode;
    /** 28字节的随机数+4字节CRC+13字节wifiSN+1字节功能集 */
    @JsonProperty("device_sn")
    private String deviceSn;
    /** p2p登录ID */
    @JsonProperty("device_model")
    private String deviceModel;
    /** 硬件版本 */
    private String mac;
    /** Wifi MAC曾经使用，现在没用 */
    @JsonProperty("device_did")
    private String deviceDid;
    /** p2p 设备ID，讯美写入 */
    @JsonProperty("p2p_password")
    private String p2pPassword;


  }
}
