package com.kaadas.protocol.v2x.impl;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@Data
public abstract class BaseEvent<E> {
  @Setter(AccessLevel.PROTECTED)
  private Func func = Func.wfevent;
  @Setter(AccessLevel.PROTECTED)
  private Eventtype eventtype;
  @Setter(AccessLevel.PROTECTED)
  private Msgtype msgtype = Msgtype.event;
  /** 用来配对请求与响应. 范围: [1, 255] */
  private short msgId;
  /** 设备类型 */
  private Devtype devtype;
  private String timestamp = String.valueOf(System.currentTimeMillis() / 1000L);
  private String wfId;
  private E eventparams;
}
