package com.kaadas.protocol.v2x;

import com.kaadas.protocol.v2x.impl.BaseEvent;
import com.kaadas.protocol.v2x.impl.Devtype;
import com.kaadas.protocol.v2x.impl.Eventtype;
import com.kaadas.protocol.v2x.impl.Func;
import com.kaadas.util.JsonUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.jetbrains.annotations.NotNull;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Record4binary extends BaseEvent<String> {

  private List<Mediaparams> mediaparams;

  public static void main(String[] args) {
    List<Eventparam> eventparams = new ArrayList<>();
    Eventparam eventparam = null;

    eventparam = new Eventparam();
    eventparam.setEventType((short) 1);
    eventparam.setEventSource((short) 9);
    eventparam.setEventCode((short) 2);
    eventparam.setUserId((short) 100);
    eventparam.setAppId((short) 0);
    eventparam.setTime(1686760242);
    eventparams.add(eventparam);


    eventparam = new Eventparam();
    eventparam.setEventType((short) 1);
    eventparam.setEventSource((short) 255);
    eventparam.setEventCode((short) 1);
    eventparam.setUserId((short) 255);
    eventparam.setAppId((short) 0);
    eventparam.setTime(1686760247);
    eventparams.add(eventparam);


    Record4binary record4binary = new Record4binary();
    record4binary.setWfId("ASD");
    record4binary.setDevtype(Devtype.kdswflock);
    record4binary.setFunc(Func.wfevent);
    record4binary.setEventparams(eventparams);
    System.out.println(JsonUtils.serialize(record4binary));
  }

  @Override
  public Eventtype getEventtype() {
    return Eventtype.record4binary;
  }

  public void setEventparams(List<Eventparam> eventparams) {
    eventparams.sort(Comparator.reverseOrder());
    ByteBuffer buffer = ByteBuffer.allocate(eventparams.size() * 9);
    eventparams.forEach(eventparam -> {
      buffer.put((byte) eventparam.getEventType());
      buffer.put((byte) eventparam.getEventSource());
      buffer.put((byte) eventparam.getEventCode());
      buffer.put((byte) eventparam.getUserId());
      buffer.put((byte) eventparam.getAppId());
      buffer.putInt(eventparam.getTime());
    });
    setEventparams(Base64.getEncoder().encodeToString(buffer.array()));
    buffer.clear();
  }

  @Data
  public static class Eventparam implements Comparable<Eventparam> {
    private short eventType;
    private short eventSource;
    private short eventCode;
    private short userId;
    private short appId;
    private int time;

    @Override
    public int compareTo(@NotNull Record4binary.Eventparam o) {
      return time - o.time;
    }
  }

  @Data
  public static class Mediaparams {
    private String eventId;
    private int thumbState;
    private int time;
    private int startTime;
    private int fileDate;
    private String fileName;
    private int height;
    private int width;
    private int type;
    private int offsetTime;
  }
}
