package com.kaadas.mqtt;

import com.fasterxml.jackson.databind.JsonNode;
import com.kaadas.protocol.v2x.Record;
import com.kaadas.protocol.v2x.Record4binary;
import com.kaadas.protocol.v2x.impl.Devtype;
import com.kaadas.protocol.v2x.impl.Topics;
import com.kaadas.schema.ObjectTypeDefinition;
import com.kaadas.util.JsonUtils;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import org.apache.rocketmq.common.message.Message;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
public class CsvUtils {

  public static void main(String[] args) throws IOException {
    String filename = CsvUtils.class.getResource("/").getFile() + "schema/event/Record.json";
    JsonSchemaFactory jsonSchemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
    JsonNode schemaNode = JsonUtils.getObjectMapper().readTree(new File(filename));

    ObjectTypeDefinition typeDefinition =
      JsonUtils.getObjectMapper().treeToValue(schemaNode, ObjectTypeDefinition.class);
    System.out.println(typeDefinition);
    JsonSchema jsonSchema = jsonSchemaFactory.getSchema(schemaNode);

    BufferedReader reader = Files.newBufferedReader(Paths.get("F:\\CSG023.csv"));
    reader.readLine();
    String line = reader.readLine();
    //    reader.lines().forEach(line -> {
    String esn = line.split(",")[1];


    List<Record4binary.Eventparam> eventparams = new ArrayList<>();
    Record4binary.Eventparam eventparam = null;

    eventparam = new Record4binary.Eventparam();
    eventparam.setEventType((short) 1);
    eventparam.setEventSource((short) 9);
    eventparam.setEventCode((short) 2);
    eventparam.setUserId((short) 100);
    eventparam.setAppId((short) 0);
    eventparam.setTime((int) (System.currentTimeMillis() / 1000L));
    eventparams.add(eventparam);

    Record4binary record4binary = new Record4binary();
    record4binary.setWfId(esn);
    record4binary.setDevtype(Devtype.kdswflock);
    record4binary.setEventparams(eventparams);

    Record record = new Record();
    record.setWfId(esn);
    record.setDevtype(Devtype.kdswflock);
    Record.Eventparams recordEventparams = new Record.Eventparams();
    recordEventparams.setEventType((short) 1);
    recordEventparams.setEventSource((short) 9);
    recordEventparams.setEventCode((short) 2);
    recordEventparams.setUserId((short) 100);
    recordEventparams.setAppId((short) 0);
    record.setEventparams(recordEventparams);
    jsonSchema.validate(JsonUtils.getObjectMapper().valueToTree(record)).forEach(validationMessage -> {
      System.out.println(validationMessage.getMessage());
    });

    MessagePublish messagePublish = new MessagePublish();
    messagePublish.setId(UUID.randomUUID().toString());
    messagePublish.setNode("mqtt@172.16.3.77");
    messagePublish.setFrom("wf:" + esn);
    messagePublish.setQos(0);
    messagePublish.setTopic(Topics.getEventTopic(esn));
    messagePublish.setPayload(record4binary);

    Message message = new Message();
    message.setTopic("mqtt_message_publish");
    message.setBody(JsonUtils.serialize(messagePublish).getBytes(Charset.defaultCharset()));

    System.out.println(JsonUtils.serialize(record));
    try {
      Thread.sleep(10L);
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
    //    });
    reader.close();
  }
}
