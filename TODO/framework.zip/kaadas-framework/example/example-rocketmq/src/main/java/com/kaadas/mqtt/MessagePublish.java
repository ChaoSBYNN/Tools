package com.kaadas.mqtt;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@Data
public class MessagePublish {
  private String id;
  private String node;
  private String from;
  private String topic;
  private int qos;
  private long timestamp = System.currentTimeMillis();
  private Object payload;
}