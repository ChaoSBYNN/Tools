package com.kaadas.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.kaadas.mqtt.CsvUtils;
import com.kaadas.schema.IntegerTypeDefinition;
import com.kaadas.schema.JsonType;
import com.kaadas.schema.ObjectTypeDefinition;
import com.kaadas.schema.StringTypeDefinition;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.NumberUtils;

import java.io.File;
import java.io.IOException;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-21
 * @since 1.0.0
 */
public class JsonSchemaToPojo {
  public static void main(String[] args) throws IOException {
    String filename = CsvUtils.class.getResource("/").getFile() + "schema/event/Record.json";
    JsonNode schemaNode = JsonUtils.getObjectMapper().readTree(new File(filename));
    ObjectTypeDefinition typeDefinition =
      JsonUtils.getObjectMapper().treeToValue(schemaNode, ObjectTypeDefinition.class);
    String title = typeDefinition.getTitle();
    int lastIndexOf = title.lastIndexOf(".");
    String javaname = "Pojo";
    String javapackage = "com.kaadas.jsonschema";
    if (lastIndexOf > -1) {
      javapackage = title.substring(0, lastIndexOf);
      javaname = title.substring(lastIndexOf + 1, title.length());
    }
    System.out.println("package " + javapackage + ";");
    System.out.println();
    System.out.println("/** " + typeDefinition.getDescription() + " */");
    System.out.println("public class " + javaname + " {");
    typeDefinition.getProperties().forEach((k, v) -> {
      JsonType propType = v.getType();
      System.out.println("  /** " + v.getDescription() + " */");
      switch (propType) {
        case STRING:
          StringTypeDefinition std = (StringTypeDefinition) v;
          if (std.getConstVal() != null) {
            System.out.println("  private final String " + k + " = \"" + std.getConstVal() + "\";");
          }
          System.out.println("  private String " + k + ";");
          break;
        case NUMBER:
          System.out.println("  private Number " + k + ";");
          break;
        case INTEGER:
          IntegerTypeDefinition itd = (IntegerTypeDefinition) v;
          long maximum = NumberUtils.toLong(itd.getMaximum(), 0L);
          if (maximum <= Byte.MAX_VALUE) {
            System.out.println("  private Byte " + k + ";");
          } else if (maximum <= Short.MAX_VALUE) {
            System.out.println("  private Short " + k + ";");
          } else if (maximum <= Integer.MAX_VALUE) {
            System.out.println("  private Integer " + k + ";");
          } else {
            System.out.println("  private Long " + k + ";");
          }
          break;
        case OBJECT:
          System.out.println("  private Object " + k + ";");
          break;
        case ANY:
          System.out.println("  private Object " + k + ";");
          break;
        case ARRAY:
          System.out.println("  private List " + k + ";");
          break;
        case BOOLEAN:
          System.out.println("  private Boolean " + k + ";");
          break;
        default:
          break;
      }
    });
    System.out.println("}");
  }
}
