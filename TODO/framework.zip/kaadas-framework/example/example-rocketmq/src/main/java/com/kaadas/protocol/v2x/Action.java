package com.kaadas.protocol.v2x;

import com.kaadas.protocol.v2x.impl.BaseEvent;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-21
 * @since 1.0.0
 */
public class Action extends BaseEvent<Action.Eventparams> {

  @Data
  public static class Eventparams {
    private int amMode;
    private int safeMode;
    private int defences;
    private String language;
    private int operatingMode;
    private int volume;
    private int volLevel;
    private int powerSave;
    private int openForce;
    private int lockingMethod;
    private int openDirection;
    private int faceStatus;
    private int bodySensor;
    private int touchHandleStatus;
    private int hoverAlarm;
    private int hoverAlarmLevel;
  }
}
