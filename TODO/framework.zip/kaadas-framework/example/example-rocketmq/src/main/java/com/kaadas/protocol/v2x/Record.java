package com.kaadas.protocol.v2x;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kaadas.protocol.v2x.impl.BaseEvent;
import com.kaadas.protocol.v2x.impl.Eventtype;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2023-06-19
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Record extends BaseEvent<Record.Eventparams> {

  @Override
  public Eventtype getEventtype() {
    return Eventtype.record;
  }

  @Data
  public static class Eventparams {
    private short eventType;
    private short eventSource;
    private short eventCode;
    @JsonProperty("userID")
    private short userId;
    @JsonProperty("appID")
    private short appId;
  }
}
