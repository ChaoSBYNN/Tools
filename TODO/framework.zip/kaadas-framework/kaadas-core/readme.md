## EMQX

### Hook

**启用Hook**

```properties
kaadas.emqx.hook.grpc.enabled=true
```

**配置项**

```properties
kaadas.emqx.hook.grpc=9000
```

### API

**启用API**

```properties
kaadas.emqx.api.enabled=true
`kaadas.emqx.api.url=
kaadas.emqx.api.username=
kaadas.emqx.api.password=`
kaadas.emqx.api.poolSize=
```

## RocketMQ

```properties
kaadas.rocketmq.consumer.enabled=true
kaadas.rocketmq.namesrvAddr=127.0.0.1:9876
# 消费线程池最小线程数，默认值：20
kaadas.rocketmq.consumer.consumeThreadMin=20
# 消费线程池最大线程数，默认值：20。请与最小线程数保持一致。
kaadas.rocketmq.consumer.consumeThreadMax=20

# 单队列并行消费位点允许的最大跨度，默认值：2000，允许区间为[1,65535]。
kaadas.rocketmq.consumer.consumeConcurrentlyMaxSpan=2000
# 拉消息本地队列缓存消息最大数，默认值：1000，单位：条，允许区间为[1,65535]。
kaadas.rocketmq.consumer.pullThresholdForQueue=1000
# 单队列本地最大缓存消息数量，默认值：100，单位：MB，允许区间为[1,1024]。
kaadas.rocketmq.consumer.pullThresholdSizeForQueue=100
# 最大重试次数，默认值：-1，单位：次。 */
kaadas.rocketmq.consumer.maxReconsumeTimes=-1
# 顺序消息最小重试间隔，默认值：1000，单位：毫秒，允许区间为[10,30000]。
kaadas.rocketmq.consumer.suspendCurrentQueueTimeMillis=1000
kaadas.rocketmq.consumer.consumeMessageBatchMaxSize=1
kaadas.rocketmq.consumer.pullBatchSize=32
```