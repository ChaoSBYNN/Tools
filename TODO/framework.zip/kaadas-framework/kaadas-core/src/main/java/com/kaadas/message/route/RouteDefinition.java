package com.kaadas.message.route;

import com.kaadas.schema.TypeDefinition;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-10
 * @since 1.0.0
 */
@Data
public class RouteDefinition {
  private String id;
  /** /orangeiot/{esn}/call */
  private String topic;
  private String protocol;
  private String version;
  private List<PredicateConf> predicates;
  private List<FilterConf> filters;
  private List<String> handlers;
  /** JsonSchema */
  private TypeDefinition<?> schema;

  public RouteDefinition() {}

  public RouteDefinition(String id, String topic, String protocol, String version, List<PredicateConf> predicates,
                         List<FilterConf> filters, List<String> handlers, TypeDefinition<?> schema) {
    this.id = id;
    this.topic = topic;
    this.protocol = protocol;
    this.version = version;
    this.predicates = predicates;
    this.filters = filters;
    this.handlers = handlers;
    this.schema = schema;
  }

  public static RouteDefinitionBuilder builder() {return new RouteDefinitionBuilder();}

  public static class RouteDefinitionBuilder {
    private String id;
    private String topic;
    private String protocol;
    private String version;
    private List<PredicateConf> predicates;
    private List<FilterConf> filters;
    private List<String> handlers;
    private TypeDefinition<?> schema;

    RouteDefinitionBuilder() {
      predicates = new ArrayList<>();
      filters = new ArrayList<>();
      handlers = new ArrayList<>();
    }

    public RouteDefinitionBuilder id(String id) {
      this.id = id;
      return this;
    }

    public RouteDefinitionBuilder topic(String topic) {
      this.topic = topic;
      return this;
    }

    public RouteDefinitionBuilder protocol(String protocol) {
      this.protocol = protocol;
      return this;
    }

    public RouteDefinitionBuilder version(String version) {
      this.version = version;
      return this;
    }

    public RouteDefinitionBuilder addPredicate(PredicateConf predicate) {
      this.predicates.add(predicate);
      return this;
    }

    public RouteDefinitionBuilder predicates(List<PredicateConf> predicates) {
      this.predicates.addAll(predicates);
      return this;
    }

    public RouteDefinitionBuilder addFilter(FilterConf filter) {
      this.filters.add(filter);
      return this;
    }

    public RouteDefinitionBuilder filters(List<FilterConf> filters) {
      this.filters.addAll(filters);
      return this;
    }

    public RouteDefinitionBuilder addHandler(String handler) {
      this.handlers.add(handler);
      return this;
    }

    public RouteDefinitionBuilder handlers(List<String> handlers) {
      this.handlers.addAll(handlers);
      return this;
    }

    public RouteDefinitionBuilder schema(TypeDefinition<?> schema) {
      this.schema = schema;
      return this;
    }

    public RouteDefinition build() {
      return new RouteDefinition(id, topic, protocol, version, predicates, filters, handlers, schema);
    }

    public String toString() {
      return "RouteDefinition.RouteDefinitionBuilder(id=" + this.id + ", topic=" + this.topic + ", protocol=" +
             this.protocol + ", version=" + this.version + ", predicates=" + this.predicates + ", filters=" +
             this.filters + ", handlers=" + this.handlers + ", schema=" + this.schema + ")";
    }
  }
}
