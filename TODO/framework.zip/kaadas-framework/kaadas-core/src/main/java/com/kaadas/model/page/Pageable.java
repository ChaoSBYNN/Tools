package com.kaadas.model.page;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kaadas.util.StringUtils;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-06
 * @since 1.0.0
 */
@Data
public class Pageable {
  @Getter(AccessLevel.NONE)
  private final String springPageable = "org.springframework.data.domain.Pageable";
  @Getter(AccessLevel.NONE)
  private final String mybatisIPage = "com.baomidou.mybatisplus.core.metadata.IPage";
  @Getter(AccessLevel.NONE)
  private final String mybatisPage = "com.baomidou.mybatisplus.extension.plugins.pagination.Page";
  private int num;
  private int size;
  private Object sort;
  @Setter(AccessLevel.PRIVATE)
  private List<Sort> sorts;

  public void setSort(Object sort) {
    if (sort == null) {
      return;
    }
    this.sort = sort;
    List<String> sorts = null;
    if (sort instanceof String) {
      sorts = Arrays.asList(((String) sort).split(","));
    } else if (sort.getClass().isArray()) {
      sorts = Arrays.asList((String[]) sort);
    } else if (sort instanceof List) {
      sorts = (List<String>) sort;
    } else {
      return;
    }
    this.sorts = sorts.stream()
      .filter(StringUtils::isNotBlank)
      .map(str -> {
        str = str.trim();
        if (!str.endsWith("+") && !str.endsWith("-")) {
          str = str + "+";
        }
        return Sort.by(str.substring(0, str.length() - 1))
          .order(str.endsWith("+") ? 1 : -1);
      }).collect(Collectors.toList());
  }

  @JsonIgnore
  public Pageable sorts(String[] sorts) {
    return this;
  }

  @SuppressWarnings("unchecked")
  public <T> T toPageable(Class<T> tClass) {
    String className = tClass.getName();
    if (springPageable.equals(className)) {
      return (T) SpringPageUtils.toPageable(this);
    }
    if (mybatisIPage.equals(className) || mybatisPage.equals(className)) {
      return (T) MybatisPageUtils.toPage(this);
    }
    throw new UnsupportedOperationException("Convert to " + tClass.getName());
  }

  @Data
  public static class Sort {
    /** 排序的字段 */
    private String by;
    /** 正序： 1， 倒序：-1 */
    private int order;

    public Sort() {
    }

    public Sort(String by, int order) {
      if (StringUtils.isBlank(by)) {
        throw new IllegalArgumentException("Sort by must be not empty !");
      }
      this.by = by;
      this.order = order;
    }

    public static Sort by(String by) {
      return new Sort(by, 0);
    }

    public Sort order(int order) {
      this.order = order;
      return this;
    }

    @JsonIgnore
    public Sort asc() {
      this.order = 1;
      return this;
    }

    @JsonIgnore
    public Sort desc() {
      this.order = -1;
      return this;
    }


    @JsonIgnore
    public boolean isAsc() {
      return order >= 0;
    }

    @JsonIgnore
    public boolean isDesc() {
      return order < 0;
    }
  }
}
