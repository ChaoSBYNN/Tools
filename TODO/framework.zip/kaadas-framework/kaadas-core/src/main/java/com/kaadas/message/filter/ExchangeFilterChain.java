package com.kaadas.message.filter;


import com.kaadas.message.Exchange;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-24
 * @since 1.0.0
 */
public interface ExchangeFilterChain {
  /**
   * TODO
   *
   * @param exchange param1
   * @date 2022-06-24 17:09
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  void filter(Exchange exchange);
}
