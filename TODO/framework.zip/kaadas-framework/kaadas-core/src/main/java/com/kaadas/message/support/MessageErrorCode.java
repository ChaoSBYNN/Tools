package com.kaadas.message.support;

import com.kaadas.result.ErrorCode;
import com.kaadas.result.ResultCode;
import lombok.Getter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-28
 * @since 1.0.0
 */
public enum MessageErrorCode implements ErrorCode {

  /** JSON Schema 校验 错误 */
  JSON_SCHEMA_INVALID(ResultCode.BAD_REQUEST, "json_schema_invalid", "JSON Schema校验错误"),
  JSON_SCHEMA_NOT_FOUND(ResultCode.BAD_REQUEST, "json_schema_not_found", "JSON Schema文件未找到"),


  ;

  @Getter
  private final ResultCode resultCode;
  @Getter
  private final String errCode;
  @Getter
  private final String errDes;

  MessageErrorCode(ResultCode resultCode, String errCode, String errDes) {
    this.resultCode = resultCode;
    this.errCode = errCode;
    this.errDes = errDes;
  }

}
