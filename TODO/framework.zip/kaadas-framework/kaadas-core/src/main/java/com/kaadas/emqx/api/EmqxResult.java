package com.kaadas.emqx.api;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-13
 * @since 1.0.0
 */
@Data
public class EmqxResult<T> {
  private int code = -1;
  private T data;
}