package com.kaadas.message.filter;

import com.kaadas.message.support.NameUtils;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-21
 * @since 1.0.0
 */
public interface ExchangeFilterFactory<T> {

  /**
   * TODO
   *
   * @param params param1
   * @return com.kaadas.paas.message.filter.ExchangeFilter
   * @date 2022-05-10 16:03
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  ExchangeFilter apply(T params);

  Class<T> getConfigClass();

  default String getName() {
    return NameUtils.normalizeFilterFactoryName(getClass());
  }
}
