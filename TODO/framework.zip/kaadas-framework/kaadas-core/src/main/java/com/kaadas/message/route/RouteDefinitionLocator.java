package com.kaadas.message.route;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-21
 * @since 1.0.0
 */
public interface RouteDefinitionLocator {
  /**
   * 获取路由定义
   *
   * @return java.util.List&lt;com.kaadas.message.route.RouteDefinition&gt;
   * @date 2022-06-24 15:55
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  List<RouteDefinition> getRouteDefinitions();
}
