package com.kaadas.message.support;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-25
 * @since 1.0.0
 */
public class ExchangeUtils {

  public static final String MQTT_ROUTE_ATTR = qualify("mqttRoute");
  public static final String MQTT_CLIENT_ID = qualify("clientId");
  public static final String MQTT_ORIGIN_MESSAGE_ATTR = qualify("originMessage");
  public static final String THING_MODEL_ATTR = qualify("thingModel");
  public static final String THING_MODEL_EVENT = qualify("thingModelEvent");
  public static final String REPLY_MESSAGE = qualify("replyMessage");

  private static String qualify(String attr) {
    return ExchangeUtils.class.getName() + "." + attr;
  }
}
