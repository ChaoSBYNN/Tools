package com.kaadas.redis;

import lombok.Getter;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

@NoRepositoryBean
public abstract class AbstractRedisRepository<T> implements CrudRepository<T, String> {
  @Getter
  protected RedisConnectionFactory redisConnectionFactory;
  @Getter
  protected Class<T> tClass;

  @SuppressWarnings("unchecked")
  public AbstractRedisRepository(@NotNull RedisConnectionFactory redisConnectionFactory) {
    this.redisConnectionFactory = redisConnectionFactory;
    Type superClass = getClass().getGenericSuperclass();
    if (superClass instanceof Class<?>) {
      throw new IllegalArgumentException("Internal error: TypeReference constructed without actual type " +
        "information");
    }
    tClass = (Class<T>) ((ParameterizedType) superClass).getActualTypeArguments()[0];
  }

  /**
   * 具体实现
   *
   * @return org.springframework.data.redis.core.RedisTemplate&lt;java.lang.String,T&gt;
   * @date 2020-05-06 11:22
   * @author zhangduanfeng
   * @since 1.0.0
   */
  protected abstract @NotNull RedisTemplate<String, T> getRedisTemplate();

  /**
   * Redis的Key
   *
   * @return java.lang.String
   * @date 2020-05-08 13:53
   * @author zhangduanfeng
   * @since 1.0.0
   */
  protected abstract @NotNull String getRedisKey();
}
