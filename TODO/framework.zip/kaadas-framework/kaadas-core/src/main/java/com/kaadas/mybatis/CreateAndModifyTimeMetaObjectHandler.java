package com.kaadas.mybatis;

import com.baomidou.mybatisplus.core.MybatisPlusVersion;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@ConditionalOnClass(MybatisPlusVersion.class)
@Component
public class CreateAndModifyTimeMetaObjectHandler implements MetaObjectHandler {

  @Override
  public void insertFill(MetaObject metaObject) {
    this.strictInsertFill(metaObject, MybatisEntity.CREATE_TIME, LocalDateTime::now, LocalDateTime.class);
    this.strictInsertFill(metaObject, MybatisEntity.UPDATE_TIME, LocalDateTime::now, LocalDateTime.class);
  }

  @Override
  public void updateFill(MetaObject metaObject) {
    this.strictUpdateFill(metaObject, MybatisEntity.UPDATE_TIME, LocalDateTime::now, LocalDateTime.class);
  }
}
