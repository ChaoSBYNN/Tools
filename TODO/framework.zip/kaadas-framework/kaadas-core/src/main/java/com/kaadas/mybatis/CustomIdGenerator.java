package com.kaadas.mybatis;

import com.baomidou.mybatisplus.core.MybatisPlusVersion;
import com.baomidou.mybatisplus.core.incrementer.IdentifierGenerator;
import com.kaadas.util.ObjectId;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnClass(MybatisPlusVersion.class)
public class CustomIdGenerator implements IdentifierGenerator {
  @Override
  public Number nextId(Object entity) {
    return null;
  }

  @Override
  public String nextUUID(Object entity) {
    return ObjectId.get().toHexString();
  }
}