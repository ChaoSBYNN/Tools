package com.kaadas.model;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-06
 * @since 1.0.0
 */
public interface BaseQry extends BaseModel{
}
