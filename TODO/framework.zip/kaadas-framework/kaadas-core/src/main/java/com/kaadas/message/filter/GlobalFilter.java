package com.kaadas.message.filter;

import com.kaadas.message.Exchange;
import org.springframework.core.Ordered;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
public interface GlobalFilter extends Ordered {
  /**
   * TODO
   *
   * @param exchange    param1
   * @param filterChain param2
   * @date 2022-05-10 16:01
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  void filter(Exchange exchange, ExchangeFilterChain filterChain);

  @Override
  default int getOrder() {
    return Ordered.LOWEST_PRECEDENCE;
  }
}
