package com.kaadas.elasticsearch;

import com.kaadas.util.Lists;
import org.elasticsearch.client.ElasticsearchClient;
import org.jetbrains.annotations.NotNull;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.elasticsearch.core.convert.ElasticsearchCustomConversions;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@ConditionalOnClass({ElasticsearchClient.class})
@EnableElasticsearchRepositories(basePackages = "com.kaadas",
                                 repositoryBaseClass = ElasticsearchOperationRepositoryImpl.class)
@Configuration
public class ElasticsearchConfiguration {

  static final DateTimeFormatter NORMAL_PATTERN_DATE_HOUR_MINUTE_SECOND_MILLIS =
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
  @SuppressWarnings("UnnecessaryStringEscape")
  static final DateTimeFormatter ES_DEFAULT_DATE_HOUR_MINUTE_SECOND_MILLIS =
    DateTimeFormatter.ofPattern("yyyy-MM-dd\'T\'HH:mm:ss.SSS");

  @Bean
  public ElasticsearchCustomConversions elasticsearchCustomConversions() {
    return new ElasticsearchCustomConversions(Lists.newArrayList(StringToLocalDateTimeConverter.INSTANCE,
      LocalDateTimeToStringConverter.INSTANCE));
  }


  @ReadingConverter
  enum StringToLocalDateTimeConverter implements Converter<String, LocalDateTime> {
    INSTANCE;

    @Override
    public LocalDateTime convert(@NotNull String source) {
      if (source.contains("T")) {
        return LocalDateTime.parse(source, ES_DEFAULT_DATE_HOUR_MINUTE_SECOND_MILLIS);
      }
      return LocalDateTime.parse(source, NORMAL_PATTERN_DATE_HOUR_MINUTE_SECOND_MILLIS);
    }
  }

  @WritingConverter
  enum LocalDateTimeToStringConverter implements Converter<LocalDateTime, String> {
    INSTANCE;

    @Override
    public String convert(@NotNull LocalDateTime source) {
      return ES_DEFAULT_DATE_HOUR_MINUTE_SECOND_MILLIS.format(source);
    }
  }
}
