package com.kaadas.model.page;

import com.kaadas.util.CollectionUtils;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-08
 * @since 1.0.0
 */
public class SpringPageUtils {
  public static org.springframework.data.domain.Pageable toPageable(Pageable pageable) {
    Sort sort = Sort.unsorted();
    if (CollectionUtils.isNotEmpty(pageable.getSorts())) {
      List<Sort.Order> orders = pageable.getSorts().stream().map(s -> {
        if (s.isAsc()) {
          return Sort.Order.asc(s.getBy());
        } else {
          return Sort.Order.desc(s.getBy());
        }
      }).collect(Collectors.toList());
      sort = Sort.by(orders);
    }
    int page = pageable.getNum() > 0 ? pageable.getNum() - 1 : 0;
    return org.springframework.data.domain.PageRequest.of(page, pageable.getSize(), sort);
  }
}
