package com.kaadas.asserts;

import com.kaadas.result.ErrorCode;
import com.kaadas.result.ResultCode;
import lombok.Getter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-01
 * @since 1.0.0
 */
public enum AssertErrorCode implements ErrorCode {

  /** 参数为空 */
  PARAM_IS_NULL(ResultCode.BAD_REQUEST, "param_is_null", "参数为空"),
  PARAM_IS_EMPTY(ResultCode.BAD_REQUEST, "param_is_empty", "参数为空"),
  PARAM_IS_BLANK(ResultCode.BAD_REQUEST, "param_is_blank", "参数为空"),
  PARAM_IS_TRUE(ResultCode.BAD_REQUEST, "param_is_true", "参数为真"),
  PARAM_IS_FALSE(ResultCode.BAD_REQUEST, "param_is_false", "参数为假"),
  ;

  @Getter
  private final ResultCode resultCode;
  @Getter
  private final String errCode;
  @Getter
  private final String errDes;

  AssertErrorCode(ResultCode resultCode, String errCode, String errDes) {
    this.resultCode = resultCode;
    this.errCode = errCode;
    this.errDes = errDes;
  }
}

