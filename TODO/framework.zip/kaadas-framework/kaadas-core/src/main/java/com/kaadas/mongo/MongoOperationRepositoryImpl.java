package com.kaadas.mongo;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ResolvableType;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.query.MongoEntityInformation;
import org.springframework.data.repository.NoRepositoryBean;

import java.lang.reflect.Type;

@NoRepositoryBean
public class MongoOperationRepositoryImpl<T extends MongoEntity> extends AbstractMongoOperationRepository<T> {
  private MongoOperations mongoOperations;
  private MongoTemplate mongoTemplate;
  private final MongoEntityInformation<T, String> entityInformation;

  @Autowired(required = false)
  @SuppressWarnings("unchecked")
  public MongoOperationRepositoryImpl(MongoEntityInformationCreator mongoEntityInformationCreator) {
    super();
    Type superClass = getClass().getGenericSuperclass();
    if (superClass instanceof Class<?>) {
      throw new IllegalArgumentException("Internal error: TypeReference constructed without actual type " +
        "information");
    }
//    Type  t= ((ParameterizedType) superClass).getActualTypeArguments()[0];
//    Class<T> tClass = (Class<T>) (((ParameterizedType) superClass).getActualTypeArguments()[0]);
//    this.entityInformation = mongoEntityInformationCreator.entityInformationFor(tClass);

    Class<T> tClass = (Class<T>) ResolvableType.forClass(this.getClass()).getSuperType().getGeneric(0).getRawClass();
    this.entityInformation = mongoEntityInformationCreator.entityInformationFor(tClass);
  }

  @Autowired
  public void setMongoOperations(MongoOperations mongoOperations) {
    this.mongoOperations = mongoOperations;
  }

  @Autowired
  public void setMongoTemplate(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  @NotNull
  @Override
  public MongoOperations getMongoOperations() {
    return mongoOperations;
  }

  @NotNull
  @Override
  protected MongoEntityInformation<T, String> getEntityInformation() {
    return entityInformation;
  }

  public MongoTemplate getMongoTemplate() {
    return mongoTemplate;
  }
}
