package com.kaadas.message.handler.predicate;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-11
 * @since 1.0.0
 */
public abstract class AbstractRoutePredicateFactory<T> implements RoutePredicateFactory<T> {
  /** Config参数类 */
  private final Class<T> tClass;

  public AbstractRoutePredicateFactory(Class<T> tClass) {
    this.tClass = tClass;
  }

  @Override
  public Class<T> getConfigClass() {
    return tClass;
  }
}
