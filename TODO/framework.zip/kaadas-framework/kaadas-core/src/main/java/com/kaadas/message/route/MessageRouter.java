package com.kaadas.message.route;

import com.kaadas.message.Exchange;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-28
 * @since 1.0.0
 */
public interface MessageRouter {
  /**
   * TODO
   *
   * @param exchange param1
   * @date 2022-06-28 11:25
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  void route(Exchange exchange);
}
