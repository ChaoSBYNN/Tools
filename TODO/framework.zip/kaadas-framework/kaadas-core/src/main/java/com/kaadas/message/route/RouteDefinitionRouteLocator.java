package com.kaadas.message.route;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kaadas.message.Exchange;
import com.kaadas.message.filter.ExchangeFilter;
import com.kaadas.message.filter.ExchangeFilterFactory;
import com.kaadas.message.handler.ExchangeHandler;
import com.kaadas.message.handler.predicate.RoutePredicate;
import com.kaadas.message.handler.predicate.RoutePredicateFactory;
import com.kaadas.message.support.ConfigConverter;
import com.kaadas.message.support.JsonPropertyAccessor;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.convert.support.GenericConversionService;

import java.util.*;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-21
 * @since 1.0.0
 */
@SuppressWarnings({"rawtypes", "unchecked"})
@Log4j2
public abstract class RouteDefinitionRouteLocator implements InitializingBean {
  static final ObjectMapper mapper = JsonUtils.getObjectMapper();
  RouteDefinitionLocator routeDefinitionLocator;
  JsonPropertyAccessor jsonPropertyAccessor = new JsonPropertyAccessor();

  Map<String, ExchangeFilterFactory> exchangeFilterFactories = new HashMap<>();
  Map<String, RoutePredicateFactory> routePredicateFactories = new HashMap<>();
  Map<String, ExchangeHandler> exchangeHandlers = new HashMap<>();
  GenericConversionService conversionService = new GenericConversionService();

  private final Set<Route> routes = new HashSet<>();

  public RouteDefinitionRouteLocator(RouteDefinitionLocator routeDefinitionLocator,
                                     ObjectProvider<ExchangeFilterFactory<?>> exchangeFilterFactories,
                                     ObjectProvider<RoutePredicateFactory<?>> routePredicateFactories,
                                     ObjectProvider<ExchangeHandler> exchangeHandlers,
                                     ObjectProvider<ConfigConverter<?, ?>> configConverters) {
    this.routeDefinitionLocator = routeDefinitionLocator;
    exchangeFilterFactories.forEach(exchangeFilterFactory -> this.exchangeFilterFactories.put(exchangeFilterFactory.getName(),
      exchangeFilterFactory));
    routePredicateFactories.forEach(routePredicateFactory -> this.routePredicateFactories.put(routePredicateFactory.getName(),
      routePredicateFactory));
    exchangeHandlers.forEach(exchangeHandler -> this.exchangeHandlers.put(exchangeHandler.getName(), exchangeHandler));
    configConverters.forEach(configConverter -> this.conversionService.addConverter(configConverter));
    jsonPropertyAccessor.setObjectMapper(mapper);

  }

  public Set<Route> getRoutes() {
    return this.routes;
  }

  public void refresh() {
    this.routes.addAll(routeDefinitionLocator
      .getRouteDefinitions()
      .stream()
      .map(this::toRoute)
      .collect(Collectors.toSet()));
  }

  @Override
  public void afterPropertiesSet() {
    refresh();
  }

  Route toRoute(RouteDefinition routeDefinition) {
    Route route = new Route();
    route.setId(routeDefinition.getId());
    route.setVersion(routeDefinition.getVersion());
    if (routeDefinition.getPredicates() != null) {
      // 断言
      List<RoutePredicate<Exchange>> predicates = new ArrayList<>(routeDefinition.getPredicates().size());
      routeDefinition.getPredicates().forEach(predicateConf -> {
        RoutePredicateFactory factory = this.routePredicateFactories.get(predicateConf.getName());
        if (factory == null) {
          return;
        }
        if (predicateConf.getArgs() == null) {
          predicates.add(factory.apply(null));
          return;
        }
        BeanWrapper beanWrapper = new BeanWrapperImpl(BeanUtils.instantiateClass(factory.getConfigClass()));
        beanWrapper.setConversionService(conversionService);
        beanWrapper.setPropertyValues(predicateConf.getArgs());
        predicates.add(factory.apply(beanWrapper.getWrappedInstance()));
      });
      route.setPredicates(predicates);
    }
    if (routeDefinition.getFilters() != null) {
      // 过滤器
      List<ExchangeFilter> filters = new ArrayList<>(routeDefinition.getFilters().size());
      routeDefinition.getFilters().forEach(filterConf -> {
        ExchangeFilterFactory factory = this.exchangeFilterFactories.get(filterConf.getName());
        if (factory == null) {
          return;
        }
        if (filterConf.getArgs() == null) {
          filters.add(factory.apply(null));
          return;
        }
        BeanWrapperImpl beanWrapper = new BeanWrapperImpl(BeanUtils.instantiateClass(factory.getConfigClass()));
        beanWrapper.setConversionService(conversionService);
        beanWrapper.setPropertyValues(filterConf.getArgs());
        filters.add(factory.apply(beanWrapper.getWrappedInstance()));
      });
      route.setFilters(filters);
    }
    if (routeDefinition.getHandlers() != null) {
      // 处理器
      List<ExchangeHandler> handlers = new ArrayList<>(routeDefinition.getHandlers().size());
      routeDefinition.getHandlers().forEach(name -> {
        ExchangeHandler exchangeHandler = this.exchangeHandlers.get(name);
        if (exchangeHandler == null) {
          return;
        }
        handlers.add(exchangeHandler);
      });
      route.setHandlers(handlers);
    }
    if (log.isDebugEnabled()) {
      log.debug("Register route: {}", JsonUtils.serialize(routeDefinition));
    }
    return route;
  }
}
