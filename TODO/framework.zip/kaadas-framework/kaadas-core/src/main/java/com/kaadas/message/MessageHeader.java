package com.kaadas.message;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
@Getter
@Setter(AccessLevel.PACKAGE)
public abstract class MessageHeader {
  protected String id;
  protected String node;
  protected String from;
  protected String topic;
  protected Integer qos;
  protected Long timestamp;
}
