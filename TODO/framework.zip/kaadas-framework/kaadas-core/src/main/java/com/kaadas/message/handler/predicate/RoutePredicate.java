package com.kaadas.message.handler.predicate;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-12
 * @since 1.0.0
 */
@FunctionalInterface
public interface RoutePredicate<T> {
  /**
   * TODO
   *
   * @param t param1
   * @return boolean
   * @date 2022-05-12 09:01
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  boolean test(T t);
}