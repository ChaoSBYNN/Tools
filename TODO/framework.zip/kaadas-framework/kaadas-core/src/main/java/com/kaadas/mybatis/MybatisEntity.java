package com.kaadas.mybatis;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kaadas.model.Entity;
import com.kaadas.util.StringUtils;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-04-06
 * @since 1.0.0
 */
@Getter
@Setter
public class MybatisEntity implements Entity {
  public static final String CREATE_TIME = "create_time";
  public static final String UPDATE_TIME = "update_time";
  public static final String CREATE_USER = "create_user";
  public static final String UPDATE_USER = "update_user";

  /**
   * 数据库主键ID
   */
  @TableId(value = ID, type = IdType.ASSIGN_UUID)
  protected String id;

  /**
   * 创建时间
   */
  @TableField(CREATE_TIME)
  protected LocalDateTime createTime;

  /**
   * 修改时间
   */
  @TableField(UPDATE_TIME)
  protected LocalDateTime updateTime;

  /**
   * 创建人. 理论上可自动绑定当前登录人.  详见MongoAuditorAware
   */
  @TableField(CREATE_USER)
  protected String createUser;

  /**
   * 创建人. 理论上可自动绑定当前登录人.  详见MongoAuditorAware
   */
  @TableField(UPDATE_USER)
  protected String updateUser;

  /**
   * 根据ID是否为空
   *
   * @return boolean
   * @date 2020-03-31 15:26
   * @author zhangduanfeng
   * @since 1.0.0
   */
  @JsonIgnore
  public boolean isNew() {
    return StringUtils.isBlank(getId());
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MybatisEntity entity = (MybatisEntity) o;
    return Objects.equals(entity.getId(), this.getId());
  }

  @Override
  public int hashCode() {
    if (this.getId() == null) {
      return super.hashCode();
    }
    return Objects.hash(this.getClass().getName(), this.getId());
  }
}
