package com.kaadas.message.route;

import com.kaadas.message.Exchange;
import com.kaadas.message.filter.ExchangeFilter;
import com.kaadas.message.handler.ExchangeHandler;
import com.kaadas.message.handler.predicate.RoutePredicate;
import com.kaadas.message.validation.JsonSchemaValidator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Route {
  private String id;
  private String version;
  private List<RoutePredicate<Exchange>> predicates;
  private List<ExchangeFilter> filters;
  private List<ExchangeHandler> handlers;
  private JsonSchemaValidator jsonSchemaValidator;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    Route route = (Route) o;
    return Objects.equals(id, route.id);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(id);
  }
}
