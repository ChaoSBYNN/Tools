package com.kaadas.message.filter.exchange;

import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kaadas.message.Exchange;
import com.kaadas.message.filter.AbstractExchangeFilterFactory;
import com.kaadas.message.filter.ExchangeFilter;
import com.kaadas.message.filter.ExchangeFilterChain;
import com.kaadas.message.support.ExchangeUtils;
import com.kaadas.util.CollectionUtils;
import com.kaadas.util.JsonUtils;
import com.kaadas.util.StringUtils;
import lombok.Data;
import lombok.extern.log4j.Log4j2;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 物模型过滤器工厂， 暂时未使用
 *
 * @author ZhangDuanFeng
 * @date 2022-05-27
 * @since 1.0.0
 */
@Log4j2
@ConditionalOnProperty(value = "kaadas.message.enabled", havingValue = "true")
@Component
public class ThingModelExchangeFilterFactory
  extends AbstractExchangeFilterFactory<ThingModelExchangeFilterFactory.Config> {
  static ObjectMapper mapper = JsonUtils.getObjectMapper();

  public ThingModelExchangeFilterFactory() {
    super(Config.class);
  }

  public static ObjectNode delete(ObjectNode parentNode, JsonPointer jsonPointer) {
    String property = jsonPointer.getMatchingProperty();
    JsonPointer next = jsonPointer.tail();
    if (next == null || StringUtils.isBlank(next.getMatchingProperty())) {
      parentNode.remove(property);
      return parentNode;
    }
    if (parentNode.has(property)) {
      parentNode = (ObjectNode) parentNode.get(property);
    }
    delete(parentNode, next);
    return parentNode;
  }

  public static void tail(ObjectNode parentNode, JsonPointer jsonPointer, JsonNode value) {
    String property = jsonPointer.getMatchingProperty();
    JsonPointer next = jsonPointer.tail();
    if (next == null || StringUtils.isBlank(next.getMatchingProperty())) {
      if (parentNode.has(property) && value.isObject()) {
        ((ObjectNode) parentNode.get(property)).setAll((ObjectNode) value);
        return;
      }
      if (!value.isMissingNode()) {
        parentNode.set(property, value);
      }
      return;
    }
    if (parentNode.has(property)) {
      parentNode = (ObjectNode) parentNode.get(property);
    } else {
      ObjectNode newNode = mapper.createObjectNode();
      parentNode.set(property, newNode);
      parentNode = newNode;
    }
    tail(parentNode, next, value);
  }

  @Override
  public ExchangeFilter apply(Config params) {
    return new ExchangeFilter() {

      @Override
      public void filter(Exchange exchange, ExchangeFilterChain filterChain) {
        ObjectNode unwrapper = exchange.getPayload().deepCopy();
        if (StringUtils.isNotBlank(params.getName())) {
          unwrapper = (ObjectNode) unwrapper.get(params.getName());
        }
        Map<String, String> mapping = params.mapping;

        if (CollectionUtils.isEmpty(mapping)) {
          exchange.getProperties().put(ExchangeUtils.THING_MODEL_ATTR, unwrapper);
          filterChain.filter(exchange);
          return;
        }
        ObjectNode objectNode = unwrapper;
        List<String> keys = new ArrayList<>(mapping.keySet());
        keys.sort(Comparator.reverseOrder());
        keys.forEach(k -> {
          JsonPointer jsonPointer = JsonPointer.compile(k);
          JsonNode originNode = objectNode.at(jsonPointer);
          String v = mapping.get(k);
          if (v == null) {
            return;
          }
          //"/" + v.replace(".", "/")
          JsonPointer targetPointer = JsonPointer.compile(v);
          tail(objectNode, targetPointer, originNode);
          delete(objectNode, jsonPointer);
        });
        Iterator<JsonNode> iterator = objectNode.iterator();
        while (iterator.hasNext()) {
          JsonNode jsonNode = iterator.next();
          if (!jsonNode.isValueNode() && jsonNode.isEmpty()) {
            iterator.remove();
          }
        }
        exchange.putProperty(ExchangeUtils.THING_MODEL_ATTR, objectNode);
        filterChain.filter(exchange);
      }

      @Override
      public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 2;
      }
    };
  }

  @Data
  public static class Config {
    private String name;
    private Map<String, String> mapping;
  }

  public static void main(String[] args) throws JsonProcessingException {
    String str = "{\"lockId\":\"W9120C2104270DC0287961\",\"devtype\":\"xmkdswflock\"," +
                 "\"eventparams\":{\"camera_version\":\"2.0.17-20201229\",\"keep_alive_status\":0," +
                 "\"mqttPayloadVersion\":\"2.0.4\",\"device_model\":\"K10V01\",\"stay_status\":0," +
                 "\"setPir\":{\"pir_sen\":35,\"stay_time\":30},\"WIFIversion\":\"1.2.6-20210204\"," +
                 "\"alive_time\":{\"keep_alive_snooze\":[1,2,3,4,5,6,7],\"snooze_end_time\":86400," +
                 "\"snooze_start_time\":0},\"mcu_version\":\"0.1.3\"},\"func\":\"wfevent\",\"msgId\":5," +
                 "\"eventtype\":\"cameraInf\",\"msgtype\":\"event\",\"wfId\":\"79F0220810001\"," +
                 "\"timestamp\":1658735882}";

    Config conf = new Config();
    conf.name = "eventparams";
    conf.mapping = new HashMap<>();
    conf.mapping.put("/device_model", "/deviceModel");
    conf.mapping.put("/stay_allow_max_times", "/stayAllowMaxTimes");
    conf.mapping.put("/mqttPayloadVersion", "/payloadVer");
    conf.mapping.put("/camera_version", "/cameraVer");
    conf.mapping.put("/WIFIversion", "/wifiVer");
    conf.mapping.put("/mcu_version", "/mcuVer");
    conf.mapping.put("/screen_version", "/screenVer");
    conf.mapping.put("/keep_alive_status", "/keepAlive/enabled");
    conf.mapping.put("/alive_time/keep_alive_snooze", "/keepAlive/snoozeWeeks");
    conf.mapping.put("/alive_time/snooze_start_time", "/keepAlive/snoozeStartTime");
    conf.mapping.put("/alive_time/snooze_end_time", "/keepAlive/snoozeEndTime");
    conf.mapping.put("/stay_status", "/pir/enabled");
    conf.mapping.put("/setPir/stay_time", "/pir/stayTime");
    conf.mapping.put("/setPir/range", "/pir/range");
    conf.mapping.put("/setPir/pir_sen", "/pir/sensitivity");
    conf.mapping.put("/screenLightSwitch", "/screen/enabled");
    conf.mapping.put("/screenLightTime", "/screen/duration");
    conf.mapping.put("/screenLightLevel", "/screen/brightness");

    ObjectNode unwrapper = (ObjectNode) JsonUtils.getObjectMapper().readTree(str);
    ObjectNode objectNode = (ObjectNode) unwrapper.get(conf.name);
    List<String> keys = new ArrayList<>(conf.mapping.keySet());
    keys.sort(Comparator.reverseOrder());
    keys.forEach(k -> {
      JsonPointer jsonPointer = JsonPointer.compile(k);
      JsonNode originNode = objectNode.at(jsonPointer);
      String v = conf.mapping.get(k);
      if (v == null) {
        return;
      }
      //"/" + v.replace(".", "/")
      JsonPointer targetPointer = JsonPointer.compile(v);
      tail(objectNode, targetPointer, originNode);
      delete(objectNode, jsonPointer);
    });
    Iterator<JsonNode> iterator = objectNode.iterator();
    while (iterator.hasNext()) {
      JsonNode jsonNode = iterator.next();
      if (!jsonNode.isValueNode() && jsonNode.isEmpty()) {
        iterator.remove();
      }
    }
  }
}
