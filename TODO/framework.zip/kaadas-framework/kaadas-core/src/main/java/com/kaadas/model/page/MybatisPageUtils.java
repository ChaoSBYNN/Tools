package com.kaadas.model.page;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-08
 * @since 1.0.0
 */
public class MybatisPageUtils {
  public static <T> IPage<T> toPage(Pageable pageRequest) {
    Page<T> page = new Page<>(pageRequest.getNum(), pageRequest.getSize(), false);
    List<OrderItem> orderItems = pageRequest.getSorts().stream().map(s -> {
      if (s.isAsc()) {
        return OrderItem.asc(s.getBy());
      } else {
        return OrderItem.desc(s.getBy());
      }
    }).collect(Collectors.toList());
    page.addOrder(orderItems);
    return page;
  }
}
