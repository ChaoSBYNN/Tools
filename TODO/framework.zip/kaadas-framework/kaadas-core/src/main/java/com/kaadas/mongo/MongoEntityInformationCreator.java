package com.kaadas.mongo;

import org.springframework.data.mapping.context.MappingContext;
import org.springframework.data.mongodb.core.mapping.MongoPersistentEntity;
import org.springframework.data.mongodb.core.mapping.MongoPersistentProperty;
import org.springframework.data.mongodb.repository.query.MongoEntityInformation;
import org.springframework.data.mongodb.repository.support.MappingMongoEntityInformation;

import java.io.Serializable;
import java.util.Objects;

public class MongoEntityInformationCreator {
  private final MappingContext<? extends MongoPersistentEntity<?>, MongoPersistentProperty> mappingContext;

  public MongoEntityInformationCreator(
    MappingContext<? extends MongoPersistentEntity<?>, MongoPersistentProperty> mappingContext) {
    this.mappingContext = mappingContext;
  }


  public <T, ID extends Serializable> MongoEntityInformation<T, ID> entityInformationFor(Class<T> domainClass) {
    return entityInformationFor(domainClass, null);
  }


  @SuppressWarnings({"ConstantConditions", "unchecked"})
  public <T, ID extends Serializable> MongoEntityInformation<T, ID> entityInformationFor(Class<T> domainClass,
                                                                                         Class<?> collectionClass) {

    MongoPersistentEntity<T> persistentEntity = (MongoPersistentEntity<T>) mappingContext.getPersistentEntity(domainClass);
    String customCollectionName = collectionClass == null ?
      persistentEntity
        .getCollection() :
      Objects.requireNonNull(mappingContext.getPersistentEntity(collectionClass))
        .getCollection();

    return new MappingMongoEntityInformation<>(Objects.requireNonNull(persistentEntity), Objects.requireNonNull(customCollectionName));
  }
}
