package com.kaadas.elasticsearch;

import org.elasticsearch.index.query.IdsQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.domain.*;
import org.springframework.data.elasticsearch.core.*;
import org.springframework.data.elasticsearch.core.mapping.ElasticsearchPersistentEntity;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.MoreLikeThisQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.Query;
import org.springframework.data.elasticsearch.repository.support.ElasticsearchEntityInformation;
import org.springframework.data.elasticsearch.repository.support.SimpleElasticsearchRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.util.StreamUtils;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-15
 * @since 1.0.0
 */
@NoRepositoryBean
public abstract class AbstractElasticsearchRepository<T> implements ElasticsearchOperationRepository<T> {
  protected IndexOperations indexOperations;
  protected Class<T> entityClass;

  public AbstractElasticsearchRepository() {
  }

  /**
   * 获取当前类中的实体信息
   *
   * @return org.springframework.data.mongodb.repository.query.MongoEntityInformation&lt;T,java.lang.String&gt;
   * @date 2019-09-04 09:45
   * @author zhangduanfeng
   * @since 1.0.0
   */
  protected abstract @NotNull ElasticsearchEntityInformation<T, String> getEntityInformation();

  private boolean shouldCreateIndexAndMapping() {
    ElasticsearchPersistentEntity<?> entity =
      getOperations().getElasticsearchConverter().getMappingContext().getRequiredPersistentEntity(this.entityClass);
    return entity.isCreateIndexAndMapping();
  }

  public Optional<T> findById(String id) {
    return Optional.ofNullable(this.execute((operations) -> {
      return operations.get(this.stringIdRepresentation(id), this.entityClass, this.getIndexCoordinates());
    }));
  }

  public Iterable<T> findAll() {
    int itemCount = (int) this.count();
    return (Iterable) (itemCount == 0 ? new PageImpl(Collections.emptyList()) :
                       this.findAll((Pageable) PageRequest.of(0, Math.max(1, itemCount)))
    );
  }

  public Page<T> findAll(Pageable pageable) {
    NativeSearchQuery query =
      (new NativeSearchQueryBuilder()).withQuery(QueryBuilders.matchAllQuery()).withPageable(pageable).build();
    SearchHits<T> searchHits = (SearchHits) this.execute((operations) -> {
      return operations.search(query, this.entityClass, this.getIndexCoordinates());
    });
    SearchPage<T> page = SearchHitSupport.searchPageFor(searchHits, query.getPageable());
    return (Page) SearchHitSupport.unwrapSearchHits(page);
  }

  public Iterable<T> findAll(Sort sort) {
    int itemCount = (int) this.count();
    if (itemCount == 0) {
      return new PageImpl(Collections.emptyList());
    } else {
      NativeSearchQuery query = (new NativeSearchQueryBuilder())
        .withQuery(QueryBuilders.matchAllQuery())
        .withPageable(PageRequest.of(0, itemCount, sort))
        .build();
      List<SearchHit<T>> searchHitList = (List) this.execute((operations) -> {
        return operations.search(query, this.entityClass, this.getIndexCoordinates()).getSearchHits();
      });
      return (List) SearchHitSupport.unwrapSearchHits(searchHitList);
    }
  }

  public Iterable<T> findAllById(Iterable<String> ids) {
    Assert.notNull(ids, "ids can't be null.");
    List<T> result = new ArrayList();
    Query idQuery = this.getIdQuery(ids);
    if (CollectionUtils.isEmpty(idQuery.getIds())) {
      return result;
    } else {
      List<MultiGetItem<T>> multiGetItems = (List) this.execute((operations) -> {
        return operations.multiGet(idQuery, this.entityClass, this.getIndexCoordinates());
      });
      if (multiGetItems != null) {
        multiGetItems.forEach((multiGetItem) -> {
          if (multiGetItem.hasItem()) {
            result.add(multiGetItem.getItem());
          }

        });
      }

      return result;
    }
  }

  public long count() {
    NativeSearchQuery query = (new NativeSearchQueryBuilder()).withQuery(QueryBuilders.matchAllQuery()).build();
    return (Long) this.execute((operations) -> {
      return operations.count(query, this.entityClass, this.getIndexCoordinates());
    });
  }

  public <S extends T> S save(S entity) {
    Assert.notNull(entity, "Cannot save 'null' entity.");
    return this.executeAndRefresh((operations) -> {
      return operations.save(entity, this.getIndexCoordinates());
    });
  }

  public <S extends T> List<S> save(List<S> entities) {
    Assert.notNull(entities, "Cannot insert 'null' as a List.");
    return (List) Streamable.of(this.saveAll(entities)).stream().collect(Collectors.toList());
  }

  public <S extends T> Iterable<S> saveAll(Iterable<S> entities) {
    Assert.notNull(entities, "Cannot insert 'null' as a List.");
    IndexCoordinates indexCoordinates = this.getIndexCoordinates();
    this.executeAndRefresh((operations) -> {
      return operations.save(entities, indexCoordinates);
    });
    return entities;
  }

  public boolean existsById(String id) {
    return (Boolean) this.execute((operations) -> {
      return operations.exists(this.stringIdRepresentation(id), this.getIndexCoordinates());
    });
  }

  public Page<T> searchSimilar(T entity, @Nullable String[] fields, Pageable pageable) {
    Assert.notNull(entity, "Cannot search similar records for 'null'.");
    Assert.notNull(pageable, "'pageable' cannot be 'null'");
    MoreLikeThisQuery query = new MoreLikeThisQuery();
    query.setId(this.stringIdRepresentation(this.extractIdFromBean(entity)));
    query.setPageable(pageable);
    if (fields != null) {
      query.addFields(fields);
    }

    SearchHits<T> searchHits = (SearchHits) this.execute((operations) -> {
      return operations.search(query, this.entityClass, this.getIndexCoordinates());
    });
    SearchPage<T> searchPage = SearchHitSupport.searchPageFor(searchHits, pageable);
    return (Page) SearchHitSupport.unwrapSearchHits(searchPage);
  }

  public void deleteById(String id) {
    Assert.notNull(id, "Cannot delete entity with id 'null'.");
    this.doDelete(id, (String) null, this.getIndexCoordinates());
  }

  public void delete(T entity) {
    Assert.notNull(entity, "Cannot delete 'null' entity.");
    this.doDelete(this.extractIdFromBean(entity), getOperations().getEntityRouting(entity), this.getIndexCoordinates());
  }

  public void deleteAllById(Iterable<? extends String> ids) {
    Assert.notNull(ids, "Cannot delete 'null' list.");
    IndexCoordinates indexCoordinates = this.getIndexCoordinates();
    IdsQueryBuilder idsQueryBuilder = QueryBuilders.idsQuery();
    Iterator<? extends String> var4 = ids.iterator();

    while (var4.hasNext()) {
      String id = var4.next();
      idsQueryBuilder.addIds(new String[]{this.stringIdRepresentation(id)});
    }

    if (!idsQueryBuilder.ids().isEmpty()) {
      this.executeAndRefresh((operations) -> {
        operations.delete((new NativeSearchQueryBuilder()).withQuery(idsQueryBuilder).build(),
          this.entityClass,
          indexCoordinates);
        return null;
      });
    }
  }

  public void deleteAll(Iterable<? extends T> entities) {
    Assert.notNull(entities, "Cannot delete 'null' list.");
    List<String> ids = new ArrayList<>();
    Iterator<? extends T> var3 = entities.iterator();

    while (var3.hasNext()) {
      T entity = var3.next();
      String id = this.extractIdFromBean(entity);
      if (id != null) {
        ids.add(id);
      }
    }

    this.deleteAllById(ids);
  }

  private void doDelete(@Nullable String id, @Nullable String routing, IndexCoordinates indexCoordinates) {
    if (id != null) {
      this.executeAndRefresh((operations) -> {
        return operations.delete(this.stringIdRepresentation(id), routing, indexCoordinates);
      });
    }

  }

  public void deleteAll() {
    IndexCoordinates indexCoordinates = this.getIndexCoordinates();
    Query query = (new NativeSearchQueryBuilder()).withQuery(QueryBuilders.matchAllQuery()).build();
    this.executeAndRefresh((operations) -> {
      operations.delete(query, this.entityClass, indexCoordinates);
      return null;
    });
  }

  private void doRefresh() {
    RefreshPolicy refreshPolicy = null;
    if (this.getOperations() instanceof AbstractElasticsearchTemplate) {
      refreshPolicy = ((AbstractElasticsearchTemplate) this.getOperations()).getRefreshPolicy();
    }

    if (refreshPolicy == null) {
      this.indexOperations.refresh();
    }

  }

  @Nullable
  protected String extractIdFromBean(T entity) {
    return this.getEntityInformation().getId(entity);
  }

  private List stringIdsRepresentation(Iterable<String> ids) {
    Assert.notNull(ids, "ids can't be null.");
    return StreamUtils
      .createStreamFromIterator(ids.iterator())
      .map(this::stringIdRepresentation)
      .collect(Collectors.toList());
  }

  @Nullable
  protected String stringIdRepresentation(@Nullable String id) {
    return getOperations().stringIdRepresentation(id);
  }

  private IndexCoordinates getIndexCoordinates() {
    return getOperations().getIndexCoordinatesFor(this.entityClass);
  }

  private Query getIdQuery(Iterable<String> ids) {
    List<String> stringIds = this.stringIdsRepresentation(ids);
    return (new NativeSearchQueryBuilder()).withIds(stringIds).build();
  }

  @Nullable
  public <R> R execute(SimpleElasticsearchRepository.OperationsCallback<R> callback) {
    return callback.doWithOperations(this.getOperations());
  }

  @Nullable
  public <R> R executeAndRefresh(SimpleElasticsearchRepository.OperationsCallback<R> callback) {
    R result = callback.doWithOperations(this.getOperations());
    this.doRefresh();
    return result;
  }

  @FunctionalInterface
  public interface OperationsCallback<R> {
    @Nullable
    R doWithOperations(ElasticsearchOperations operations);
  }
}
