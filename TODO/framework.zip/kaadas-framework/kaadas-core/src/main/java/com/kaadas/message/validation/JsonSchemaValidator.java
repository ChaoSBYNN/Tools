package com.kaadas.message.validation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kaadas.ServiceException;
import com.kaadas.schema.TypeDefinition;
import com.kaadas.util.JsonUtils;
import com.networknt.schema.*;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-20
 * @since 1.0.0
 */
public class JsonSchemaValidator {
  static final ObjectMapper mapper = JsonUtils.getObjectMapper();
  static JsonSchemaFactory jsonSchemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);

  private final JsonSchema jsonSchema;

  public JsonSchemaValidator(@NotNull TypeDefinition<?> schema) {
    this.jsonSchema = jsonSchemaFactory.getSchema(mapper.valueToTree(schema));
  }

  public static JsonSchemaValidator get(@NotNull TypeDefinition<?> schema) {
    return new JsonSchemaValidator(schema);
  }

  public Set<ValidationMessage> validate(JsonNode jsonNode) throws ServiceException {
    Set<ValidationMessage> validationMessages;
    try {
      validationMessages = jsonSchema.validate(jsonNode);
    } catch (JsonSchemaException e) {
      validationMessages = e.getValidationMessages();
    }
    return validationMessages;
  }
}
