package com.kaadas.message.route;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-11
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilterConf {
  private String name;
  private Map<String, Object> args;
}
