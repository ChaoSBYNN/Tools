package com.kaadas.message.filter;

import com.kaadas.message.Exchange;
import com.kaadas.message.route.Route;
import com.kaadas.message.support.ExchangeUtils;
import lombok.extern.log4j.Log4j2;

import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
@Log4j2
public class DefaultExchangeFilterChain implements ExchangeFilterChain {
  private final List<ExchangeFilter> filters;
  private int index = 0;

  public DefaultExchangeFilterChain(List<ExchangeFilter> filters) {
    this.filters = filters;
    this.index = 0;
  }

  public DefaultExchangeFilterChain(DefaultExchangeFilterChain parent, int index) {
    this.filters = parent.filters;
    this.index = index;
  }

  @Override
  public void filter(Exchange exchange) {
    if (this.index < filters.size()) {
      ExchangeFilter filter = filters.get(this.index);
      if (log.isTraceEnabled()) {
        log.trace("Do filter: {}", filter.getClass().getSimpleName());
      }
      DefaultExchangeFilterChain chain = new DefaultExchangeFilterChain(this, this.index + 1);
      filter.filter(exchange, chain);
    } else {
      Route route = exchange.getProperty(ExchangeUtils.MQTT_ROUTE_ATTR);
      if (route.getHandlers() == null) {
        return;
      }
      route.getHandlers().forEach(exchangeHandler -> {
        if (log.isTraceEnabled()) {
          log.trace("Do handler: {}", exchangeHandler.getClass().getSimpleName());
        }
        exchangeHandler.handle(exchange);
      });
    }
  }
}
