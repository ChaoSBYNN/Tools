package com.kaadas.emqx.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.kaadas.ServiceException;
import com.kaadas.util.StringUtils;
import com.kaadas.util.http.HttpOperations;
import com.kaadas.util.http.JsonHttpClient;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.List;

/**
 * EMQX API
 *
 * @author ZhangDuanFeng
 * @date 2022-06-13
 * @since 1.0.0
 */
@Component
@ConditionalOnProperty(value = "kaadas.emqx.api.enabled", havingValue = "true")
@EnableConfigurationProperties(EmqxProperties.class)
public class EmqxApi {
  final JsonHttpClient httpClient;
  final EmqxProperties emqxProperties;
  final Headers headers;

  public EmqxApi(EmqxProperties emqxProperties) {
    this.emqxProperties = emqxProperties;
    httpClient = new JsonHttpClient(new OkHttpClient.Builder()
                                      .connectionPool(HttpOperations.DEFAULT_CONNECTION_POOL)
                                      .connectTimeout(Duration.of(
                                        HttpOperations.DEFAULT_CONNECT_TIMEOUT,
                                        ChronoUnit.SECONDS
                                      ))
                                      .callTimeout(Duration.of(HttpOperations.DEFAULT_CALL_TIMEOUT, ChronoUnit.SECONDS))
                                      .build());
    Headers.Builder headersBuilder = new Headers.Builder();
    if (StringUtils.isNotBlank(emqxProperties.getUsername()) && StringUtils.isNotBlank(emqxProperties.getPassword())) {
      String basicStr = Base64.getEncoder().encodeToString((emqxProperties.getUsername() + ":" +
                                                            emqxProperties.getPassword()
                                                           ).getBytes(StandardCharsets.UTF_8));
      headersBuilder.add("Authorization", "Basic " + basicStr);
    }
    headers = headersBuilder.build();
  }

  /**
   * 发布
   *
   * @param publishMessage param1
   * @return com.kaadas.emqx.EmqxResult&lt;java.lang.Void&gt;
   * @date 2022-06-24 17:07
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public EmqxResult<Void> publish(PublishMessage publishMessage) {
    String url = emqxProperties.getUrl() + "/api/v4/mqtt/publish";
    return httpClient.post(url, publishMessage, headers, new TypeReference<EmqxResult<Void>>() {});
  }

  /**
   * 批量发布
   *
   * @param publishMessages param1
   * @date 2022-06-24 17:07
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public void publishBatch(List<PublishMessage> publishMessages) {
    String url = emqxProperties.getUrl() + "/api/v4/mqtt/publish_batch";
    EmqxResult<Void> emqxResult = httpClient.post(
      url,
      publishMessages,
      headers,
      new TypeReference<EmqxResult<Void>>() {}
    );
    if (emqxResult.getCode() == 0) {
      return;
    }
    throw new ServiceException(EmqxErrorCode.findByEmqxCode(emqxResult.getCode()));
  }

  /**
   * 订阅
   *
   * @param subscribeMessage param1
   * @date 2022-06-24 17:07
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public void subscribe(SubscribeMessage subscribeMessage) {
    String url = emqxProperties.getUrl() + "/api/v4/mqtt/subscribe";
    EmqxResult<Void> emqxResult = httpClient.post(
      url,
      subscribeMessage,
      headers,
      new TypeReference<EmqxResult<Void>>() {}
    );
    if (emqxResult.getCode() == 0) {
      return;
    }
    throw new ServiceException(EmqxErrorCode.findByEmqxCode(emqxResult.getCode()));
  }

  /**
   * 批量订阅
   *
   * @param subscribeMessages param1
   * @date 2022-06-24 17:07
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public void subscribeBatch(List<SubscribeMessage> subscribeMessages) {
    String url = emqxProperties.getUrl() + "/api/v4/mqtt/subscribe_batch";
    EmqxResult<Void> emqxResult = httpClient.post(
      url,
      subscribeMessages,
      headers,
      new TypeReference<EmqxResult<Void>>() {}
    );
    if (emqxResult.getCode() == 0) {
      return;
    }
    throw new ServiceException(EmqxErrorCode.findByEmqxCode(emqxResult.getCode()));
  }
}
