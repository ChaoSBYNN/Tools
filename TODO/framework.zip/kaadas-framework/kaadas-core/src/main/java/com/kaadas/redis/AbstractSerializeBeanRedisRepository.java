package com.kaadas.redis;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

import java.util.Optional;

public class AbstractSerializeBeanRedisRepository<T> extends AbstractRedisRepository<T> {
  private RedisTemplate<String, T> redisTemplate;

  public AbstractSerializeBeanRedisRepository(@NotNull RedisConnectionFactory redisConnectionFactory) {
    super(redisConnectionFactory);
    JdkSerializationRedisSerializer jdkSerializationRedisSerializer = new JdkSerializationRedisSerializer();
    redisTemplate = new RedisTemplate<>();
    redisTemplate.setConnectionFactory(redisConnectionFactory);
    redisTemplate.setKeySerializer(RedisSerializer.string());
    redisTemplate.setValueSerializer(jdkSerializationRedisSerializer);
    redisTemplate.setHashKeySerializer(RedisSerializer.string());
    redisTemplate.setHashValueSerializer(jdkSerializationRedisSerializer);
    redisTemplate.setDefaultSerializer(jdkSerializationRedisSerializer);
    redisTemplate.setEnableDefaultSerializer(true);
    redisTemplate.afterPropertiesSet();
  }

  @Override
  protected @NotNull RedisTemplate<String, T> getRedisTemplate() {
    return redisTemplate;
  }

  @Override
  protected @NotNull String getRedisKey() {
    return null;
  }

  @Override
  public <S extends T> S save(S entity) {
    return null;
  }

  @Override
  public <S extends T> Iterable<S> saveAll(Iterable<S> entities) {
    return null;
  }

  @Override
  public Optional<T> findById(String s) {
    return Optional.empty();
  }

  @Override
  public boolean existsById(String s) {
    return false;
  }

  @Override
  public Iterable<T> findAll() {
    return null;
  }

  @Override
  public Iterable<T> findAllById(Iterable<String> strings) {
    return null;
  }

  @Override
  public long count() {
    return 0;
  }

  @Override
  public void deleteById(String s) {

  }

  @Override
  public void delete(T entity) {

  }

  @Override
  public void deleteAllById(Iterable<? extends String> strings) {

  }

  @Override
  public void deleteAll(Iterable<? extends T> entities) {

  }

  @Override
  public void deleteAll() {

  }
}
