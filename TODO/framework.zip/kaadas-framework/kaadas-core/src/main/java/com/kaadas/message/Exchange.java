package com.kaadas.message;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.NullNode;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
@Getter
@Setter(AccessLevel.PACKAGE)
public abstract class Exchange {
  protected JsonNode payload;
  protected MessageHeader headers;
  protected Map<String, Object> properties = new HashMap<>(16);

  public void putProperty(String key, Object value) {
    properties.put(key, value);
  }

  @SuppressWarnings("unchecked")
  public <T> T getProperty(String key) {
    return (T) properties.get(key);
  }

  public String getTopic() {
    return headers.getTopic();
  }

  public String getFrom() {
    return headers.getFrom();
  }

  public JsonNode payloadAt(String path) {
    if (payload == null) {
      return NullNode.getInstance();
    }
    return payload.at(path);
  }

}
