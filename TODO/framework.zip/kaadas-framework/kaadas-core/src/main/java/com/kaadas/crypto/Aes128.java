package com.kaadas.crypto;


import com.kaadas.asserts.Assert;
import lombok.extern.log4j.Log4j2;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;

@Log4j2
public class Aes128 {

  public final static String AES_ECB_NO_PADDING = "AES/ECB/NoPadding";
  public final static String AES_ECB_PKCS5_PADDING = "AES/ECB/PKCS5Padding";
  //  private final byte[] key;
  private final String transformation;
  private final SecretKeySpec keySpec;

  public Aes128(byte[] key, String transformation) {
    //    this.key = key;
    this.transformation = transformation;
    this.keySpec = new SecretKeySpec(key, "AES");
  }

  public byte[] encrypt(byte[] content) throws GeneralSecurityException {
    Assert.isNull(content);
    Cipher cipher = Cipher.getInstance(transformation);
    cipher.init(Cipher.ENCRYPT_MODE, keySpec);
    return cipher.doFinal(content);
  }

  public byte[] decrypt(byte[] content) throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(transformation);
    cipher.init(Cipher.DECRYPT_MODE, keySpec);
    return cipher.doFinal(content);
  }
}
