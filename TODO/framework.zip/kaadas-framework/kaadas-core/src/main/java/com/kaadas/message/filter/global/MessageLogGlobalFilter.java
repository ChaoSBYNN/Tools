package com.kaadas.message.filter.global;

import com.kaadas.message.Exchange;
import com.kaadas.message.filter.ExchangeFilterChain;
import com.kaadas.message.filter.GlobalFilter;
import com.kaadas.message.route.Route;
import com.kaadas.message.support.ExchangeUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.Ordered;

/**
 * 日志过滤器
 *
 * @author ZhangDuanFeng
 * @date 2022-05-07
 * @since 1.0.0
 */
@Log4j2
public class MessageLogGlobalFilter implements GlobalFilter {
  @Override
  public void filter(Exchange exchange, ExchangeFilterChain filterChain) {
    Route route = exchange.getProperty(ExchangeUtils.MQTT_ROUTE_ATTR);
    filterChain.filter(exchange);
    if (log.isDebugEnabled()) {
      log.debug("Message ID: {}. Route: {}, Payload: {}",
                exchange.getHeaders().getId(),
                route.getId(),
                exchange.getPayload()
      );
    }
  }

  @Override
  public int getOrder() {
    return Ordered.HIGHEST_PRECEDENCE;
  }
}
