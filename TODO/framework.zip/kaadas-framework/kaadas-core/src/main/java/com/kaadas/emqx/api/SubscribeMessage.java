package com.kaadas.emqx.api;

import lombok.Data;

/**
 * EMQX API订阅Topic请求类
 *
 * @author ZhangDuanFeng
 * @date 2022-06-13
 * @since 1.0.0
 */
@Data
public class SubscribeMessage {
  /** 主题，与 topics 至少指定其中之一 */
  private String topic;
  /** 以 , 分割的多个主题，使用此字段能够同时发布消息到多个主题 */
  private String topics;
  /** 客户端标识符 */
  private String clientid;
  /** QoS 等级 */
  private Integer qos;
}
