package com.kaadas.message.filter.global;

import com.kaadas.message.Exchange;
import com.kaadas.message.filter.ExchangeFilterChain;
import com.kaadas.message.filter.GlobalFilter;
import com.kaadas.util.CollectionUtils;
import com.kaadas.util.JsonUtils;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
@Log4j2
@Component
@ConditionalOnProperty(value = "kaadas.message.enabled", havingValue = "true")
@ConditionalOnClass(JsonSchema.class)
public class JsonSchemaValidationGlobalFilter implements GlobalFilter {
  static Logger validationLog = LogManager.getLogger("JsonSchema");
  static JsonSchemaFactory jsonSchemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
  boolean strictMode = false;

  public JsonSchemaValidationGlobalFilter() {

  }

  @Override
  public void filter(Exchange exchange, ExchangeFilterChain filterChain) {
    //    Route route = exchange.getProperty(ExchangeUtils.MQTT_ROUTE_ATTR);
    //    if (route == null) {
    //      if (strictMode) {
    //        throw new ServiceException(MessageErrorCode.JSON_SCHEMA_NOT_FOUND);
    //      }
    //      filterChain.filter(exchange);
    //      return;
    //    }
    //    if (route.getSchema() == null) {
    //      filterChain.filter(exchange);
    //      return;
    //    }
    //    JsonSchema jsonSchema = jsonSchemaFactory.getSchema(JsonUtils.getObjectMapper().valueToTree(route.getSchema
    //    ()));
    //    Set<ValidationMessage> validationMessages;
    //    try {
    //      validationMessages = jsonSchema.validate(exchange.getPayload());
    //    } catch (JsonSchemaException e) {
    //      validationMessages = e.getValidationMessages();
    //    }
    //
    //    if (CollectionUtils.isNotEmpty(validationMessages)) {
    //      logValidationMessage(exchange, validationMessages);
    //      if (strictMode) {
    //        throw new ServiceException(MessageErrorCode.JSON_SCHEMA_INVALID);
    //      }
    //    }
    filterChain.filter(exchange);
  }

  void logValidationMessage(Exchange exchange, Set<ValidationMessage> validationMessages) {
    if (CollectionUtils.isNotEmpty(validationMessages)) {
      validationMessages.forEach(validationMessage -> {
        validationLog.warn(
          "{\"code\":{}, \"message\":\"{}\", \"args\":{}, \"topic\":{}, \"payload\": {}}",
          validationMessage.getCode(),
          validationMessage.getMessage(),
          JsonUtils.serialize(validationMessage.getArguments()),
          exchange.getHeaders().getTopic(),
          JsonUtils.serialize(exchange.getPayload())
        );
      });
    }
  }

  @Override
  public int getOrder() {
    return Ordered.HIGHEST_PRECEDENCE;
  }
}
