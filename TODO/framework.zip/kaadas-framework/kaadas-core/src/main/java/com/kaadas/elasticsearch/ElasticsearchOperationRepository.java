package com.kaadas.elasticsearch;

import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-15
 * @since 1.0.0
 */
@NoRepositoryBean
public interface ElasticsearchOperationRepository<T> extends ElasticsearchRepository<T, String> {
  /**
   * 获取{@link ElasticsearchOperations}对象
   *
   * @return org.springframework.data.elasticsearch.core.ElasticsearchOperations
   * @date 2022-08-17 16:06
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  ElasticsearchOperations getOperations();

  /**
   * 获取{@link ElasticsearchRestTemplate}对象
   *
   * @return org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate
   * @date 2022-08-17 16:41
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  ElasticsearchRestTemplate getTemplate();
}
