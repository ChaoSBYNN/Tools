package com.kaadas.elasticsearch;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.repository.support.ElasticsearchEntityInformation;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.util.Assert;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-15
 * @since 1.0.0
 */
@NoRepositoryBean
public class ElasticsearchOperationRepositoryImpl<T> extends AbstractElasticsearchRepository<T> {
  protected ElasticsearchOperations operations;
  protected ElasticsearchRestTemplate template;
  protected ElasticsearchEntityInformation<T, String> entityInformation;

  public ElasticsearchOperationRepositoryImpl(ElasticsearchEntityInformation<T, String> metadata,
                                              ElasticsearchOperations operations) {
    this.operations = operations;
    Assert.notNull(metadata, "ElasticsearchEntityInformation must not be null!");
    this.entityInformation = metadata;
    this.entityClass = this.entityInformation.getJavaType();
    this.indexOperations = operations.indexOps(this.entityClass);
  }

  @Override
  public @NotNull ElasticsearchOperations getOperations() {
    return operations;
  }

  @Autowired
  public void setOperations(ElasticsearchOperations operations) {
    this.operations = operations;
  }

  @Override
  public ElasticsearchRestTemplate getTemplate() {
    return template;
  }

  @Autowired
  public void setTemplate(ElasticsearchRestTemplate template) {
    this.template = template;
  }

  @Override
  protected @NotNull ElasticsearchEntityInformation<T, String> getEntityInformation() {
    return entityInformation;
  }
}
