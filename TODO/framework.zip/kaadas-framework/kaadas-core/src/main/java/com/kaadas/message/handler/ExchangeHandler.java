package com.kaadas.message.handler;

import com.kaadas.message.Exchange;
import com.kaadas.message.support.NameUtils;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-19
 * @since 1.0.0
 */
public interface ExchangeHandler {

  void handle(Exchange exchange);

  default String getName() {
    return NameUtils.normalizeExchangeHandlerName(getClass());
  }
}
