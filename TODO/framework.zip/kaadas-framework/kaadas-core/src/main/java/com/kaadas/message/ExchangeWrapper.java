package com.kaadas.message;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
public class ExchangeWrapper extends Exchange {

  public ExchangeWrapper(Exchange exchange) {
    super();
    setPayload(exchange.getPayload());
    setHeaders(exchange.getHeaders());
    setProperties(exchange.getProperties());
  }

  @Override
  public void setPayload(JsonNode payload) {
    super.setPayload(payload);
  }
}