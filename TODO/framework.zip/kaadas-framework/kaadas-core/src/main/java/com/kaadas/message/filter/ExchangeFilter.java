package com.kaadas.message.filter;

import com.kaadas.message.Exchange;
import org.springframework.core.Ordered;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
public interface ExchangeFilter extends Ordered {
  /**
   * 执行过滤
   *
   * @param exchange    param1
   * @param filterChain param2
   * @date 2022-05-10 17:48
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  void filter(Exchange exchange, ExchangeFilterChain filterChain);

  /**
   * 默认最低优先级
   *
   * @return int
   * @date 2022-05-10 17:48
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  @Override
  default int getOrder() {
    return Ordered.LOWEST_PRECEDENCE;
  }
}
