package com.kaadas.message.support;

import org.springframework.core.convert.converter.Converter;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-16
 * @since 1.0.0
 */
public interface ConfigConverter<T, R> extends Converter<T, R> {}
