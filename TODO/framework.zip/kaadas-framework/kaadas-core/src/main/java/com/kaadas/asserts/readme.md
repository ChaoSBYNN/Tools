# 断言器

**使用方式**

```java

String str="";

    Assert.isBlank(str);
    Assert.isBlank(str,AssertErrorCode.PARAM_IS_BLANK);
```

**默认抛出Runtime异常**

```java
throw new ServiceException();
```
