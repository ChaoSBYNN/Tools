package com.kaadas.message.filter;

/**
 * 抽象Exchange过滤器工厂
 *
 * @author ZhangDuanFeng
 * @date 2022-05-10
 * @since 1.0.0
 */
public abstract class AbstractExchangeFilterFactory<T> implements ExchangeFilterFactory<T> {
  private final Class<T> tClass;

  public AbstractExchangeFilterFactory(Class<T> tClass) {
    this.tClass = tClass;
  }

  @Override
  public Class<T> getConfigClass() {
    return tClass;
  }
}
