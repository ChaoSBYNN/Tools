package com.kaadas.message.route;

import com.kaadas.message.Exchange;
import com.kaadas.message.filter.DefaultExchangeFilterChain;
import com.kaadas.message.filter.ExchangeFilter;
import com.kaadas.message.support.ExchangeUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-28
 * @since 1.0.0
 */
@Log4j2
public abstract class AbstractMessageRouter implements MessageRouter {
  RouteDefinitionRouteLocator routeDefinitionRouteLocator;
  List<ExchangeFilter> globalFilters;

  public AbstractMessageRouter(RouteDefinitionRouteLocator routeDefinitionRouteLocator,
                               List<ExchangeFilter> globalFilters) {
    this.routeDefinitionRouteLocator = routeDefinitionRouteLocator;
    this.globalFilters = globalFilters;
  }

  @Override
  public final void route(Exchange exchange) {
    routeDefinitionRouteLocator.getRoutes().stream().filter(bean -> {
      if (bean.getPredicates() == null) {
        return false;
      }
      return bean.getPredicates().stream().allMatch(mp -> mp.test(exchange));
    }).forEach(route -> {
      exchange.putProperty(ExchangeUtils.MQTT_ROUTE_ATTR, route);
      List<ExchangeFilter> combined = new ArrayList<>(this.globalFilters);
      if (route.getFilters() != null) {
        combined.addAll(route.getFilters());
      }
      AnnotationAwareOrderComparator.sort(combined);
      new DefaultExchangeFilterChain(combined).filter(onRoute(exchange, route));
    });
  }

  /**
   * TODO
   *
   * @param exchange param1
   * @param route    param2
   * @return com.kaadas.message.Exchange
   * @date 2022-06-28 15:48
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public abstract Exchange onRoute(Exchange exchange, Route route);
}
