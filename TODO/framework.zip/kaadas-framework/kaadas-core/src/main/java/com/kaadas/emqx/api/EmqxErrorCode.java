package com.kaadas.emqx.api;

import com.kaadas.result.ErrorCode;
import com.kaadas.result.ResultCode;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-16
 * @since 1.0.0
 */
public enum EmqxErrorCode implements ErrorCode {
  /** EMQX服务器异常 */
  EMQX_SERVER_ERROR(ResultCode.INTERNAL_SERVER_ERROR, "emqx_server_error", "EMQX服务器异常", -1),
  /** 成功 */
  SUCCEED(ResultCode.OK, null, null, 0),
  /** RPC 错误 */
  RPC_ERROR(ResultCode.INTERNAL_SERVER_ERROR, "rpc_error", "RPC 错误", 101),
  /** 未知错误 */
  UNKNOWN_ERROR(ResultCode.INTERNAL_SERVER_ERROR, "unknown_error", "未知错误", 102),
  /** 用户名或密码错误 */
  ACCOUNT_PASSWORD_NOT_MATCH(ResultCode.BAD_REQUEST, "account_password_not_match", "用户名或密码错误", 103),
  /** 空用户名或密码 */
  ACCOUNT_PASSWORD_EMPTY(ResultCode.BAD_REQUEST, "account_password_empty", "空用户名或密码", 104),
  /** 用户不存在 */
  ACCOUNT_NOT_EXISTS(ResultCode.INTERNAL_SERVER_ERROR, "dirty_data", "用户不存在", 105),
  /** 管理员账户不可删除 */
  ADMIN_ACCOUNT_IS_NOT_DELETABLE(ResultCode.UNAUTHORIZED, "admin_account_is_not_deletable", "管理员账户不可删除", 106),
  /** 关键请求参数缺失 */
  MISSING_REQUEST_PARAM(ResultCode.BAD_REQUEST, "missing_request_param", "关键请求参数缺失", 107),
  /** 请求参数错误 */
  INVALID_PARAMETER(ResultCode.BAD_REQUEST, "invalid_parameter", "请求参数错误", 108),
  /** 请求参数不是合法 JSON 格式 */
  PARAM_NOT_JSON(ResultCode.BAD_REQUEST, "param_not_json", "请求参数不是合法 JSON 格式", 109),
  /** 插件已开启 */
  PLUGIN_ENABLED(ResultCode.OK, "plugin_enabled", "插件已开启", 110),
  /** 插件已关闭 */
  PLUGIN_DISABLED(ResultCode.OK, "plugin_disabled", "插件已关闭", 111),
  /** 客户端不在线 */
  CLIENT_IS_OFFLINE(ResultCode.ACCEPTED, "client_is_offline", "客户端不在线", 112),
  /** 用户已存在 */
  ACCOUNT_EXISTED(ResultCode.BAD_REQUEST, "account_existed", "用户已存在", 113),
  /** 旧密码错误 */
  INVALID_OLD_PASSWORD(ResultCode.BAD_REQUEST, "invalid_old_password", "旧密码错误", 114),
  /** 不合法的主题 */
  INVALID_TOPIC(ResultCode.BAD_REQUEST, "invalid_topic", "不合法的主题", 115),
  ;

  static Map<Integer, EmqxErrorCode> CACHE = new HashMap<>(16);

  static {
    for (EmqxErrorCode emqxErrorCode : values()) {
      CACHE.put(emqxErrorCode.getEmqxCode(), emqxErrorCode);
    }
  }

  @Getter
  private final ResultCode resultCode;
  @Getter
  private final String errCode;
  @Getter
  private final String errDes;
  @Getter
  private final int emqxCode;

  EmqxErrorCode(ResultCode resultCode, String errCode, String errDes, int emqxCode) {
    this.resultCode = resultCode;
    this.errCode = errCode;
    this.errDes = errDes;
    this.emqxCode = emqxCode;
  }

  public static EmqxErrorCode findByEmqxCode(int emqxCode) {
    return CACHE.get(emqxCode);
  }
}
