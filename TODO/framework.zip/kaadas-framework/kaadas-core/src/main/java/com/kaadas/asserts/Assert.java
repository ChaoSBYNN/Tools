package com.kaadas.asserts;

import com.kaadas.ServiceException;
import com.kaadas.result.ErrorCode;
import com.kaadas.util.CollectionUtils;
import com.kaadas.util.StringUtils;

import java.util.Collection;
import java.util.Map;
import java.util.function.Supplier;

/**
 * 统一抛{@link com.kaadas.ServiceException}
 *
 * @author ZhangDuanFeng
 * @date 2022-07-01
 * @since 1.0.0
 */
public class Assert {
  /**
   * 字符串为Blank抛异常。
   *
   * @param str param1
   * @date 2022-07-01 17:02
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isBlank(String str) {
    isBlank(str, AssertErrorCode.PARAM_IS_BLANK);
  }

  /**
   * 字符串为Blank抛异常，指定ErrorCode
   *
   * @param str       param1
   * @param errorCode param2
   * @date 2022-07-01 17:03
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isBlank(String str, ErrorCode errorCode) {
    if (StringUtils.isBlank(str)) {
      throw new ServiceException(errorCode);
    }
  }

  /**
   * 对象为null抛异常。
   *
   * @param obj param1
   * @date 2022-07-01 17:03
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isNull(Object obj) {
    isNull(obj, AssertErrorCode.PARAM_IS_NULL);
  }

  /**
   * 对象为null抛异常。指定ErrorCode
   *
   * @param obj       param1
   * @param errorCode param2
   * @date 2022-07-01 17:04
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isNull(Object obj, ErrorCode errorCode) {
    if (obj == null) {
      throw new ServiceException(errorCode);
    }
  }

  /**
   * 字符串为Empty抛异常。
   *
   * @param str param1
   * @date 2022-07-01 17:04
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isEmpty(String str) {
    isEmpty(str, AssertErrorCode.PARAM_IS_EMPTY);
  }

  /**
   * 字符串为Empty抛异常。指定ErrorCode
   *
   * @param str       param1
   * @param errorCode param2
   * @date 2022-07-01 17:05
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  public static void isEmpty(String str, ErrorCode errorCode) {
    if (StringUtils.isEmpty(str)) {
      throw new ServiceException(errorCode);
    }
  }

  public static void isEmpty(Collection<?> coll) {
    isNull(coll, AssertErrorCode.PARAM_IS_EMPTY);
  }

  public static void isEmpty(Collection<?> coll, ErrorCode errorCode) {
    if (CollectionUtils.isEmpty(coll)) {
      throw new ServiceException(errorCode);
    }
  }

  public static void isEmpty(Map<?, ?> map) {
    isNull(map, AssertErrorCode.PARAM_IS_EMPTY);
  }

  public static void isEmpty(Map<?, ?> map, ErrorCode errorCode) {
    if (CollectionUtils.isEmpty(map)) {
      throw new ServiceException(errorCode);
    }
  }


  public static void isTrue(boolean b) {
    isTrue(b, AssertErrorCode.PARAM_IS_TRUE);
  }

  public static void isTrue(boolean b, ErrorCode errorCode) {
    if (b) {
      throw new ServiceException(errorCode);
    }
  }

  public static void isFalse(boolean b) {
    isFalse(b, AssertErrorCode.PARAM_IS_FALSE);
  }

  public static void isFalse(boolean b, ErrorCode errorCode) {
    if (!b) {
      throw new ServiceException(errorCode);
    }
  }

  public static void isTrue(Supplier<Boolean> supplier) {
    isTrue(supplier, AssertErrorCode.PARAM_IS_TRUE);
  }

  public static void isTrue(Supplier<Boolean> supplier, ErrorCode errorCode) {
    if (supplier.get()) {
      throw new ServiceException(errorCode);
    }
  }

  public static void isFalse(Supplier<Boolean> supplier) {
    isFalse(supplier, AssertErrorCode.PARAM_IS_FALSE);
  }

  public static void isFalse(Supplier<Boolean> supplier, ErrorCode errorCode) {
    if (!supplier.get()) {
      throw new ServiceException(errorCode);
    }
  }
}
