package com.kaadas.emqx.api;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-13
 * @since 1.0.0
 */
@Data
@ConfigurationProperties("kaadas.emqx.api")
public class EmqxProperties {
  private String url;
  private String username;
  private String password;
  private int poolSize = 16;
}
