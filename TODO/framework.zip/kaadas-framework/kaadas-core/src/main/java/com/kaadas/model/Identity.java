package com.kaadas.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Objects;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Getter
@Setter
public class Identity<I extends Serializable> {
  @Id
  @TableId(value = "id", type = IdType.ASSIGN_UUID)
  protected I id;

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Identity<?> identity = (Identity<?>) o;
    return Objects.equals(id, identity.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }
}
