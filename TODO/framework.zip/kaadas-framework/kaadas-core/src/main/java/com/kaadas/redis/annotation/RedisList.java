package com.kaadas.redis.annotation;

import org.springframework.core.annotation.AliasFor;
import org.springframework.data.annotation.Persistent;
import org.springframework.data.keyvalue.annotation.KeySpace;

import java.lang.annotation.*;

/**
 * TODO
 *
 * @author df
 * @date 2022-03-25
 * @since 1.0.0
 */
@Persistent
@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@KeySpace
public @interface RedisList {
  @AliasFor(
    annotation = KeySpace.class,
    attribute = "value"
  )
  String value() default "";

  long timeToLive() default -1L;
}
