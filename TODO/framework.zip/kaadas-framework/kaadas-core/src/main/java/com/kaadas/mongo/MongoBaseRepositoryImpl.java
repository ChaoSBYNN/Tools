package com.kaadas.mongo;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.query.MongoEntityInformation;
import org.springframework.data.mongodb.repository.support.SimpleMongoRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.util.Assert;

@NoRepositoryBean
public class MongoBaseRepositoryImpl<T extends MongoEntity> extends AbstractMongoOperationRepository<T> implements MongoRepository<T, String>,
  MongoOperationRepository<T> {
  private final MongoOperations mongoOperations;
  private final MongoEntityInformation<T, String> entityInformation;

  /**
   * Creates a new {@link SimpleMongoRepository} for the given {@link MongoEntityInformation} and
   * {@link MongoTemplate}.
   *
   * @param metadata        must not be {@literal null}.
   * @param mongoOperations must not be {@literal null}.
   */
  public MongoBaseRepositoryImpl(MongoEntityInformation<T, String> metadata, MongoOperations mongoOperations) {
    super();
    Assert.notNull(metadata, "MongoEntityInformation must not be null!");
    Assert.notNull(mongoOperations, "MongoOperations must not be null!");

    this.entityInformation = metadata;
    this.mongoOperations = mongoOperations;
  }

  @NotNull
  @Override
  public MongoOperations getMongoOperations() {
    return mongoOperations;
  }

  @NotNull
  @Override
  protected MongoEntityInformation<T, String> getEntityInformation() {
    return entityInformation;
  }
}
