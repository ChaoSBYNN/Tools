package com.kaadas.mongo;

import com.mongodb.client.MongoClient;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.converter.ConverterFactory;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-02-23
 * @since 1.0.0
 */
@ConditionalOnClass({MongoClient.class, MongoTemplate.class})
@EnableMongoAuditing
@EnableMongoRepositories(basePackages = "com.kaadas", repositoryBaseClass = MongoBaseRepositoryImpl.class)
@Configuration
public class MongoConfiguration {

  @Bean
  public MongoCustomConversions mongoCustomConversions(ObjectProvider<Converter<?, ?>> converters,
                                                       ObjectProvider<ConverterFactory<?, ?>> converterFactories
  ) {
    return MongoCustomConversions.create(mongoConverterConfigurationAdapter -> {
      mongoConverterConfigurationAdapter.registerConverters(converters.stream().collect(Collectors.toList()));
      mongoConverterConfigurationAdapter.registerConverters(converterFactories.stream().collect(Collectors.toList()));
    });
  }

  @Bean
  public MongoEntityInformationCreator mongoEntityInformationCreator(MongoMappingContext mongoMappingContext) {
    return new MongoEntityInformationCreator(mongoMappingContext);
  }

  @Bean
  @ConditionalOnMissingBean
  public AuditorAware<String> mongoAuditorAware() {
    return new MongoAuditorAware();
  }
}
