package com.kaadas.model;

public interface Entity {
  String ID = "id";
}
