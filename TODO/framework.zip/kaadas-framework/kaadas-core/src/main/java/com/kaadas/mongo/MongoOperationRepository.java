package com.kaadas.mongo;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.FindAndReplaceOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;
import java.util.Optional;

@NoRepositoryBean
public interface MongoOperationRepository<T> extends MongoRepository<T, String> {
  /**
   * 地理位置查询
   *
   * @param near {@link NearQuery}
   * @return org.springframework.data.geo.GeoResults&lt;T&gt;
   * @date 2022-02-28 16:56
   * @author zhangduanfeng
   * @since 1.0.0
   */
  GeoResults<T> geoNear(NearQuery near);

  /**
   * 根据查询条件找一个{@link Query}
   *
   * @param query {@link Query}
   * @return java.util.Optional&lt;T&gt;
   * @date 2022-02-28 16:56
   * @author zhangduanfeng
   * @since 1.0.0
   */
  Optional<T> findOne(Query query);

  /**
   * 检查是否存在
   *
   * @param query {@link Query}
   * @return boolean
   * @date 2022-02-28 16:56
   * @author zhangduanfeng
   * @since 1.0.0
   */
  boolean exists(Query query);

  /**
   * 列表查询
   *
   * @param query {@link Query}
   * @return java.util.List&lt;T&gt;
   * @date 2022-02-28 16:56
   * @author zhangduanfeng
   * @since 1.0.0
   */
  List<T> find(Query query);

  /**
   * 查找并修改，原子操作(get-and-set)。比{@link MongoOperationRepository#updateFirst(Query, Update)}略慢
   *
   * @param query  {@link Query}
   * @param update {@link Update}
   * @return T
   * @date 2022-02-28 16:57
   * @author zhangduanfeng
   * @since 1.0.0
   */
  T findAndModify(Query query, Update update);

  /**
   * 查找并修改，原子操作(get-and-set)。比{@link MongoOperationRepository#updateFirst(Query, Update)}略慢
   *
   * @param query   {@link Query}
   * @param update  {@link Update}
   * @param options 选项{@link FindAndModifyOptions}
   * @return T
   * @date 2022-02-28 16:57
   * @author zhangduanfeng
   * @since 1.0.0
   */
  T findAndModify(Query query, Update update, FindAndModifyOptions options);

  /**
   * 查找并替换
   *
   * @param query       {@link Query}
   * @param replacement T 要替换的对象
   * @return T
   * @date 2022-02-28 16:58
   * @author zhangduanfeng
   * @since 1.0.0
   */
  default T findAndReplace(Query query, T replacement) {
    return findAndReplace(query, replacement, FindAndReplaceOptions.empty());
  }

  /**
   * 查找并替换
   *
   * @param query       {@link Query}
   * @param replacement T 要替换的对象
   * @param options     替换操作
   * @return T
   * @date 2022-02-28 16:58
   * @author zhangduanfeng
   * @since 1.0.0
   */
  T findAndReplace(Query query, T replacement, FindAndReplaceOptions options);


  /**
   * 查找并删除
   *
   * @param query {@link Query}
   * @return T
   * @date 2022-02-28 16:58
   * @author zhangduanfeng
   * @since 1.0.0
   */
  T findAndRemove(Query query);

  /**
   * 根据条件查询数量
   *
   * @param query {@link Query}
   * @return long
   * @date 2022-02-28 16:58
   * @author zhangduanfeng
   * @since 1.0.0
   */
  long count(Query query);

  /**
   * 根据ID修改，方法不会自动更新修改时间/人
   *
   * @param id     MongoDB主键
   * @param update {@link Update}
   * @return com.mongodb.client.result.UpdateResult
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  UpdateResult updateById(String id, Update update);

  /**
   * 修改或新增，方法不会自动更新创建时间/人和修改时间/人
   *
   * @param query  {@link Query}
   * @param update {@link Update}
   * @return com.mongodb.client.result.UpdateResult
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  UpdateResult upsert(Query query, Update update);

  /**
   * 修改第一个，方法不会自动更新修改时间/人
   *
   * @param query  {@link Query}
   * @param update {@link Update}
   * @return com.mongodb.client.result.UpdateResult
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  UpdateResult updateFirst(Query query, Update update);

  /**
   * 修改多个，方法不会自动更新修改时间/人
   *
   * @param query  {@link Query}
   * @param update {@link Update}
   * @return com.mongodb.client.result.UpdateResult
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  UpdateResult updateMulti(Query query, Update update);

  /**
   * 根据条件删除
   *
   * @param query {@link Query}
   * @return com.mongodb.client.result.DeleteResult
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  DeleteResult remove(Query query);

  /**
   * 根据条件删除多个
   *
   * @param query {@link Query}
   * @return java.util.List&lt;T&gt;
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  List<T> findAllAndRemove(Query query);

  /**
   * 分页查询
   *
   * @param query {@link Query}
   * @return org.springframework.data.domain.Page&lt;T&gt;
   * @date 2020-05-09 13:39
   * @author zhangduanfeng
   * @since 1.0.0
   */
  Page<T> page(Query query);

  /**
   * 分页查询
   *
   * @param query    {@link Query}
   * @param pageable {@link Pageable}
   * @return org.springframework.data.domain.Page&lt;T&gt;
   * @date 2022-09-04 09:51
   * @author zhangduanfeng
   * @since 1.0.0
   */
  Page<T> page(Query query, Pageable pageable);

  /**
   * 分页查询
   *
   * @param query    {@link Query}
   * @param pageable {@link Pageable}
   * @param sort     {@link Sort}
   * @return org.springframework.data.domain.Page&lt;T&gt;
   * @date 2022-09-04 09:52
   * @author zhangduanfeng
   * @since 1.0.0
   */
  Page<T> page(Query query, Pageable pageable, Sort sort);


  /**
   * 去重查询
   *
   * @param field 去重字段
   * @param query {@link Query}
   * @return java.util.List&lt;T&gt;
   * @date 2022-02-28 16:59
   * @author zhangduanfeng
   * @since 1.0.0
   */
  List<String> distinct(String field, Query query);

  /**
   * 获取{@link MongoOperations}对象
   *
   * @return org.springframework.data.mongodb.core.MongoOperations
   * @date 2019-09-04 09:45
   * @author zhangduanfeng
   * @since 1.0.0
   */
  MongoOperations getMongoOperations();
}
