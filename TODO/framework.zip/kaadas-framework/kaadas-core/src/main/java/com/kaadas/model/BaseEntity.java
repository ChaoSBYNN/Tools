package com.kaadas.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
@Getter
@Setter
public class BaseEntity<I extends Serializable> extends Identity<I> implements Entity, BaseModel {
  private static final long serialVersionUID = -3154883694634537347L;
  protected LocalDateTime createTime;
  protected I createUser;
  protected LocalDateTime updateTime;
  protected I updateUser;
}
