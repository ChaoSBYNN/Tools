package com.kaadas.emqx;

import io.grpc.BindableService;
import io.grpc.Grpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import lombok.Setter;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.concurrent.TimeUnit;

/**
 * EMQX gRPC Server.
 * <p>
 * 主要配置：
 * emqx.hook.grpc.enabled = {true | false}，用于开关gRPC Server
 * emqx.hook.grpc.port = {9000}，gRPC Server监听的端口
 *
 * @author ZhangDuanFeng
 * @date 2022-06-07
 * @since 1.0.0
 */
@Log4j2
@Component
@ConditionalOnProperty(value = "kaadas.emqx.hook.grpc.enabled", havingValue = "true")
@ConditionalOnClass(Grpc.class)
@ConfigurationProperties(prefix = "kaadas.emqx.hook.grpc")
public class EmqxHookServer implements CommandLineRunner {
  /** BindableService 是 EmqxHookProvider 的顶层父类 */
  ObjectProvider<BindableService> bindableServiceObjectProvider;
  private Server server;
  /** 默认端口为9000 */
  @Setter
  private int port = 9000;

  public EmqxHookServer(ObjectProvider<BindableService> bindableServiceObjectProvider) {
    this.bindableServiceObjectProvider = bindableServiceObjectProvider;
  }

  @Override
  public void run(String... args) throws Exception {
    ServerBuilder<?> serverBuilder = ServerBuilder.forPort(port);
    // 绑定多个 BindableService ，同名BindableService会被覆盖
    bindableServiceObjectProvider.forEach(serverBuilder::addService);
    server = serverBuilder.build().start();
    log.info("gRPC server starting on port {}", port);
  }

  @PreDestroy
  public void stop() throws InterruptedException {
    if (server != null) {
      server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
      log.info("gRPC server shutting");
    }
  }
}
