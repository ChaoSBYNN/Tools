package com.kaadas.model.page;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-03-07
 * @since 1.0.0
 */
@Data
public class Page {
  private int num;
  private int size;
  private long total;
  private long pages;
}
