package com.kaadas.model;

import com.kaadas.util.BeanUtils;

import java.io.Serializable;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2021-10-27
 * @since 1.0.0
 */
public interface BaseModel extends Serializable {

  /**
   * TODO
   *
   * @param tClass param1
   * @return T
   * @date 2022-03-06 16:50
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  default <T> T copyTo(Class<T> tClass) {
    return BeanUtils.copyBean(this, tClass);
  }

  default void copyTo(Object obj) {
    BeanUtils.copyProperties(this, obj);
  }
}
