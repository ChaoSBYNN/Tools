package com.kaadas.message.filter;

import com.kaadas.message.Exchange;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-28
 * @since 1.0.0
 */
public class ExchangeFilterAdapter implements ExchangeFilter {
  private final GlobalFilter delegate;

  public ExchangeFilterAdapter(GlobalFilter globalFilter) {
    this.delegate = globalFilter;
  }

  @Override
  public void filter(Exchange exchange, ExchangeFilterChain filterChain) {
    delegate.filter(exchange, filterChain);
  }

  @Override
  public int getOrder() {
    return delegate.getOrder();
  }
}
