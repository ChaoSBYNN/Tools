package com.kaadas.mongo;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.data.domain.*;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.FindAndReplaceOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.query.MongoEntityInformation;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.data.util.StreamUtils;
import org.springframework.data.util.Streamable;
import org.springframework.util.Assert;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@NoRepositoryBean
public abstract class AbstractMongoOperationRepository<T extends MongoEntity> implements MongoOperationRepository<T>, MongoRepository<T, String> {
  private static final String ENTITIES_NOT_BE_NULL = "The given Iterable of entities not be null!";
  private static final String ID_NOT_BE_NULL = "The given id must not be null!";
  private static final String SAMPLE_NOT_BE_NULL = "Sample must not be null!";

  public AbstractMongoOperationRepository() {
  }


  /**
   * 获取{@link MongoOperations}对象
   *
   * @return org.springframework.data.mongodb.core.MongoOperations
   * @date 2019-09-04 09:45
   * @author zhangduanfeng
   * @since 1.0.0
   */
  @Override
  public abstract @NotNull MongoOperations getMongoOperations();

  /**
   * 获取当前类中的实体信息
   *
   * @return org.springframework.data.mongodb.repository.query.MongoEntityInformation&lt;T,java.lang.String&gt;
   * @date 2019-09-04 09:45
   * @author zhangduanfeng
   * @since 1.0.0
   */
  protected abstract @NotNull MongoEntityInformation<T, String> getEntityInformation();

  @NotNull
  @Override
  public <S extends T> S save(@NotNull S entity) {
    Assert.notNull(entity, "Entity must not be null!"); if (getEntityInformation().isNew(entity)) {
      // 禁止使用自定义主键ID
      entity.setId(null); return getMongoOperations().insert(entity, getEntityInformation().getCollectionName());
    } return getMongoOperations().save(entity, getEntityInformation().getCollectionName());
  }

  @NotNull
  @Override
  public <S extends T> List<S> saveAll(@NotNull Iterable<S> entities) {
    Assert.notNull(entities, ENTITIES_NOT_BE_NULL); Streamable<S> source = Streamable.of(entities);
    boolean allNew = source.stream().allMatch(it -> {
      boolean isNew = getEntityInformation().isNew(it); if (isNew) {
        it.setId(null);
      } return isNew;
    }); if (allNew) {
      List<S> result = source.stream().collect(Collectors.toList());
      return new ArrayList<>(getMongoOperations().insert(result, getEntityInformation().getCollectionName()));
    } return source.stream().map(this::save).collect(Collectors.toList());
  }


  @NotNull
  @Override
  public Optional<T> findById(@NotNull String id) {
    Assert.notNull(id, ID_NOT_BE_NULL);
    return Optional.ofNullable(getMongoOperations().findById(id, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName()));
  }

  @Override
  public boolean existsById(@NotNull String id) {
    Assert.notNull(id, ID_NOT_BE_NULL);
    return getMongoOperations().exists(getIdQuery(id), getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public long count() {
    return getMongoOperations().count(new Query(), getEntityInformation().getCollectionName());
  }

  @Override
  public void deleteById(@NotNull String id) {
    Assert.notNull(id, ID_NOT_BE_NULL);
    getMongoOperations().remove(getIdQuery(id), getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }


  @Override
  public void delete(@NotNull T entity) {
    Assert.notNull(entity, "The given entity must not be null!");
    deleteById(getEntityInformation().getRequiredId(entity));
  }


  @Override
  public void deleteAll(@NotNull Iterable<? extends T> entities) {
    Assert.notNull(entities, ENTITIES_NOT_BE_NULL); entities.forEach(this::delete);
  }


  @Override
  public void deleteAll() {
    getMongoOperations().remove(new Query(), getEntityInformation().getCollectionName());
  }

  @Override
  public void deleteAllById(@NotNull Iterable<? extends String> ids) {
    remove(getIdQuery(ids));
  }

  @NotNull
  @Override
  public List<T> findAll() {
    return findAll(new Query());
  }


  @NotNull
  @Override
  public Iterable<T> findAllById(@NotNull Iterable<String> ids) {
    return findAll(new Query(new Criteria(getEntityInformation().getIdAttribute()).in(Streamable.of(ids).stream().collect(StreamUtils.toUnmodifiableList()))));
  }

  @NotNull
  @Override
  public Page<T> findAll(@NotNull Pageable pageable) {
    Assert.notNull(pageable, "Pageable must not be null!"); List<T> list = findAll(new Query().with(pageable));
    return new PageImpl<>(list, pageable, count());
  }


  @NotNull
  @Override
  public List<T> findAll(@NotNull Sort sort) {
    Assert.notNull(sort, "Sort must not be null!"); return findAll(new Query().with(sort));
  }


  @NotNull
  @Override
  public <S extends T> S insert(@NotNull S entity) {
    Assert.notNull(entity, "Entity must not be null!");
    return getMongoOperations().insert(entity, getEntityInformation().getCollectionName());
  }


  @NotNull
  @Override
  public <S extends T> List<S> insert(@NotNull Iterable<S> entities) {
    Assert.notNull(entities, ENTITIES_NOT_BE_NULL);
    List<S> insertList = StreamSupport.stream(entities.spliterator(), false).peek(s -> s.setId(null)).collect(Collectors.toList());
    return new ArrayList<>(getMongoOperations().insertAll(insertList));
  }

  @NotNull
  @Override
  public <S extends T> Page<S> findAll(@NotNull final Example<S> example, @NotNull Pageable pageable) {
    Assert.notNull(example, SAMPLE_NOT_BE_NULL); Assert.notNull(pageable, "Pageable must not be null!");
    Query q = new Query(new Criteria().alike(example)).with(pageable);
    List<S> list = getMongoOperations().find(q, example.getProbeType(), getEntityInformation().getCollectionName());
    return PageableExecutionUtils.getPage(list, pageable, () -> getMongoOperations().count(q, example.getProbeType(), getEntityInformation().getCollectionName()));
  }

  @NotNull
  @Override
  public <S extends T> List<S> findAll(@NotNull Example<S> example, @NotNull Sort sort) {

    Assert.notNull(example, SAMPLE_NOT_BE_NULL); Assert.notNull(sort, "Sort must not be null!");

    Query q = new Query(new Criteria().alike(example)).with(sort);

    return getMongoOperations().find(q, example.getProbeType(), getEntityInformation().getCollectionName());
  }


  @NotNull
  @Override
  public <S extends T> List<S> findAll(@NotNull Example<S> example) {
    return findAll(example, Sort.unsorted());
  }


  @NotNull
  @Override
  public <S extends T> Optional<S> findOne(@NotNull Example<S> example) {

    Assert.notNull(example, SAMPLE_NOT_BE_NULL);

    Query q = new Query(new Criteria().alike(example));
    return Optional.ofNullable(getMongoOperations().findOne(q, example.getProbeType(), getEntityInformation().getCollectionName()));
  }


  @Override
  public <S extends T> long count(@NotNull Example<S> example) {

    Assert.notNull(example, SAMPLE_NOT_BE_NULL);

    Query q = new Query(new Criteria().alike(example));
    return getMongoOperations().count(q, example.getProbeType(), getEntityInformation().getCollectionName());
  }

  @Override
  public <S extends T> boolean exists(@NotNull Example<S> example) {

    Assert.notNull(example, SAMPLE_NOT_BE_NULL);

    Query q = new Query(new Criteria().alike(example));
    return getMongoOperations().exists(q, example.getProbeType(), getEntityInformation().getCollectionName());
  }

  private Query getIdQuery(Object id) {
    return new Query(getIdCriteria(id));
  }

  private Query getIdQuery(Iterable<String> ids) {

    return new Query(new Criteria(getEntityInformation().getIdAttribute()).in(toCollection(ids)));
  }

  private static <E> Collection<E> toCollection(Iterable<E> ids) {
    return ids instanceof Collection ? (Collection<E>) ids : StreamUtils.createStreamFromIterator(ids.iterator()).collect(Collectors.toList());
  }

  private Criteria getIdCriteria(Object id) {
    return Criteria.where(getEntityInformation().getIdAttribute()).is(id);
  }

  private List<T> findAll(@Nullable Query query) {

    if (query == null) {
      return Collections.emptyList();
    }

    return getMongoOperations().find(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }


  @Override
  public GeoResults<T> geoNear(NearQuery near) {
    return getMongoOperations().geoNear(near, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public Optional<T> findOne(Query query) {
    return Optional.ofNullable(getMongoOperations().findOne(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName()));
  }

  @Override
  public boolean exists(Query query) {
    return getMongoOperations().exists(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public List<T> find(Query query) {
    return getMongoOperations().find(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public T findAndModify(Query query, Update update) {
    return getMongoOperations().findAndModify(query, update, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public T findAndModify(Query query, Update update, FindAndModifyOptions options) {
    return getMongoOperations().findAndModify(query, update, options, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public T findAndReplace(Query query, T replacement, FindAndReplaceOptions options) {
    return getMongoOperations().findAndReplace(query, replacement, options, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public T findAndRemove(Query query) {
    return getMongoOperations().findAndRemove(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public long count(Query query) {
    return getMongoOperations().count(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public UpdateResult updateById(String id, Update update) {
    return getMongoOperations().updateFirst(getIdQuery(id), update, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public UpdateResult upsert(Query query, Update update) {
    return getMongoOperations().upsert(query, update, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public UpdateResult updateFirst(Query query, Update update) {
    return getMongoOperations().updateFirst(query, update, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public UpdateResult updateMulti(Query query, Update update) {
    return getMongoOperations().updateMulti(query, update, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public DeleteResult remove(Query query) {
    return getMongoOperations().remove(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public List<T> findAllAndRemove(Query query) {
    return getMongoOperations().findAllAndRemove(query, getEntityInformation().getJavaType(), getEntityInformation().getCollectionName());
  }

  @Override
  public Page<T> page(Query query) {
    PageRequest pageRequest; if (query.getLimit() == 0L) {
      pageRequest = PageRequest.of((int) query.getSkip(), 20);
    } else {
      pageRequest = PageRequest.of((int) (query.getSkip() / query.getLimit()), query.getLimit());
    } return page(query, pageRequest, Sort.unsorted());
  }

  @Override
  public Page<T> page(Query query, Pageable pageable) {
    return page(query, pageable, pageable.getSort());
  }

  @Override
  public Page<T> page(Query query, Pageable pageable, Sort sort) {
    long count = count(query); if (count > 0L) {
      int page = pageable.getPageNumber() + 1; int size = pageable.getPageSize();
      long pageCount = (count + size - 1) / size; if (pageCount < page) {
        return new PageImpl<>(new ArrayList<>(0), pageable, count);
      } if (sort.isUnsorted()) {
        sort = Sort.by(Sort.Order.desc(MongoEntity.Fields.id));
      } query.with(pageable).with(sort);
      List<T> results = getMongoOperations().find(query, getEntityInformation().getJavaType());
      return PageableExecutionUtils.getPage(results, pageable, () -> count);
    } return new PageImpl<>(new ArrayList<>(0), pageable, 0L);
  }

  @Override
  public List<String> distinct(String field, Query query) {
    return getMongoOperations().findDistinct(query, field, getEntityInformation().getJavaType(), String.class);
  }
}
