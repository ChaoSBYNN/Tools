package com.kaadas.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kaadas.model.Entity;
import com.kaadas.util.StringUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.springframework.data.annotation.*;
import org.springframework.data.domain.Persistable;

import java.util.Objects;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-04-02
 * @since 1.0.0
 */
@Getter
@Setter
@FieldNameConstants
public class MongoEntity implements Entity, Persistable<String> {

  /**
   * 数据库主键ID
   */
  @Id
  protected String id;

  /**
   * 创建时间
   */
  @CreatedDate
  protected Long createTime;

  /**
   * 修改时间
   */
  @LastModifiedDate
  protected Long updateTime;

  /**
   * 创建人. 理论上可自动绑定当前登录人.  详见MongoAuditorAware
   */
  @CreatedBy
  protected Object createUser;

  /**
   * 修改人. 理论上可自动绑定当前登录人.  详见MongoAuditorAware
   */
  @LastModifiedBy
  protected Object updateUser;

  /**
   * 根据ID是否为空
   *
   * @return boolean
   * @date 2020-03-31 15:26
   * @author zhangduanfeng
   * @since 1.0.0
   */
  @Override
  @JsonIgnore
  public boolean isNew() {
    return StringUtils.isBlank(getId());
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MongoEntity entity = (MongoEntity) o;
    return Objects.equals(entity.getId(), this.getId());
  }

  @Override
  public int hashCode() {
    if (this.getId() == null) {
      return super.hashCode();
    }
    return Objects.hash(this.getClass().getName(), this.getId());
  }

  @Override
  public String toString() {
    return "MongoEntity{" +
      "id='" + id + '\'' +
      ", createTime=" + createTime +
      ", updateTime=" + updateTime +
      ", createUser=" + createUser +
      ", updateUser=" + updateUser +
      '}';
  }
}
