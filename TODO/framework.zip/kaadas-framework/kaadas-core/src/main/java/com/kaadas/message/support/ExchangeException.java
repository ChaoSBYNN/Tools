package com.kaadas.message.support;

import com.kaadas.ServiceException;
import com.kaadas.result.ErrorCode;
import org.jetbrains.annotations.NotNull;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-05-26
 * @since 1.0.0
 */
public class ExchangeException extends ServiceException {
  public ExchangeException(@NotNull ErrorCode errorCode) {
    super(errorCode);
  }

  public ExchangeException(@NotNull ErrorCode errorCode, String msg) {
    super(errorCode, msg);
  }

  public ExchangeException(@NotNull ErrorCode errorCode, Throwable cause) {
    super(errorCode, cause);
  }

  public ExchangeException(@NotNull ErrorCode errorCode, String message, Throwable cause) {
    super(errorCode, message, cause);
  }
}
