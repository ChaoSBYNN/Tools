package com.kaadas.message.handler.predicate;

import com.kaadas.message.Exchange;
import com.kaadas.message.support.NameUtils;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-06-21
 * @since 1.0.0
 */
public interface RoutePredicateFactory<T> {
  /**
   * TODO
   *
   * @param config param1
   * @return com.kaadas.paas.message.predicate.ProtocolPredicate&lt;com.kaadas.paas.message.Exchange&gt;
   * @date 2022-05-12 09:02
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  RoutePredicate<Exchange> apply(T config);

  /**
   * 获取配置类class
   *
   * @return java.lang.Class&lt;T&gt;
   * @date 2022-06-24 17:10
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  Class<T> getConfigClass();

  /**
   * 获取名称，类名截断RoutePredicateFactory。可覆盖自定义
   *
   * @return java.lang.String
   * @date 2022-06-24 17:10
   * @author ZhangDuanFeng
   * @since 1.0.0
   */
  default String getName() {
    return NameUtils.normalizeRoutePredicateName(getClass());
  }
}
