package com.kaadas.iot.event;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-26
 * @since 1.0.0
 */
@Data
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "id", include = JsonTypeInfo.As.EXISTING_PROPERTY)
@AllArgsConstructor
public abstract class IotEvent<T extends EventPayload> {
  protected String id;
  protected String name;
  protected String esn;
  protected long time;
  protected Type eventType;
  protected T payload;

  public IotEvent() {
    this.setId(this.getClass().getSimpleName());
    this.setEventType(Type.Message);
  }

  public IotEvent(String id, Type eventType) {
    this.setId(id);
    this.setEventType(eventType);
  }

  public IotEvent(T payload) {
    this();
    this.setPayload(payload);
  }

  public IotEvent(Type eventType, T payload) {
    this.setId(this.getClass().getSimpleName());
    this.setEventType(eventType);
    this.setPayload(payload);
  }

  public IotEvent(String id, Type eventType, T payload) {
    this(id, eventType);
    this.setPayload(payload);
  }

  public enum Type {
    Message,
    Alarm,
    Error;
  }
}
