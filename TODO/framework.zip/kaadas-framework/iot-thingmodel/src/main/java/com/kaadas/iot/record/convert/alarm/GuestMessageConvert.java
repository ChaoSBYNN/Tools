package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.GuestMessage;
import com.kaadas.iot.record.convert.AlarmConvertTyep;
import com.kaadas.iot.record.convert.IotEventConvertType;
import org.springframework.stereotype.Component;

/**
 * 访客留言
 *
 * @author liuqinxian
 * @date 2023-1-31
 * @since 1.0.0
 */
@Component
public class GuestMessageConvert extends AlarmConvertAbstract<AlarmPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return AlarmConvertTyep.GUEST_MESSAGE;
  }

  @Override
  IotEvent<AlarmPayload> createIotEvent() {
    return new GuestMessage();
  }
}
