package com.kaadas.iot.record.old;

import com.kaadas.mongo.MongoEntity;
import lombok.Data;
import lombok.experimental.FieldNameConstants;

import java.util.List;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@FieldNameConstants
@Data
public class OldRecord extends MongoEntity {

  /**
   * 锁名称
   */
  private String lockName;
  /**
   * wifi设备SN
   */
  private String wifiSN;
  /**
   * 蓝牙SN
   */
  private String bleSN;
  /**
   * 产品SN
   */
  private String productSN;
  /**
   * 设备mac地址
   */
  private String mac;
  /**
   * 记录时间
   */
  private Long time;
  /**
   * 密码类型：0=密码 3=卡片 4=指纹 7=人脸 8=APP 9=Unlock机械钥匙 10=室内OPEN键开锁 11=室内感应把手开锁 12=掌静脉 16=小度 17=天猫精灵 18=指静脉
   */
  private Integer pwdType;
  /**
   * 密码编号
   */
  private Integer pwdNum;
  /**
   * 锁端用户编号. 范围: [0, 99]
   */
  private String user;
  /**
   * 用户昵称
   */
  private String userNickname;
  /**
   * 密码昵称
   */
  private String pwdNickname;
  /**
   * 密码下的细分类型 5:时效密码 6:周期密码
   */
  private Integer pwdDetailType;
  /**
   * 是否胁迫
   */

  private Boolean duress;
  /**
   * 用户密码列表
   */
  private List<WifiOperationRecord.PwdInfo> pwdList;
}
