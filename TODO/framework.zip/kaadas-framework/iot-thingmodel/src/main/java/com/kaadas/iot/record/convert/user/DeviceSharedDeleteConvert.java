package com.kaadas.iot.record.convert.user;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.user.DeviceSharedDelete;
import com.kaadas.iot.event.user.DeviceSharedPayload;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
@Component
public class DeviceSharedDeleteConvert implements OptRecordConvert<DeviceSharedPayload> {
  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.DEVICE_SHARED_DELETE;
  }

  @Override
  public IotEvent<DeviceSharedPayload> toIotEvent(WifiOperationRecord oldRecord) {
    DeviceSharedDelete deviceSharedDelete = new DeviceSharedDelete();
    setIotEvent(deviceSharedDelete,oldRecord);
    DeviceSharedPayload payload = new DeviceSharedPayload();
    payload.setShareUid(oldRecord.getShareUid());
    payload.setUid(oldRecord.getUid());
    payload.setShareAccount(oldRecord.getShareAccount());
    payload.setUserNickname(oldRecord.getUserNickname());
    payload.setShareUserNickname(oldRecord.getShareUserNickname());
    deviceSharedDelete.setPayload(payload);
    return deviceSharedDelete;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<DeviceSharedPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    DeviceSharedPayload payload = iotEvent.getPayload();
    oldRecord.setShareUid(payload.getShareUid());
    oldRecord.setUid(payload.getUid());
    oldRecord.setShareAccount(payload.getShareAccount());
    oldRecord.setUserNickname(payload.getUserNickname());
    oldRecord.setShareUserNickname(payload.getShareUserNickname());
    return oldRecord;
  }
}
