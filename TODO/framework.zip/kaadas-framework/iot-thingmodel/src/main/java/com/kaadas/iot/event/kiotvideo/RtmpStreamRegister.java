package com.kaadas.iot.event.kiotvideo;

import com.kaadas.iot.event.EventPayload;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
public class RtmpStreamRegister extends KiotvideoEvent<EventPayload> {

  public RtmpStreamRegister() {
    super("Rtmp设备流注册");
  }
}
