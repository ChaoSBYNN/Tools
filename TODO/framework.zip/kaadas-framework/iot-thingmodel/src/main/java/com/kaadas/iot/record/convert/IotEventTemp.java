package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import lombok.experimental.FieldNameConstants;

/**
 * 此类只方便做数据转换
 * @author haungxufeng
 * @date 2022-11-11
 * @since 1.0.0
 */
@FieldNameConstants
public class IotEventTemp<T extends EventPayload> extends IotEvent<T> {}
