package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.secret.LockSecret;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public final class UnlockPayload implements EventPayload {
  /** 锁状态. 布尔: {0, 1}. 0 = 开锁; 1 = 关锁 */
  private int lockState;
  /** 锁密钥信息 */
  private LockSecret unlockSecret;
  /** 锁密钥扩展信息 */
  private Map<String, Object> extra;
}
