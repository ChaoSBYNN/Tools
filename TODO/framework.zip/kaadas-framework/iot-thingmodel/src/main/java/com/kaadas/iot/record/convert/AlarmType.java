package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public enum AlarmType implements IotEventType {

  /**输入错误密码或指纹或卡片超过10次就会触发系统锁定报警**/
  LOCKED_ALARM("LockedAlarm","锁定报警",IotEvent.Type.Alarm),
  /**输入防劫持密码或防劫持指纹开锁就报警**/
  DURESS_ALARM("DuressAlarm","劫持报警",IotEvent.Type.Alarm),
  /**三次错误，上报提醒**/
  THREE_ERRORS_ALARM("ThreeErrorsAlarm","三次错误报警",IotEvent.Type.Alarm),
  /**锁被撬开/强行打开触发报警**/
  FORCE_OPEN_ALARM("ForceOpenAlarm","撬锁报警",IotEvent.Type.Alarm),
  /**使用机械钥匙开锁产生报警**/
  MECHANICAL_KEY_UNLOCK_ALARM("MechanicalKeyUnlockAlarm","机械钥匙报警",IotEvent.Type.Alarm),
  /**电池电量不足**/
  LOW_BATTERY_ALARM("LowBatteryAlarm","低电压报警",IotEvent.Type.Alarm),
  /**锁体异常(旧：门锁不上)时触发报警**/
  LOCK_ERROR_ALARM("LockErrorAlarm","锁体异常报警(门锁不上报警)",IotEvent.Type.Alarm),
  /**门外布防后，从门内开锁了就会报警**/
  DEFENCE_ALARM("DefenceAlarm","门锁布防报警",IotEvent.Type.Alarm),
  /**门铃响了**/
  DOOR_BELL_RINGING("DoorBellRinging","门铃报警",IotEvent.Type.Alarm),
  /**访客有留言**/
  GUEST_MESSAGE("GuestMessage","访客留言",IotEvent.Type.Alarm),
  /**PIR动作侦测报警**/
  PIR_ALARM("PirAlarm","PIR报警",IotEvent.Type.Alarm),
  /**门锁前人员徘徊时产生报警**/
  WANDERING_ALARM("WanderingAlarm","人脸徘徊报警",IotEvent.Type.Alarm);

  ;
  AlarmType(String id,String name,IotEvent.Type eventType){
    this.id = id;
    this.name = name;
    this.eventType = eventType;
  }

  private String id;
  private String name;
  private IotEvent.Type eventType;

  @Override
  public String getId() {
    return id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public IotEvent.Type getEventType() {
    return eventType;
  }
}
