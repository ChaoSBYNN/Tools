package com.kaadas.iot.event.network;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
public class Triple {
  private String id;
  /** 腾讯产品ID */
  private String productId;
  /** 设备名 */
  private String deviceName;
  /** 设备密钥 */
  private String deviceSecret;

  public String toTripleString() {
    return getProductId() + ";" + getDeviceName() + ";" + getDeviceSecret();
  }
}
