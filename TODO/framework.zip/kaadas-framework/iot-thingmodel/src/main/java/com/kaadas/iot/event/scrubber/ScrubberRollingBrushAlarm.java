package com.kaadas.iot.event.scrubber;

import com.kaadas.iot.event.EventAlarmPayload;
import com.kaadas.iot.event.IotEventAlarm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 洗地机滚刷异常告警
 * @author haungxufeng
 * @date 2023-01-06
 * @since 1.0.0
 */
public class ScrubberRollingBrushAlarm extends IotEventAlarm<ScrubberRollingBrushAlarm.RollingBrushAlarmPayload> {
  public ScrubberRollingBrushAlarm() {
    super();
    setName("滚刷异常报警");
    setEventType(Type.Alarm);
  }

  public ScrubberRollingBrushAlarm(ScrubberRollingBrushAlarm.RollingBrushAlarmPayload payload) {
    super(payload);
    setName("滚刷异常报警");
    setEventType(Type.Alarm);
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class RollingBrushAlarmPayload extends EventAlarmPayload {
    private int rollingBrush;
  }
}
