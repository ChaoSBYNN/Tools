package com.kaadas.iot.record.convert;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-28
 * @since 1.0.0
 */
public enum AlarmConvertTyep implements IotEventConvertType {

  /**输入错误密码或指纹或卡片超过10次就会触发系统锁定报警**/
  LOCKED_ALARM(1, AlarmType.LOCKED_ALARM),
  /**输入防劫持密码或防劫持指纹开锁就报警**/
  DURESS_ALARM(2, AlarmType.DURESS_ALARM),
  /**三次错误，上报提醒**/
  THREE_ERRORS_ALARM(3, AlarmType.THREE_ERRORS_ALARM),
  /**锁被撬开/强行打开触发报警**/
  FORCE_OPEN_ALARM(4, AlarmType.FORCE_OPEN_ALARM),
  /**使用机械钥匙开锁产生报警**/
  MECHANICAL_KEY_UNLOCK_ALARM(8, AlarmType.MECHANICAL_KEY_UNLOCK_ALARM),
  /**电池电量不足**/
  LOW_BATTERY_ALARM(16, AlarmType.LOW_BATTERY_ALARM),
  /**锁体异常(旧：门锁不上)时触发报警**/
  LOCK_ERROR_ALARM(32, AlarmType.LOCK_ERROR_ALARM),
  /**门外布防后，从门内开锁了就会报警**/
  DEFENCE_ALARM(64, AlarmType.DEFENCE_ALARM),
  /**门铃响了**/
  DOOR_BELL_RINGING(96, AlarmType.DOOR_BELL_RINGING),
  /**门铃响了**/
  GUEST_MESSAGE(97, AlarmType.GUEST_MESSAGE),
  /**PIR动作侦测报警**/
  PIR_ALARM(112, AlarmType.PIR_ALARM),
  /**门锁前人员徘徊时产生报警**/
  WANDERING_ALARM(113, AlarmType.WANDERING_ALARM);

  private AlarmConvertTyep(int type, IotEventType iotEventType){
    this.type=type;
    this.iotEventType = iotEventType;
  }

  private final int type;


  private final IotEventType iotEventType;

  @Override
  public int getType() {
    return this.type;
  }

  @Override
  public IotEventType iotEventType() {
    return this.iotEventType;
  }


  public static AlarmConvertTyep findByType(int type) {

    for (AlarmConvertTyep alarmTyep:values()) {
      if (type==alarmTyep.getType()){
        return alarmTyep;
      }
    }
    return null;
  }


  public static AlarmConvertTyep findById(String id) {
    for (AlarmConvertTyep alarmTyep:values()) {
      if (alarmTyep.iotEventType.getId().equals(id)){
        return alarmTyep;
      }
    }
    return null;
  }
}
