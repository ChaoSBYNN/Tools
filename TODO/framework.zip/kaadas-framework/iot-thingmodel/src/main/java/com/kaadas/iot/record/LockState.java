package com.kaadas.iot.record;

import lombok.Getter;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-28
 * @since 1.0.0
 */
public enum LockState {
  /**开锁**/UNLOCK(0),
  /**关锁**/ LOCKED(1),
  ;

  private LockState(int state){
    this.state = state;
  }
  @Getter
  private int state;
}
