package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * 门内呼叫已接听
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class DoorPanelCallAnswer extends IotEvent<EmptyPayload> {
  public DoorPanelCallAnswer() {
    super();
    setName("门内呼叫已接听");
  }
}
