package com.kaadas.iot.event.call;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

@Data
public class DoorPanelCallPayload implements EventPayload {
  /** 门内屏呼叫值：枚举{1呼叫, 2取消呼叫, 3挂断通话} */
  private Integer callValue;
}