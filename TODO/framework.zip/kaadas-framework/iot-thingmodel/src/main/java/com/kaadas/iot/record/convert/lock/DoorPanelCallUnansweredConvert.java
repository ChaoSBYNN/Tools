package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.DoorPanelCallUnanswered;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * 门内呼叫未接听
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class DoorPanelCallUnansweredConvert implements OptRecordConvert<EmptyPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.DOOR_PANEL_CALL_UNANSWERED;
  }

  @Override
  public IotEvent<EmptyPayload> toIotEvent(WifiOperationRecord oldRecord) {
    DoorPanelCallUnanswered doorPanelCallUnanswered = new DoorPanelCallUnanswered();
    setIotEvent(doorPanelCallUnanswered,oldRecord);
    EmptyPayload emptyPayload = new EmptyPayload();
    doorPanelCallUnanswered.setPayload(emptyPayload);
    return doorPanelCallUnanswered;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<EmptyPayload> iotEvent) {
    return createOldRecord(iotEvent);
  }

}
