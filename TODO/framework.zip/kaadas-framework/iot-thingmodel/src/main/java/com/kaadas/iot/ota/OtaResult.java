package com.kaadas.iot.ota;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-28
 * @since 1.0.0
 */
public class OtaResult extends IotOta<OtaResultPayload> {
  public OtaResult() {
    super();
    setMsgType(MsgType.OtaResult);
  }

  public OtaResult(OtaResultPayload payload) {
    this();
    this.setPayload(payload);
  }
}
