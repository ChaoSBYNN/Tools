package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.UnLockedOutOperating;
import com.kaadas.iot.record.LockOutState;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class UnLockedOutOperatingConvert implements OptRecordConvert<UnLockedOutOperating.UnLockedOutOperatingPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.UNLOCKED_OUT_OPERATING;
  }

  @Override
  public IotEvent<UnLockedOutOperating.UnLockedOutOperatingPayload> toIotEvent(WifiOperationRecord oldRecord) {
    UnLockedOutOperating unLockedOutOperating = new UnLockedOutOperating();
    setIotEvent(unLockedOutOperating,oldRecord);
    UnLockedOutOperating.UnLockedOutOperatingPayload payload = new UnLockedOutOperating.UnLockedOutOperatingPayload();
    payload.setLockedOutState(LockOutState.UN_LOCK_OUT_STATE.getState());
    unLockedOutOperating.setPayload(payload);
    return unLockedOutOperating;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<UnLockedOutOperating.UnLockedOutOperatingPayload> iotEvent) {
    return createOldRecord(iotEvent);
  }
}
