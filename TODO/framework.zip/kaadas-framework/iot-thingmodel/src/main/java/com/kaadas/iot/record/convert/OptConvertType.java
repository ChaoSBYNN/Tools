package com.kaadas.iot.record.convert;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-28
 * @since 1.0.0
 */
public enum OptConvertType implements IotEventConvertType{
  UNLOCK(1, LockType.UNLOCK),
  LOCKED(2, LockType.LOCKED),
  ADDED_SECRET(3, SecretType.ADDED_SECRET),
  DELETED_SECRET(4, SecretType.DELETED_SECRET),
  MASTER_PASSWORD_CHANGED(5, SecretType.MASTER_PASSWORD_CHANGED),
  /** 0x01：自动模式 */ AUTO_MODE(6, ModeType.AUTO_MODE),
  /** 0x02：手动模式 */ MANUAL_MODE(7,  ModeType.MANUAL_MODE),
  /** 0x03：通用模式 */ COMMON_MODE(8, ModeType.COMMON_MODE),
  /** 0x04：安全模式 */ SAFE_MODE(9, ModeType.SAFE_MODE),
  /** 0x05:	反锁模式 */ LOCKED_OUT_MODE(10, ModeType.LOCKED_OUT_MODE),
  /** 0x06:	布防模式 */ DEFENCE_MODE(11, ModeType.DEFENCE_MODE),
  SECRET_NICKNAME_CHANGED(12, SecretType.SECRET_NICKNAME_CHANGED),
  DEVICE_SHARED_ADDED(13, UserType.DEVICE_SHARED_ADDED),
  DEVICE_SHARED_DELETE(14, UserType.DEVICE_SHARED_DELETE),
  MASTER_FINGERPRINT_CHANGED(15, SecretType.MASTER_FINGERPRINT_CHANGED),
  MASTER_FINGERPRINT_ADDED(16, SecretType.MASTER_FINGERPRINT_ADDED),
  /** 0x07:	节能模式 */ POWER_SAVING_MODE(17, ModeType.POWER_SAVING_MODE),
  /** 0x08:	关闭节能模式 */ CANCEL_POWER_SAVING_MODE(18, ModeType.CANCEL_POWER_SAVING_MODE),
  /**  */ RESTORE_FACTORY_SETTINGS(19, LockType.RESTORE_FACTORY_SETTINGS),
  /**室内反锁操作 */ LOCKED_OUT_OPERATING(20, LockType.LOCKED_OUT_OPERATING),
  /**室内反锁解除操**/UNLOCKED_OUT_OPERATING(21, LockType.UNLOCKED_OUT_OPERATING),
  DEVICE_USER_Added(22, UserType.DEVICE_USER_Added),
  DEVICE_USER_DELETE(23, UserType.DEVICE_USER_DELETE),
  DEVICE_USER_NICK_CHANGED(24, UserType.DEVICE_USER_NICK_CHANGED),
  MASTER_VEIN_CHANGED(25, SecretType.MASTER_VEIN_CHANGED),
  MASTER_VEIN_ADDED(26, SecretType.MASTER_VEIN_ADDED),
  MASTER_PALM_CHANGED(27, SecretType.MASTER_PALM_CHANGED),
  MASTER_PALM_ADDED(28, SecretType.MASTER_PALM_ADDED),
  DOOR_PANEL_CALL_ANSWER(29, LockType.DOOR_PANEL_CALL_ANSWER),
  DOOR_PANEL_CALL_UNANSWERED(30, LockType.DOOR_PANEL_CALL_ANSWER),
  ;

  private final int type;

  private final IotEventType iotEventType;

  @Override
  public int getType() {
    return this.type;
  }

  @Override
  public IotEventType iotEventType() {
    return this.iotEventType;
  }


  OptConvertType(int type, IotEventType iotEventType) {
    this.type = type;
    this.iotEventType = iotEventType;
  }



  public static OptConvertType findByType(int type) {
    for (OptConvertType optType:values()) {
      if (type==optType.getType()){
        return optType;
      }
    }
    return null;
  }


  public static OptConvertType findById(String id) {
    for (OptConvertType optType:values()) {
      if (optType.iotEventType.getId().equals(id)){
        return optType;
      }
    }
    return null;
  }

  //    public static void values(){
  //      OptType.values();
  //      return;
  //    }
}
