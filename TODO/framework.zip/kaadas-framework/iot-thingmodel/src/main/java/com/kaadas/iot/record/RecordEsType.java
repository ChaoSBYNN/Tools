package com.kaadas.iot.record;

public enum RecordEsType {
  Message,
  Alarm,
  Error,
  Guest;
}