package com.kaadas.iot.record.convert;


import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.old.OldRecord;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
public interface RecordConvert<T extends OldRecord ,P extends EventPayload> {

   IotEventConvertType getIotEventType();

   IotEvent<P>  toIotEvent(T oldRecord);

   T toOldRecord(IotEvent<P> iotEvent);
}
