package com.kaadas.iot.record.convert.mode;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.ModePayload;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
public abstract class ModelConvertAbstract<P extends ModePayload> implements OptRecordConvert<P> {

  @Override
  public IotEvent<P> toIotEvent(WifiOperationRecord oldRecord) {
    IotEvent iotEvent = createIotEvent();
    setIotEvent(iotEvent,oldRecord);
    iotEvent.setPayload(createModePayload());
    return iotEvent;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<P> iotEvent) {
    return createOldRecord(iotEvent);
  }


  ModePayload createModePayload(){
    return new ModePayload();
  }

  abstract IotEvent<P> createIotEvent();
}
