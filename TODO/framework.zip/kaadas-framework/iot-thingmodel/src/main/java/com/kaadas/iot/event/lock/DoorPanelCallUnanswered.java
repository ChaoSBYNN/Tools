package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * 门内呼叫未接听
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class DoorPanelCallUnanswered extends IotEvent<EmptyPayload> {
  public DoorPanelCallUnanswered() {
    super();
    setName("门内呼叫未接听");
  }

}
