package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.Locked;
import com.kaadas.iot.event.lock.LockedPayload;
import com.kaadas.iot.record.LockState;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class LockedConvert implements OptRecordConvert<LockedPayload> {


  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.LOCKED;
  }

  @Override
  public IotEvent<LockedPayload> toIotEvent(WifiOperationRecord oldRecord) {
    Locked locked = new Locked();
    setIotEvent(locked,oldRecord);
    LockedPayload lockedPayload = new LockedPayload();
    lockedPayload.setLockState(LockState.LOCKED.getState());
    locked.setPayload(lockedPayload);
    return locked;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<LockedPayload> iotEvent) {
    return createOldRecord(iotEvent);
  }
}
