package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.IotAlarm;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class ThreeErrorsAlarm extends IotAlarm<AlarmPayload> {
  public ThreeErrorsAlarm() {
    super();
  }

  public ThreeErrorsAlarm(AlarmPayload payload) {
    super(payload);
  }
}
