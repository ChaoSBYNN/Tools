package com.kaadas.iot.record.old;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.experimental.FieldNameConstants;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 设备操作记录
 * @ClassName OperationRecord
 * @Description
 * @Author huangxufeng
 * @Date 2022/3/22 15:29
 */
@Data
@FieldNameConstants
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document("kdsWifiOperationRecord")
public class WifiOperationRecord extends OldRecord {
  /**
   * 记录类型：1开锁 2关锁 3添加密钥\\n\" +\n" +
   *     "      \"4删除密钥 5修改管理员密码 6自动模式 7手动模式 8通用模式 9安全模式 10反锁模式\\n\" +\n" +
   *     "      \"11布防模式 12修改密码昵称 13添加分享用户 14删除分享用户 15修改管理指纹\\n\" +\n" +
   *     "      \"16添加管理员指纹 17开启节能模式 18关闭节能模式 20室内反锁 21室内反锁解除\\n\"+\n" +
   *     "      \"22添加设备用户 23删除设备用户 24修改用户昵称 25修改管理员指静脉 26添加管理员指静脉  27修改管理员掌静脉 28添加管理员掌静脉
   */
  private Integer type;
  /**
   * 旧密码昵称
   */
  private String oldPwdNickname;
  /**
   * 主账号下分享用户编号
   */
  private String appId;
  /**
   * 用户账号
   */
  private String uname;
  /**
   * 主账号用户id
   */
  private String uid;
  /**
   * 分享用户账号
   */
  private String shareAccount;
  /**
   * 分享用户id
   */
  private String shareUid;
  /**
   * 分享用户昵称
   */
  private String shareUserNickname;
  /**
   * 旧用户昵称
   */
  private String oldUserNickname;
  /**
   * 用于数据去重 添加数据的时候将数据拼接，在数据库这个字段会建立唯一索引
   */
  private String uk;
  /**
   * 子设备用户昵称
   */
  private String subNickname;

  @Data
  public class PwdInfo{
    /**
     * 密钥类型
     */
    private Integer pwdType;
    /**
     * 密钥编号
     */
    private Integer pwdNum;
  }


  /**
   * 描述
   *    操作类型
   * @author huangxufeng
   * @date 2022/4/5 18:05
   * @return
   */
  public enum OptType {
    UNLOCK(1, "Unlock"),
    LOCKED(2, "Locked"),
    ADDED(3, "AddedSecret"),
    DELETED(4, "DeletedSecret"),
    MASTER_PASSWORD_MODIFIED(5, "MasterPasswordChanged"),
    /** 0x01：自动模式 */ AUTO(6, "AutoMode"),
    /** 0x02：手动模式 */ MANUAL(7, "ManualMode"),
    /** 0x03：通用模式 */ COMMON(8, "CommonMode"),
    /** 0x04：安全模式 */ SAFE(9, "SafeMode"),
    /** 0x05:	反锁模式 */ LOCKED_OUT(10, "LockedOutMode"),
    /** 0x06:	布防模式 */ DEFENCE(11, "DefenceMode"),
    SECRET_NICKNAME_MODIFIED(12, "SecretNicknameChanged"),
    DEVICE_SHARED(13, "DeviceSharedAdded"),
    DEVICE_SHARING_CANCELED(14, "DeviceSharedDelete"),
    MASTER_FINGERPRINT_MODIFIED(15, "MasterFingerprintChanged"),
    MASTER_FINGERPRINT_ADDED(16, "MasterFingerprintAdded"),
    /** 0x07:	节能模式 */ POWER_SAVING(17, "PowerSavingMode"),
    /** 0x08:	关闭节能模式 */ DISABLE_POWER_SAVING(18, "CancelPowerSavingMode"),
    /**  */ RESTORE_FACTORY_SETTINGS(19, "RestoreFactorySettings"),
    /**室内反锁操作 */ LOCKED_OUT_OPERATING(20, "LockedOutOperating"),
    /**室内反锁解除操**/UNLOCKED_OUT_OPERATING(21,"UnLockedOutOperating"),
    DEVICE_USER_ADD(22, "DeviceUserAdded"),
    DEVICE_USER_DELETE(23, "DeviceUserDelete"),
    USER_NICK_MODIFIED(24, "DeviceUserNickChanged"),
    MASTER_VEIN_MODIFIED(25, "MasterVeinChanged"),
    MASTER_VEIN_ADDED(26, "MasterVeinAdded"),
    ;
    @Getter
    private final int type;
    @Getter
    private final String name;

    OptType(int type, String name) {
      this.type = type;
      this.name = name;
    }

    //    public static void values(){
    //      OptType.values();
    //      return;
    //    }
  }

}
