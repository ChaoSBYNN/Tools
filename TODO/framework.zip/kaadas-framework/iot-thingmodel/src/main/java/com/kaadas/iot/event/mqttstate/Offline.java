package com.kaadas.iot.event.mqttstate;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class Offline extends IotEvent<OfflinePayload> {
  public Offline() {
    setName("设备离线");
  }
}
