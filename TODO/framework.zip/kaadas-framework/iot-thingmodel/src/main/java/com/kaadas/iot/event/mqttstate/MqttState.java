package com.kaadas.iot.event.mqttstate;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public enum MqttState {
  Online,
  Offline
}
