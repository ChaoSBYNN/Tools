package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.RecordEs;
import com.kaadas.iot.record.RecordEsType;
import com.kaadas.iot.record.old.OldRecord;
import com.kaadas.iot.record.old.WifiAlarmRecord;
import com.kaadas.iot.record.old.WifiOperationRecord;
import com.kaadas.util.BeanUtils;
import com.kaadas.util.CollectionUtils;
import com.kaadas.util.JsonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Log4j2
@Component
public class RecordConvertFactory {

  Map<IotEventConvertType,RecordConvert> iotEventMap = new HashMap<>();
  Map<IotEventConvertType,Class<EventPayload>> iotEventPayloadMap = new HashMap<>();


  public RecordConvertFactory(ObjectProvider<RecordConvert<?,?>> recordConverts){
    recordConverts.stream().forEach(recordConvert -> {
      IotEventConvertType iotEventType = recordConvert.getIotEventType();
      iotEventMap.put(iotEventType,recordConvert);
      Optional<Class<EventPayload>> clz = getPayloadClass(recordConvert);
      if (clz.isPresent()){
        iotEventPayloadMap.put(iotEventType,clz.get());
      }
    });
  }

  public  <T extends OldRecord> List<IotEvent<EventPayload>> toIotEvent(List<T> oldRecords){
    if (CollectionUtils.isEmpty(oldRecords)){
      return new ArrayList<>();
    }
    return oldRecords.stream()
                     .map(oldRecord -> toIotEvent(oldRecord))
                     .filter(Objects::nonNull)
                     .collect(Collectors.toList());
  }

  public  <T extends OldRecord,E extends EventPayload> IotEvent<E> toIotEvent(T oldRecord){
    IotEventConvertType byType = null;
    if (oldRecord instanceof WifiAlarmRecord){
      byType = AlarmConvertTyep.findByType(((WifiAlarmRecord) oldRecord).getType());
    }
    if (oldRecord instanceof WifiOperationRecord){
       byType = OptConvertType.findByType(((WifiOperationRecord) oldRecord).getType());
    }
    RecordConvert  recordConvert = iotEventMap.get(byType);
    if (Objects.isNull(recordConvert)){
      return null;
    }
    return recordConvert.toIotEvent(oldRecord);
  }

  public <T extends OldRecord> List<T> toOldRecord(List<IotEvent<EventPayload>> iotEvents){
    if (CollectionUtils.isEmpty(iotEvents)){
      return new ArrayList<>();
    }
    return iotEvents.stream().map(iotEvent -> {
      T oldRecord = toOldRecord(iotEvent);
      return oldRecord;
    }).filter(Objects::nonNull).collect(Collectors.toList());
  }

  public <T extends OldRecord,E extends EventPayload> T toOldRecord(IotEvent<E> iotEvent){
    IotEventConvertType byType = null;
    if (iotEvent.getEventType().equals(IotEvent.Type.Alarm)){
      byType = AlarmConvertTyep.findById(iotEvent.getId());
    }
    if (iotEvent.getEventType().equals(IotEvent.Type.Message)){
      byType = OptConvertType.findById(iotEvent.getId());
    }
    RecordConvert recordConvert = iotEventMap.get(byType);
    if (Objects.isNull(recordConvert)){
      return null;
    }
    return (T) recordConvert.toOldRecord(iotEvent);
  }

  public <T extends OldRecord> List<T> newRecordToOldRecord(List<RecordEs> records){
    if (CollectionUtils.isEmpty(records)){
      return new ArrayList<>();
    }
    return records.stream().map(record -> {
      T oldRecord = newRecordToOldRecord(record);
      return oldRecord;
    }).filter(Objects::nonNull).collect(Collectors.toList());
  }

  public <T extends OldRecord> T newRecordToOldRecord(RecordEs record){
    RecordEsType type = record.getType();
    String name = record.getName();
    IotEventConvertType byType = null;
    if (type.equals(RecordEsType.Alarm)||type.equals(RecordEsType.Guest)){
      byType = AlarmConvertTyep.findById(name);
    }
    if (type.equals(RecordEsType.Message)){
      byType = OptConvertType.findById(name);
    }
    if (Objects.isNull(byType)){
      return null;
    }
    Class<EventPayload> clz = iotEventPayloadMap.get(byType);
    if (Objects.isNull(clz)){
      return null;
    }
    IotEventTemp<EventPayload> iotEvent = BeanUtils.copyBean(record, IotEventTemp.class);
    Map<String, Object> payload = record.getPayload();
    if (Objects.nonNull(payload)){
      try {
        iotEvent.setPayload(JsonUtils.mapToBean(payload,clz));
      }catch (Exception e){
        log.warn("转换数据异常:" + JsonUtils.serialize(record),e);
      }

    }
    iotEvent.setEventType(byType.iotEventType().getEventType());
    iotEvent.setId(record.getName());
    iotEvent.setName(byType.iotEventType().getName());
    return toOldRecord(iotEvent);
  }

  /**
   * 获取记录数据类型
   * @param recordHandler
   * @param <H>
   * @return
   */
  <H extends RecordConvert,R> Optional<Class<R>> getPayloadClass(H recordHandler){
    //获得带有泛型的父类
    Type genericSuperclass = recordHandler.getClass().getGenericSuperclass();
    if (!(genericSuperclass instanceof ParameterizedType)){
      genericSuperclass = Optional.of(recordHandler.getClass().getGenericInterfaces())
                                  .filter(interfaces->Objects.nonNull(interfaces))
                                  .filter(interfaces->interfaces.length>0)
                                  .map(interfaces->interfaces[0])
                                  .orElse(genericSuperclass);
    }
    //判断父类是不是参数化的类型，如果是强转成ParameterizedType
    if (genericSuperclass instanceof ParameterizedType){
      ParameterizedType parameterizedType = (ParameterizedType)genericSuperclass;
      //获得MqMessageHandler<T extends MqMessage>，T中的实际类型参数
      Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
      //获得参数类型
      Class<R> clazz = (Class<R>)actualTypeArguments[0];
      return Optional.of(clazz);
    }
    return Optional.empty();
  }


}
