package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-01
 * @since 1.0.0
 */
public class DeviceError extends IotEvent<DeviceError.DeviceErrorEventPayload> {
  public DeviceError() {
    super();
    setEventType(Type.Error);
    setName("设备异常");
  }

  public DeviceError(int devErrCode) {
    super();
    setEventType(Type.Error);
    setName("设备异常");
    setPayload(new DeviceErrorEventPayload(devErrCode));
  }

  @NoArgsConstructor
  @AllArgsConstructor
  @Data
  public static class DeviceErrorEventPayload implements EventPayload {
    private int devErrCode;
  }
}
