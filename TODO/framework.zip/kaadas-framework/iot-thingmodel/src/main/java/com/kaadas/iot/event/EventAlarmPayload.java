package com.kaadas.iot.event;

import lombok.Data;

/**
 * V3mqtt通讯协事件告警
 * @author haungxufeng
 * @date 2023-01-06
 * @since 1.0.0
 */
@Data
public class EventAlarmPayload implements EventPayload {

}