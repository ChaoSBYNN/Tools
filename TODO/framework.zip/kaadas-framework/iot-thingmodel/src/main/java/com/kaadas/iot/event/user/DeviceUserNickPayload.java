package com.kaadas.iot.event.user;

import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class DeviceUserNickPayload extends DeviceUserPayload {
  private String oldUserNickname;

  public String getOldUserNickname() {
    return oldUserNickname;
  }

  public void setOldUserNickname(String oldUserNickname) {
    this.oldUserNickname = oldUserNickname;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof DeviceUserNickPayload)) return false;
    if (!super.equals(o)) return false;
    DeviceUserNickPayload that = (DeviceUserNickPayload) o;
    return getOldUserNickname().equals(that.getOldUserNickname());
  }

  @Override
  public int hashCode() {
    return Objects.hash(super.hashCode(), getOldUserNickname());
  }

  @Override
  public String toString() {
    return "DeviceUserNickChangedPayload{" + "oldUserNickname='" + oldUserNickname + '\'' + '}';
  }
}
