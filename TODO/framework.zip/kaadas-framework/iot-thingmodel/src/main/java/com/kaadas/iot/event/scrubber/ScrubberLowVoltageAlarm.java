package com.kaadas.iot.event.scrubber;

import com.kaadas.iot.event.EventAlarmPayload;
import com.kaadas.iot.event.IotEventAlarm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 洗地机低电量告警
 * @author haungxufeng
 * @date 2023-01-06
 * @since 1.0.0
 */
public class ScrubberLowVoltageAlarm extends IotEventAlarm<ScrubberLowVoltageAlarm.LowVoltageAlarmPayload> {
  public ScrubberLowVoltageAlarm() {
    super();
    setName("低电量报警");
    setEventType(Type.Alarm);
  }

  public ScrubberLowVoltageAlarm(ScrubberLowVoltageAlarm.LowVoltageAlarmPayload payload) {
    super(payload);
    setName("低电量报警");
    setEventType(Type.Alarm);
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class LowVoltageAlarmPayload extends EventAlarmPayload {
    private boolean lowVoltage;
  }
}
