package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.Unlock;
import com.kaadas.iot.event.lock.UnlockPayload;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.record.LockState;
import com.kaadas.iot.record.convert.*;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.old.OldRecord;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class UnlockConvert implements OptRecordConvert<UnlockPayload>, LockSecretConvert {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.UNLOCK;
  }

  @Override
  public IotEvent<UnlockPayload> toIotEvent(WifiOperationRecord oldRecord) {
    Unlock unlock = new Unlock();
    setIotEvent(unlock,oldRecord);
    UnlockPayload unlockPayload = new UnlockPayload();
    unlockPayload.setLockState(LockState.UNLOCK.getState());
    //密钥信息
    LockSecret lockSecret = createLockSecret(oldRecord);
    //密码附属属性
    Map<String, Object> extra = createSecretExtra(oldRecord);
    //旧数据补齐pwdNIckName
    extra.put(OldRecord.Fields.pwdNickname,fillUpPwdNickname(oldRecord));
    extra.put(WifiOperationRecord.Fields.appId,oldRecord.getAppId());
    extra.put(WifiOperationRecord.Fields.uname,oldRecord.getUname());
    unlockPayload.setUnlockSecret(lockSecret);
    unlockPayload.setExtra(extra);
    unlock.setPayload(unlockPayload);
    return unlock;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<UnlockPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    UnlockPayload payload = iotEvent.getPayload();
    //>>设置密钥信息
    LockSecret unlockSecret = payload.getUnlockSecret();
    setLockSecret(unlockSecret,oldRecord);
    //密钥附件属性
    Map<String, Object> extra = payload.getExtra();
    setSecretExtra(extra,oldRecord);
    return oldRecord;
  }

}
