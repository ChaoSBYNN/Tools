package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class UnLockedOutOperating extends IotEvent<UnLockedOutOperating.UnLockedOutOperatingPayload> {
  public UnLockedOutOperating() {
    super();
    setName("解除反锁");
    setPayload(new UnLockedOutOperatingPayload(0));
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class UnLockedOutOperatingPayload implements EventPayload {
    private int lockedOutState;
  }
}
