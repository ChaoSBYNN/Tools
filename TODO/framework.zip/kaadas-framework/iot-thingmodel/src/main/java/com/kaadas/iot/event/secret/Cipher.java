package com.kaadas.iot.event.secret;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class Cipher {
  private int type;
  private int num;
  private boolean duress;
  private long createTime;
  private long startTime;
  private long endTime;
  private List<Integer> week;
  private Map<String, Object> extra;
}