package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class LockedOutOperating extends IotEvent<LockedOutOperating.LockedOutOperatingPayload> {
  public LockedOutOperating() {
    super();
    setName("反锁");
    setPayload(new LockedOutOperatingPayload(1));
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class LockedOutOperatingPayload implements EventPayload {
    private int lockedOutState;
  }
}
