package com.kaadas.iot.record.convert.secret;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.event.user.SecretNicknameChanged;
import com.kaadas.iot.event.user.SecretNicknamePayload;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.LockSecretConvert;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import com.kaadas.util.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
@Component
public class SecretNicknameChangedConvert implements OptRecordConvert<SecretNicknamePayload>, LockSecretConvert {
  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.SECRET_NICKNAME_CHANGED;
  }

  @Override
  public IotEvent<SecretNicknamePayload> toIotEvent(WifiOperationRecord oldRecord) {
    SecretNicknameChanged secretNicknameChanged = new SecretNicknameChanged();
    setIotEvent(secretNicknameChanged,oldRecord);
    SecretNicknamePayload payload = new SecretNicknamePayload();
    //设置密钥信息
    LockSecret lockSecret = createLockSecret(oldRecord);
    payload.setLockSecret(lockSecret);
    //设置密钥附加信息
    Map<String, Object> extra = createSecretExtra(oldRecord);
    extra.put(WifiOperationRecord.Fields.oldPwdNickname,oldRecord.getOldPwdNickname());
    payload.setExtra(extra);
    secretNicknameChanged.setPayload(payload);
    return secretNicknameChanged;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<SecretNicknamePayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    SecretNicknamePayload payload = iotEvent.getPayload();
    LockSecret lockSecret = payload.getLockSecret();
    setLockSecret(lockSecret,oldRecord);
    Map<String, Object> extra = payload.getExtra();
    //设置密钥附加属性
    if (CollectionUtils.isNotEmpty(extra)){
      setSecretExtra(extra,oldRecord);
      String oldPwdNickname = Optional.ofNullable(extra.get(WifiOperationRecord.Fields.oldPwdNickname))
                                      .map(String::valueOf)
                                      .orElse(null);
      oldRecord.setOldPwdNickname(oldPwdNickname);
    }

    return oldRecord;
  }
}
