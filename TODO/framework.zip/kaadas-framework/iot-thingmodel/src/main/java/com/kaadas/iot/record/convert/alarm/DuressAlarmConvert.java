package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.DuressAlarm;
import com.kaadas.iot.event.alarm.DuressPayload;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.record.convert.AlarmConvertTyep;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.LockSecretConvert;
import com.kaadas.iot.record.old.OldRecord;
import com.kaadas.iot.record.old.WifiAlarmRecord;
import com.kaadas.util.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class DuressAlarmConvert extends AlarmConvertAbstract<DuressPayload> implements LockSecretConvert {

  @Override
  public IotEventConvertType getIotEventType() {
    return AlarmConvertTyep.DURESS_ALARM;
  }

  @Override
  public IotEvent<DuressPayload> toIotEvent(WifiAlarmRecord oldRecord) {
    IotEvent<DuressPayload> duressPayloadIotEvent = super.toIotEvent(oldRecord);
    DuressPayload payload = duressPayloadIotEvent.getPayload();
    if (Objects.nonNull(oldRecord.getPwdType())){
      LockSecret lockSecret = createLockSecret(oldRecord);
      Map<String, Object> extra = createSecretExtra(oldRecord);
      //旧数据补齐pwdNIckName
      extra.put(OldRecord.Fields.pwdNickname,fillUpPwdNickname(oldRecord));
      payload.setUnlockSecret(lockSecret);
      payload.setExtra(extra);
    }
    duressPayloadIotEvent.setPayload(payload);
    return duressPayloadIotEvent;
  }

  @Override
  public WifiAlarmRecord toOldRecord(IotEvent<DuressPayload> iotEvent) {
    WifiAlarmRecord oldRecord = super.toOldRecord(iotEvent);
    DuressPayload payload = iotEvent.getPayload();
    //降本劫持告警不会有密钥信息
    LockSecret unlockSecret = payload.getUnlockSecret();
    if (Objects.nonNull(unlockSecret)){
      setLockSecret(unlockSecret,oldRecord);
    }
    Map<String, Object> extra = payload.getExtra();
    if (CollectionUtils.isNotEmpty(extra)){
      setSecretExtra(extra,oldRecord);
    }
    return oldRecord;
  }

  @Override
  IotEvent<DuressPayload> createIotEvent() {
    return new DuressAlarm();
  }

  @Override
  DuressPayload createAlarmPayload() {
    return new DuressPayload();
  }
}
