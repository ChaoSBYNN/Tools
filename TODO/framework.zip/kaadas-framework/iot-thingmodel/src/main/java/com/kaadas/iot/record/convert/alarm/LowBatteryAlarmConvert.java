package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.LowBatteryAlarm;
import com.kaadas.iot.event.alarm.LowBatteryPayload;
import com.kaadas.iot.record.convert.AlarmConvertTyep;
import com.kaadas.iot.record.convert.IotEventConvertType;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class LowBatteryAlarmConvert extends AlarmConvertAbstract<LowBatteryPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return AlarmConvertTyep.LOW_BATTERY_ALARM;
  }

  @Override
  IotEvent<LowBatteryPayload> createIotEvent() {
    return new LowBatteryAlarm();
  }
}
