package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class RestoreFactorySettings extends IotEvent<EmptyPayload> {
  public RestoreFactorySettings() {
    super();
    setName("恢复出厂设置");
  }
}
