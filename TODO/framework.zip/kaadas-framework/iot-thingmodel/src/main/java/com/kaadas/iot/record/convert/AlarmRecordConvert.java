package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.old.WifiAlarmRecord;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
public interface AlarmRecordConvert<P extends EventPayload> extends RecordConvert<WifiAlarmRecord,P> {


  default  void setIotEvent(IotEvent<P> iotEvent, WifiAlarmRecord oldRecord){
    IotEventType iotEventType = getIotEventType().iotEventType();
    iotEvent.setId(iotEventType.getId());
    iotEvent.setName(iotEventType.getName());
    iotEvent.setEsn(oldRecord.getWifiSN());
    long time = oldRecord.getTime();
    //如果是时间戳毫秒/转成时间戳秒
    String timeStr = time+"";
    if (timeStr.length()==13){
      time = time/1000;
    }
    iotEvent.setTime(time);
    iotEvent.setEventType(IotEvent.Type.Alarm);
  }

  default WifiAlarmRecord createOldAlarmRecord(IotEvent<P> iotEvent){
    long time = iotEvent.getTime();
    WifiAlarmRecord oldRecord = new WifiAlarmRecord();
    oldRecord.setWifiSN(iotEvent.getEsn());
    oldRecord.setTime(time);
    oldRecord.setType(getIotEventType().getType());
    //以下时间字段APP有用到
    long recotdTime = time*1000;
    oldRecord.setCreateTime(recotdTime);
    oldRecord.setUpdateTime(recotdTime);
    return oldRecord;
  }
}
