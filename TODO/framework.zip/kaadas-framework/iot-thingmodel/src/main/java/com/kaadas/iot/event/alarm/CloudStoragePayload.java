package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.AlarmPayload;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 描述
 *  云存上报
 * @author huangxufeng
 * @date 2024/1/14 20:16
 * @return
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class CloudStoragePayload extends AlarmPayload {
  private String eventId;
  /** 是否共享视频 */
  private boolean eventShareVideo;
  /** oss文件名称，带后缀 */
  private String cloudStorageFile;
}
