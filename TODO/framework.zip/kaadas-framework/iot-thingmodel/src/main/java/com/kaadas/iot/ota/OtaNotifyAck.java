package com.kaadas.iot.ota;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-28
 * @since 1.0.0
 */
public class OtaNotifyAck extends IotOta<OtaNotifyPayload> {
  public OtaNotifyAck() {
    super();
    setMsgType(MsgType.OtaNotifyAck);
  }

  public OtaNotifyAck(OtaNotifyPayload payload) {
    this();
    this.setPayload(payload);
  }
}
