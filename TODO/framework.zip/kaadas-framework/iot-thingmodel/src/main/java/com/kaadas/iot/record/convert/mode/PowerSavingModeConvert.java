package com.kaadas.iot.record.convert.mode;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.ModePayload;
import com.kaadas.iot.event.mode.PowerSavingMode;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class PowerSavingModeConvert extends ModelConvertAbstract<ModePayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.POWER_SAVING_MODE;
  }


  @Override
  IotEvent<ModePayload> createIotEvent() {
    return new PowerSavingMode();
  }
}
