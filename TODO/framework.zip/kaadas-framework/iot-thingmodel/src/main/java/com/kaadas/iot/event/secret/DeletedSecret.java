package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class DeletedSecret extends IotEvent<SecretPayload> {
  public DeletedSecret() {
    super();
    setName("删除密钥");
  }

  public DeletedSecret(SecretPayload payload) {
    this();
    this.setPayload(payload);
  }
}
