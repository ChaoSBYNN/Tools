package com.kaadas.iot.event.kiotvideo;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
public class TransTalk extends KiotvideoEvent<TransTalkPayload> {

  public TransTalk() {
    super("Trans对讲通知");
  }
}
