package com.kaadas.iot.event.network;

import lombok.Data;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
public class ConfigToken {
  private String id;
  private String token;
  private Map<String, Object> extra;
}
