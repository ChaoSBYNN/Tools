package com.kaadas.iot.record.convert;

import com.kaadas.iot.record.old.OldRecord;
import lombok.Getter;

import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-11
 * @since 1.0.0
 */
public enum PwdConvertType {
  /** 0x00：Keypad键盘（密码） */ Keypad(0x00, 1),
  /** 0x03：RFID卡片 */ RFID(0x03, 3),
  /** 0x04：Fingerprint指纹 */ Fingerprint(0x04, 2),
  /** 0x07：人脸 */ FACE(0x07, 4),
  /** 0x08：App */ APP(0x08, 0x08),
  /** 0x09：Key Unlock机械钥匙（室内机械方式开锁、室外机械钥匙开锁） */ Latchkey(0x09, 0x09),
  /** 0x0A：室内open键开锁 */ OpenButton(0x0A, 0x0A),
  /** 0x0B：室内感应把手开锁 */ Handle(0x0B, 0x0B),
  /** 0x10：小度 */ XiaoDu(0x10, 0x10),
  /** 0x11：天猫精灵 */ TianMao(0x11, 0x11),
  /** 0x12：指静脉 */ VEIN(0x12, 5),
  /** 0x0C：Palm */ PALM(0x0C, 12),
  /** 0xFF：不确定（无效值） */ Unknown(0xFF, 0xFF),
  ;
  PwdConvertType(int from,int target){
    this.from = from;
    this.target = target;
  }
  @Getter
  private int from;
  @Getter
  private int target;

  public static PwdConvertType findByFrom(Integer from){
    if (Objects.isNull(from)){
      return PwdConvertType.Unknown;
    }
    for (PwdConvertType pwdConvertType:values()) {
      if (pwdConvertType.from==from){
        return pwdConvertType;
      }
    }
    return PwdConvertType.Unknown;
  }

  public static PwdConvertType findByTarget(Integer target){
    if (Objects.isNull(target)){
      return PwdConvertType.Unknown;
    }
    for (PwdConvertType pwdConvertType:values()) {
      if (pwdConvertType.target==target){
        return pwdConvertType;
      }
    }
    return PwdConvertType.Unknown;
  }

  public static void convert(OldRecord oldRecord){
    PwdConvertType byFrom = findByFrom(oldRecord.getPwdType());
    if (byFrom==PwdConvertType.Unknown){
      return;
    }
    oldRecord.setPwdType(byFrom.getTarget());
  }

  public static void convertByTarget(OldRecord oldRecord){
    PwdConvertType byTarget = findByTarget(oldRecord.getPwdType());
    if (byTarget==PwdConvertType.Unknown){
      return;
    }
    oldRecord.setPwdType(byTarget.getFrom());
  }
}
