package com.kaadas.iot.event.mqttstate;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class Online extends IotEvent<OnlinePayload> {
  public Online() {
    setName("设备上线");
  }
}
