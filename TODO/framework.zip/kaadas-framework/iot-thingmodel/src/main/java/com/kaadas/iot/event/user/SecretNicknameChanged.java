package com.kaadas.iot.event.user;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class SecretNicknameChanged extends IotEvent<SecretNicknamePayload> {
  public SecretNicknameChanged() {
  }

  public SecretNicknameChanged(SecretNicknamePayload payload) {
    super(payload);
  }
}
