package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public interface IotEventType {
  String getId();
  String getName();
  IotEvent.Type getEventType();
}
