package com.kaadas.iot.util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-23
 * @since 1.0.0
 */
public class DigestUtils {
  private static final String MD5_ALGORITHM_NAME = "MD5";
  private static final char[] HEX_CHARS =
    {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

  public static byte[] md5(String data) {
    return getDigest(MD5_ALGORITHM_NAME).digest(getBytes(data));
  }

  public static String md5Hex(String data) {
    return new String(encodeHex(md5(data)));
  }

  private static MessageDigest getDigest(String algorithm) {
    try {
      return MessageDigest.getInstance(algorithm);
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException("Could not find MessageDigest with algorithm \"" + algorithm + "\"", e);
    }
  }

  public static char[] encodeHex(byte[] bytes) {
    char[] chars = new char[32];
    for (int i = 0; i < chars.length; i = i + 2) {
      byte b = bytes[i / 2];
      chars[i] = HEX_CHARS[(b >>> 0x4) & 0xf];
      chars[i + 1] = HEX_CHARS[b & 0xf];
    }
    return chars;
  }

  private static byte[] getBytes(String data) {
    if (data == null) {
      return null;
    }
    return data.getBytes(StandardCharsets.UTF_8);
  }

  private static byte[] getBytes(String data, Charset charset) {
    if (data == null) {
      return null;
    }
    return data.getBytes(charset);
  }
}
