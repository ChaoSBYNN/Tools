package com.kaadas.iot.event.kiotvideo;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
@Data
public class AuthPayload implements EventPayload {

  private String userId;

  private String msg;

  private Integer code;

  public static AuthPayload create(Integer code){
    return AuthPayload.create(code,null);
  }

  public static AuthPayload create(Integer code, String msg){
    AuthPayload authPayload = new AuthPayload();
    authPayload.setCode(code);
    authPayload.setMsg(msg);
    return authPayload;
  }
}
