package com.kaadas.iot.ota;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-28
 * @since 1.0.0
 */
@Data
public class OtaNotifyPayload {
  private Integer msgId;
  /** 升级模块 */
  private Integer devNum;
  /** 待升级版本号 */
  private String version;
  /** 固件下载地址 */
  private String fileUrl;
  /** 固件MD5值 */
  private String fileMd5;
  /** 固件字节数 */
  private int fileLen;
  /** 文件连接有效时间 */
  private int fileExpires;
}
