package com.kaadas.iot.event;

import lombok.Data;

@Data
public class AlarmPayload implements EventPayload {
  /** 事件ID，存储在系统中的唯一业务主键 */
  private String eventId;
  /** 腾讯云事件ID，用于调用腾讯API查询事件及相关视频 */
  private Integer txEventId;
  /** 告警编码，与锁端共同约定的告警事件编码 */
  private Integer alarmCode;
  /** 视频开始时间，一般会在视频录制完成后上报 */
  private Long videoStartTime;
  /** 视频结束时间，一般会在视频录制完成后上报 */
  private Long videoEndTime;
  /** 告警图片缩略图, 事件触发时上报 */
  private String thumbnail;
  private Integer thumbState;
  private String fileDate;
  private String fileName;
  private Integer height;
  private Integer width;
  private Long offsetTime;
  private Integer clusterID;
  /** 告警视频封包类型枚举 【ts: TS封包，fmp4：MP4封包】*/
  private String videoPackType;

  //与本地视频时间可能会不一致，新增此字段
  /** 云存视频开始时间 */
  private Long cloudStartTime;

  /** 云存视频结束时间 */
  private Long cloudEndTime;

}