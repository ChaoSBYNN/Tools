package com.kaadas.iot.record;

import lombok.Getter;

/**
 * 密钥类型
 */
public enum SpecialPwdNumber {
  /** 机械钥匙 */ MECHANICAL_KEY(100),
  /** 一键开锁 */ ONE_KEY_UNLOCK(102),
  /** PP指令 */ APP_COMMAND(103),
  /** 管理密码 */ ADMIN_PASSWORD(254),
  /** 访客密码 */ VISITORS_PASSWORD(253),
  /** 一次性密码 */ disposable_Password(252),
  /** 离线密码/临时密码 */ OFFLINE_PASSWORD(250)
  ;
  SpecialPwdNumber(int pwdNumber){
    this.pwdNumber = pwdNumber;
  }
  @Getter
  private final int pwdNumber;

}
