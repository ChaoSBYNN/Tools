package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class AddedSecret extends IotEvent<SecretPayload> {
  public AddedSecret() {
    super();
    setName("添加密钥");
  }

  public AddedSecret(SecretPayload payload) {
    this();
    this.setPayload(payload);
  }
}
