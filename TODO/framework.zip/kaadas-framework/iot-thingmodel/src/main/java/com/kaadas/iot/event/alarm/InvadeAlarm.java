package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.IotAlarm;

/**
 * TODO
 * 入侵告警
 * @author liuyul
 * @date 2023-07-28
 * @since 1.0.0
 */
public class InvadeAlarm extends IotAlarm<PirPayload> {
  public InvadeAlarm() {
    super();
  }

  public InvadeAlarm(PirPayload payload) {
    super(payload);
  }
}
