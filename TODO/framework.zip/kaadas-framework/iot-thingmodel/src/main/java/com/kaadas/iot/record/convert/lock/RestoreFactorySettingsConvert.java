package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.RestoreFactorySettings;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class RestoreFactorySettingsConvert implements OptRecordConvert<EmptyPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.RESTORE_FACTORY_SETTINGS;
  }

  @Override
  public IotEvent<EmptyPayload> toIotEvent(WifiOperationRecord oldRecord) {
    RestoreFactorySettings restoreFactorySettings = new RestoreFactorySettings();
    setIotEvent(restoreFactorySettings,oldRecord);
    EmptyPayload emptyPayload = new EmptyPayload();
    restoreFactorySettings.setPayload(emptyPayload);
    return restoreFactorySettings;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<EmptyPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    return oldRecord;
  }
}
