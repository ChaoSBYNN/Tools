package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.IotAlarm;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-14
 * @since 1.0.0
 */
public class CloudStorageAlarm extends IotAlarm<CloudStoragePayload> {
  public CloudStorageAlarm() {
    super();
    super.setName("云存告警上报");
  }

  public CloudStorageAlarm(CloudStoragePayload payload) {
    super(payload);
    super.setName("云存告警上报");
  }
}
