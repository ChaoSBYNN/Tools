package com.kaadas.iot.event.kiotvideo;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
@Data
public class TransTalkPayload implements EventPayload {

  private String userId;

  private String msg;

  private Integer code;

  public static TransTalkPayload create(String userId,Integer code){
    return TransTalkPayload.create(userId,code,null);
  }

  public static TransTalkPayload create(String userId,Integer code, String msg){
    TransTalkPayload authPayload = new TransTalkPayload();
    authPayload.setUserId(userId);
    authPayload.setCode(code);
    authPayload.setMsg(msg);
    return authPayload;
  }
}
