package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class MasterFingerprintAdded extends IotEvent<EmptyPayload> {}
