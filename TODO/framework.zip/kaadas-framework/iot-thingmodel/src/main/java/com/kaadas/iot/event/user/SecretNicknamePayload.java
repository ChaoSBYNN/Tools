package com.kaadas.iot.event.user;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.secret.LockSecret;

import java.util.Map;
import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class SecretNicknamePayload implements EventPayload {
  private LockSecret lockSecret;
  private Map<String, Object> extra;

  public LockSecret getLockSecret() {
    return lockSecret;
  }

  public void setLockSecret(LockSecret lockSecret) {
    this.lockSecret = lockSecret;
  }

  public Map<String, Object> getExtra() {
    return extra;
  }

  public void setExtra(Map<String, Object> extra) {
    this.extra = extra;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof SecretNicknamePayload)) return false;
    SecretNicknamePayload that = (SecretNicknamePayload) o;
    return getLockSecret().equals(that.getLockSecret()) && getExtra().equals(that.getExtra());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getLockSecret(), getExtra());
  }

  @Override
  public String toString() {
    return "SecretNicknamePayload{" + "lockSecret=" + lockSecret + ", extra=" + extra + '}';
  }
}
