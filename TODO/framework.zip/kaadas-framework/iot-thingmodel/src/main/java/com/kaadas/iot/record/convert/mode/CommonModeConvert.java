package com.kaadas.iot.record.convert.mode;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.ModePayload;
import com.kaadas.iot.event.mode.CommonMode;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class CommonModeConvert extends ModelConvertAbstract<ModePayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.COMMON_MODE;
  }

  @Override
  IotEvent<ModePayload> createIotEvent() {
    return new CommonMode();
  }
}
