package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class Locked extends IotEvent<LockedPayload> {

  public Locked() {
    super();
    setName("上锁");
    setPayload(new LockedPayload(1));
  }
}
