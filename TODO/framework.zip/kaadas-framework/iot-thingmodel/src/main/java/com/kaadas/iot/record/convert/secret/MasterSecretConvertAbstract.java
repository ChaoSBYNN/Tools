package com.kaadas.iot.record.convert.secret;


import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-31
 * @since 1.0.0
 */
public abstract class MasterSecretConvertAbstract<P extends EventPayload> implements OptRecordConvert<P> {

  @Override
  public IotEvent<P> toIotEvent(WifiOperationRecord oldRecord) {
    IotEvent iotEvent = createIotEvent();
    EmptyPayload eventPayload = createEventPayload();
    setIotEvent(iotEvent,oldRecord);
    iotEvent.setPayload(eventPayload);
    return iotEvent;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<P> iotEvent) {
    return createOldRecord(iotEvent);
  }

  EmptyPayload createEventPayload(){
    return new EmptyPayload();
  }

  abstract IotEvent<P> createIotEvent();
}
