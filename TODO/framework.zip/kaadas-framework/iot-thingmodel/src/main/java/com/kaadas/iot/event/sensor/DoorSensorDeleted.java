package com.kaadas.iot.event.sensor;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.secret.SecretPayload;

/**
 * 描述
 * 删除门磁
 * @author huangxufeng
 * @date 2023/6/6 9:19
 */
public class DoorSensorDeleted extends IotEvent<EventPayload> {
  public DoorSensorDeleted() {
    super();
    setName("删除门磁");
  }

  public DoorSensorDeleted(SecretPayload payload) {
    this();
    this.setPayload(payload);
  }
}
