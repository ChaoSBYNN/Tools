package com.kaadas.iot.record.convert.user;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.user.DeviceUserDelete;
import com.kaadas.iot.event.user.DeviceUserPayload;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
@Component
public class DeviceUserDeleteConvert implements OptRecordConvert<DeviceUserPayload> {
  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.DEVICE_USER_DELETE;
  }

  @Override
  public IotEvent<DeviceUserPayload> toIotEvent(WifiOperationRecord oldRecord) {
    DeviceUserDelete deviceUserDelete = new DeviceUserDelete();
    setIotEvent(deviceUserDelete,oldRecord);
    DeviceUserPayload payload = new DeviceUserPayload();
    payload.setUser(oldRecord.getUser());
    payload.setUserNickname(oldRecord.getUserNickname());
    deviceUserDelete.setPayload(payload);
    return deviceUserDelete;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<DeviceUserPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    DeviceUserPayload payload = iotEvent.getPayload();
    oldRecord.setUser(payload.getUser());
    oldRecord.setUserNickname(payload.getUserNickname());
    return oldRecord;
  }
}
