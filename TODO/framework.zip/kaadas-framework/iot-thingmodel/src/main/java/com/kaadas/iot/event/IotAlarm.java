package com.kaadas.iot.event;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public abstract class IotAlarm<T extends AlarmPayload> extends IotEvent<T> {
  public IotAlarm() {
    super();
    this.setEventType(Type.Alarm);
  }

  public IotAlarm(T payload) {
    this();
    setPayload(payload);
  }
}
