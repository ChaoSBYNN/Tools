package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.EventPayload;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public final class LockedPayload implements EventPayload {
  /** 锁状态. 布尔: {0, 1}. 0 = 开锁; 1 = 关锁 */
  private int lockState;
}
