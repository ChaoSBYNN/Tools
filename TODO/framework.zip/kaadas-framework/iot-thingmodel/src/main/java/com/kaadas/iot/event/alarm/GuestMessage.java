package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.IotAlarm;

/**
 * 访客留言
 *
 * @author liuqinxian
 * @date 2023-1-31
 * @since 1.0.0
 */
public class GuestMessage extends IotAlarm<AlarmPayload> {
  public GuestMessage() {
    super();
  }

  public GuestMessage(AlarmPayload payload) {
    super(payload);
  }
}
