package com.kaadas.iot.event.vod;

import com.kaadas.iot.event.IotEvent;

/**
 * 点播视频中转事件/小程序点播
 * @author huangxufeng
 * @date 2024-01-23
 * @since 1.0.0
 */
public class VodTransVideo extends IotEvent<VodTransVideoPayload> {

  public VodTransVideo() {
    super();
    setName("视频中转");
  }
}
