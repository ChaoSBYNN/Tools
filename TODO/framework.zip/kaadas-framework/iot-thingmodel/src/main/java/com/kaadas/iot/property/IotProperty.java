package com.kaadas.iot.property;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
public class IotProperty<T> {
  private String esn;
  private long time;
  private T properties;
}
