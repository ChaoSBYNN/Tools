package com.kaadas.iot.event.network;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-26
 * @since 1.0.0
 */
@Data
public class NetworkPayload implements EventPayload {
  private int code;
  private String msg;
  private String errCode;
  private String errDes;

  private ConfigToken configToken;
  private Triple triple;
  private Integer functionSet;
  private String randomCode;
}
