package com.kaadas.iot.record;


import lombok.Getter;

/**
 * 密钥类型
 */
public enum PwdType {
  /** 0x00：Keypad键盘（密码） */ Keypad(0x00, "Keypad"),
  /** 0x03：RFID卡片 */ RFID(0x03, "RFID"),
  /** 0x04：Fingerprint指纹 */ Fingerprint(0x04, "Fingerprint"),
  /** 0x07：人脸 */ FACE(0x07, "Face"),
  /** 0x08：App */ APP(0x08, "App"),
  /** 0x09：Key Unlock机械钥匙（室内机械方式开锁、室外机械钥匙开锁） */ Latchkey(0x09, "Latchkey"),
  /** 0x0A：室内open键开锁 */ OpenButton(0x0A, "OpenButton"),
  /** 0x0B：室内感应把手开锁 */ Handle(0x0B, "Handle"),
  /** 0x10：小度 */ XiaoDu(0x10, "XiaoDu"),
  /** 0x11：天猫精灵 */ TianMao(0x11, "TianMao"),
  /** 0x12：指静脉 */ VEIN(0x12, "Vein"),
  /** 0x0C：掌静脉 */ PALM(0x0C, "Palm"),
  /** 0xFF：不确定（无效值） */ Unknown(0xFF, "Unknown"),
  ;

  @Getter
  private final int type;
  @Getter
  private final String name;



  PwdType(int type, String name) {
    this.type = type;
    this.name = name;
  }

  final static PwdType[] VALUES = PwdType.values();

  public static PwdType findByType(int type) {
    if (type < 0 || type > 255) {
      return Unknown;
    }
    for (PwdType eventSource : VALUES) {
      if (eventSource.type == type) {
        return eventSource;
      }
    }
    return Unknown;
  }

  public static PwdType findByName(String name) {

    for (PwdType eventSource : VALUES) {
      if (eventSource.name.equals(name)) {
        return eventSource;
      }
    }
    return Unknown;
  }
}
