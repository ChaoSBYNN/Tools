package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
public class LockSecret implements EventPayload {
  /** 密钥类型. 枚举: {Keypad, RFID, Fingerprint, Face}. Keypad = 密码; RFID = RFID卡片; Fingerprint = 指纹; Face = 人脸 */
  private String mode;
  /** 锁密钥用户. 范围: [0, 99] */
  private int user;
  /** 锁密钥编号. 范围: [0, 99] */
  private int num;
}
