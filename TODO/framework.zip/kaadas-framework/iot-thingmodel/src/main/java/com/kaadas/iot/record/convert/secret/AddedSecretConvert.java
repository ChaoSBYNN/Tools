package com.kaadas.iot.record.convert.secret;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.secret.AddedSecret;
import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.event.secret.SecretPayload;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.LockSecretConvert;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-31
 * @since 1.0.0
 */
@Component
public class AddedSecretConvert implements OptRecordConvert<SecretPayload>, LockSecretConvert {
  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.ADDED_SECRET;
  }

  @Override
  public IotEvent<SecretPayload> toIotEvent(WifiOperationRecord oldRecord) {
    IotEvent<SecretPayload> iotEvent = new AddedSecret();
    setIotEvent(iotEvent,oldRecord);
    SecretPayload secretPayload = new SecretPayload();
    //密钥信息
    LockSecret lockSecret = createLockSecret(oldRecord);
    //密码附属属性
    Map<String, Object> extra = createSecretExtra(oldRecord);
    secretPayload.setLockSecret(lockSecret);
    secretPayload.setExtra(extra);
    iotEvent.setPayload(secretPayload);
    return iotEvent;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<SecretPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    SecretPayload payload = iotEvent.getPayload();
    //>>设置密钥信息
    LockSecret lockSecret = payload.getLockSecret();
    setLockSecret(lockSecret,oldRecord);
    //密钥附件属性
    Map<String, Object> extra = payload.getExtra();
    setSecretExtra(extra,oldRecord);
    return oldRecord;
  }

}
