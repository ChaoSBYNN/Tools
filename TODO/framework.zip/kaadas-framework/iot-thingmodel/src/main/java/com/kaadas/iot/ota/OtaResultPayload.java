package com.kaadas.iot.ota;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-28
 * @since 1.0.0
 */
@Data
public class OtaResultPayload {

  /** 升级模块 */
  private Integer devNum;
  /** 升级后当前版本 */
  private String currentVersion;
  /** 升级时间 */
  private Long otaTime;
}
