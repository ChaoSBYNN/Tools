package com.kaadas.iot.record.old;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.experimental.FieldNameConstants;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 设备报警记录
 * @ClassName WifiAlarmRecord
 * @Description
 * @Author huangxufeng
 * @Date 2022/3/23 11:54
 */
@Data
@FieldNameConstants
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document("kdsWifiAlarmRecord")
public class WifiAlarmRecord extends OldRecord {


  /**
   * 报警类型：1锁定 2劫持 3三次错误 4防撬 8机械钥匙报警 16低电压 32锁体异常 64布防 96门铃报警 97访客留言 112=pir动作 113人脸徘徊
   */
  private Integer type;
  /**
   * 原有字段，作用未知
   */
  private String content;
  /**
   * 事件ID
   */
  private String eventId;
  /**
   * 图片地址
   */
  private String thumbUrl;
  /**
   * 图片上传结果0:上传失败 1:上传成功
   */
  private Integer thumbState;
  /**
   * 录像时长
   */
  private Integer vedioTime;
  /**
   * 录像开始时间
   */
  private Long startTime;
  /**
   * 文件路径
   */
  private String fileDate;
  /**
   * 文件名
   */
  private String fileName;
  /**
   * 分辨率高
   */
  private String height;
  /**
   * 分辨率宽
   */
  private String width;
  /**
   * 设备类型
   */
  private String devtype;
  /**
   * 作用未知
   */
  private Long offsetTime;
  /**
   * 添加数据的时候将数据拼接，在数据库这个字段会建立唯一索引
   */
  private String uk;
  /**
   * 集群id
   */
  private Integer clusterID;

  /**
   * pir轨迹
   */
  List<List<List<Integer>>> tracks;


  public enum AlarmTyepEnum{

    CODE_1(1,"锁定"),
    CODE_2(2,"劫持"),
    CODE_3(3,"三次错误"),
    CODE_4(4,"防撬"),
    CODE_8(8,"机械钥匙报警"),
    CODE_16(16,"低电压"),
    CODE_32(32,"锁体异常"),
    CODE_64(64,"布防"),
    CODE_96(96,"门铃报警"),
    CODE_97(97,"访客留言"),
    CODE_112(112,"pir动作"),
    CODE_113(113,"人脸徘徊");

    private AlarmTyepEnum(int code,String desc){
      this.code=code;
      this.desc=desc;
    }
    @Getter
    private int code;
    @Getter
    private String desc;

    /**
     * 返回全部code
     * @param excludeCode 排除的code
     * @return
     */
    public static List<Integer> codeAll(int... excludeCode){
      List<Integer> codes = new ArrayList<>();
      for (AlarmTyepEnum alarmTyepEnum:AlarmTyepEnum.values()) {
        boolean match = Arrays.stream(excludeCode).anyMatch(code-> alarmTyepEnum.getCode() == code);
        if (!match){
          codes.add(alarmTyepEnum.getCode());
        }
      }
      return codes;
    }

    public static List<Integer> guest(){
      return Arrays.asList(AlarmTyepEnum.CODE_96.getCode(),AlarmTyepEnum.CODE_97.getCode());
    }

    public static List<Integer> alarm(){
      List<Integer> guest = guest();
      List<Integer> codes = codeAll(-1);
      codes.removeIf(code->guest.contains(code));
      return codes;
    }

  }

}
