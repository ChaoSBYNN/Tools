package com.kaadas.iot.event.user;

import com.kaadas.iot.event.EventPayload;

import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class DeviceUserPayload implements EventPayload {
  /** 设备用户编号 */
  private String user;
  /** 设备用户名称 */
  private String userNickname;

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getUserNickname() {
    return userNickname;
  }

  public void setUserNickname(String userNickname) {
    this.userNickname = userNickname;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof DeviceUserPayload)) return false;
    DeviceUserPayload that = (DeviceUserPayload) o;
    return getUser().equals(that.getUser()) && getUserNickname().equals(that.getUserNickname());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getUser(), getUserNickname());
  }

  @Override
  public String toString() {
    return "DeviceUserPayload{" + "user='" + user + '\'' + ", userNickname='" + userNickname + '\'' + '}';
  }
}
