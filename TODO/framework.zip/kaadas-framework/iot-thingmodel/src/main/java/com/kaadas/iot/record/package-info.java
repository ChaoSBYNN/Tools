package com.kaadas.iot.record;
/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-17
 * @since 1.0.0
 */