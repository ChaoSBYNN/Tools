package com.kaadas.iot.record;

import lombok.Getter;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-28
 * @since 1.0.0
 */
public enum LockOutState {
  /**反锁**/ UN_LOCK_OUT_STATE(0),
  /**解除反锁**/LOCK_OUT_STATE(1),

  ;

  private LockOutState(int state){
    this.state = state;
  }
  @Getter
  private int state;
}
