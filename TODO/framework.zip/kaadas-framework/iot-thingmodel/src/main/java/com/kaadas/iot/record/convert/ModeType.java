package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public enum ModeType implements IotEventType {

  /** 0x01：自动模式 */ AUTO_MODE("AutoMode","自动模式", IotEvent.Type.Message),
  /** 0x02：手动模式 */ MANUAL_MODE( "ManualMode","手动模式",IotEvent.Type.Message),
  /** 0x03：通用模式 */ COMMON_MODE("CommonMode","通用模式",IotEvent.Type.Message),
  /** 0x04：安全模式 */ SAFE_MODE("SafeMode","安全模式",IotEvent.Type.Message),
  /** 0x05:	反锁模式 */ LOCKED_OUT_MODE( "LockedOutMode","反锁模式",IotEvent.Type.Message),
  /** 0x06:	布防模式 */ DEFENCE_MODE("DefenceMode","布防模式",IotEvent.Type.Message),
  /** 0x07:	节能模式 */ POWER_SAVING_MODE("PowerSavingMode","节能模式",IotEvent.Type.Message),
  /** 0x08:	关闭节能模式 */ CANCEL_POWER_SAVING_MODE( "CancelPowerSavingMode","关闭节能模式",IotEvent.Type.Message),
  ;
  ModeType(String id, String name, IotEvent.Type eventType){
    this.id = id;
    this.name = name;
    this.eventType = eventType;
  }

  private String id;
  private String name;
  private IotEvent.Type eventType;

  @Override
  public String getId() {
    return id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public IotEvent.Type getEventType() {
    return eventType;
  }
}
