package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public enum LockType implements IotEventType {

  UNLOCK("Unlock","开锁", IotEvent.Type.Message),
  LOCKED( "Locked","关锁",IotEvent.Type.Message),
  /** 恢复出厂设置 */ RESTORE_FACTORY_SETTINGS("RestoreFactorySettings","恢复出厂设置",IotEvent.Type.Message),
  /**室内反锁操作 */ LOCKED_OUT_OPERATING("LockedOutOperating","反锁",IotEvent.Type.Message),
  /**室内反锁解除操**/UNLOCKED_OUT_OPERATING("UnLockedOutOperating","解除反锁",IotEvent.Type.Message),
  /**室内呼叫已接听**/DOOR_PANEL_CALL_ANSWER("DoorPanelCallAnswer","室内呼叫已接听",IotEvent.Type.Message),
  /**室内呼叫未接听**/DOOR_PANEL_CALL_UNANSWERED("DoorPanelCallUnanswered","室内呼叫未接听",IotEvent.Type.Message),
  ;
  LockType(String id,String name,IotEvent.Type eventType){
    this.id = id;
    this.name = name;
    this.eventType = eventType;
  }

  private String id;
  private String name;
  private IotEvent.Type eventType;

  @Override
  public String getId() {
    return id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public IotEvent.Type getEventType() {
    return eventType;
  }
}
