package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.EventPayload;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SecretPayload implements EventPayload {
  /** 锁密钥信息 */
  private LockSecret lockSecret;
  /** 锁密钥扩展信息 */
  private Map<String, Object> extra;
}
