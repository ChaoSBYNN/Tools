package com.kaadas.iot.event.lock;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class Unlock extends IotEvent<UnlockPayload> {
  public Unlock() {
    super();
    setName("开锁");
  }

  public Unlock(UnlockPayload payload) {
    super(payload);
    setName("开锁");
  }
}
