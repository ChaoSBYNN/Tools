package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.secret.LockSecret;
import com.kaadas.iot.record.PwdType;
import com.kaadas.iot.record.old.OldRecord;
import com.kaadas.util.JavaTypeUtils;
import com.kaadas.util.NumberUtils;
import com.kaadas.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-31
 * @since 1.0.0
 */
public interface LockSecretConvert {

  default LockSecret createLockSecret(OldRecord oldRecord){
    LockSecret lockSecret = new LockSecret();
    lockSecret.setUser(NumberUtils.toInt(oldRecord.getUser()));
    Integer pwdNum = oldRecord.getPwdNum();
    if (Objects.nonNull(pwdNum)){
      lockSecret.setNum(pwdNum);
    }
    Integer pwdType = oldRecord.getPwdType();
    if (Objects.nonNull(pwdType)){
      //设置密码类型
      PwdType byPwdType = PwdType.findByType(pwdType);
      lockSecret.setMode(byPwdType.getName());
    }
    return lockSecret;
  }

  default void setLockSecret(LockSecret unlockSecret,OldRecord oldRecord){
    //密钥基础信息
    String mode = unlockSecret.getMode();
    if (Objects.nonNull(mode)) {
      PwdType pwdType = PwdType.findByName(mode);
      oldRecord.setPwdType(pwdType.getType());
    }
    oldRecord.setPwdNum(unlockSecret.getNum());
    oldRecord.setUser(unlockSecret.getUser()+"");
  }

  default Map<String,Object> createSecretExtra(OldRecord oldRecord){
    //设置附加属性
    Map<String, Object> extra = new HashMap<>(5);
    extra.put(OldRecord.Fields.pwdNickname,oldRecord.getPwdNickname());
    extra.put(OldRecord.Fields.userNickname,oldRecord.getUserNickname());
//    extra.put(OldRecord.Fields.oldPwdNickname,oldRecord.getOldPwdNickname());
//    extra.put(OldRecord.Fields.oldUserNickname,oldRecord.getOldUserNickname());
    extra.put(OldRecord.Fields.pwdDetailType,oldRecord.getPwdDetailType());
    extra.put(OldRecord.Fields.duress,oldRecord.getDuress());
    extra.put(OldRecord.Fields.pwdList,oldRecord.getPwdList());
    return extra;
  }

  /**
   * 旧数据补齐pwdNIckName
   * @param oldRecord
   * @return
   */
  default String fillUpPwdNickname(OldRecord oldRecord){
    //设置附加属性
    //旧数据未设置昵称时开锁这昵称为空，填入对应的编号
    String pwdNickname = oldRecord.getPwdNickname();
    String userNickname = oldRecord.getUserNickname();
    Integer pwdNum = oldRecord.getPwdNum();
    if (StringUtils.isBlank(pwdNickname) && StringUtils.isBlank(userNickname) && Objects.nonNull(pwdNum)){
      return pwdNum>=10?"编号"+pwdNum:"编号0"+pwdNum;
    }
    if (StringUtils.isBlank(pwdNickname)){
      return userNickname;
    }
    return pwdNickname;
  }

  default void setSecretExtra(Map<String,Object> extra,OldRecord oldRecord){
    if (Objects.isNull(extra)){
      return;
    }
    //密钥附件属性
    oldRecord.setPwdNickname(JavaTypeUtils.toString(extra.get(OldRecord.Fields.pwdNickname)));
    oldRecord.setUserNickname(JavaTypeUtils.toString(extra.get(OldRecord.Fields.userNickname)));
//    oldRecord.setOldPwdNickname(JavaTypeUtils.toString(extra.get(OldRecord.Fields.oldPwdNickname)));
//    oldRecord.setOldUserNickname(JavaTypeUtils.toString(extra.get(OldRecord.Fields.oldUserNickname)));
    oldRecord.setPwdDetailType(JavaTypeUtils.toInt(extra.get(OldRecord.Fields.pwdDetailType)));
    oldRecord.setDuress(JavaTypeUtils.cast(extra.get(OldRecord.Fields.duress),Boolean.class));
    oldRecord.setPwdList(JavaTypeUtils.cast(extra.get(OldRecord.Fields.pwdList), List.class));
  }

}
