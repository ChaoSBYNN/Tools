package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.DoorPanelCallAnswer;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * 门内呼叫已接听
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class DoorPanelCallAnswerConvert implements OptRecordConvert<EmptyPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.DOOR_PANEL_CALL_ANSWER;
  }

  @Override
  public IotEvent<EmptyPayload> toIotEvent(WifiOperationRecord oldRecord) {
    DoorPanelCallAnswer doorPanelCallAnswer = new DoorPanelCallAnswer();
    setIotEvent(doorPanelCallAnswer,oldRecord);
    EmptyPayload emptyPayload = new EmptyPayload();
    doorPanelCallAnswer.setPayload(emptyPayload);
    return doorPanelCallAnswer;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<EmptyPayload> iotEvent) {
    return createOldRecord(iotEvent);
  }

}
