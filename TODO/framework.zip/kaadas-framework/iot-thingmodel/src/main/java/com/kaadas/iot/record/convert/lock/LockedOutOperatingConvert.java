package com.kaadas.iot.record.convert.lock;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.lock.LockedOutOperating;
import com.kaadas.iot.record.LockOutState;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class LockedOutOperatingConvert implements OptRecordConvert<LockedOutOperating.LockedOutOperatingPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.LOCKED_OUT_OPERATING;
  }

  @Override
  public IotEvent<LockedOutOperating.LockedOutOperatingPayload> toIotEvent(WifiOperationRecord oldRecord) {
    LockedOutOperating lockedOutOperating = new LockedOutOperating();
    setIotEvent(lockedOutOperating,oldRecord);
    LockedOutOperating.LockedOutOperatingPayload payload = new LockedOutOperating.LockedOutOperatingPayload();
    payload.setLockedOutState(LockOutState.LOCK_OUT_STATE.getState());
    lockedOutOperating.setPayload(payload);
    return lockedOutOperating;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<LockedOutOperating.LockedOutOperatingPayload> iotEvent) {
    return createOldRecord(iotEvent);
  }

}
