package com.kaadas.iot.event.mode;

import com.kaadas.iot.event.IotMode;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
public class SafeMode extends IotMode {}
