package com.kaadas.iot.event.mqttstate;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@Data
public class OnlinePayload implements EventPayload {
  private MqttState connectState;
  private String ip;
  private String clientid;
  private String userType;

  public OnlinePayload() {
    setConnectState(MqttState.Online);
  }
}
