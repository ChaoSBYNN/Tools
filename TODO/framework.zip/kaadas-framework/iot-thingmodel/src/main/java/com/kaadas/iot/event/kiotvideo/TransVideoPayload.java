package com.kaadas.iot.event.kiotvideo;

import com.kaadas.iot.event.EventPayload;
import lombok.Data;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
@Data
public class TransVideoPayload implements EventPayload {

  private String msg;

  private Integer code;

  public static TransVideoPayload create(Integer code){
    return TransVideoPayload.create(code,null);
  }

  public static TransVideoPayload create(Integer code, String msg){
    TransVideoPayload authPayload = new TransVideoPayload();
    authPayload.setCode(code);
    authPayload.setMsg(msg);
    return authPayload;
  }
}
