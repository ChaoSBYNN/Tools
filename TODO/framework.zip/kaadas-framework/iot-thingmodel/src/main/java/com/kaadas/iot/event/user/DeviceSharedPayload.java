package com.kaadas.iot.event.user;

import com.kaadas.iot.event.EventPayload;

import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class DeviceSharedPayload implements EventPayload {

  private String uid;

  private String userNickname;

  private String shareAccount;

  private String shareUid;

  private String shareUserNickname;

  public String getUid() {
    return uid;
  }

  public void setUid(String uid) {
    this.uid = uid;
  }

  public String getUserNickname() {
    return userNickname;
  }

  public void setUserNickname(String userNickname) {
    this.userNickname = userNickname;
  }

  public String getShareAccount() {
    return shareAccount;
  }

  public void setShareAccount(String shareAccount) {
    this.shareAccount = shareAccount;
  }

  public String getShareUid() {
    return shareUid;
  }

  public void setShareUid(String shareUid) {
    this.shareUid = shareUid;
  }

  public String getShareUserNickname() {
    return shareUserNickname;
  }

  public void setShareUserNickname(String shareUserNickname) {
    this.shareUserNickname = shareUserNickname;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof DeviceSharedPayload)) return false;
    DeviceSharedPayload that = (DeviceSharedPayload) o;
    return getUid().equals(that.getUid()) && getUserNickname().equals(that.getUserNickname()) &&
           getShareAccount().equals(that.getShareAccount()) && getShareUid().equals(that.getShareUid()) &&
           getShareUserNickname().equals(that.getShareUserNickname());
  }

  @Override
  public int hashCode() {
    return Objects.hash(getUid(), getUserNickname(), getShareAccount(), getShareUid(), getShareUserNickname());
  }

  @Override
  public String toString() {
    return "DeviceSharedPayload{" + "uid='" + uid + '\'' + ", userNickname='" + userNickname + '\'' +
           ", shareAccount='" + shareAccount + '\'' + ", shareUid='" + shareUid + '\'' + ", shareUserNickname='" +
           shareUserNickname + '\'' + '}';
  }
}
