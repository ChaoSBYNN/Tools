package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public enum UserType implements IotEventType {

  DEVICE_SHARED_ADDED("DeviceSharedAdded","添加分享用户",IotEvent.Type.Message),
  DEVICE_SHARED_DELETE("DeviceSharedDelete","删除分享用户",IotEvent.Type.Message),
  DEVICE_USER_Added("DeviceUserAdded","添加设备用户",IotEvent.Type.Message),
  DEVICE_USER_DELETE( "DeviceUserDelete","删除设备用户",IotEvent.Type.Message),
  DEVICE_USER_NICK_CHANGED( "DeviceUserNickChanged","修改设备用户昵称",IotEvent.Type.Message),
  ;
  UserType(String id, String name, IotEvent.Type eventType){
    this.id = id;
    this.name = name;
    this.eventType = eventType;
  }

  private String id;
  private String name;
  private IotEvent.Type eventType;

  @Override
  public String getId() {
    return id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public IotEvent.Type getEventType() {
    return eventType;
  }
}