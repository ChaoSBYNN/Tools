package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.AlarmPayload;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2023-02-07
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PirPayload extends AlarmPayload {
  private List<List<List<Integer>>> tracks;

//  @Getter
//  @Setter
//  public static class Track{
//    /** 角度 */
//    private int a;
//    /** 距离 */
//    private int d;
//  }
}
