package com.kaadas.iot.event.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.secret.LockSecret;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-08-11
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class LowBatteryPayload extends AlarmPayload {
  /**
   * 低电量告警时存在，[1=大电池，2=小电池，3=门磁电池] (旧设备无此值，记录只显示低电量告警)
   */
  private Integer batteryType;

}
