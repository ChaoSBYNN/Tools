package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.old.WifiOperationRecord;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
public interface OptRecordConvert<P extends EventPayload> extends RecordConvert<WifiOperationRecord,P> {

  default  void setIotEvent(IotEvent<P> iotEvent, WifiOperationRecord oldRecord){
    IotEventType iotEventType = getIotEventType().iotEventType();
    iotEvent.setId(iotEventType.getId());
    iotEvent.setName(iotEventType.getName());
    iotEvent.setEsn(oldRecord.getWifiSN());
    iotEvent.setTime(oldRecord.getTime());
    iotEvent.setEventType(IotEvent.Type.Message);
  }

  default WifiOperationRecord createOldRecord(IotEvent<P> iotEvent){
    long time = iotEvent.getTime();
    WifiOperationRecord oldRecord = new WifiOperationRecord();
    oldRecord.setWifiSN(iotEvent.getEsn());
    oldRecord.setTime(time);
    oldRecord.setType(getIotEventType().getType());
    //以下时间字段APP有用到
    long recotdTime = time*1000;
    oldRecord.setCreateTime(recotdTime);
    oldRecord.setUpdateTime(recotdTime);
    return oldRecord;
  }

}
