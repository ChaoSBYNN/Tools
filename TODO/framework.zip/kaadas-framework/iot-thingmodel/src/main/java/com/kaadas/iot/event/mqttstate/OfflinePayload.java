package com.kaadas.iot.event.mqttstate;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-27
 * @since 1.0.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OfflinePayload extends OnlinePayload {
  private String reason;

  public OfflinePayload() {
    setConnectState(MqttState.Offline);
  }
}
