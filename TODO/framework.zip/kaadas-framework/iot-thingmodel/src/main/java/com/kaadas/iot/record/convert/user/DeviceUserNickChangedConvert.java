package com.kaadas.iot.record.convert.user;


import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.user.DeviceUserNickChanged;
import com.kaadas.iot.event.user.DeviceUserNickPayload;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.convert.OptRecordConvert;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
@Component
public class DeviceUserNickChangedConvert implements OptRecordConvert<DeviceUserNickPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.DEVICE_USER_NICK_CHANGED;
  }

  @Override
  public IotEvent<DeviceUserNickPayload> toIotEvent(WifiOperationRecord oldRecord) {
    DeviceUserNickChanged deviceUserNickChanged = new DeviceUserNickChanged();
    setIotEvent(deviceUserNickChanged,oldRecord);
    DeviceUserNickPayload payload = new DeviceUserNickPayload();
    payload.setUser(oldRecord.getUser());
    payload.setUserNickname(oldRecord.getUserNickname());
    payload.setOldUserNickname(oldRecord.getOldUserNickname());
    deviceUserNickChanged.setPayload(payload);
    return deviceUserNickChanged;
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<DeviceUserNickPayload> iotEvent) {
    WifiOperationRecord oldRecord = createOldRecord(iotEvent);
    DeviceUserNickPayload payload = iotEvent.getPayload();
    oldRecord.setUser(payload.getUser());
    oldRecord.setUserNickname(payload.getUserNickname());
    oldRecord.setOldUserNickname(payload.getOldUserNickname());
    return oldRecord;
  }
}
