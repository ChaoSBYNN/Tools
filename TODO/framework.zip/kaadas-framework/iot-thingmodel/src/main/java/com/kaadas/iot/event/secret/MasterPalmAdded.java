package com.kaadas.iot.event.secret;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-31
 * @since 1.0.0
 */
public class MasterPalmAdded extends IotEvent<EmptyPayload> {}
