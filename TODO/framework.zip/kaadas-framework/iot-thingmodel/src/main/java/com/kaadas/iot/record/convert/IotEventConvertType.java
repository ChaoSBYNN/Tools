package com.kaadas.iot.record.convert;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-28
 * @since 1.0.0
 */
public interface IotEventConvertType {
  int getType();
  IotEventType iotEventType();
}
