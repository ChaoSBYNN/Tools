package com.kaadas.iot.event.network;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-26
 * @since 1.0.0
 */
public class NetworkResult extends IotEvent<NetworkPayload> {
  public NetworkResult() {
    setName("配网结果");
  }
}
