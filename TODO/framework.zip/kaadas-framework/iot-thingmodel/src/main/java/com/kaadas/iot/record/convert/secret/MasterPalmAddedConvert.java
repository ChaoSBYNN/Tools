package com.kaadas.iot.record.convert.secret;

import com.kaadas.iot.event.EmptyPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.secret.MasterVeinAdded;
import com.kaadas.iot.record.PwdType;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.convert.OptConvertType;
import com.kaadas.iot.record.old.WifiOperationRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-31
 * @since 1.0.0
 */
@Component
public class MasterPalmAddedConvert extends MasterSecretConvertAbstract<EmptyPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return OptConvertType.MASTER_PALM_ADDED;
  }

  @Override
  IotEvent<EmptyPayload> createIotEvent() {
    return new MasterVeinAdded();
  }

  @Override
  public WifiOperationRecord toOldRecord(IotEvent<EmptyPayload> iotEvent) {
    WifiOperationRecord wifiOperationRecord = super.toOldRecord(iotEvent);
    wifiOperationRecord.setPwdType(PwdType.PALM.getType());
    return wifiOperationRecord;
  }
}
