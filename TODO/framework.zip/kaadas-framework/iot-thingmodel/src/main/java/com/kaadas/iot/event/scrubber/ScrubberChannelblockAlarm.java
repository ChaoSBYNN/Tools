package com.kaadas.iot.event.scrubber;

import com.kaadas.iot.event.EventAlarmPayload;
import com.kaadas.iot.event.IotEventAlarm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 洗地机通道阻塞告警
 * @author haungxufeng
 * @date 2023-01-06
 * @since 1.0.0
 */
public class ScrubberChannelblockAlarm extends IotEventAlarm<ScrubberChannelblockAlarm.ChannelblockAlarmPayload> {
  public ScrubberChannelblockAlarm() {
    super();
    setName("通道阻塞报警");
    setEventType(Type.Alarm);
  }

  public ScrubberChannelblockAlarm(ScrubberChannelblockAlarm.ChannelblockAlarmPayload payload) {
    super(payload);
    setName("通道阻塞报警");
    setEventType(Type.Alarm);
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ChannelblockAlarmPayload extends EventAlarmPayload {
    private boolean channelblock;
  }
}
