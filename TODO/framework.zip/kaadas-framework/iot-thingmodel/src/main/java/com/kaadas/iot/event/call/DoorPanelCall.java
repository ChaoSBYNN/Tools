package com.kaadas.iot.event.call;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.user.DeviceSharedPayload;

/**
 * 门内屏呼叫
 *
 * @author liuqinxian
 * @date 2023-4-11
 * @since 1.0.0
 */
public class DoorPanelCall extends IotEvent<DoorPanelCallPayload> {
  public DoorPanelCall() {
  }

  public DoorPanelCall(DoorPanelCallPayload payload) {
    super(payload);
  }
}
