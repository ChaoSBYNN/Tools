package com.kaadas.iot.event.user;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-01
 * @since 1.0.0
 */
public class DeviceSharedAdded extends IotEvent<DeviceSharedPayload> {
  public DeviceSharedAdded() {
  }

  public DeviceSharedAdded(DeviceSharedPayload payload) {
    super(payload);
  }
}
