package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.PirAlarm;
import com.kaadas.iot.event.alarm.PirPayload;
import com.kaadas.iot.record.convert.AlarmConvertTyep;
import com.kaadas.iot.record.convert.IotEventConvertType;
import com.kaadas.iot.record.old.WifiAlarmRecord;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class PirAlarmConvert extends AlarmConvertAbstract<PirPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return AlarmConvertTyep.PIR_ALARM;
  }


  @Override
  IotEvent<PirPayload> createIotEvent() {
    return new PirAlarm();
  }

  @Override
  public IotEvent<PirPayload> toIotEvent(WifiAlarmRecord oldRecord) {
    IotEvent<PirPayload> pirPayloadIotEvent = super.toIotEvent(oldRecord);
    pirPayloadIotEvent.getPayload().setTracks(oldRecord.getTracks());
    return pirPayloadIotEvent;
  }

  @Override
  public WifiAlarmRecord toOldRecord(IotEvent<PirPayload> iotEvent) {
    WifiAlarmRecord wifiAlarmRecord = super.toOldRecord(iotEvent);
    wifiAlarmRecord.setTracks(iotEvent.getPayload().getTracks());
    return wifiAlarmRecord;
  }
}
