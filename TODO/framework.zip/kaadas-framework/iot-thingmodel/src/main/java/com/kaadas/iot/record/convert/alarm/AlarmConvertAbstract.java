package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.record.convert.AlarmRecordConvert;
import com.kaadas.iot.record.old.WifiAlarmRecord;
import com.kaadas.util.StringUtils;

import java.util.Objects;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
public abstract class AlarmConvertAbstract<P extends AlarmPayload> implements AlarmRecordConvert<P> {

  @Override
  public IotEvent<P> toIotEvent(WifiAlarmRecord oldRecord) {
    IotEvent iotEvent = createIotEvent();
    AlarmPayload alarmPayload = createAlarmPayload();
    setIotEvent(iotEvent,oldRecord);
    setAlarmPayload(alarmPayload,oldRecord);
    iotEvent.setPayload(alarmPayload);
    return iotEvent;
  }

  @Override
  public WifiAlarmRecord toOldRecord(IotEvent<P> iotEvent) {
    WifiAlarmRecord oldRecord = createOldAlarmRecord(iotEvent);
    P payload = iotEvent.getPayload();
    if (Objects.isNull(payload)){
      return oldRecord;
    }
    oldRecord.setEventId(payload.getEventId());
    oldRecord.setClusterID(payload.getClusterID());
    oldRecord.setFileDate(payload.getFileDate());
    oldRecord.setFileName(payload.getFileName());
    oldRecord.setOffsetTime(payload.getOffsetTime());
    oldRecord.setThumbUrl(payload.getThumbnail());
    oldRecord.setThumbState(payload.getThumbState());

    Long videoStartTime = payload.getVideoStartTime();
    Long videoEndTime = payload.getVideoEndTime();
    oldRecord.setStartTime(videoStartTime);
    if (Objects.nonNull(videoEndTime)){
      oldRecord.setVedioTime((int) (videoEndTime - videoStartTime));
    }
    Integer height = payload.getHeight();
    if (Objects.nonNull(height)){
      oldRecord.setHeight(height.toString());
    }
    Integer width = payload.getWidth();
    if (Objects.nonNull(width)){
      oldRecord.setWidth(width.toString());
    }
    return oldRecord;
  }

  abstract IotEvent<P> createIotEvent();

   AlarmPayload createAlarmPayload(){
    return  new AlarmPayload();
  }

  protected void setAlarmPayload(AlarmPayload alarmPayload,WifiAlarmRecord oldRecord){
    alarmPayload.setAlarmCode(oldRecord.getType());
    alarmPayload.setEventId(oldRecord.getEventId());
    alarmPayload.setClusterID(oldRecord.getClusterID());
    alarmPayload.setFileDate(oldRecord.getFileDate());
    alarmPayload.setFileName(oldRecord.getFileName());
    alarmPayload.setOffsetTime(oldRecord.getOffsetTime());
    alarmPayload.setThumbnail(oldRecord.getThumbUrl());
    alarmPayload.setThumbState(oldRecord.getThumbState());
    alarmPayload.setTxEventId(oldRecord.getType());
    Long startTime = oldRecord.getStartTime();
    if(Objects.nonNull(startTime)){
      //如果是时间戳毫秒/转成时间戳秒
      String timeStr = startTime+"";
      if (timeStr.length()==13){
        startTime = startTime/1000;
      }
    }
    Integer vedioTime = oldRecord.getVedioTime();
    alarmPayload.setVideoStartTime(startTime);
    if (Objects.nonNull(vedioTime)){
      alarmPayload.setVideoEndTime(startTime+vedioTime);
    }
    String height = oldRecord.getHeight();
    if (StringUtils.isNotBlank(height)){
      alarmPayload.setHeight(Integer.valueOf(height));
    }
    String width = oldRecord.getWidth();
    if (StringUtils.isNotBlank(height)){
      alarmPayload.setWidth(Integer.valueOf(width));
    }
  }

}
