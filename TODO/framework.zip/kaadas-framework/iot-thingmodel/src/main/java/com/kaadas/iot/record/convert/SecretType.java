package com.kaadas.iot.record.convert;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-02
 * @since 1.0.0
 */
public enum SecretType implements IotEventType {

  ADDED_SECRET("AddedSecret","添加密钥",IotEvent.Type.Message),
  DELETED_SECRET("DeletedSecret","删除密钥",IotEvent.Type.Message),
  MASTER_PASSWORD_CHANGED( "MasterPasswordChanged","修改管理员密码",IotEvent.Type.Message),
  MASTER_FINGERPRINT_CHANGED( "MasterFingerprintChanged","修改管理员指纹",IotEvent.Type.Message),
  MASTER_FINGERPRINT_ADDED("MasterFingerprintAdded","添加管理员指纹",IotEvent.Type.Message),
  MASTER_VEIN_CHANGED("MasterVeinChanged","修改管理员指静脉",IotEvent.Type.Message),
  MASTER_VEIN_ADDED("MasterVeinAdded","添加管理员指静脉",IotEvent.Type.Message),
  MASTER_PALM_CHANGED("MasterPalmChanged","修改管理员掌静脉",IotEvent.Type.Message),
  MASTER_PALM_ADDED("MasterPalmAdded","添加管理员掌静脉",IotEvent.Type.Message),
  SECRET_NICKNAME_CHANGED("SecretNicknameChanged","修改密钥昵称",IotEvent.Type.Message),
  ;
  SecretType(String id, String name, IotEvent.Type eventType){
    this.id = id;
    this.name = name;
    this.eventType = eventType;
  }

  private String id;
  private String name;
  private IotEvent.Type eventType;

  @Override
  public String getId() {
    return id;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public IotEvent.Type getEventType() {
    return eventType;
  }
}
