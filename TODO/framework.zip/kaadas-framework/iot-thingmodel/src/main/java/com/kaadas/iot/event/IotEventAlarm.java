package com.kaadas.iot.event;

/**
 * V3mqtt通讯协事件告警
 * @author haungxufeng
 * @date 2023-01-06
 * @since 1.0.0
 */
public abstract class IotEventAlarm<T extends EventAlarmPayload> extends IotEvent<T> {
  public IotEventAlarm() {
    super();
    this.setEventType(Type.Alarm);
  }

  public IotEventAlarm(T payload) {
    this();
    setPayload(payload);
  }
}
