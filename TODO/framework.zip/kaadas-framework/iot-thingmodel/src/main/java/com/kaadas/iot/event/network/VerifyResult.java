package com.kaadas.iot.event.network;

import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-26
 * @since 1.0.0
 */
public class VerifyResult extends IotEvent<NetworkPayload> {
  public VerifyResult() {
    setName("配网Token校验结果");
  }
}
