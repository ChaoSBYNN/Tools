package com.kaadas.iot.ota;

import lombok.Data;

/**
 * TODO
 *
 * @author ZhangDuanFeng
 * @date 2022-07-28
 * @since 1.0.0
 */
@Data
public class IotOta<T> {
  protected String esn;
  protected long time;
  protected Integer code;
  protected String errCode;
  protected MsgType msgType;
  protected T payload;

  public enum MsgType {
    OtaNotifyAck,
    OtaResult
  }
}
