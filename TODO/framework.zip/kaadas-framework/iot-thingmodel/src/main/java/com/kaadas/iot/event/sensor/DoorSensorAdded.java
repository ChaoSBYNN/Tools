package com.kaadas.iot.event.sensor;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * 描述
 * 添加门磁
 * @author huangxufeng
 * @date 2023/6/6 9:19
 */
public class DoorSensorAdded extends IotEvent<EventPayload> {
  public DoorSensorAdded() {
    super();
    setName("添加门磁");
  }

  public DoorSensorAdded(EventPayload payload) {
    this();
    setPayload(payload);
  }
}
