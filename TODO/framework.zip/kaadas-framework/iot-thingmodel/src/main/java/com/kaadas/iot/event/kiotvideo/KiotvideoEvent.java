package com.kaadas.iot.event.kiotvideo;

import com.kaadas.iot.event.EventPayload;
import com.kaadas.iot.event.IotEvent;

/**
 * TODO
 *
 * @author huangxufeng
 * @date 2024-01-13
 * @since 1.0.0
 */
public class KiotvideoEvent<T extends EventPayload> extends IotEvent<T> {


  public KiotvideoEvent(String name) {
    super();
    super.setName(name);
  }
}
