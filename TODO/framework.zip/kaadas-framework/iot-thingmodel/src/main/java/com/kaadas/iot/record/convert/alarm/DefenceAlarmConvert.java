package com.kaadas.iot.record.convert.alarm;

import com.kaadas.iot.event.AlarmPayload;
import com.kaadas.iot.event.IotEvent;
import com.kaadas.iot.event.alarm.DefenceAlarm;
import com.kaadas.iot.record.convert.AlarmConvertTyep;
import com.kaadas.iot.record.convert.IotEventConvertType;
import org.springframework.stereotype.Component;
/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-10-27
 * @since 1.0.0
 */
@Component
public class DefenceAlarmConvert extends AlarmConvertAbstract<AlarmPayload> {

  @Override
  public IotEventConvertType getIotEventType() {
    return AlarmConvertTyep.DEFENCE_ALARM;
  }

  @Override
  IotEvent<AlarmPayload> createIotEvent() {
    return new DefenceAlarm();
  }
}
