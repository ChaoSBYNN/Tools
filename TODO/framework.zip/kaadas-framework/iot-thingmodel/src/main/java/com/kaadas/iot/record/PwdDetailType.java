package com.kaadas.iot.record;

import lombok.Getter;

/**
 * TODO
 *
 * @author haungxufeng
 * @date 2022-11-15
 * @since 1.0.0
 */
public enum PwdDetailType {

  /** 时效密码 */ AGING(5),
  /** 周期密码 */ CYCLE(6),
  ;
  PwdDetailType(int type){
    this.type = type;
  }
  @Getter
  private final int type;

}
