package com.kaadas.iot.event.vod;

import com.kaadas.iot.event.EventPayload;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 点播视频中转事件/小程序点播
 * @author huangxufeng
 * @date 2024-01-23
 * @since 1.0.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public final class VodTransVideoPayload implements EventPayload {
  /**
   * 点播用户id
   */
  private String userId;
  /**
   * 文件名称
   */
  private String cloudStorageFile;
  /**
   * 视频开始时间
   */
  private Long videoStartTime;
  /**
   * 视频结束时间
   */
  private Long videoEndTime;
}
